/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for GLR parsing with Bison,
   Copyright (C) 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* This is the parser code for GLR (Generalized LR) parser. */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "glr.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 1

/* Substitute the variable and function names.  */
#define yyparse c_parse
#define yylex   c_lex
#define yyerror c_error
#define yylval  c_lval
#define yychar  c_char
#define yydebug c_debug
#define yynerrs c_nerrs
#define yylloc c_lloc

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NET_TOK = 258,
     STR0_TOK = 259,
     STR1_TOK = 260,
     GATE_TOK = 261,
     STRING_TOK = 262,
     DIGIT_TOK = 263,
     UNDERSCORE_TOK = 264,
     SEM_TOK = 265,
     DOT_TOK = 266,
     LETTER_TOK = 267,
     PLUS_TOK = 268,
     MINUS_TOK = 269,
     COLON_TOK = 270,
     LBRACE_TOK = 271,
     RBRACE_TOK = 272,
     LBRACKET_TOK = 273,
     RBRACKET_TOK = 274,
     AND_TOK = 275,
     OR_TOK = 276,
     EQU_TOK = 277,
     GT_TOK = 278,
     LT_TOK = 279,
     NOT_TOK = 280,
     MULT_TOK = 281,
     PERCENTAL_TOK = 282,
     ENV_TOK = 283,
     PARA_TOK = 284,
     CHAR_TOK = 285,
     AT_TOK = 286,
     DOLLAR_TOK = 287,
     BASE_TOK = 288,
     SN_TOK = 289,
     EXCLAMATION_TOK = 290,
     RRAM_TOK = 291,
     LRAM_TOK = 292,
     PARAMETER_TOK = 293,
     OUTPUT_TOK = 294,
     INOUT_TOK = 295,
     SMALL_TOK = 296,
     MEDIUM_TOK = 297,
     LARGE_TOK = 298,
     VEC_TOK = 299,
     SCALAR_TOK = 300,
     REG_TOK = 301,
     TIME_TOK = 302,
     REAL_TOK = 303,
     EVENT_TOK = 304,
     ASSIGN_TOK = 305,
     DEFPARAM_TOK = 306,
     MODUL_TOK = 307,
     ENDMODUL_TOK = 308,
     MACRO_MODUL_TOK = 309,
     ENDPRIMITIVE_TOK = 310,
     PRIMITIVE_TOK = 311,
     INITIAL_TOK = 312,
     TABLE_TOK = 313,
     ENDTABLE_TOK = 314,
     ALWAYS_TOK = 315,
     TASK_TOK = 316,
     ENDTASK_TOK = 317,
     FUNC_TOK = 318,
     ENDFUNC_TOK = 319,
     IF_TOK = 320,
     CASE_TOK = 321,
     CASEX_TOK = 322,
     CASEZ_TOK = 323,
     FOREVER_TOK = 324,
     REPEAT_TOK = 325,
     FOR_TOK = 326,
     JOIN_TOK = 327,
     WAIT_TOK = 328,
     FORCE_TOK = 329,
     RELEASE_TOK = 330,
     DEASSIGN_TOK = 331,
     DISABLE_TOK = 332,
     WHILE_TOK = 333,
     ELSE_TOK = 334,
     ENDCASE_TOK = 335,
     BEGIN_TOK = 336,
     DEFAULT_TOK = 337,
     FORK_TOK = 338,
     END_TOK = 339,
     SPECIFY_TOK = 340,
     ENDSPECIFY_TOK = 341,
     SPECPARAM_TOK = 342,
     DSETUP_TOK = 343,
     DHOLD_TOK = 344,
     DWIDTH_TOK = 345,
     DPERIOD_TOK = 346,
     DSKEW_TOK = 347,
     DRECOVERY_TOK = 348,
     DSETUPHOLD_TOK = 349,
     POSEDGE_TOK = 350,
     NEGEDGE_TOK = 351,
     EDGE_TOK = 352,
     COMMA_TOK = 353,
     QUESTION_TOK = 354,
     AUTO_TOK = 355,
     INPUT_TOK = 356,
     SIGNED_TOK = 357,
     LOCALPARAM_TOK = 358,
     INTEGER_TOK = 359,
     NOCHANGE_TOK = 360,
     GENERATE_TOK = 361,
     ENDGENERATE_TOK = 362,
     GENVAR_TOK = 363,
     LIBRARY_TOK = 364,
     CONFIG_TOK = 365,
     ENDCONFIG_TOK = 366,
     INCLUDE_TOK = 367,
     PULSEON_DETECT_TOK = 368,
     PULSEONE_EVENT_TOK = 369,
     USE_TOK = 370,
     LIBLIST_TOK = 371,
     INSTANCE_TOK = 372,
     CELL_TOK = 373,
     SHOWCANCEL_TOK = 374,
     NOSHOWCANCEL_TOK = 375,
     REMOVAL_TOK = 376,
     FULLSKEW_TOK = 377,
     TIMESKEW_TOK = 378,
     RECREM_TOK = 379,
     IFNONE_TOK = 380,
     REALTIME_TOK = 381,
     DESIGN_TOK = 382,
     ATL_TOK = 383,
     ATR_TOK = 384,
     OOR_TOK = 385,
     AAND_TOK = 386,
     SNNOT_TOK = 387,
     NOTSN_TOK = 388,
     AAAND_TOK = 389
   };
#endif
/* Tokens.  */
#define NET_TOK 258
#define STR0_TOK 259
#define STR1_TOK 260
#define GATE_TOK 261
#define STRING_TOK 262
#define DIGIT_TOK 263
#define UNDERSCORE_TOK 264
#define SEM_TOK 265
#define DOT_TOK 266
#define LETTER_TOK 267
#define PLUS_TOK 268
#define MINUS_TOK 269
#define COLON_TOK 270
#define LBRACE_TOK 271
#define RBRACE_TOK 272
#define LBRACKET_TOK 273
#define RBRACKET_TOK 274
#define AND_TOK 275
#define OR_TOK 276
#define EQU_TOK 277
#define GT_TOK 278
#define LT_TOK 279
#define NOT_TOK 280
#define MULT_TOK 281
#define PERCENTAL_TOK 282
#define ENV_TOK 283
#define PARA_TOK 284
#define CHAR_TOK 285
#define AT_TOK 286
#define DOLLAR_TOK 287
#define BASE_TOK 288
#define SN_TOK 289
#define EXCLAMATION_TOK 290
#define RRAM_TOK 291
#define LRAM_TOK 292
#define PARAMETER_TOK 293
#define OUTPUT_TOK 294
#define INOUT_TOK 295
#define SMALL_TOK 296
#define MEDIUM_TOK 297
#define LARGE_TOK 298
#define VEC_TOK 299
#define SCALAR_TOK 300
#define REG_TOK 301
#define TIME_TOK 302
#define REAL_TOK 303
#define EVENT_TOK 304
#define ASSIGN_TOK 305
#define DEFPARAM_TOK 306
#define MODUL_TOK 307
#define ENDMODUL_TOK 308
#define MACRO_MODUL_TOK 309
#define ENDPRIMITIVE_TOK 310
#define PRIMITIVE_TOK 311
#define INITIAL_TOK 312
#define TABLE_TOK 313
#define ENDTABLE_TOK 314
#define ALWAYS_TOK 315
#define TASK_TOK 316
#define ENDTASK_TOK 317
#define FUNC_TOK 318
#define ENDFUNC_TOK 319
#define IF_TOK 320
#define CASE_TOK 321
#define CASEX_TOK 322
#define CASEZ_TOK 323
#define FOREVER_TOK 324
#define REPEAT_TOK 325
#define FOR_TOK 326
#define JOIN_TOK 327
#define WAIT_TOK 328
#define FORCE_TOK 329
#define RELEASE_TOK 330
#define DEASSIGN_TOK 331
#define DISABLE_TOK 332
#define WHILE_TOK 333
#define ELSE_TOK 334
#define ENDCASE_TOK 335
#define BEGIN_TOK 336
#define DEFAULT_TOK 337
#define FORK_TOK 338
#define END_TOK 339
#define SPECIFY_TOK 340
#define ENDSPECIFY_TOK 341
#define SPECPARAM_TOK 342
#define DSETUP_TOK 343
#define DHOLD_TOK 344
#define DWIDTH_TOK 345
#define DPERIOD_TOK 346
#define DSKEW_TOK 347
#define DRECOVERY_TOK 348
#define DSETUPHOLD_TOK 349
#define POSEDGE_TOK 350
#define NEGEDGE_TOK 351
#define EDGE_TOK 352
#define COMMA_TOK 353
#define QUESTION_TOK 354
#define AUTO_TOK 355
#define INPUT_TOK 356
#define SIGNED_TOK 357
#define LOCALPARAM_TOK 358
#define INTEGER_TOK 359
#define NOCHANGE_TOK 360
#define GENERATE_TOK 361
#define ENDGENERATE_TOK 362
#define GENVAR_TOK 363
#define LIBRARY_TOK 364
#define CONFIG_TOK 365
#define ENDCONFIG_TOK 366
#define INCLUDE_TOK 367
#define PULSEON_DETECT_TOK 368
#define PULSEONE_EVENT_TOK 369
#define USE_TOK 370
#define LIBLIST_TOK 371
#define INSTANCE_TOK 372
#define CELL_TOK 373
#define SHOWCANCEL_TOK 374
#define NOSHOWCANCEL_TOK 375
#define REMOVAL_TOK 376
#define FULLSKEW_TOK 377
#define TIMESKEW_TOK 378
#define RECREM_TOK 379
#define IFNONE_TOK 380
#define REALTIME_TOK 381
#define DESIGN_TOK 382
#define ATL_TOK 383
#define ATR_TOK 384
#define OOR_TOK 385
#define AAND_TOK 386
#define SNNOT_TOK 387
#define NOTSN_TOK 388
#define AAAND_TOK 389




/* Copy the first part of user declarations.  */
#line 33 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "verilogdocgen.h"
#include "membergroup.h"
//#include "verilogparser.hpp"
#include "vhdldocgen.h"
#include "doxygen.h"
#include "searchindex.h"
#include "verilogscanner.h"
#include "commentscan.h"

#define YYMAXDEPTH 15000

static MyParserConv* myconv=0;

static int CurrState;
static bool generateItem=false;
static int          currVerilogType;
static Entry*       current=0;
static Entry*		current_rootVerilog  ;
static Entry*		currentVerilog=0  ;
static Entry*       currentFunctionVerilog=0;
static Entry*       lastModule=0;

static Entry        prevDocEntryVerilog;

static bool         parseCode=FALSE; 

static QCString     currVerilogClass;
static QCString     identVerilog; // last written word
static QCString     currVerilogInst;
static QCString     prevName; // stores the last parsed word

int c_lex (void);
void c_error (char const *);


// functions for  verilog parser ---------------------

static void parseString();
static void writeDigit();
static void initVerilogParser();
static void parseModule();
static void parseFunction(Entry* e);
static void parseReg(Entry* e);
static void parsePortDir(Entry* e,int type);
static void parseParam(Entry* e);
static void parseListOfPorts();
static void parseAlways(bool b=false);
static void parseModuleInst(QCString& first,QCString& sec);


bool findExtendsComponent(QList<BaseInfo> *extend,QCString& compName);
void addSubEntry(Entry* root, Entry* e);


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 92 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
typedef union YYSTYPE {
	int itype;	/* for count */
	char ctype;	/* for char */
	char cstr[1024];
	} YYSTYPE;
/* Line 186 of glr.c.  */
#line 413 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.cpp"
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{

  int first_line;
  int first_column;
  int last_line;
  int last_column;

} YYLTYPE;
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

/* Default (constant) value used for initialization for null
   right-hand sides.  Unlike the standard yacc.c template,
   here we set the default value of $$ to a zeroed-out value.
   Since the default value is undefined, this behavior is
   technically correct. */
static YYSTYPE yyval_default;

/* Copy the second part of user declarations.  */


/* Line 217 of glr.c.  */
#line 443 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.cpp"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

#ifndef YYFREE
# define YYFREE free
#endif
#ifndef YYMALLOC
# define YYMALLOC malloc
#endif
#ifndef YYREALLOC
# define YYREALLOC realloc
#endif

#define YYSIZEMAX ((size_t) -1)

#ifdef __cplusplus
   typedef bool yybool;
#else
   typedef unsigned char yybool;
#endif
#define yytrue 1
#define yyfalse 0

#ifndef YYSETJMP
# include <setjmp.h>
# define YYJMP_BUF jmp_buf
# define YYSETJMP(env) setjmp (env)
# define YYLONGJMP(env, val) longjmp (env, val)
#endif

/*-----------------.
| GCC extensions.  |
`-----------------*/

#ifndef __attribute__
/* This feature is available in gcc versions 2.5 and later.  */
# if (!defined (__GNUC__) || __GNUC__ < 2 \
      || (__GNUC__ == 2 && __GNUC_MINOR__ < 5) || __STRICT_ANSI__)
#  define __attribute__(Spec) /* empty */
# endif
#endif

#define YYOPTIONAL_LOC(Name) Name

#ifndef YYASSERT
# define YYASSERT(condition) ((void) ((condition) || (abort (), 0)))
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  14
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   4839

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  135
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  319
/* YYNRULES -- Number of rules. */
#define YYNRULES  795
/* YYNRULES -- Number of states. */
#define YYNSTATES  1742
/* YYMAXRHS -- Maximum number of symbols on right-hand side of rule. */
#define YYMAXRHS 25
/* YYMAXLEFT -- Maximum number of symbols to the left of a handle
   accessed by $0, $-1, etc., in any rule. */
#define YYMAXLEFT 0

/* YYTRANSLATE(X) -- Bison symbol number corresponding to X.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   389

#define YYTRANSLATE(YYX)						\
  ((YYX <= 0) ? YYEOF :							\
   (unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short int yyprhs[] =
{
       0,     0,     3,     5,     6,     9,    12,    14,    16,    18,
      20,    22,    25,    27,    29,    35,    39,    46,    52,    56,
      60,    62,    65,    69,    73,    77,    81,    85,    87,    90,
      93,    96,    98,   101,   105,   106,   109,   111,   113,   115,
     121,   126,   133,   140,   147,   154,   161,   169,   177,   185,
     187,   189,   191,   194,   195,   198,   200,   203,   204,   210,
     214,   215,   219,   220,   226,   227,   232,   233,   238,   242,
     246,   248,   252,   254,   259,   265,   267,   271,   275,   277,
     279,   281,   286,   291,   294,   297,   300,   303,   305,   308,
     312,   315,   318,   321,   324,   327,   330,   333,   336,   339,
     342,   345,   348,   351,   353,   355,   357,   359,   361,   363,
     365,   367,   369,   371,   372,   377,   381,   382,   388,   389,
     395,   396,   401,   402,   408,   409,   416,   420,   421,   426,
     427,   433,   434,   441,   442,   448,   449,   455,   459,   464,
     468,   472,   473,   479,   480,   487,   493,   500,   501,   507,
     508,   515,   521,   528,   529,   534,   535,   539,   540,   543,
     548,   552,   558,   563,   565,   567,   569,   571,   573,   575,
     578,   581,   584,   586,   590,   594,   598,   602,   606,   610,
     617,   624,   632,   640,   649,   657,   665,   673,   682,   690,
     694,   695,   697,   699,   701,   705,   709,   710,   715,   719,
     725,   730,   734,   735,   740,   744,   746,   749,   755,   761,
     765,   769,   773,   777,   782,   785,   787,   791,   793,   795,
     797,   799,   801,   805,   808,   813,   815,   819,   821,   825,
     827,   829,   833,   835,   839,   842,   844,   846,   850,   852,
     856,   860,   864,   868,   874,   880,   890,   903,   915,   919,
     921,   922,   924,   926,   928,   930,   932,   933,   935,   936,
     938,   940,   943,   945,   948,   951,   955,   963,   970,   981,
     991,   995,   997,  1000,  1002,  1005,  1007,  1009,  1012,  1014,
    1018,  1020,  1026,  1030,  1035,  1042,  1050,  1051,  1053,  1054,
    1056,  1057,  1059,  1063,  1067,  1071,  1075,  1077,  1081,  1086,
    1092,  1096,  1100,  1107,  1115,  1121,  1125,  1127,  1129,  1131,
    1133,  1136,  1139,  1142,  1145,  1148,  1151,  1154,  1157,  1162,
    1168,  1172,  1174,  1178,  1180,  1183,  1188,  1192,  1197,  1203,
    1207,  1211,  1213,  1217,  1219,  1223,  1230,  1236,  1241,  1245,
    1248,  1250,  1252,  1254,  1255,  1256,  1263,  1264,  1269,  1271,
    1275,  1280,  1286,  1288,  1290,  1292,  1296,  1298,  1300,  1304,
    1310,  1315,  1320,  1324,  1327,  1329,  1331,  1333,  1337,  1340,
    1342,  1346,  1349,  1350,  1355,  1359,  1361,  1364,  1366,  1368,
    1370,  1372,  1374,  1376,  1378,  1384,  1392,  1399,  1401,  1405,
    1409,  1413,  1416,  1430,  1434,  1440,  1444,  1448,  1454,  1465,
    1476,  1478,  1480,  1484,  1488,  1490,  1494,  1498,  1500,  1503,
    1506,  1509,  1512,  1515,  1519,  1524,  1531,  1535,  1539,  1543,
    1547,  1551,  1553,  1557,  1561,  1566,  1568,  1571,  1576,  1583,
    1589,  1593,  1595,  1597,  1599,  1602,  1605,  1609,  1614,  1619,
    1621,  1623,  1625,  1627,  1629,  1631,  1633,  1635,  1641,  1646,
    1650,  1652,  1656,  1663,  1669,  1671,  1677,  1682,  1686,  1691,
    1693,  1697,  1701,  1704,  1708,  1709,  1713,  1717,  1722,  1726,
    1730,  1733,  1739,  1744,  1749,  1752,  1755,  1758,  1761,  1764,
    1768,  1770,  1773,  1777,  1784,  1790,  1795,  1798,  1800,  1803,
    1807,  1811,  1818,  1824,  1827,  1832,  1836,  1837,  1842,  1848,
    1853,  1856,  1860,  1864,  1867,  1869,  1872,  1876,  1879,  1882,
    1885,  1888,  1891,  1895,  1898,  1902,  1905,  1908,  1911,  1914,
    1916,  1918,  1922,  1925,  1928,  1931,  1934,  1937,  1940,  1942,
    1945,  1948,  1953,  1955,  1957,  1958,  1965,  1969,  1972,  1977,
    1980,  1985,  1989,  1994,  1996,  1999,  2002,  2004,  2008,  2012,
    2015,  2021,  2027,  2035,  2043,  2049,  2057,  2064,  2071,  2078,
    2082,  2089,  2093,  2095,  2098,  2102,  2106,  2109,  2112,  2118,
    2124,  2134,  2137,  2143,  2149,  2159,  2165,  2171,  2174,  2176,
    2180,  2183,  2185,  2189,  2192,  2196,  2198,  2201,  2203,  2205,
    2207,  2209,  2211,  2215,  2219,  2223,  2227,  2231,  2235,  2238,
    2241,  2244,  2248,  2255,  2261,  2268,  2270,  2274,  2276,  2280,
    2284,  2286,  2291,  2296,  2298,  2302,  2304,  2310,  2318,  2332,
    2358,  2360,  2364,  2368,  2375,  2381,  2392,  2402,  2408,  2416,
    2418,  2420,  2422,  2428,  2434,  2437,  2439,  2441,  2443,  2445,
    2447,  2449,  2451,  2453,  2455,  2457,  2459,  2461,  2463,  2475,
    2485,  2497,  2507,  2521,  2533,  2545,  2555,  2560,  2572,  2582,
    2586,  2600,  2612,  2624,  2634,  2646,  2656,  2668,  2678,  2690,
    2704,  2716,  2724,  2732,  2742,  2744,  2748,  2750,  2752,  2754,
    2756,  2761,  2764,  2768,  2770,  2772,  2774,  2776,  2778,  2783,
    2786,  2789,  2792,  2795,  2797,  2801,  2803,  2805,  2809,  2816,
    2820,  2822,  2826,  2831,  2836,  2840,  2842,  2844,  2848,  2853,
    2857,  2862,  2864,  2868,  2873,  2878,  2880,  2884,  2887,  2892,
    2898,  2900,  2903,  2907,  2909,  2911,  2913,  2915,  2918,  2922,
    2924,  2928,  2933,  2939,  2941,  2947,  2949,  2951,  2953,  2955,
    2957,  2959,  2961,  2964,  2966,  2968,  2971,  2973,  2975,  2977,
    2979,  2982,  2986,  2989,  2993,  2995,  2997,  2999,  3001,  3004,
    3007,  3010,  3013,  3015,  3017,  3019,  3021,  3023,  3025,  3027,
    3029,  3032,  3036,  3040,  3045,  3048,  3050,  3052,  3054,  3056,
    3058,  3060,  3063,  3067,  3071,  3072,  3076,  3080,  3082,  3086,
    3090,  3092,  3094,  3098,  3100,  3102
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short int yyrhs[] =
{
     136,     0,    -1,   137,    -1,    -1,   138,   154,    -1,   137,
     154,    -1,   178,    -1,   140,    -1,   141,    -1,   143,    -1,
     144,    -1,   109,    10,    -1,   451,    -1,     7,    -1,   112,
      23,   142,    24,    10,    -1,   112,     1,    10,    -1,   110,
     451,    10,   145,   146,   111,    -1,   110,   451,    10,   145,
     111,    -1,   127,   148,    10,    -1,   127,     1,    10,    -1,
     147,    -1,   146,   147,    -1,    82,   151,    10,    -1,   149,
     151,    10,    -1,   149,   152,    10,    -1,   150,   151,    10,
      -1,   150,   152,    10,    -1,   451,    -1,   148,   451,    -1,
     117,   451,    -1,   118,   451,    -1,   116,    -1,   116,   148,
      -1,   115,   451,   153,    -1,    -1,    15,   110,    -1,   155,
      -1,   308,    -1,   139,    -1,   448,   158,    10,   161,   159,
      -1,   448,   158,    10,   159,    -1,   448,   158,   162,    10,
     161,   159,    -1,   448,   158,   168,    10,   161,   159,    -1,
     448,   158,   170,    10,   161,   159,    -1,   448,   158,   170,
      10,     1,   159,    -1,   448,   158,   168,    10,     1,   159,
      -1,   448,   158,    16,    17,    10,   161,   159,    -1,   448,
     158,   162,   168,    10,   161,   159,    -1,   448,   158,   162,
     170,    10,   161,   159,    -1,   452,    -1,    52,    -1,    54,
      -1,   157,   156,    -1,    -1,   160,    53,    -1,   177,    -1,
     161,   177,    -1,    -1,    29,    16,   163,   164,    17,    -1,
      29,     1,    17,    -1,    -1,    38,   165,   239,    -1,    -1,
     164,    98,    38,   166,   239,    -1,    -1,   164,    98,   167,
     239,    -1,    -1,    16,   169,   171,    17,    -1,    16,     1,
      17,    -1,    16,   256,    17,    -1,   172,    -1,   171,    98,
     172,    -1,   173,    -1,    11,   173,    16,    17,    -1,    11,
     173,    16,   173,    17,    -1,   175,    -1,    37,   174,    36,
      -1,   174,    98,   175,    -1,   175,    -1,   452,    -1,     8,
      -1,   452,    18,   436,    19,    -1,   452,    18,   432,    19,
      -1,   448,   195,    -1,   448,   198,    -1,   448,   201,    -1,
       1,    10,    -1,   178,    -1,   176,    10,    -1,   176,     1,
      10,    -1,   448,   296,    -1,   448,   182,    -1,   448,   188,
      -1,   448,   376,    -1,   448,   194,    -1,   448,   179,    -1,
     448,   180,    -1,   448,   334,    -1,   448,   270,    -1,   448,
     330,    -1,   448,   277,    -1,   448,   337,    -1,   448,   338,
      -1,   211,    -1,   217,    -1,   210,    -1,   214,    -1,   218,
      -1,   215,    -1,   208,    -1,   209,    -1,   251,    -1,   243,
      -1,    -1,    51,   181,   233,    10,    -1,    51,     1,    10,
      -1,    -1,   103,   242,   183,   233,    10,    -1,    -1,   103,
     265,   184,   233,    10,    -1,    -1,   103,   185,   233,    10,
      -1,    -1,   103,   444,   186,   233,    10,    -1,    -1,   103,
     444,   242,   187,   233,    10,    -1,   103,     1,    10,    -1,
      -1,    38,   189,   233,    10,    -1,    -1,    38,   265,   190,
     233,    10,    -1,    -1,    38,   444,   242,   191,   233,    10,
      -1,    -1,    38,   242,   192,   233,    10,    -1,    -1,    38,
     444,   193,   233,    10,    -1,    38,     1,    10,    -1,    87,
     242,   236,    10,    -1,    87,   236,    10,    -1,    87,     1,
      10,    -1,    -1,    40,   247,   260,   196,   452,    -1,    -1,
      40,   207,   247,   260,   197,   452,    -1,   195,    98,   247,
     260,   452,    -1,   195,    98,   207,   247,   260,   452,    -1,
      -1,   101,   247,   260,   199,   452,    -1,    -1,   101,   207,
     247,   260,   200,   452,    -1,   198,    98,   247,   260,   452,
      -1,   198,    98,   207,   247,   260,   452,    -1,    -1,    39,
     206,   202,   452,    -1,    -1,    39,   203,   452,    -1,    -1,
      39,   204,    -1,   201,    98,    39,   336,    -1,   201,    98,
     452,    -1,   201,    98,    39,   206,   452,    -1,   201,    98,
      39,   452,    -1,    47,    -1,   104,    -1,   207,    -1,   242,
      -1,   444,    -1,    46,    -1,   206,   102,    -1,   206,   242,
      -1,   206,   205,    -1,     3,    -1,    49,   227,    10,    -1,
      49,     1,    10,    -1,   108,   230,    10,    -1,   108,     1,
      10,    -1,   104,   237,    10,    -1,   104,     1,    10,    -1,
       3,   212,   247,   260,   232,    10,    -1,     3,   212,   247,
     260,   231,    10,    -1,     3,   212,   247,   260,   223,   231,
      10,    -1,     3,   212,   247,   260,   223,   232,    10,    -1,
       3,   221,   212,   247,   260,   223,   231,    10,    -1,     3,
     221,   212,   247,   260,   231,    10,    -1,     3,   221,   212,
     247,   260,   232,    10,    -1,     3,   222,   212,   247,   260,
     232,    10,    -1,     3,   222,   212,   247,   260,   223,   232,
      10,    -1,     3,   222,   212,   247,   260,   231,    10,    -1,
       3,     1,    10,    -1,    -1,   213,    -1,    44,    -1,    45,
      -1,    48,   237,    10,    -1,    48,     1,    10,    -1,    -1,
     126,   216,   237,    10,    -1,   126,     1,    10,    -1,    46,
     247,   242,   237,    10,    -1,    46,   247,   237,    10,    -1,
      46,     1,    10,    -1,    -1,    47,   219,   237,    10,    -1,
      47,     1,    10,    -1,   241,    -1,   220,   241,    -1,    16,
       4,    98,     5,    17,    -1,    16,     5,    98,     4,    17,
      -1,    16,     1,    17,    -1,    16,    41,    17,    -1,    16,
      42,    17,    -1,    16,    43,    17,    -1,    29,    16,   224,
      17,    -1,    29,   226,    -1,   226,    -1,   224,    98,   226,
      -1,   223,    -1,   437,    -1,   228,    -1,   229,    -1,   452,
      -1,   228,    98,   452,    -1,   452,   220,    -1,   229,    98,
     452,   220,    -1,   452,    -1,   230,    98,   452,    -1,   238,
      -1,   231,    98,   238,    -1,   227,    -1,   239,    -1,   233,
      98,   239,    -1,   452,    -1,   452,    22,   436,    -1,   452,
     220,    -1,   234,    -1,   240,    -1,   236,    98,   240,    -1,
     235,    -1,   237,    98,   235,    -1,   452,    22,   436,    -1,
     451,    22,   436,    -1,   452,    22,   437,    -1,    18,   431,
      15,   431,    19,    -1,    18,   439,    15,   438,    19,    -1,
      63,   246,   247,   245,   244,    10,   248,   355,    64,    -1,
      63,   246,   247,   245,   244,    16,   250,    17,    10,   253,
     355,    64,    -1,    63,   246,   247,   245,   244,    16,   250,
      17,    10,   355,    64,    -1,    63,     1,    64,    -1,   452,
      -1,    -1,   242,    -1,   104,    -1,    48,    -1,    47,    -1,
     126,    -1,    -1,   100,    -1,    -1,   102,    -1,   249,    -1,
     248,   249,    -1,   266,    -1,   263,    10,    -1,   448,   264,
      -1,   250,    98,   264,    -1,    61,   246,   252,    10,   254,
     352,    62,    -1,    61,   246,   252,    10,   352,    62,    -1,
      61,   246,   252,    16,   256,    17,    10,   253,   352,    62,
      -1,    61,   246,   252,    16,   256,    17,    10,   352,    62,
      -1,    61,     1,    62,    -1,   452,    -1,   253,   266,    -1,
     266,    -1,   254,   255,    -1,   255,    -1,   266,    -1,   257,
      10,    -1,   257,    -1,   256,    98,   257,    -1,   258,    -1,
     262,   247,   259,   260,   452,    -1,   262,   265,   452,    -1,
     258,    98,   265,   452,    -1,   258,    98,   247,   259,   260,
     452,    -1,   258,    98,   262,   247,   259,   260,   452,    -1,
      -1,    46,    -1,    -1,   242,    -1,    -1,     3,    -1,   448,
      40,   261,    -1,   448,    39,   261,    -1,   448,   101,   261,
      -1,   262,    98,   452,    -1,   264,    -1,   263,    98,   264,
      -1,   101,   247,   260,   452,    -1,   101,    46,   247,   260,
     452,    -1,   101,   265,   452,    -1,   264,    98,   452,    -1,
     264,    98,   101,   247,   260,   452,    -1,   264,    98,   101,
      46,   247,   260,   452,    -1,   264,    98,   101,   265,   452,
      -1,   101,     1,    10,    -1,    47,    -1,    48,    -1,   126,
      -1,   104,    -1,   448,   267,    -1,   448,   208,    -1,   448,
     210,    -1,   448,   182,    -1,   448,   188,    -1,   448,   214,
      -1,   448,   215,    -1,   448,   218,    -1,    46,   242,   268,
      10,    -1,    46,   444,   242,   268,    10,    -1,    46,   268,
      10,    -1,   269,    -1,   268,    98,   269,    -1,   452,    -1,
     452,   220,    -1,     6,   223,   272,    10,    -1,     6,   272,
      10,    -1,     6,   221,   272,    10,    -1,     6,   221,   223,
     272,    10,    -1,     6,   271,    10,    -1,     6,     1,    10,
      -1,   274,    -1,   271,    98,   274,    -1,   273,    -1,   272,
      98,   273,    -1,   275,    16,   276,    98,   433,    17,    -1,
      16,   276,    98,   433,    17,    -1,   275,    16,   276,    17,
      -1,    16,   276,    17,    -1,   452,   242,    -1,   452,    -1,
     443,    -1,   278,    -1,    -1,    -1,   452,   279,   283,   282,
     280,    10,    -1,    -1,   452,   282,   281,    10,    -1,   289,
      -1,   282,    98,   289,    -1,    29,    16,   284,    17,    -1,
      29,    16,     1,    17,    10,    -1,   285,    -1,   287,    -1,
     286,    -1,   285,    98,   286,    -1,   436,    -1,   288,    -1,
     287,    98,   288,    -1,    11,   452,    16,   436,    17,    -1,
      11,   452,    16,    17,    -1,   290,    16,   291,    17,    -1,
     290,    16,    17,    -1,   452,   260,    -1,   292,    -1,   294,
      -1,   293,    -1,   292,    98,   293,    -1,   448,   436,    -1,
     295,    -1,   294,    98,   295,    -1,   448,   288,    -1,    -1,
     106,   297,   298,   107,    -1,   106,     1,   107,    -1,   300,
      -1,   298,   300,    -1,   300,    -1,    10,    -1,   301,    -1,
     302,    -1,   305,    -1,   307,    -1,   178,    -1,    65,    16,
     436,    17,   299,    -1,    65,    16,   436,    17,   299,    79,
     299,    -1,    66,    16,   436,    17,   303,    80,    -1,   304,
      -1,   303,    98,   304,    -1,   433,    15,   299,    -1,    82,
      15,   299,    -1,    82,   299,    -1,    71,    16,   306,    10,
     436,    10,   306,    17,    81,    15,   452,   298,    84,    -1,
     452,    22,   436,    -1,    81,    15,   452,   298,    84,    -1,
      81,   298,    84,    -1,    81,     1,    84,    -1,    81,    15,
     452,     1,    84,    -1,   448,    56,   309,    16,   310,    17,
      10,   313,   318,    55,    -1,   448,    56,   309,    16,   311,
      17,    10,   313,   318,    55,    -1,   452,    -1,   452,    -1,
     310,    98,   452,    -1,   315,    98,   312,    -1,   316,    -1,
     312,    98,   316,    -1,   312,    98,   452,    -1,   314,    -1,
     313,   314,    -1,   315,    10,    -1,   316,    10,    -1,   317,
      10,    -1,   314,    10,    -1,   448,    39,   452,    -1,   448,
      39,    46,   452,    -1,   448,    39,    46,   452,    22,   436,
      -1,   315,    98,   452,    -1,   448,   101,   452,    -1,   316,
      98,   452,    -1,   448,    46,   452,    -1,   317,    98,   452,
      -1,   319,    -1,    58,   320,    59,    -1,    58,     1,    59,
      -1,   322,    58,   320,    59,    -1,   321,    -1,   320,   321,
      -1,   324,    15,   328,    10,    -1,   324,    15,   326,    15,
     327,    10,    -1,    57,   452,    22,   323,    10,    -1,    57,
       1,    10,    -1,     8,    -1,   325,    -1,   329,    -1,   324,
     325,    -1,   324,   329,    -1,    16,   329,    17,    -1,    16,
     329,   329,    17,    -1,   325,    16,   329,    17,    -1,   329,
      -1,   328,    -1,    14,    -1,   329,    -1,     8,    -1,    99,
      -1,    26,    -1,    12,    -1,   452,   221,   225,   331,    10,
      -1,   452,   221,   331,    10,    -1,   452,   331,    10,    -1,
     332,    -1,   331,    98,   332,    -1,   333,    16,   276,    98,
     433,    17,    -1,    16,   276,    98,   433,    17,    -1,   290,
      -1,    50,   221,   223,   335,    10,    -1,    50,   223,   335,
      10,    -1,    50,   335,    10,    -1,    50,   221,   335,    10,
      -1,   336,    -1,   335,    98,   336,    -1,   443,    22,   436,
      -1,    57,   353,    -1,    57,     1,    84,    -1,    -1,    60,
     339,   353,    -1,   338,     1,    84,    -1,   443,    22,   358,
     436,    -1,   443,    22,   436,    -1,   443,    22,   358,    -1,
     340,     1,    -1,   443,    23,    22,   358,   436,    -1,   443,
      23,    22,   436,    -1,   443,    23,    22,   358,    -1,   341,
       1,    -1,    50,   347,    -1,    76,   443,    -1,    74,   336,
      -1,    75,   443,    -1,   443,    22,   436,    -1,   355,    -1,
     448,    10,    -1,    81,   352,    84,    -1,    81,    15,   452,
     253,   352,    84,    -1,    81,    15,   452,   346,    84,    -1,
      81,   253,   352,    84,    -1,    81,    84,    -1,   355,    -1,
     346,   355,    -1,   443,    22,   436,    -1,    83,   352,    72,
      -1,    83,    15,   452,   253,   352,    72,    -1,    83,    15,
     452,   352,    72,    -1,    83,    72,    -1,    83,    15,     1,
      72,    -1,    83,     1,    72,    -1,    -1,    81,   350,   352,
      84,    -1,    81,   351,   253,   352,    84,    -1,    81,   351,
     352,    84,    -1,    81,    84,    -1,    81,   351,    84,    -1,
      81,     1,    84,    -1,    15,   452,    -1,   353,    -1,   352,
     353,    -1,   448,   340,    10,    -1,   448,   369,    -1,   448,
     367,    -1,   448,   360,    -1,   448,   362,    -1,   448,   373,
      -1,   448,   341,    10,    -1,   448,   348,    -1,   448,   342,
      10,    -1,   448,   365,    -1,   448,   349,    -1,   448,   374,
      -1,   448,   366,    -1,   353,    -1,    10,    -1,   448,   343,
      10,    -1,   448,   356,    -1,   448,   368,    -1,   448,   372,
      -1,   448,   345,    -1,   448,   360,    -1,   448,   374,    -1,
     369,    -1,    29,     8,    -1,    29,    12,    -1,    29,    16,
     437,    17,    -1,   357,    -1,   361,    -1,    -1,    70,    16,
     436,   359,    17,   361,    -1,    77,   452,    10,    -1,    31,
     452,    -1,    31,    16,   364,    17,    -1,    31,    26,    -1,
      31,    16,    26,    17,    -1,    31,   128,    17,    -1,    14,
      24,   452,    10,    -1,   436,    -1,    95,   436,    -1,    96,
     436,    -1,   363,    -1,   364,    98,   363,    -1,   364,     6,
     363,    -1,   358,   354,    -1,    73,    16,   436,    17,   354,
      -1,    65,    16,   436,    17,   354,    -1,    65,    16,   436,
      17,   354,    79,   354,    -1,    65,    16,   436,    17,     1,
      79,   354,    -1,    65,    16,   436,    17,   344,    -1,    65,
      16,   436,    17,   344,    79,   344,    -1,    66,    16,   436,
      17,   370,    80,    -1,    66,    16,   436,    17,     1,    80,
      -1,    68,    16,   436,    17,   370,    80,    -1,    68,     1,
      80,    -1,    67,    16,   436,    17,   370,    80,    -1,    67,
       1,    80,    -1,   371,    -1,   370,   371,    -1,   433,    15,
     354,    -1,    82,    15,   354,    -1,    82,   354,    -1,    69,
     355,    -1,    70,    16,   436,    17,   355,    -1,    78,    16,
     436,    17,   355,    -1,    71,    16,   347,    10,   436,    10,
     347,    17,   355,    -1,    69,   353,    -1,    70,    16,   436,
      17,   353,    -1,    78,    16,   436,    17,   353,    -1,    71,
      16,   347,    10,   436,    10,   347,    17,   353,    -1,   451,
      16,   375,    17,    10,    -1,   451,    16,     1,    17,    10,
      -1,   451,    10,    -1,   436,    -1,   375,    98,   436,    -1,
     375,    98,    -1,    98,    -1,    85,   377,    86,    -1,    85,
      86,    -1,    85,     1,    86,    -1,   378,    -1,   377,   378,
      -1,   194,    -1,   381,    -1,   399,    -1,   379,    -1,   380,
      -1,   113,   385,    10,    -1,   114,   385,    10,    -1,   114,
       1,    10,    -1,   119,   385,    10,    -1,   120,   385,    10,
      -1,   120,     1,    10,    -1,   382,    10,    -1,   391,    10,
      -1,   397,    10,    -1,   383,    22,   388,    -1,    16,   387,
      22,    24,   387,    17,    -1,    16,   384,   386,   385,    17,
      -1,    16,   384,    26,    24,   385,    17,    -1,   387,    -1,
     384,    98,   387,    -1,   384,    -1,   398,    22,    24,    -1,
     398,    26,    24,    -1,   452,    -1,   452,    18,   432,    19,
      -1,   452,    18,   436,    19,    -1,   389,    -1,    16,   389,
      17,    -1,   390,    -1,    16,   390,    98,   390,    17,    -1,
      16,   390,    98,   390,    98,   390,    17,    -1,    16,   390,
      98,   390,    98,   390,    98,   390,    98,   390,    98,   390,
      17,    -1,    16,   390,    98,   390,    98,   390,    98,   390,
      98,   390,    98,   390,    98,   390,    98,   390,    98,   390,
      98,   390,    98,   390,    98,   390,    17,    -1,   437,    -1,
     392,    22,   388,    -1,   393,    22,   388,    -1,    16,   396,
     387,    22,    24,   394,    -1,    16,   387,    22,    24,   394,
      -1,    16,   396,   384,    26,    24,   385,   445,    15,   395,
      17,    -1,    16,   384,    26,    24,   385,   445,    15,   395,
      17,    -1,   387,   445,    15,   395,    17,    -1,    16,   387,
     445,    15,   395,    17,    17,    -1,   436,    -1,    95,    -1,
      96,    -1,    65,    16,   436,    17,   382,    -1,    65,    16,
     436,    17,   391,    -1,   125,   382,    -1,   445,    -1,   403,
      -1,   404,    -1,   405,    -1,   406,    -1,   407,    -1,   408,
      -1,   411,    -1,   410,    -1,   409,    -1,   402,    -1,   400,
      -1,   401,    -1,   122,    16,   415,    98,   416,    98,   414,
      98,   412,    17,    10,    -1,   122,    16,   415,    98,   416,
      98,   414,    17,    10,    -1,   123,    16,   415,    98,   416,
      98,   414,    98,   412,    17,    10,    -1,   123,    16,   415,
      98,   416,    98,   414,    17,    10,    -1,   124,    16,   417,
      98,   417,    98,   414,    98,   414,    98,   412,    17,    10,
      -1,   124,    16,   417,    98,   417,    98,   414,    98,   414,
      17,    10,    -1,    88,    16,   415,    98,   416,    98,   414,
      98,   412,    17,    10,    -1,    88,    16,   415,    98,   416,
      98,   414,    17,    10,    -1,    88,    16,     1,    17,    -1,
      89,    16,   415,    98,   416,    98,   414,    98,   412,    17,
      10,    -1,    89,    16,   415,    98,   416,    98,   414,    17,
      10,    -1,    89,     1,    10,    -1,    94,    16,   417,    98,
     417,    98,   414,    98,   414,    98,   412,    17,    10,    -1,
      94,    16,   417,    98,   417,    98,   414,    98,   414,    17,
      10,    -1,    93,    16,   415,    98,   416,    98,   414,    98,
     412,    17,    10,    -1,    93,    16,   415,    98,   416,    98,
     414,    17,    10,    -1,   121,    16,   415,    98,   416,    98,
     414,    98,   412,    17,    10,    -1,   121,    16,   415,    98,
     416,    98,   414,    17,    10,    -1,    92,    16,   415,    98,
     416,    98,   414,    98,   412,    17,    10,    -1,    92,    16,
     415,    98,   416,    98,   414,    17,    10,    -1,   105,    16,
     417,    98,   417,    98,   437,    98,   437,    17,    10,    -1,
     105,    16,   417,    98,   417,    98,   437,    98,   437,    98,
     412,    17,    10,    -1,    90,    16,   418,    98,   414,    98,
     436,    98,   412,    17,    10,    -1,    90,    16,   418,    98,
     414,    17,    10,    -1,    91,    16,   418,    98,   414,    17,
      10,    -1,    91,    16,   418,    98,   414,    98,   412,    17,
      10,    -1,   413,    -1,   412,    98,   413,    -1,   436,    -1,
     436,    -1,   417,    -1,   417,    -1,   419,   423,   134,   424,
      -1,   419,   423,    -1,   423,   134,   424,    -1,   423,    -1,
     417,    -1,    95,    -1,    96,    -1,   420,    -1,    97,    18,
     422,    19,    -1,     1,    19,    -1,     8,     8,    -1,     8,
      12,    -1,    12,     8,    -1,   421,    -1,   422,    98,   421,
      -1,   387,    -1,   437,    -1,    37,   433,    36,    -1,    37,
     436,    37,   433,    36,    36,    -1,    37,   427,    36,    -1,
     428,    -1,   427,    98,   428,    -1,   452,    18,   432,    19,
      -1,   452,    18,   436,    19,    -1,   452,   430,   432,    -1,
     426,    -1,   452,    -1,    16,   433,    17,    -1,   447,    16,
     433,    17,    -1,    18,   436,    19,    -1,   430,    18,   436,
      19,    -1,   436,    -1,   436,    15,   438,    -1,   436,    13,
      15,   440,    -1,   436,    14,    15,   440,    -1,   436,    -1,
     433,    98,   436,    -1,   451,   430,    -1,   451,    18,   432,
      19,    -1,   451,   430,    18,   432,    19,    -1,   451,    -1,
     451,   429,    -1,    16,   437,    17,    -1,   425,    -1,   446,
      -1,   434,    -1,     7,    -1,   441,   434,    -1,   441,   447,
     434,    -1,   435,    -1,   436,   442,   435,    -1,   436,   442,
     447,   435,    -1,   436,    99,   436,    15,   435,    -1,   436,
      -1,   436,    15,   436,    15,   437,    -1,   436,    -1,   436,
      -1,   436,    -1,    35,    -1,    20,    -1,    25,    -1,    34,
      -1,    34,    20,    -1,   132,    -1,    21,    -1,    34,    21,
      -1,   445,    -1,   133,    -1,    27,    -1,   445,    -1,    22,
      22,    -1,    22,    22,    22,    -1,    35,    22,    -1,    35,
      22,    22,    -1,   131,    -1,   130,    -1,    24,    -1,    23,
      -1,    23,    23,    -1,    23,    22,    -1,    24,    22,    -1,
      24,    24,    -1,    26,    -1,    28,    -1,    25,    -1,    20,
      -1,    21,    -1,    34,    -1,   132,    -1,   133,    -1,    26,
      26,    -1,    23,    23,    23,    -1,    24,    24,    24,    -1,
     452,    18,   432,    19,    -1,   452,   430,    -1,   426,    -1,
     451,    -1,   102,    -1,    14,    -1,    13,    -1,     8,    -1,
     445,     8,    -1,   128,   449,   129,    -1,   128,     1,   129,
      -1,    -1,   128,   449,   129,    -1,   128,     1,   129,    -1,
     450,    -1,   449,    98,   450,    -1,   452,    22,   436,    -1,
     452,    -1,   452,    -1,   451,    11,   452,    -1,   453,    -1,
      12,    -1,    32,   453,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short int yyrline[] =
{
       0,   128,   128,   130,   130,   131,   132,   140,   142,   143,
     144,   147,   150,   151,   154,   155,   161,   162,   166,   167,
     172,   173,   177,   178,   179,   180,   181,   185,   186,   190,
     193,   197,   198,   201,   204,   205,   212,   213,   214,   218,
     219,   220,   222,   223,   224,   225,   226,   227,   228,   233,
     236,   237,   239,   258,   258,   266,   267,   274,   274,   275,
     278,   278,   279,   279,   280,   280,   286,   286,   287,   291,
     295,   296,   299,   300,   301,   304,   305,   308,   309,   312,
     313,   314,   315,   318,   319,   320,   321,   328,   329,   330,
     331,   332,   333,   334,   335,   339,   340,   341,   342,   343,
     344,   345,   346,   349,   350,   351,   352,   353,   354,   355,
     356,   357,   358,   362,   362,   363,   371,   371,   372,   372,
     373,   373,   374,   374,   375,   375,   376,   379,   379,   380,
     380,   381,   381,   382,   382,   383,   383,   384,   387,   388,
     389,   396,   396,   397,   397,   398,   399,   402,   402,   403,
     403,   404,   405,   410,   410,   411,   411,   413,   413,   415,
     416,   417,   418,   426,   427,   431,   432,   433,   434,   435,
     436,   437,   442,   446,   447,   450,   451,   454,   455,   459,
     460,   461,   462,   463,   464,   465,   466,   467,   468,   469,
     473,   474,   478,   479,   482,   483,   485,   485,   486,   489,
     490,   491,   494,   494,   495,   498,   499,   506,   507,   508,
     513,   514,   515,   524,   525,   528,   529,   532,   535,   542,
     543,   546,   547,   551,   552,   556,   557,   560,   561,   564,
     567,   568,   573,   574,   575,   578,   582,   583,   586,   589,
     597,   599,   606,   614,   617,   625,   633,   637,   640,   644,
     657,   658,   659,   660,   661,   662,   666,   667,   670,   671,
     674,   675,   679,   680,   684,   685,   693,   695,   697,   699,
     701,   704,   716,   717,   720,   721,   725,   726,   730,   731,
     736,   740,   745,   749,   754,   759,   767,   768,   770,   771,
     773,   774,   777,   778,   779,   780,   784,   785,   788,   789,
     790,   791,   792,   793,   794,   795,   799,   800,   801,   802,
     809,   810,   811,   812,   813,   814,   815,   816,   819,   820,
     821,   825,   826,   829,   830,   837,   838,   839,   840,   841,
     842,   845,   846,   849,   850,   855,   856,   861,   862,   865,
     866,   874,   881,   884,   885,   884,   886,   886,   889,   890,
     893,   894,   896,   897,   900,   901,   904,   907,   908,   912,
     913,   917,   918,   921,   937,   938,   941,   942,   945,   949,
     950,   953,   963,   963,   964,   967,   968,   972,   973,   977,
     978,   979,   980,   981,   984,   985,   988,   991,   992,   995,
     996,   997,  1001,  1004,  1007,  1008,  1009,  1010,  1018,  1020,
    1025,  1047,  1048,  1050,  1053,  1054,  1055,  1058,  1059,  1062,
    1063,  1064,  1066,  1069,  1070,  1071,  1072,  1075,  1076,  1078,
    1079,  1085,  1089,  1090,  1091,  1094,  1095,  1098,  1099,  1104,
    1105,  1108,  1112,  1113,  1114,  1115,  1118,  1119,  1120,  1124,
    1126,  1127,  1130,  1133,  1134,  1135,  1136,  1144,  1145,  1146,
    1149,  1150,  1153,  1154,  1157,  1165,  1166,  1167,  1168,  1171,
    1172,  1175,  1178,  1179,  1182,  1182,  1192,  1196,  1197,  1198,
    1199,  1202,  1203,  1204,  1205,  1212,  1213,  1214,  1215,  1218,
    1222,  1223,  1231,  1232,  1233,  1234,  1235,  1240,  1241,  1244,
    1247,  1248,  1249,  1250,  1251,  1252,  1257,  1256,  1259,  1260,
    1261,  1262,  1263,  1266,  1275,  1276,  1284,  1285,  1286,  1287,
    1288,  1289,  1290,  1291,  1292,  1293,  1294,  1295,  1296,  1299,
    1300,  1304,  1305,  1306,  1307,  1308,  1309,  1310,  1313,  1319,
    1320,  1321,  1324,  1325,  1326,  1326,  1329,  1332,  1333,  1334,
    1335,  1336,  1339,  1342,  1343,  1344,  1347,  1348,  1349,  1352,
    1354,  1360,  1361,  1362,  1366,  1367,  1374,  1375,  1376,  1377,
    1378,  1379,  1383,  1384,  1388,  1389,  1390,  1397,  1398,  1399,
    1400,  1404,  1405,  1406,  1407,  1415,  1416,  1417,  1420,  1421,
    1422,  1423,  1430,  1431,  1432,  1436,  1437,  1441,  1442,  1443,
    1444,  1445,  1449,  1450,  1451,  1455,  1456,  1457,  1464,  1465,
    1466,  1470,  1475,  1476,  1477,  1480,  1481,  1484,  1487,  1488,
    1498,  1499,  1500,  1504,  1505,  1509,  1510,  1511,  1512,  1513,
    1521,  1524,  1525,  1529,  1530,  1534,  1536,  1542,  1543,  1547,
    1549,  1550,  1554,  1555,  1556,  1560,  1569,  1570,  1571,  1572,
    1573,  1574,  1575,  1576,  1577,  1578,  1579,  1580,  1584,  1585,
    1588,  1589,  1593,  1594,  1598,  1599,  1600,  1603,  1604,  1605,
    1609,  1610,  1613,  1614,  1616,  1617,  1621,  1622,  1625,  1626,
    1629,  1630,  1634,  1635,  1638,  1639,  1642,  1650,  1652,  1655,
    1658,  1659,  1660,  1661,  1664,  1668,  1669,  1670,  1673,  1674,
    1677,  1678,  1679,  1682,  1683,  1686,  1690,  1698,  1699,  1704,
    1706,  1707,  1710,  1711,  1712,  1713,  1714,  1723,  1724,  1732,
    1733,  1738,  1742,  1743,  1744,  1747,  1748,  1756,  1757,  1758,
    1759,  1760,  1761,  1762,  1764,  1768,  1769,  1770,  1771,  1774,
    1775,  1776,  1777,  1780,  1781,  1784,  1786,  1788,  1795,  1796,
    1797,  1798,  1799,  1800,  1801,  1802,  1803,  1804,  1808,  1809,
    1811,  1812,  1813,  1814,  1815,  1816,  1817,  1818,  1819,  1820,
    1821,  1822,  1823,  1824,  1825,  1826,  1827,  1828,  1829,  1830,
    1831,  1832,  1833,  1841,  1842,  1843,  1844,  1850,  1853,  1854,
    1858,  1859,  1870,  1871,  1874,  1875,  1876,  1879,  1880,  1883,
    1884,  1887,  1888,  1892,  1895,  1900
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "NET_TOK", "STR0_TOK", "STR1_TOK",
  "GATE_TOK", "STRING_TOK", "DIGIT_TOK", "UNDERSCORE_TOK", "SEM_TOK",
  "DOT_TOK", "LETTER_TOK", "PLUS_TOK", "MINUS_TOK", "COLON_TOK",
  "LBRACE_TOK", "RBRACE_TOK", "LBRACKET_TOK", "RBRACKET_TOK", "AND_TOK",
  "OR_TOK", "EQU_TOK", "GT_TOK", "LT_TOK", "NOT_TOK", "MULT_TOK",
  "PERCENTAL_TOK", "ENV_TOK", "PARA_TOK", "CHAR_TOK", "AT_TOK",
  "DOLLAR_TOK", "BASE_TOK", "SN_TOK", "EXCLAMATION_TOK", "RRAM_TOK",
  "LRAM_TOK", "PARAMETER_TOK", "OUTPUT_TOK", "INOUT_TOK", "SMALL_TOK",
  "MEDIUM_TOK", "LARGE_TOK", "VEC_TOK", "SCALAR_TOK", "REG_TOK",
  "TIME_TOK", "REAL_TOK", "EVENT_TOK", "ASSIGN_TOK", "DEFPARAM_TOK",
  "MODUL_TOK", "ENDMODUL_TOK", "MACRO_MODUL_TOK", "ENDPRIMITIVE_TOK",
  "PRIMITIVE_TOK", "INITIAL_TOK", "TABLE_TOK", "ENDTABLE_TOK",
  "ALWAYS_TOK", "TASK_TOK", "ENDTASK_TOK", "FUNC_TOK", "ENDFUNC_TOK",
  "IF_TOK", "CASE_TOK", "CASEX_TOK", "CASEZ_TOK", "FOREVER_TOK",
  "REPEAT_TOK", "FOR_TOK", "JOIN_TOK", "WAIT_TOK", "FORCE_TOK",
  "RELEASE_TOK", "DEASSIGN_TOK", "DISABLE_TOK", "WHILE_TOK", "ELSE_TOK",
  "ENDCASE_TOK", "BEGIN_TOK", "DEFAULT_TOK", "FORK_TOK", "END_TOK",
  "SPECIFY_TOK", "ENDSPECIFY_TOK", "SPECPARAM_TOK", "DSETUP_TOK",
  "DHOLD_TOK", "DWIDTH_TOK", "DPERIOD_TOK", "DSKEW_TOK", "DRECOVERY_TOK",
  "DSETUPHOLD_TOK", "POSEDGE_TOK", "NEGEDGE_TOK", "EDGE_TOK", "COMMA_TOK",
  "QUESTION_TOK", "AUTO_TOK", "INPUT_TOK", "SIGNED_TOK", "LOCALPARAM_TOK",
  "INTEGER_TOK", "NOCHANGE_TOK", "GENERATE_TOK", "ENDGENERATE_TOK",
  "GENVAR_TOK", "LIBRARY_TOK", "CONFIG_TOK", "ENDCONFIG_TOK",
  "INCLUDE_TOK", "PULSEON_DETECT_TOK", "PULSEONE_EVENT_TOK", "USE_TOK",
  "LIBLIST_TOK", "INSTANCE_TOK", "CELL_TOK", "SHOWCANCEL_TOK",
  "NOSHOWCANCEL_TOK", "REMOVAL_TOK", "FULLSKEW_TOK", "TIMESKEW_TOK",
  "RECREM_TOK", "IFNONE_TOK", "REALTIME_TOK", "DESIGN_TOK", "ATL_TOK",
  "ATR_TOK", "OOR_TOK", "AAND_TOK", "SNNOT_TOK", "NOTSN_TOK", "AAAND_TOK",
  "$accept", "file", "lines", "@1", "library_text", "library_descriptions",
  "library_declaration", "file_path_spec", "include_statement",
  "config_declaration", "design_statement", "config_rule_statement_list",
  "config_rule_statement", "aidentifier_list", "inst_clause",
  "cell_clause", "liblist_clause", "use_clause", "config", "description",
  "module_declaration", "name_of_module", "module_type", "module_keyword",
  "end_mod", "@2", "module_option", "module_parameter_port_list", "@3",
  "parameter_declaration_list", "@4", "@5", "@6", "list_of_ports", "@7",
  "list_of_port_declarations", "port_list", "port", "port_expression",
  "port_reference_list", "port_reference", "port_declaration",
  "module_item", "module_or_generate_item",
  "module_or_generate_item_declaration", "parameter_override", "@8",
  "local_parameter_declaration", "@9", "@10", "@11", "@12", "@13",
  "parameter_declaration", "@14", "@15", "@16", "@17", "@18",
  "specparam_declaration", "inout_declaration", "@19", "@20",
  "input_declaration", "@21", "@22", "output_declaration", "@23", "@24",
  "@25", "output_var_type", "s_type", "net_type", "event_declaration",
  "genvar_declaration", "integer_declaration", "net_declaration",
  "xscalared", "scalared", "real_declaration", "realtime_declaration",
  "@26", "reg_declaration", "time_declaration", "@27", "dimension_list",
  "drive_strength", "charge_strength", "delay3", "delay_value_list",
  "delay2", "delay_value", "list_of_event_identifiers",
  "list_of_event_lists", "dim_list", "list_of_genvar_identifiers",
  "list_of_net_decl_assignments", "list_of_net_identifiers",
  "list_of_param_assignments", "real_type", "variable_type",
  "list_of_specparam_assignments", "list_of_variable_identifiers",
  "net_decl_assignment", "param_assignment", "specparam_assignment",
  "dimension", "range", "function_declaration", "name_of_function",
  "range_or_type", "automatic", "xsigned",
  "function_item_declaration_list", "function_item_declaration",
  "function_port_list", "task_declaration", "name_of_task",
  "block_item_declaration_list", "task_item_declaration_list",
  "task_item_declaration", "task_port_list", "task_port_item",
  "tf_port_declaration", "xreg", "xrange", "xnettype", "tf_port_dir",
  "tf_input_declaration_list", "tf_input_declaration", "task_port_type",
  "block_item_declaration", "block_reg_declaration",
  "list_of_block_variable_identifiers", "block_variable_type",
  "gate_instantiation", "pull_gate_instance_list",
  "cmos_switch_instance_list", "cmos_switch_instance",
  "pull_gate_instance", "name_of_gate_instance", "output_terminal",
  "module_instantiation", "module_identifier", "@28", "@29", "@30",
  "module_instance_list", "parameter_value_assignment",
  "list_of_parameter_assignments", "ordered_parameter_assignment_list",
  "ordered_parameter_assignment", "named_parameter_assignment_list",
  "named_parameter_assignment", "module_instance", "identifier11",
  "list_of_port_connections", "ordered_port_connection_list",
  "ordered_port_connection", "named_port_connection_list",
  "named_port_connection", "generated_instantiation", "@31",
  "generate_item_list", "generate_item_or_null", "generate_item",
  "generate_conditional_statement", "generate_case_statement",
  "genvar_module_case_item_list", "genvar_case_item",
  "generate_loop_statement", "genvar_assignment", "generate_block",
  "udp_declaration", "name_of_udp", "udp_port_list",
  "udp_declaration_port_list", "udp_input_declaration_list",
  "udp_port_declaration_list", "udp_port_declaration",
  "udp_output_declaration", "udp_input_declaration", "udp_reg_declaration",
  "udp_body", "combinational_body", "combinational_entry_list",
  "combinational_entry", "udp_initial_statement", "init_val",
  "edge_input_list", "edge_indicator", "current_state", "next_state",
  "output_symbol", "level_symbol", "udp_instantiation",
  "udp_instance_list", "udp_instance", "name_of_instance",
  "continuous_assign", "list_of_net_assignments", "net_assignment",
  "initial_construct", "always_construct", "@32", "blocking_assignment",
  "nonblocking_assignment", "procedural_continuous_assignments",
  "function_blocking_assignment", "function_statement_or_null",
  "function_seq_block", "function_statement_list", "variable_assignment",
  "par_block", "seq_block", "@33", "always_label", "statement_list",
  "statement", "statement_or_null", "function_statement",
  "function_case_statement", "delay_control", "delay_or_event_control",
  "@34", "disable_statement", "event_control", "event_trigger",
  "event_expression", "event_expression_list",
  "procedural_timing_control_statement", "wait_statement",
  "conditional_statement", "function_conditional_statement",
  "case_statement", "case_item_list", "case_item",
  "function_loop_statement", "loop_statement", "system_task_enable",
  "expression_list_null", "specify_block", "specify_item_list",
  "specify_item", "pulsestyle_declaration", "showcancelled_declaration",
  "path_declaration", "simple_path_declaration",
  "parallel_path_description", "list_of_path_inputs",
  "list_of_path_outputs", "connection",
  "specify_input_terminal_descriptor", "path_delay_value",
  "list_of_path_delay_expressions", "path_delay_expression",
  "edge_sensitive_path_declaration",
  "parallel_edge_sensitive_path_description",
  "full_edge_sensitive_path_description", "example",
  "data_source_expression", "edge_identifier",
  "state_dependent_path_declaration", "polarity_operator",
  "system_timing_check", "fullskew_timing_check",
  "timingskew_timing_check", "recrem_timing_check", "setup_timing_check",
  "hold_timing_check", "setuphold_timing_check", "recovery_timing_check",
  "removal_timing_check", "skew_timing_check", "nochange_timing_check",
  "width_timing_check", "period_timing_check", "notify_register_list",
  "notify_register", "timing_check_limit", "data_event", "reference_event",
  "timing_check_event", "controlled_timing_check_event",
  "timing_check_event_control", "edge_control_specifier",
  "edge_descriptor", "edge_descriptor_list", "specify_terminal_descriptor",
  "timing_check_condition", "concatenation", "net_concatenation",
  "net_concatenation_value_list", "net_concatenation_value",
  "function_call", "expression_bracket_list",
  "dimension_constant_expression", "range_expression", "expression_list",
  "primary", "unprim", "expression", "mintypemax_expression",
  "lsb_constant_expression", "msb_constant_expression",
  "width_constant_expression", "unary_operator", "binary_operator",
  "net_lvalue", "signed", "pol_op", "number", "attribute_instance11",
  "attribute_instance", "attr_spec_list", "attr_spec", "simple_identifier",
  "identifier", "ident", 0
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned short int yyr1[] =
{
       0,   135,   136,   138,   137,   137,   137,   139,   140,   140,
     140,   141,   142,   142,   143,   143,   144,   144,   145,   145,
     146,   146,   147,   147,   147,   147,   147,   148,   148,   149,
     150,   151,   151,   152,   153,   153,   154,   154,   154,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   156,
     157,   157,   158,   160,   159,   161,   161,   163,   162,   162,
     165,   164,   166,   164,   167,   164,   169,   168,   168,   170,
     171,   171,   172,   172,   172,   173,   173,   174,   174,   175,
     175,   175,   175,   176,   176,   176,   176,   177,   177,   177,
     177,   177,   177,   177,   177,   178,   178,   178,   178,   178,
     178,   178,   178,   179,   179,   179,   179,   179,   179,   179,
     179,   179,   179,   181,   180,   180,   183,   182,   184,   182,
     185,   182,   186,   182,   187,   182,   182,   189,   188,   190,
     188,   191,   188,   192,   188,   193,   188,   188,   194,   194,
     194,   196,   195,   197,   195,   195,   195,   199,   198,   200,
     198,   198,   198,   202,   201,   203,   201,   204,   201,   201,
     201,   201,   201,   205,   205,   206,   206,   206,   206,   206,
     206,   206,   207,   208,   208,   209,   209,   210,   210,   211,
     211,   211,   211,   211,   211,   211,   211,   211,   211,   211,
     212,   212,   213,   213,   214,   214,   216,   215,   215,   217,
     217,   217,   219,   218,   218,   220,   220,   221,   221,   221,
     222,   222,   222,   223,   223,   224,   224,   225,   226,   227,
     227,   228,   228,   229,   229,   230,   230,   231,   231,   232,
     233,   233,   234,   234,   234,   235,   236,   236,   237,   237,
     238,   239,   240,   241,   242,   243,   243,   243,   243,   244,
     245,   245,   245,   245,   245,   245,   246,   246,   247,   247,
     248,   248,   249,   249,   250,   250,   251,   251,   251,   251,
     251,   252,   253,   253,   254,   254,   255,   255,   256,   256,
     257,   258,   258,   258,   258,   258,   259,   259,   260,   260,
     261,   261,   262,   262,   262,   262,   263,   263,   264,   264,
     264,   264,   264,   264,   264,   264,   265,   265,   265,   265,
     266,   266,   266,   266,   266,   266,   266,   266,   267,   267,
     267,   268,   268,   269,   269,   270,   270,   270,   270,   270,
     270,   271,   271,   272,   272,   273,   273,   274,   274,   275,
     275,   276,   277,   279,   280,   278,   281,   278,   282,   282,
     283,   283,   284,   284,   285,   285,   286,   287,   287,   288,
     288,   289,   289,   290,   291,   291,   292,   292,   293,   294,
     294,   295,   297,   296,   296,   298,   298,   299,   299,   300,
     300,   300,   300,   300,   301,   301,   302,   303,   303,   304,
     304,   304,   305,   306,   307,   307,   307,   307,   308,   308,
     309,   310,   310,   311,   312,   312,   312,   313,   313,   314,
     314,   314,   314,   315,   315,   315,   315,   316,   316,   317,
     317,   318,   319,   319,   319,   320,   320,   321,   321,   322,
     322,   323,   324,   324,   324,   324,   325,   325,   325,   326,
     327,   327,   328,   329,   329,   329,   329,   330,   330,   330,
     331,   331,   332,   332,   333,   334,   334,   334,   334,   335,
     335,   336,   337,   337,   339,   338,   338,   340,   340,   340,
     340,   341,   341,   341,   341,   342,   342,   342,   342,   343,
     344,   344,   345,   345,   345,   345,   345,   346,   346,   347,
     348,   348,   348,   348,   348,   348,   350,   349,   349,   349,
     349,   349,   349,   351,   352,   352,   353,   353,   353,   353,
     353,   353,   353,   353,   353,   353,   353,   353,   353,   354,
     354,   355,   355,   355,   355,   355,   355,   355,   356,   357,
     357,   357,   358,   358,   359,   358,   360,   361,   361,   361,
     361,   361,   362,   363,   363,   363,   364,   364,   364,   365,
     366,   367,   367,   367,   368,   368,   369,   369,   369,   369,
     369,   369,   370,   370,   371,   371,   371,   372,   372,   372,
     372,   373,   373,   373,   373,   374,   374,   374,   375,   375,
     375,   375,   376,   376,   376,   377,   377,   378,   378,   378,
     378,   378,   379,   379,   379,   380,   380,   380,   381,   381,
     381,   382,   383,   383,   383,   384,   384,   385,   386,   386,
     387,   387,   387,   388,   388,   389,   389,   389,   389,   389,
     390,   391,   391,   392,   392,   393,   393,   394,   394,   395,
     396,   396,   397,   397,   397,   398,   399,   399,   399,   399,
     399,   399,   399,   399,   399,   399,   399,   399,   400,   400,
     401,   401,   402,   402,   403,   403,   403,   404,   404,   404,
     405,   405,   406,   406,   407,   407,   408,   408,   409,   409,
     410,   410,   411,   411,   412,   412,   413,   414,   415,   416,
     417,   417,   417,   417,   418,   419,   419,   419,   420,   420,
     421,   421,   421,   422,   422,   423,   424,   425,   425,   426,
     427,   427,   428,   428,   428,   428,   428,   429,   429,   430,
     430,   431,   432,   432,   432,   433,   433,   434,   434,   434,
     434,   434,   434,   434,   434,   435,   435,   435,   435,   436,
     436,   436,   436,   437,   437,   438,   439,   440,   441,   441,
     441,   441,   441,   441,   441,   441,   441,   441,   442,   442,
     442,   442,   442,   442,   442,   442,   442,   442,   442,   442,
     442,   442,   442,   442,   442,   442,   442,   442,   442,   442,
     442,   442,   442,   443,   443,   443,   443,   444,   445,   445,
     446,   446,   447,   447,   448,   448,   448,   449,   449,   450,
     450,   451,   451,   452,   453,   453
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     0,     2,     2,     1,     1,     1,     1,
       1,     2,     1,     1,     5,     3,     6,     5,     3,     3,
       1,     2,     3,     3,     3,     3,     3,     1,     2,     2,
       2,     1,     2,     3,     0,     2,     1,     1,     1,     5,
       4,     6,     6,     6,     6,     6,     7,     7,     7,     1,
       1,     1,     2,     0,     2,     1,     2,     0,     5,     3,
       0,     3,     0,     5,     0,     4,     0,     4,     3,     3,
       1,     3,     1,     4,     5,     1,     3,     3,     1,     1,
       1,     4,     4,     2,     2,     2,     2,     1,     2,     3,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     0,     4,     3,     0,     5,     0,     5,
       0,     4,     0,     5,     0,     6,     3,     0,     4,     0,
       5,     0,     6,     0,     5,     0,     5,     3,     4,     3,
       3,     0,     5,     0,     6,     5,     6,     0,     5,     0,
       6,     5,     6,     0,     4,     0,     3,     0,     2,     4,
       3,     5,     4,     1,     1,     1,     1,     1,     1,     2,
       2,     2,     1,     3,     3,     3,     3,     3,     3,     6,
       6,     7,     7,     8,     7,     7,     7,     8,     7,     3,
       0,     1,     1,     1,     3,     3,     0,     4,     3,     5,
       4,     3,     0,     4,     3,     1,     2,     5,     5,     3,
       3,     3,     3,     4,     2,     1,     3,     1,     1,     1,
       1,     1,     3,     2,     4,     1,     3,     1,     3,     1,
       1,     3,     1,     3,     2,     1,     1,     3,     1,     3,
       3,     3,     3,     5,     5,     9,    12,    11,     3,     1,
       0,     1,     1,     1,     1,     1,     0,     1,     0,     1,
       1,     2,     1,     2,     2,     3,     7,     6,    10,     9,
       3,     1,     2,     1,     2,     1,     1,     2,     1,     3,
       1,     5,     3,     4,     6,     7,     0,     1,     0,     1,
       0,     1,     3,     3,     3,     3,     1,     3,     4,     5,
       3,     3,     6,     7,     5,     3,     1,     1,     1,     1,
       2,     2,     2,     2,     2,     2,     2,     2,     4,     5,
       3,     1,     3,     1,     2,     4,     3,     4,     5,     3,
       3,     1,     3,     1,     3,     6,     5,     4,     3,     2,
       1,     1,     1,     0,     0,     6,     0,     4,     1,     3,
       4,     5,     1,     1,     1,     3,     1,     1,     3,     5,
       4,     4,     3,     2,     1,     1,     1,     3,     2,     1,
       3,     2,     0,     4,     3,     1,     2,     1,     1,     1,
       1,     1,     1,     1,     5,     7,     6,     1,     3,     3,
       3,     2,    13,     3,     5,     3,     3,     5,    10,    10,
       1,     1,     3,     3,     1,     3,     3,     1,     2,     2,
       2,     2,     2,     3,     4,     6,     3,     3,     3,     3,
       3,     1,     3,     3,     4,     1,     2,     4,     6,     5,
       3,     1,     1,     1,     2,     2,     3,     4,     4,     1,
       1,     1,     1,     1,     1,     1,     1,     5,     4,     3,
       1,     3,     6,     5,     1,     5,     4,     3,     4,     1,
       3,     3,     2,     3,     0,     3,     3,     4,     3,     3,
       2,     5,     4,     4,     2,     2,     2,     2,     2,     3,
       1,     2,     3,     6,     5,     4,     2,     1,     2,     3,
       3,     6,     5,     2,     4,     3,     0,     4,     5,     4,
       2,     3,     3,     2,     1,     2,     3,     2,     2,     2,
       2,     2,     3,     2,     3,     2,     2,     2,     2,     1,
       1,     3,     2,     2,     2,     2,     2,     2,     1,     2,
       2,     4,     1,     1,     0,     6,     3,     2,     4,     2,
       4,     3,     4,     1,     2,     2,     1,     3,     3,     2,
       5,     5,     7,     7,     5,     7,     6,     6,     6,     3,
       6,     3,     1,     2,     3,     3,     2,     2,     5,     5,
       9,     2,     5,     5,     9,     5,     5,     2,     1,     3,
       2,     1,     3,     2,     3,     1,     2,     1,     1,     1,
       1,     1,     3,     3,     3,     3,     3,     3,     2,     2,
       2,     3,     6,     5,     6,     1,     3,     1,     3,     3,
       1,     4,     4,     1,     3,     1,     5,     7,    13,    25,
       1,     3,     3,     6,     5,    10,     9,     5,     7,     1,
       1,     1,     5,     5,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,    11,     9,
      11,     9,    13,    11,    11,     9,     4,    11,     9,     3,
      13,    11,    11,     9,    11,     9,    11,     9,    11,    13,
      11,     7,     7,     9,     1,     3,     1,     1,     1,     1,
       4,     2,     3,     1,     1,     1,     1,     1,     4,     2,
       2,     2,     2,     1,     3,     1,     1,     3,     6,     3,
       1,     3,     4,     4,     3,     1,     1,     3,     4,     3,
       4,     1,     3,     4,     4,     1,     3,     2,     4,     5,
       1,     2,     3,     1,     1,     1,     1,     2,     3,     1,
       3,     4,     5,     1,     5,     1,     1,     1,     1,     1,
       1,     1,     2,     1,     1,     2,     1,     1,     1,     1,
       2,     3,     2,     3,     1,     1,     1,     1,     2,     2,
       2,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       2,     3,     3,     4,     2,     1,     1,     1,     1,     1,
       1,     2,     3,     3,     0,     3,     3,     1,     3,     3,
       1,     1,     3,     1,     1,     2
};

/* YYDPREC[RULE-NUM] -- Dynamic precedence of rule #RULE-NUM (0 if none). */
static const unsigned char yydprec[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0
};

/* YYMERGER[RULE-NUM] -- Index of merging function for rule #RULE-NUM. */
static const unsigned char yymerger[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0
};

/* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
   doesn't specify something else to do.  Zero means the default is an
   error.  */
static const unsigned short int yydefact[] =
{
     784,     0,     0,   784,   784,     6,     0,     0,   794,     0,
       0,   787,   790,   793,     1,     0,     0,     0,    38,     7,
       8,     9,    10,     5,    36,    37,     0,     4,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   464,     0,     0,
       0,     0,     0,    95,    96,   109,   110,   105,   103,   106,
     108,   104,   107,   112,   111,    98,   100,   342,    99,    97,
     101,     0,   343,   786,   795,     0,   785,     0,    11,     0,
     791,     0,     0,    50,    51,     0,     0,     0,     0,     0,
     192,   193,   258,   191,   190,   190,     0,     0,     0,     0,
       0,     0,     0,   333,   331,     0,   340,     0,   259,     0,
       0,     0,     0,   235,   238,     0,   232,     0,     0,   219,
     220,   221,     0,     0,     0,     0,     0,   459,   775,     0,
     776,   791,     0,     0,     0,   462,     0,   784,     0,   257,
       0,     0,   258,     0,     0,     0,     0,   225,     0,     0,
       0,     0,     0,     0,   346,   348,     0,     0,   450,     0,
     288,   788,   726,   780,   779,   778,     0,   739,   744,   740,
     741,   738,     0,   743,   747,   723,   725,   729,   789,     0,
     746,   724,   720,     0,     0,    15,    13,     0,    12,     0,
     400,    52,    49,     0,     0,     0,     0,     0,     0,   189,
       0,     0,     0,     0,     0,     0,   288,   258,   258,   330,
       0,   341,     0,   214,   733,   218,     0,     0,     0,     0,
       0,   329,     0,   326,     0,     0,     0,   339,   201,     0,
       0,   204,     0,   195,   194,     0,     0,     0,   234,   205,
     174,   173,     0,     0,   223,   705,     0,   700,   706,     0,
       0,     0,   457,     0,     0,     0,   774,   115,     0,   230,
       0,   463,     0,     0,     0,     0,     0,     0,     0,     0,
     784,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   513,   516,   532,   784,   509,   533,
     510,   515,   518,   508,   507,   511,   517,     0,   776,   465,
     270,     0,   271,   248,   250,   178,   177,   176,   175,     0,
     198,     0,   466,     0,     0,   217,     0,   454,     0,     0,
       0,     0,     0,   784,   449,     0,     0,   289,   363,     0,
     742,   745,     0,   715,   765,   766,     0,   757,   756,   764,
     762,   748,   763,   767,     0,     0,   755,   754,   768,   769,
       0,   749,     0,   727,     0,     0,   781,     0,     0,   721,
     717,     0,     0,     0,   792,     0,   784,     0,    40,     0,
       0,     0,    55,    87,     0,     0,     0,     0,     0,   278,
     280,   258,     0,     0,    57,     0,     0,     0,     0,     0,
       0,   209,     0,     0,   210,   211,   212,     0,   288,   288,
     338,     0,     0,   215,   218,     0,     0,     0,   327,     0,
     325,     0,   332,     0,   334,     0,   736,     0,   200,     0,
     203,   239,     0,   711,   233,   206,   222,     0,   699,     0,
       0,     0,     0,   458,   456,   460,   461,     0,     0,     0,
     114,     0,     0,     0,   529,   530,     0,     0,   539,     0,
     537,   475,     0,     0,     0,     0,     0,     0,     0,   571,
       0,     0,     0,   477,   478,   476,     0,     0,     0,     0,
     500,   784,   784,     0,     0,   493,   784,   504,   470,   506,
     474,   512,   514,   520,   519,   549,     0,     0,   577,     0,
     784,   784,   254,   253,   252,   255,   251,     0,   226,   197,
       0,     0,   448,     0,   344,     0,   349,   347,   362,     0,
     364,   366,   365,   369,     0,   451,     0,   722,   697,     0,
       0,   750,   759,   758,   760,   761,   770,   752,     0,   730,
       0,     0,     0,   728,     0,   715,     0,     0,     0,     0,
       0,    27,     0,    17,     0,     0,     0,    20,     0,     0,
      14,     0,     0,     0,     0,   401,    86,    54,    39,    56,
       0,    88,     0,   157,   258,     0,     0,   258,     0,     0,
      91,    92,    94,    83,    84,    85,    90,    93,    68,     0,
      80,     0,     0,     0,    70,    72,    75,    79,    69,   784,
     258,   306,   307,     0,   309,   308,   286,     0,   290,   290,
     290,    59,     0,     0,     0,     0,    53,     0,    53,     0,
       0,     0,     0,   229,     0,     0,   227,   221,     0,     0,
       0,   213,     0,     0,   328,     0,     0,     0,   337,     0,
       0,   199,     0,   224,   701,     0,     0,   704,     0,   455,
     773,   779,   778,     0,   709,     0,   231,   241,     0,     0,
       0,     0,     0,   546,     0,   543,   541,     0,     0,     0,
     561,     0,   559,     0,     0,     0,     0,   536,     0,   502,
     503,   784,   501,   784,   273,   784,     0,   495,     0,   784,
     490,   505,     0,   469,   468,     0,     0,   581,     0,   578,
     784,   275,     0,   276,   784,     0,     0,     0,   249,     0,
     447,     0,     0,     0,   352,   354,   353,   357,   356,     0,
     361,   784,   784,   371,   368,     0,   716,     0,   751,   771,
     772,   753,     0,   731,   783,   782,   707,   718,     0,     0,
       0,    19,    18,    28,    31,     0,    29,    30,    16,    21,
       0,     0,     0,     0,     0,     0,     0,     0,   784,     0,
      89,     0,   777,     0,   133,   129,   135,   172,   168,     0,
     158,   153,   165,   166,   167,   258,   288,     0,     0,     0,
     583,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   587,     0,
     585,   590,   591,   588,     0,     0,     0,     0,     0,     0,
     589,   646,   647,   645,   636,   637,   638,   639,   640,   641,
     644,   643,   642,     0,     0,   236,     0,     0,   258,   288,
       0,     0,   116,   118,   122,     0,   784,   258,   258,     0,
       0,     0,     0,    78,    67,     0,     0,   279,   286,   258,
       0,   295,   287,   288,   282,   291,   293,   292,   294,    60,
       0,    41,     0,     0,    45,    42,    44,    43,   207,   208,
       0,     0,   180,     0,   179,     0,     0,     0,     0,     0,
       0,     0,   336,   216,     0,     0,     0,   735,     0,     0,
     702,   709,     0,     0,   712,   710,   542,   531,   540,   544,
     545,     0,   538,     0,   489,     0,     0,     0,     0,   784,
       0,     0,   784,   784,   497,   272,   784,   499,     0,   313,
     314,   311,   312,   315,   316,   317,   310,   494,   784,   784,
       0,   467,   473,   472,     0,     0,   580,   274,   784,   277,
     267,     0,   784,   784,   453,     0,     0,   350,     0,     0,
     345,   367,     0,   370,     0,     0,     0,   732,   719,   708,
      32,    22,    34,    23,    24,    25,    26,   784,   402,   784,
     403,   404,     0,   416,     0,   413,   137,     0,     0,     0,
       0,   131,   156,   163,   169,   164,     0,   171,   170,   288,
     141,   584,   630,   631,     0,   605,     0,   610,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   607,     0,
     605,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   634,   582,   586,   598,     0,   599,     0,     0,   600,
     140,   139,     0,     0,     0,   288,   147,   126,     0,     0,
       0,     0,   124,   374,     0,     0,     0,     0,   383,   784,
     375,   379,   380,   381,   382,   258,   288,   258,   288,     0,
     160,    46,     0,    76,     0,    71,     0,     0,   288,   286,
     283,     0,     0,    58,    64,    47,    48,   181,   182,   228,
       0,   240,     0,   184,   185,     0,   188,   186,   734,   335,
     244,   243,   737,   713,   714,   548,   547,     0,   551,     0,
     784,     0,   562,     0,     0,     0,   572,     0,     0,   550,
     573,   498,     0,     0,   321,     0,   323,   784,   492,   534,
     471,   576,   575,   579,   266,   784,     0,   784,   260,     0,
     296,   262,     0,     0,     0,   351,     0,   355,   358,   452,
     698,     0,    33,   784,   407,     0,     0,     0,     0,   784,
     784,     0,     0,   414,   128,     0,     0,     0,     0,   154,
     143,     0,     0,     0,     0,     0,   635,     0,     0,   605,
       0,     0,     0,   685,   686,     0,   695,     0,   678,     0,
     687,   683,   659,     0,     0,   684,     0,     0,     0,     0,
       0,     0,   592,   594,   593,   595,   597,   596,     0,     0,
       0,     0,     0,   605,     0,   601,   613,   615,   620,   621,
     622,   237,   138,   242,   149,     0,   121,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   784,   373,   376,   288,
       0,   288,     0,     0,   159,   162,    73,     0,    77,    82,
      81,     0,   288,   281,    61,    62,     0,   183,   187,   784,
     784,   557,   784,   566,   556,   563,   784,   560,   558,   535,
       0,     0,   320,     0,     0,   324,   491,   784,   784,     0,
     258,   288,     0,   261,     0,     0,   263,     0,     0,     0,
       0,   264,   360,     0,    35,     0,     0,   408,     0,   421,
       0,   412,   409,     0,   410,   411,     0,     0,     0,   405,
     406,   418,   417,     0,   134,   130,   136,     0,     0,   142,
       0,   606,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   656,   689,     0,     0,   681,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   615,   620,     0,   148,   117,   119,   123,     0,
       0,     0,     0,     0,   396,     0,   395,     0,   145,     0,
     151,   161,    74,   284,     0,     0,    65,   553,   552,   565,
     564,     0,   318,   322,     0,   784,   269,   305,   288,     0,
     300,   245,     0,   784,     0,     0,     0,   784,     0,   525,
     522,   526,   523,   528,   524,   527,     0,   297,   258,   301,
     784,   265,   359,     0,     0,     0,   443,   446,     0,   445,
     444,     0,   425,     0,   432,   433,   398,     0,   420,   419,
     399,   415,   132,   144,     0,   603,   608,   609,     0,     0,
     624,     0,     0,   611,   612,   632,   633,     0,     0,   693,
       0,     0,   679,     0,   682,   696,     0,     0,   677,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   614,     0,   150,   125,   784,     0,     0,     0,     0,
     784,   146,   152,   285,    63,   784,   319,   268,     0,   298,
       0,   567,     0,     0,     0,     0,     0,   486,   784,   784,
     521,     0,   258,   288,     0,   784,     0,   430,     0,   423,
       0,   422,   426,     0,   434,   435,     0,     0,   604,     0,
       0,   602,     0,     0,     0,   623,   690,   691,   692,   688,
       0,     0,   680,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   378,
     384,   377,   784,     0,   387,     0,     0,   393,   397,   394,
     574,   299,     0,     0,     0,     0,   784,   784,   482,   479,
     288,     0,   304,     0,   247,   431,     0,   436,     0,     0,
       0,   439,     0,   424,     0,     0,     0,     0,   694,     0,
       0,   671,     0,   672,     0,   674,   676,     0,     0,     0,
       0,     0,     0,     0,     0,   616,     0,   784,   784,   391,
     386,     0,   784,     0,   784,   784,     0,   784,   784,   784,
     487,   485,     0,   302,   246,   429,   437,     0,   427,   438,
       0,   629,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   385,   390,   388,   389,
       0,   554,   480,     0,   568,     0,   569,   784,   484,   488,
     303,   441,     0,   440,   442,   626,     0,   627,     0,   655,
       0,   658,     0,     0,   673,   675,   667,     0,   663,     0,
       0,     0,   665,     0,   649,     0,   651,     0,     0,   617,
       0,     0,   784,   481,     0,   483,   428,     0,   625,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   555,     0,   628,   654,   657,
     670,   666,   662,   661,     0,   668,     0,   664,   648,   650,
     653,     0,     0,     0,   784,     0,     0,     0,     0,   784,
     570,   660,   669,   652,     0,   784,     0,   392,   618,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   619
};

/* YYPDEFGOTO[NTERM-NUM]. */
static const short int yydefgoto[] =
{
      -1,     2,     3,     4,    18,    19,    20,   177,    21,    22,
     353,   536,   537,   530,   538,   539,   725,   732,  1122,    23,
      24,   181,    76,    77,   358,   359,   360,   186,   592,   840,
    1052,  1345,  1226,   187,   367,   188,   573,   574,   575,   822,
     576,   361,   362,   363,    43,    44,   123,   899,  1019,  1020,
     811,  1021,  1200,   900,   743,   959,  1138,   958,   960,   778,
     563,  1141,  1288,   564,  1195,  1324,   565,   966,   749,   750,
     967,   751,   752,   901,    46,   902,    48,    82,    83,   903,
     904,   139,    51,   905,   101,   234,    84,    85,    90,   392,
     306,   203,   603,   109,   110,   136,   604,   605,   248,   103,
     104,   804,   105,   606,   249,   805,   229,   317,    53,   687,
     487,   130,    99,  1107,  1108,  1113,    54,   291,   663,   680,
     681,   368,   369,   370,   833,   318,   836,   371,  1109,  1110,
     587,   664,   906,  1093,  1094,    55,    91,    92,    93,    94,
     209,   303,    56,    57,   143,   699,   312,   144,   310,   693,
     694,   695,   696,   703,   145,   307,   499,   500,   501,   502,
     503,   566,   816,  1029,  1520,  1521,  1031,  1032,  1523,  1524,
    1033,  1332,  1034,    25,   179,   541,   542,   950,  1123,  1124,
    1125,  1126,  1127,  1268,  1269,  1391,  1392,  1270,  1546,  1393,
    1394,  1549,  1642,  1550,  1395,    58,   147,   148,   149,    59,
     116,   117,    60,    61,   127,   271,   272,   273,  1368,  1631,
    1369,  1589,   441,   274,   275,   461,   462,   466,   467,   475,
    1632,  1370,   276,   277,   890,   278,   279,   280,   643,   644,
     281,   282,   283,  1372,   284,  1081,  1082,  1374,   285,   286,
     678,   567,   779,   780,   781,   782,   783,   784,   785,   988,
     989,  1144,  1156,  1185,  1186,  1187,   786,   787,   788,  1410,
    1600,   976,   789,  1145,   790,   791,   792,   793,   794,   795,
     796,   797,   798,   799,   800,   801,   802,  1564,  1565,  1427,
    1157,  1421,  1158,  1166,  1159,  1160,  1419,  1420,  1161,  1424,
     165,   118,   236,   237,   349,   246,   412,   427,  1083,   166,
     167,   204,  1188,   868,   407,  1073,   169,   340,   201,   754,
     170,   171,   345,   126,    10,    11,   172,    70,    13
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -1346
static const short int yypact[] =
{
    1287,   131,   127,    90,  1414, -1346,  2553,   -24, -1346,   495,
      30, -1346,   133, -1346, -1346,   156,   495,   128, -1346, -1346,
   -1346, -1346, -1346, -1346, -1346, -1346,  1527, -1346,   987,  1440,
     336,  1223,  1341,  1344,  1539,  1349,  2738, -1346,   160,   613,
    1405,  1447,  1454, -1346, -1346, -1346, -1346, -1346, -1346, -1346,
   -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346,
   -1346,  1872,  1596, -1346, -1346,   495, -1346,  3393, -1346,   456,
   -1346,   280,   833, -1346, -1346,   495,   495,   788,   294,  1033,
   -1346, -1346,   221, -1346,   606,   606,   321,  1211,  3433,  1346,
    1604,    77,   163, -1346, -1346,   190,   324,   355, -1346,  1085,
     386,   495,   499, -1346, -1346,   176,   518,   533,   576,   339,
     560,   735,  1652,  1334,  1586,  1334,   198, -1346, -1346,   662,
     811,   744,   868,   495,   746, -1346,  1680,   797,   893, -1346,
     495,   798,   221,  1023,   247,  1043,   275, -1346,  1070,   495,
     913,  1211,  1458,   985,  1006, -1346,  1100,   287, -1346,  1160,
     324, -1346, -1346, -1346, -1346, -1346,  3393, -1346, -1346, -1346,
     598, -1346,  3393, -1346, -1346, -1346, -1346, -1346,  4556,   144,
    1075, -1346,   151,  1066,   495, -1346, -1346,  1181,   811,  1224,
   -1346, -1346, -1346,  1636,   332,   641,   290,  1257,  1299, -1346,
    1335,  1240,  1284,  1373,  1386,  1404,   324,   221,   221, -1346,
     319, -1346,  3393, -1346,  3850, -1346,  1334,  1604,   288,  1411,
     295, -1346,  1617, -1346,  1604,  1334,  3393, -1346, -1346,   316,
     495, -1346,   331, -1346, -1346,   495,  3393,  3393,   735, -1346,
   -1346, -1346,   495,   495,   735, -1346,   570, -1346,  1418,  1334,
     373,   374, -1346,  1334,  3393,  3393,  1421, -1346,   377, -1346,
     122, -1346,  1420,  1328,   179,  1334,  1441,  1444,   935,  1167,
     797,  1455,  1464,  1495,  1334,  1334,  1334,   495,  1546,  2444,
    2561,   140,   463,  1524, -1346, -1346, -1346,    65, -1346, -1346,
   -1346, -1346, -1346, -1346, -1346, -1346, -1346,   890,  1358, -1346,
   -1346,   976, -1346, -1346,    78, -1346, -1346, -1346, -1346,   495,
   -1346,   379, -1346,  1445,  1334, -1346,  1628, -1346,   434,  1549,
     495,   495,  1560,    84, -1346,  1628,  1334, -1346, -1346,  1555,
   -1346, -1346,   650,  3866, -1346, -1346,  1558,   942,  1266, -1346,
    1566, -1346, -1346, -1346,  1564,  3393, -1346, -1346, -1346, -1346,
    3166, -1346,  1481, -1346,  1075,  1593, -1346,  3393,  3393, -1346,
    1599,  1603,  1496,  1084, -1346,  1614,   105,  1641, -1346,  1602,
    1636,   695, -1346, -1346,  3552,  1644,  1648,  1322,   380, -1346,
    1569,  1253,   252,  1654, -1346,  2068,   545,  1663,  1669,  2180,
    2321, -1346,  1675,  1677, -1346, -1346, -1346,  1264,   324,   324,
   -1346,  3393,   384, -1346,  1555,  3393,  1590,   436, -1346,  1334,
   -1346,  1334, -1346,  1674, -1346,   462,  4556,  1676, -1346,   466,
   -1346, -1346,  1685,  4556,  4556, -1346, -1346,   735, -1346,  1334,
    3393,  3205,   485, -1346, -1346, -1346,  4556,  1684,  3648,  3393,
   -1346,   495,  3393,   495, -1346, -1346,  3393,  2722, -1346,  1678,
   -1346, -1346,  1682,  3393,  3393,  1630,  3393,  1633,  3393, -1346,
    3393,  1334,  3393, -1346, -1346, -1346,  1698,  3393,  1632,   495,
   -1346,   797,    51,  1643,  1505, -1346,   385, -1346, -1346, -1346,
   -1346, -1346, -1346, -1346, -1346, -1346,  1532,  1696, -1346,   720,
     797,   797, -1346, -1346, -1346, -1346, -1346,   495, -1346, -1346,
    3393,   490, -1346,  1252,  1006,  1100, -1346, -1346, -1346,  1703,
    1626, -1346,  1629, -1346,  3247, -1346,  1635, -1346, -1346,  3393,
    3393,  1704, -1346,  1705, -1346,  1707, -1346,  1714,  3891, -1346,
    3393,  1612,    49, -1346,   522,  4556,  1724,  3393,  3393,  1742,
    1273,   811,  1649, -1346,   495,   495,  1139, -1346,   975,   975,
   -1346,   525,  1743,  1661,  1727, -1346, -1346, -1346, -1346, -1346,
    1757, -1346,   647,   887,   101,  3458,  1178,   101,   961,  2866,
   -1346, -1346, -1346,  1670,  1671,  1679, -1346, -1346, -1346,  2068,
   -1346,  1430,  1267,   574, -1346, -1346, -1346,  1754, -1346,   797,
    1010, -1346, -1346,   495, -1346, -1346,  1728,   495,  1770,  1770,
    1770, -1346,  1737,  1636,  2068,  2068,  1641,  1636,  1641,  1636,
    1759,  1762,   495, -1346,   498,  1773, -1346,   817,  1264,  1264,
     627, -1346,  3393,  3932, -1346,  1688,  1774,  1334, -1346,  3393,
    3393, -1346,  3393,   735, -1346,  1768,  3666, -1346,  3980, -1346,
   -1346,  1777,  1778,  3393, -1346,  3950, -1346,  4556,  1784,  1782,
    1786,  3393,  3393, -1346,   117,  4556, -1346,  3393,  4016,  4071,
   -1346,  4106, -1346,  4141,  4160,  1785,  4195, -1346,  4230, -1346,
   -1346,   254, -1346,   797, -1346,   430,  4666, -1346,  1729,   797,
   -1346, -1346,  1788,  3393,  4556,  1532,  1789, -1346,   709,  4556,
     797, -1346,  1795, -1346,   196,  4598,   843,  1129, -1346,   844,
   -1346,  1792,   495,  1793,  1713, -1346,  1715, -1346,  4556,  1802,
   -1346,   797,   797, -1346,  4556,  3393,  4556,   789, -1346, -1346,
   -1346, -1346,  3393, -1346, -1346, -1346, -1346, -1346,  1796,  3684,
     852, -1346, -1346,   811,   495,  1804,   811,   811, -1346, -1346,
     495,  1807,  1808,  1810,  1813,  1815,   495,  1816,   105,   825,
   -1346,  1818, -1346,   495, -1346, -1346,   324, -1346, -1346,   495,
   -1346,   472, -1346, -1346, -1346,   221,   324,  1746,   779,  1820,
   -1346,  1822,  1176,  1824,  1825,  1826,  1827,  1829,  1830,   495,
    1506,   495,  1509,  1831,  1832,  1836,  1837,  1838, -1346,  4710,
   -1346, -1346, -1346, -1346,  1819,  1812,  1854,  1843,  1848,  1864,
   -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346,
   -1346, -1346, -1346,  1866,   500, -1346,   495,  1857,   221,   324,
    1871,   495, -1346, -1346,   324,  1776,  1353,   101,   101,  1230,
    1636,  1869,   812, -1346, -1346,  1322,  3393, -1346,  1728,  1219,
     495, -1346, -1346,   324, -1346, -1346, -1346, -1346, -1346, -1346,
     871, -1346,  1636,  1636, -1346, -1346, -1346, -1346, -1346, -1346,
     510,  1876, -1346,   495, -1346,  3393,   495,   512,  1877,   495,
     514,  1878, -1346, -1346,  3393,  1873,   872,  4556,  1870,  1874,
   -1346,   898,  3393,  3393, -1346, -1346, -1346, -1346, -1346,  4556,
    4556,  2932, -1346,  2932,  4556,  2640,  1290,  3289,  3289,   797,
    1875,  3393,    65,   797, -1346, -1346,   549, -1346,   334, -1346,
   -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346,   797,   557,
    3393,  4556,  3393,  4556,  1884,  1885,  3393, -1346,   219, -1346,
   -1346,  1888,    10,   797, -1346,  1889,  1886, -1346,  3393,  1892,
   -1346, -1346,  3393, -1346,  1892,   877,  1880, -1346, -1346, -1346,
     495, -1346,  1397, -1346, -1346, -1346, -1346,   797, -1346,   797,
    1811,  1833,  1799, -1346,   495, -1346, -1346,   515,   495,   495,
     495, -1346, -1346, -1346, -1346, -1346,   495, -1346, -1346,   324,
   -1346, -1346, -1346, -1346,   768,  1883,   495,  1890,  3393,   603,
    1903,   718,   718,   718,   718,   718,   718,   718,  1841,  1907,
   -1346,  1917,  1920,  1924,  1926,  1930,   718,   718,   718,   718,
     495, -1346, -1346, -1346, -1346,  3464, -1346,  3464,  3464, -1346,
   -1346, -1346,   495,   580,  3393,   324, -1346, -1346,   599,   495,
     495,   495, -1346, -1346,  1925,  1928,  1929,   835, -1346,  1242,
   -1346, -1346, -1346, -1346, -1346,   221,   324,   221,   324,   969,
   -1346, -1346,  1477, -1346,  1267, -1346,  1927,  3729,   324,  1728,
   -1346,   495,   495, -1346,  1909, -1346, -1346, -1346, -1346, -1346,
    1932,  4556,   626, -1346, -1346,  1938, -1346, -1346, -1346, -1346,
   -1346, -1346,  4556, -1346, -1346, -1346, -1346,  1879,  1881,  1882,
      88,  2125, -1346,    87,  2526,  3103, -1346,  1918,  1991, -1346,
   -1346, -1346,   495,   631, -1346,   324,   735,   698, -1346,  4556,
    4556, -1346, -1346,  4556, -1346,   797,   920,    10, -1346,   633,
    1852, -1346,   643,   880,  1860, -1346,  3328, -1346, -1346, -1346,
   -1346,  1845, -1346,    73,  1953,   639,   644,   645,   938,    73,
     105,   495,   495,  1942, -1346,   660,   666,   704,   495, -1346,
   -1346,   495,  1941,   495,   495,  1462, -1346,  1943,    56,  1944,
    3393,  4282,  1295, -1346, -1346,  1951, -1346,  1887, -1346,   495,
   -1346,  1840, -1346,  1952,  1891, -1346,  1893,  1894,  1895,  1896,
    1897,  1898, -1346, -1346, -1346, -1346, -1346, -1346,  1899,  1901,
    1904,  1912,   774,  1950,  3495, -1346, -1346, -1346, -1346, -1346,
   -1346, -1346, -1346, -1346, -1346,   495, -1346,   708,   710,   725,
     495,  3393,  3393,   495,  1902,   495,  1321, -1346, -1346,   324,
     495,   324,   495,   427, -1346,  1260, -1346,  1960, -1346, -1346,
   -1346,   495,   324, -1346, -1346, -1346,   495, -1346, -1346,    65,
      65, -1346,    65, -1346, -1346, -1346,    65, -1346, -1346, -1346,
    1334,   751, -1346,   495,   495,   735, -1346,   797,   388,  1977,
     221,   324,   495, -1346,  1957,  4713, -1346,  1860,   108,  1978,
    1860,  1852, -1346,  4317, -1346,  1518,   362,  1953,  1935, -1346,
    1964, -1346, -1346,   495, -1346, -1346,   495,   495,  1968,  1833,
   -1346, -1346, -1346,  3393, -1346, -1346, -1346,   753,   495, -1346,
     495, -1346,  2007,  2003,  2008,  1631,  2009,  2011,  2012,  3810,
    2027, -1346, -1346,  1508,   718,  1910,  3393,   718,  3393,  3393,
     718,   718,   718,   718,   718,   718,   718,   718,  2021,  2022,
    3393,  2030,  1955,  1555,   495, -1346, -1346, -1346, -1346,   757,
    4352,  4371,  2040,  2029, -1346,  3041, -1346,   495, -1346,   495,
   -1346, -1346, -1346, -1346,   495,   495, -1346, -1346, -1346, -1346,
   -1346,  2037, -1346, -1346,   770,   421, -1346, -1346,   324,   495,
   -1346, -1346,  2039,   797,  2041,  2042,  2043,   104,  2053, -1346,
   -1346, -1346, -1346, -1346, -1346, -1346,  2044,  1852,  1190, -1346,
     797,  1852, -1346,  2054,  2045,  2006, -1346, -1346,   539, -1346,
   -1346,   760, -1346,   777,  2052, -1346, -1346,   696, -1346, -1346,
   -1346,  4556, -1346, -1346,  1580, -1346, -1346, -1346,   495,  1621,
   -1346,   495,  1631, -1346, -1346, -1346, -1346,  1521,  2064, -1346,
     342,  1975, -1346,  3393, -1346, -1346,  1979,   892,  4556,   957,
    1980,  1981,  1983,  1984,  1986,  1988,  1989,  1990,   495,   495,
    1955, -1346,  3393, -1346, -1346,   420,  3362,  3393,  3393,  1992,
    1323, -1346, -1346, -1346, -1346,   797, -1346, -1346,   495, -1346,
    3393, -1346,  1971,  3393,  1334,  3393,   495, -1346,   797,   749,
   -1346,  3393,   221,   324,   495,   797,  2025, -1346,  2067, -1346,
     439, -1346, -1346,   539,  2052, -1346,   539,  1009, -1346,  2076,
    1204, -1346,  2078,  1204,  1204, -1346, -1346, -1346, -1346, -1346,
    1508,  3393, -1346,  3393,  2084,  3393,  2085,  3393,  3393,  3393,
    3393,  3393,  3393,  3393,  3393,  3393,  2079,  2080,   963, -1346,
    2019, -1346,    99,   573, -1346,   172,  2322,  4556, -1346, -1346,
   -1346, -1346,  4406,  4441,  2089,  4493,   797,   820, -1346,  4556,
     324,   495, -1346,  2038, -1346, -1346,  2091, -1346,  2086,  2090,
    2094,  2099,  2093, -1346,  3393,  2096,  3393,  2097, -1346,   983,
     994, -1346,  4521, -1346,   995, -1346,  4556,  1003,  1011,  2015,
    2028,  1026,  1039,  1042,  2032, -1346,  3393,   420,   420, -1346,
   -1346,  3362,   420,   495,   797,   797,  3393,   797,   797,   870,
   -1346, -1346,   495, -1346, -1346, -1346, -1346,    98, -1346, -1346,
    2103,  4556,  3393,  2110,  3393,  2124,  3393,  2126,  3393,  3393,
    2130,  3393,  2132,  3393,  2133,  3393,  3393,  3393,  2137,  3393,
    2138,  3393,  2139,  3393,  3393,  1045, -1346, -1346, -1346, -1346,
    2118,  2075, -1346,  1790, -1346,  3597, -1346,  1004, -1346, -1346,
   -1346, -1346,  2146, -1346, -1346, -1346,  2141, -1346,  2144, -1346,
    1050, -1346,  1053,  1055, -1346, -1346, -1346,  1065, -1346,  1067,
    1082,  1083, -1346,  1093, -1346,  1096, -1346,  1105,  1109, -1346,
    3393,  2082,   797, -1346,  1334, -1346, -1346,  2148, -1346,  2157,
    2158,  2160,  2163,  2167,  2168,  3393,  2169,  3393,  2170,  2172,
    2174,  2175,  3393,  2092,  2173, -1346,  2176, -1346, -1346, -1346,
   -1346, -1346, -1346, -1346,  1111, -1346,  1124, -1346, -1346, -1346,
   -1346,  1127,  3393,   495,   797,  2177,  2179,  2181,  2100,  1353,
   -1346, -1346, -1346, -1346,  3393,  1345,  1130, -1346, -1346,  3393,
    2101,  3393,  2102,  3393,  2104,  3393,  2105,  3393,  2106,  3393,
    2178, -1346
};

/* YYPGOTO[NTERM-NUM].  */
static const short int yypgoto[] =
{
   -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346,
   -1346, -1346,  1665,  1473, -1346, -1346,   875,  1667, -1346,  2204,
   -1346, -1346, -1346, -1346,  -331, -1346,  -286, -1346, -1346, -1346,
   -1346, -1346, -1346,  2023, -1346,  2024, -1346,  1389,  -536, -1346,
    -551, -1346,  -242,    13, -1346, -1346, -1346,  1847, -1346, -1346,
   -1346, -1346, -1346,  1851, -1346, -1346, -1346, -1346, -1346,  1853,
   -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346,
   -1346,  1177,  -497,    27, -1346,    28, -1346,  1490, -1346,    41,
      42, -1346, -1346,    43, -1346,  -105,  1212, -1346,    -6, -1346,
   -1346,  -171,  2188, -1346, -1346, -1346,  -546,  -537,  -704, -1346,
    1997,  1417,    14,  1371,  -425,  1213,  -219,   -35, -1346, -1346,
   -1346,  2193,   -52, -1346,  1126, -1346, -1346, -1346,  -657, -1346,
    1554,  1755,  -411, -1346,  -769,  -145,  1021,  1655, -1346, -1019,
    -544,  -473, -1346, -1025,   996, -1346, -1346,    32,  2031,  2026,
      39,   -67, -1346, -1346, -1346, -1346, -1346,  1934, -1346, -1346,
   -1346,  1318, -1346,  -471,  1936,   -17, -1346, -1346,  1547, -1346,
    1548, -1346, -1346, -1010,  -333,  -743, -1346, -1346, -1346,   668,
   -1346,   669, -1346, -1346, -1346, -1346, -1346, -1346,  1302,    85,
    1905,  -706, -1346,  1125, -1346,   856, -1345, -1346, -1346, -1346,
     862, -1346, -1346,   665, -1309, -1346,   -76,  1949, -1346, -1346,
     -15,  -227, -1346, -1346, -1346, -1346, -1346, -1346, -1346,   594,
   -1346, -1346,  -441, -1346, -1346, -1346, -1346,  -438,    22,  -804,
   -1052, -1346, -1346,  -402, -1346, -1217,  1182, -1346,   675, -1346,
   -1346, -1346, -1346, -1346, -1215,   734,   585, -1346, -1346, -1214,
   -1346, -1346, -1346,  1492, -1346, -1346, -1346,  -759, -1346,  -705,
    -745, -1346,  -360,   670,  1088, -1107,   977, -1346, -1346,   864,
    -746, -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346, -1346,
   -1346, -1346, -1346, -1346, -1346, -1346, -1346,  -488,   671,  -942,
     800,   391,  -155,  1296, -1346, -1346,   780, -1346,  1128,   866,
   -1346,   -61, -1346,  1906, -1346,   343,  1668,  -329,  -151,   -93,
    -297,  1387,   -86,  1658, -1346,  1412, -1346, -1346,   -29,  -508,
    1738, -1346,   -94,     0,  1954,  2228,   830,   188,  2286
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -792
static const short int yytable[] =
{
       6,   228,   205,    26,    26,   119,   636,   683,   745,   415,
     655,   322,   908,     5,   813,   415,   425,  1206,  1001,   526,
     200,   823,   697,   661,   665,   992,   993,   995,   115,   548,
     196,   393,   951,    45,    47,   821,   830,   453,  1371,   957,
    1373,  1375,   684,   519,   746,   146,  1482,    49,    50,    52,
     814,   387,   235,   974,   134,  1254,   850,   755,   125,  1048,
     808,   217,   857,   860,   220,   851,   308,  1241,    95,   682,
     319,   858,   861,  1030,   673,   473,   343,  1322,   351,  1480,
     294,  1078,  1296,   207,  1485,   119,   119,   211,  1089,   593,
      -2,   625,   627,   597,   599,  1261,   216,   287,   473,   240,
     241,   498,  1236,  1232,   747,    63,  1386,  1018,   239,  1519,
    1387,  1106,  1641,   219,  1578,   222,   394,     8,   549,  1466,
       8,   208,   210,   881,  1389,   482,   483,    14,    65,    71,
    1265,  1266,     7,   174,   882,   662,   305,     9,     1,   396,
       9,   468,  1482,     8,   432,   388,   389,    65,   405,   289,
     469,    72,   153,   301,  1143,    67,     8,   154,   155,    66,
     156,   128,   174,     9,  1024,  1025,    68,   347,   827,   348,
    1026,  1548,  -256,   213,  1551,   212,     9,  1552,   715,     1,
    1027,   162,   484,   364,   372,   509,   224,  1582,  1467,    12,
     895,     8,  -256,     1,    62,   437,   524,  1390,   718,    15,
      16,     1,    17,    98,   485,   438,   215,   683,   242,  1378,
     119,     9,     1,  1440,   119,   883,     1,    96,     1,  1354,
     106,   111,   121,   713,   422,   896,   442,     1,   106,   137,
     491,   909,     1,     1,   409,   119,   454,   455,  1377,   397,
     610,  1381,   918,   608,   609,  1371,   520,  1373,  1375,   506,
     150,   403,   523,    12,  1135,  1136,  1137,   296,   920,   486,
     129,   214,   841,   180,   182,   844,   845,   846,   847,   682,
     509,  1148,   342,   912,   225,   121,  1233,    96,    96,   342,
    1222,  1104,   449,   820,  1030,   298,  1208,   106,  1644,   106,
     175,   588,   589,   495,   495,  1182,   243,   314,   398,   474,
     375,   238,   121,   121,   189,   400,   376,   439,   842,   843,
    1062,  1461,   623,   504,   121,  1197,  1198,  1199,   292,   586,
    1035,  1037,  1065,    98,     1,  1450,   408,   106,  1476,   121,
     150,   199,   615,   365,   616,  1518,   390,    97,   894,   689,
     -66,   410,   216,   -66,   -66,   225,     8,     1,  -258,   366,
     639,   549,   216,   590,  -258,   549,   544,   549,   235,   707,
     364,  1499,   354,  1385,   -66,   218,     9,  1429,  -258,   -66,
    1386,  -784,  -784,   299,  1387,   364,   372,   720,  1388,   364,
     364,   602,     1,   423,   424,   315,   214,   430,  1389,   489,
    1095,    45,    47,   214,   121,    96,   221,   578,   975,  1292,
      96,   611,    96,   121,   415,    49,    50,    52,   106,   990,
     990,   990,   990,   106,   225,   937,  1371,   391,  1373,  1375,
     416,   417,   442,  1543,  1279,  1347,  1348,   121,  1349,   225,
    1519,   121,  1350,  -784,  1287,   895,   742,   232,    98,     8,
    1500,   863,   440,   121,   492,   216,   614,  1386,  1247,  1111,
    1356,  1387,   121,   121,   121,   456,  1547,   670,  1118,     9,
       1,  1390,   666,  1208,   470,  1389,   173,   174,   866,  1625,
    1097,   243,   243,   471,   963,   431,   621,   225,   579,   618,
     685,   372,   612,  1457,  1590,  1024,  1025,   488,   671,  1041,
     216,  1026,   121,  1218,   150,   629,  1329,  1046,   150,   150,
     690,  1027,   756,   150,   121,   809,  1217,     8,   852,   223,
    1011,  1055,  1056,     1,   897,   350,     1,   744,   753,   963,
    1057,   806,  1063,   812,  1066,  1134,   205,     9,   828,   964,
      12,   965,   315,  1634,   214,  1636,   226,  1639,  1390,   716,
     227,  1415,   735,   230,   545,  1404,   365,  1386,     1,     1,
     865,  1387,    62,   -66,   935,   577,   -66,   -66,     1,  1559,
     619,  1560,  1252,  1693,   225,  1389,  1567,  1568,  1569,   364,
    1571,  1572,  1573,  1574,   964,   607,   965,   -66,   549,   372,
     372,   421,   -66,   243,  -784,  -784,   231,   121,   315,   121,
    1192,   824,  1030,   364,   364,   364,   853,   364,  1012,   364,
     549,   549,   856,   859,  1152,  1718,   418,   238,   853,  1196,
     853,   970,   853,   431,   131,     8,  1149,  1726,   320,   321,
     509,   638,  1730,   736,  1732,  -256,  1734,  1224,  1736,  1098,
    1738,  -256,  1740,  1091,  1111,     9,  1227,   287,  1390,   121,
    1183,  1242,   373,  1256,   862,  -256,  -784,   660,   741,  1272,
      80,    81,   669,  1580,  1274,  1275,   287,   374,   233,  -127,
    -256,  -256,  1720,   666,  1016,   216,  1493,  1248,   419,   666,
    1284,  1581,   825,     1,  1660,   688,  1285,     1,  1012,  -127,
     685,   552,  1668,   671,   244,     1,   508,   671,  1051,   898,
      31,    32,    33,  1516,   581,   582,   550,   431,  1153,  1154,
    1155,   932,   934,   969,  1386,   551,   671,  1208,  1387,  1725,
    1468,   961,  1388,   129,  1286,  -256,   968,  -256,  1326,  1163,
    1327,   676,  1389,  1475,   853,   509,   915,   152,   153,  1243,
       8,  1257,     8,   154,   155,  1328,   156,  1273,   952,  -256,
     157,   158,  1131,  1276,   807,   159,   558,    40,   509,   742,
       9,   584,     9,   226,   160,   161,  1015,   162,   431,   577,
     577,  1352,   245,  1402,   431,  1036,  1038,  1444,  1386,    42,
    1246,   831,  1387,   585,   895,   834,  1388,  1049,  1068,  1022,
    1456,   154,   155,  1291,   990,  1386,  1389,   154,   155,  1387,
     607,     8,  1483,  1388,  1142,  1390,   607,   607,   183,  1351,
    1318,  1346,   431,  1389,   184,   121,   431,   916,   431,  1355,
    1603,     9,  1214,  1153,  1154,  1155,     6,   185,   677,  1481,
     364,  1298,   174,   431,  1140,   936,     1,  1165,  1165,  1028,
     251,  1170,  1171,  1538,  1474,   226,  1204,     8,  -784,   855,
     176,  -784,   364,   364,  1181,     8,    69,  -784,  1043,  1243,
    1205,   431,   163,   164,   121,   431,  1646,     9,  1648,  1390,
     921,   924,   293,  1092,   120,     9,  1143,  -784,  1243,   939,
    1194,   954,  1143,   121,   972,   973,  1390,     1,   247,  1588,
     926,  -784,  -784,  -784,  -784,  -784,  -784,   509,  1053,  1069,
     747,  1210,  -784,  1212,  1119,  -784,  -784,  1259,  -784,  -155,
    1024,  1025,   178,  1221,  1591,   216,  1026,   474,   666,  1504,
    1044,  1086,   476,   477,   474,  1090,  1027,   120,   671,  -155,
    1454,  1249,  1112,  1114,   948,     1,   953,   955,  1193,  1469,
     990,   671,  -258,   748,  -703,  1409,   445,   962,  -258,  -784,
     671,   579,   509,  -784,   120,   120,   977,  1128,     1,  1128,
     509,   446,  -258,   250,  1638,   290,   288,   977,   977,   977,
     977,  -784,   810,     1,   512,   513,  1250,   581,   582,  1054,
     509,   120,   747,  -120,  1506,   509,  1030,   739,  1260,   216,
    1575,     8,  1208,  1209,  1277,  1211,   480,   216,    78,   742,
    1505,  1245,   481,  -120,   807,   895,  -703,   302,     1,  -190,
    1605,     9,   895,    79,   753,  -190,   113,  1040,   581,   582,
     119,  1607,  1610,   577,   309,   748,  -190,  1386,  1050,  -190,
    1612,  1387,    98,  1534,   584,  1388,   415,     6,  1614,     6,
    1537,    80,    81,   295,   190,  1389,   120,   191,   192,  1132,
    1028,  1060,  1028,  1618,  1060,   120,   585,   111,  1490,  -784,
    -784,   990,  1494,   297,  1251,  1507,  1620,   581,   582,  1622,
    1244,  1576,  1669,   742,  1337,   584,  1339,  1679,  1553,   120,
    1680,   742,  1681,   120,   193,   194,   195,  1344,   990,  1517,
     300,  1606,  1682,   346,  1683,   120,  1096,   585,  1675,  -190,
     730,   724,  1608,  1611,   120,   120,   120,     8,  1323,  1684,
    1686,  1613,   474,   216,   311,   666,  1359,  1255,  1390,  1615,
    1688,  -784,    98,  1689,   584,   895,   313,     9,  1650,   671,
    1652,  1653,  1690,  1128,  1619,  1657,  1691,  1659,  1715,  1128,
     952,  1663,     1,  1665,   120,  1667,   585,  1621,     1,   922,
    1623,  1716,  1133,  1670,  1717,   923,   120,  1728,  1611,  1422,
    1637,  1611,  1422,  1611,  1139,  1422,  1422,  1432,  1433,  1422,
    1422,  1422,  1437,  1611,   977,  1611,   532,   977,   447,   977,
     977,   977,   977,   977,   977,   977,   316,   980,   968,   803,
    1685,  1687,   531,   448,   977,   977,   977,   977,   977,  1579,
       8,  1611,   981,   352,  1611,   533,   216,  1704,  1358,  1706,
     807,   534,   535,  1611,  1711,   355,     6,  1692,  1267,  1611,
       9,   442,   190,  1458,  1267,   191,   192,   154,   155,  1028,
    1425,   532,  1611,     8,   100,  1611,  1376,  1215,  1729,   120,
     577,   120,   577,  1696,  1323,  -202,  1472,   581,   582,  1223,
     356,    89,     8,     9,  1626,  1627,   114,   666,   113,  1629,
     728,   474,   474,   691,   474,  -202,   534,   535,   474,   152,
     153,   250,     9,   692,     8,   154,   155,   379,   156,  1039,
     671,  -791,   157,   158,   142,   570,     8,   159,   245,     8,
    1096,   120,  -791,   722,     9,     8,   160,   161,   514,   162,
     515,  1079,    98,    88,   584,  1525,     9,   152,   153,     9,
     581,   582,     8,   154,   155,     9,   156,  1024,  1025,   380,
     157,   158,  1301,  1026,  1302,   159,   585,   583,  1280,  1281,
    1282,    98,     9,  1027,   160,   161,  1473,   162,  1541,  1289,
     570,   977,   977,   571,     8,     6,   434,  1425,   382,    -3,
     435,    -3,   102,    -3,   436,   107,     8,   977,  1028,  1207,
     122,   583,   381,     8,     9,    98,     8,   584,     8,   572,
     723,  -113,   206,  1462,   726,   727,     9,   666,   478,   174,
       1,   113,  1080,     9,   479,    88,     9,   671,     9,   585,
    1255,  -113,   383,  1325,   163,   164,  1024,  1025,  1024,  1025,
     384,  1333,  1026,  1335,  1026,  1592,    -3,    -3,  1338,    -3,
    1340,  1341,  1027,   385,  1027,  1336,   133,  1529,   174,  1343,
    1024,  1025,  1121,   731,   733,     1,  1026,     8,  1024,  1025,
    1540,   386,   163,   164,  1026,  1570,  1027,   399,   121,  1727,
    1525,  1096,  1096,  1376,  1027,   442,   420,     9,   570,   429,
    1360,    86,     8,   121,   433,     6,  1379,   120,   135,     1,
       6,     1,     8,  1384,   168,   138,    87,   443,  1028,     8,
     444,   953,     9,  1028,  1398,  1399,  -196,   572,   666,    88,
       8,   450,     9,     1,   304,  1255,  1403,  1530,   977,     9,
     451,     1,   521,   977,  1293,   570,  -196,    88,  1294,     8,
       9,   671,   977,     8,  1216,   977,   288,   529,   977,   977,
     977,   977,   977,   977,   977,   977,   668,   991,     8,     9,
     994,   452,  1443,     9,   572,   288,  1417,     8,     8,  1383,
    1418,     8,     6,    15,    16,  1451,    17,  1452,     9,  1496,
       8,  1661,  1453,  1497,   472,  1028,  1255,     9,     9,   152,
     153,     9,     1,   490,     8,   154,   155,  1459,   156,   323,
       9,     8,   157,   158,   531,   112,  1075,   159,  1076,   671,
     942,   253,   457,   254,     9,   493,   160,   161,    88,   162,
     497,     9,   507,   250,   197,   198,   113,     6,     6,    73,
     511,    74,     6,    75,  1633,  1462,   517,  1462,   666,  1462,
    1028,  1028,   516,   154,   155,  1028,   977,  1488,     8,   977,
     977,   153,   672,   406,  1376,     8,   154,   155,     8,   156,
     837,   838,   141,   413,   414,    88,     8,   527,     9,   528,
     206,  1084,  1085,   113,   540,     9,   977,   977,     9,     8,
     162,   426,   428,   401,   154,   155,     9,   357,  1491,  -784,
       8,   250,  -784,     8,   304,   442,  1531,  1408,  -784,     9,
     121,   546,   121,   190,  1536,   547,   191,   192,   569,   671,
       9,   568,  1542,     9,   163,   164,  1235,   580,  -784,  1235,
    1235,   591,  1633,   594,  -784,  -784,  -784,  1189,  1190,   595,
     600,   601,  -784,  -784,  -784,  -784,  -784,  -784,   391,   -53,
     617,   620,     8,  -784,   252,   646,  -784,  -784,  1426,  -784,
     622,  1430,  1431,   630,   647,  1434,  1435,  1436,   657,   253,
     650,   254,     9,   652,  1462,   667,   659,   113,   675,     6,
     700,  -784,   518,  -784,   701,     6,   708,   702,   709,  1593,
     255,   710,  1028,   705,   525,   428,   711,  -784,  1028,  -784,
    -784,   714,  -784,   717,  -784,   256,   257,   258,   259,   260,
     261,   262,   721,   263,   264,   265,   266,   267,   268,   738,
     737,   269,  -784,   270,     1,   724,   739,   740,   817,   818,
     723,  1333,   826,   835,   832,   839,   848,   819,   525,   849,
    1640,  1164,   613,   854,  1168,  1169,   619,   870,   250,   250,
     250,   390,   872,   873,   876,   891,  1178,  1179,  1180,   877,
    1673,   907,     8,   878,   910,   919,   914,   626,   628,   925,
     927,   928,   930,   929,   941,   938,   635,   943,   944,   637,
     945,   121,     9,   946,   645,   947,   949,   113,   956,  1004,
     648,   649,   971,   651,  1005,   653,   978,   654,   979,   656,
     982,   983,   984,   985,   658,   986,   987,   996,   997,   250,
     250,   250,   998,   999,  1000,  1362,   257,   258,   259,  1363,
    1364,  1365,   121,   674,  1006,  1007,   679,   267,  1366,   120,
    1008,  1367,  -102,   140,  1009,  -102,  1010,   525,  -102,  1014,
     698,  1017,   250,  1023,  -102,  1042,  1058,  1064,  1067,  1070,
     618,   704,  1087,  1071,  1101,  1102,   706,   525,  1105,  1115,
    1132,  1719,  1116,   692,  -102,  1147,   341,   344,  1150,  1130,
    -102,  -102,  -102,  1162,   719,   525,  1120,  1172,  -102,  -102,
    -102,  -102,  -102,  -102,  -102,  -102,  -102,  1173,  -102,  -102,
    1174,  1131,  -102,  -102,  1175,  -102,  1176,  -102,  -102,  1143,
    1177,  1201,   341,  -102,  1202,  1203,  1219,  1225,  1228,   254,
    1258,  -102,  -102,  -102,   855,  1264,  -102,  -102,  1229,  -102,
    1230,  1106,  1231,  1271,  1283,  1290,  1297,  1295,   250,  1303,
    -102,  1302,  1319,  -102,  1306,  -102,  -102,  1342,  -102,  -102,
    -102,  -102,  -102,     8,  -102,  1304,  1334,  1357,  1380,  1307,
    1396,  1308,  1309,  1310,  1311,  1312,  1313,  1314,  -102,  1315,
    -102,  1240,  1316,     9,   154,   155,   525,   867,   113,   413,
    1317,   324,   325,   326,   327,   328,   329,   330,   331,   332,
     867,  1361,  1397,  1400,  1405,   333,   334,  1406,   879,   880,
     250,  1413,  1407,  1411,   884,  1412,  1362,   257,   258,   259,
    1363,  1364,  1365,   758,  1423,  1438,  1439,  1441,   267,  1366,
    1447,  1448,  1367,  1442,  1455,  1460,   250,  1463,  1464,  1465,
     911,   341,   913,  1470,  1477,  1479,  1471,  1478,  1486,   357,
     120,  -784,  1498,  1501,  -784,  1545,  1528,  1503,  1508,  1509,
    -784,  1510,  1511,   344,  1512,   288,  1513,  1514,  1515,  1544,
     335,  1554,   525,  1556,  1561,  1563,  1488,  1491,  1577,  1586,
    -784,  1595,  1594,  1596,  1598,  1597,  -784,  -784,  -784,  -442,
    1599,  1602,  1604,  1616,  -784,  -784,  -784,  -784,  -784,  -784,
    1645,   336,   337,   338,   339,  -784,  1617,  1647,  -784,  -784,
    1624,  -784,   152,   153,  1649,  1671,  1651,     8,   154,   155,
    1654,   156,  1656,  1658,   341,   157,   158,  1662,  1664,  1666,
     159,   341,   341,  -784,  1672,  -784,  1676,     9,  1677,   160,
     161,  1678,   162,  1694,   341,  1697,   341,  1698,  1699,  -784,
    1700,  -784,  -784,  1701,  -784,   250,  -784,  1702,  1703,  1705,
    1707,   596,  1708,  -784,  1709,  1710,  -784,  1721,  1713,  1722,
    1712,  1723,  -784,  1714,  -784,  1741,     1,   940,  1724,  1731,
    1733,   729,  1735,  1737,  1739,  1234,   734,  1080,    27,   377,
     378,   560,  -784,  1047,  1045,   561,  1213,   562,  -784,  -784,
    -784,   108,   411,  1013,  1059,  1191,  -784,  -784,  -784,  -784,
    -784,  -784,   132,  1253,   917,   829,   686,  -784,   402,  1353,
    -784,  -784,  1061,  -784,   494,   404,  1117,   496,   931,  1628,
     933,  1129,  1630,  1487,  1278,  1484,   341,   163,   164,  1072,
    1072,   543,  1643,   341,   505,  -784,  1695,  -784,   645,  1239,
     645,  1003,  1321,   525,   525,   525,  1495,  1416,  1088,  1167,
    1558,  -784,  1655,  -784,  -784,  1074,  -784,  1305,  -784,  1502,
     869,   874,   288,   151,   120,    64,   522,  1099,     0,  1100,
       0,     0,     0,  1103,     0,     0,  -784,     0,     1,     0,
       0,     0,     0,     0,     0,   698,     0,     0,     0,   704,
       0,     0,   598,     0,  -784,   624,     0,  -784,     0,     0,
       0,     0,  1583,  -784,     0,   154,   155,     0,     0,     0,
       0,     0,   324,   325,   326,   327,   328,   329,   330,   331,
     332,   341,     0,  -784,     0,     0,   333,   334,     0,  -784,
    -784,  -784,     0,     0,   341,  1151,   341,  -784,  -784,  -784,
    -784,  -784,  -784,   341,     0,   341,     0,     0,  -784,     0,
       0,  -784,  -784,   341,  -784,     0,   341,   341,     0,   341,
       0,   341,   341,     0,   341,     0,   341,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  -784,     0,  -784,     0,
       0,     0,   341,     0,     0,     0,     0,   341,     0,     0,
       0,   335,  -784,     0,  -784,  -784,     0,  -784,     0,  -784,
       0,     0,     0,     0,     0,     0,   341,     0,     0,     0,
       0,     0,   341,     0,   341,   458,     0,  -784,     0,     1,
       0,     0,   336,   337,   338,   339,  -496,   341,  -496,   459,
       0,     0,     0,   288,     0,     0,     0,     0,   525,     0,
       0,   525,   525,  -496,     0,  -496,  -496,     0,     0,     0,
       0,  -496,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  -496,     0,     0,     0,     0,     0,
       0,     0,     0,  1263,   120,     0,     0,     0,     0,  -496,
    -496,  -496,  -496,  -496,  -496,  -496,     0,  -496,  -496,  -496,
    -496,  -496,  -496,     0,     0,  -496,     0,  -496,   460,     0,
       0,     0,     0,   152,   153,     0,     0,  1299,     8,   154,
     155,     0,   156,     0,     0,     0,   157,   158,     0,     0,
       0,   159,     0,     0,     0,     0,    28,     0,     9,    29,
     160,   161,   463,   162,     0,     8,     0,     0,     0,     0,
       0,     0,  -496,  -784,     0,  -784,   464,     0,     0,     0,
       0,     0,     0,     0,     0,     9,     0,     0,  1330,  1331,
    -784,     0,  -784,  -784,     0,     0,     0,     0,  -784,    30,
      31,    32,    33,    34,    35,   341,  1237,     0,  1080,     0,
      36,  -784,     0,    37,    38,     0,    39,   341,   341,     0,
       0,     0,   341,     0,     0,     0,  -784,  -784,  -784,  -784,
    -784,  -784,  -784,   465,  -784,  -784,  -784,  -784,  -784,  -784,
       0,  1077,  -784,     0,  -784,     0,     0,     0,     0,   341,
     473,   341,  -784,     0,  -784,     0,     0,    40,   163,   164,
       0,    41,     0,     0,     0,     0,     0,     0,     0,  -784,
    1401,  -784,  -784,     0,     0,     0,     0,  -784,     0,    42,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     1,
    -784,     0,     0,     0,     0,  1428,  1428,     0,     0,     0,
       0,     0,     0,     0,     0,  -784,  -784,  -784,  -784,  -784,
    -784,  -784,  1146,  -784,  -784,  -784,  -784,  -784,  -784,     0,
       0,  -784,     0,  -784,     0,     0,     0,     0,     0,   152,
     153,     0,     0,     0,     8,   154,   155,     0,   156,   124,
       0,     0,   157,   158,     0,     0,     0,   159,   640,     0,
    -784,     0,  -784,     0,     9,     0,   160,   161,     0,   162,
       0,     0,     0,     0,     0,     0,     0,  -784,     1,  -784,
    -784,     0,     0,     0,     0,  -784,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   341,     0,     0,  -784,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   341,
       0,     0,     0,  -784,  -784,  -784,  -784,  -784,  -784,  -784,
     341,  -784,  -784,  -784,  -784,  -784,  -784,   641,   642,  -784,
       0,  -784,     0,     0,     0,     0,   341,     0,     0,     0,
       0,     0,     0,   525,  1526,  1527,     0,   341,   341,     0,
       0,   341,     0,     0,     0,     0,     0,  1532,     0,     0,
    1533,     0,  1535,     0,   163,   164,     0,     0,  1539,     0,
       0,     0,     0,     0,     0,     0,     1,   815,     0,  -372,
       0,     0,  -372,     0,     0,     0,     0,     0,  -372,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1428,   341,
    1428,     0,  1562,     0,  1566,  1428,  1428,  1428,  -372,  1428,
    1428,  1428,  1428,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  -372,  -372,  -372,  -372,  -372,  -372,     0,     0,
    1146,     0,     0,  -372,     0,     0,  -372,  -372,     0,  -372,
       0,  -372,  -372,     0,     0,     0,     0,  -372,     0,   152,
     153,  1601,     0,  1601,     8,   154,   155,  -372,   156,     0,
       0,     0,   157,   158,     0,     0,     0,   159,     0,     0,
       0,     0,     0,     0,     9,     0,   160,   161,   525,   162,
    -372,     0,     0,  1635,  -372,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,  1601,
       0,  1601,  -372,  1566,  -372,  1566,  1566,     0,  1566,     0,
    1566,   341,  1566,  1428,     0,     0,  1566,     0,  1566,     0,
    1566,  1428,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   641,   642,     0,
       0,     0,     0,     0,     0,     0,     0,   341,     0,     0,
       0,     0,  1449,     0,  -784,     0,     0,  -784,     0,     0,
       0,     0,     0,  -784,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   163,   164,     0,     0,   341,   341,
       0,     0,  1566,  -784,  1566,     0,     0,     0,     0,  1566,
       0,     0,     0,     0,     0,     0,     0,  -784,  -784,  -784,
    -784,  -784,  -784,     0,     0,     0,     0,     0,  -784,     0,
       0,  -784,  -784,     0,  -784,     0,  1024,  1025,     0,     0,
     152,   153,  1026,     0,     0,     8,   154,   155,     0,   156,
       0,     0,  1027,   157,   158,     0,     0,     0,   159,     0,
       0,     0,     0,     0,     0,     9,     0,   160,   161,   341,
     162,     0,  1489,     0,     0,  -784,     0,  1492,     0,  -784,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   341,  -784,     0,     1,
       0,     0,     0,   152,   153,     0,     0,     0,     8,   154,
     155,     0,   156,  1238,     0,  1080,   157,   158,     0,     0,
       0,   159,     0,     0,     0,     0,     0,     0,     9,     0,
     160,   161,     0,   162,     0,     0,     0,     0,     0,     0,
       0,     0,   152,   153,     0,     0,     0,     8,   154,   155,
       0,   156,     0,   429,     0,   157,   158,     0,  1555,     0,
     159,  1557,  1492,     0,     0,   163,   164,     9,     0,   160,
     161,     0,   162,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   152,   153,     0,     0,   692,     8,
     154,   155,     0,   156,   341,   341,     0,   157,   158,     0,
     341,   341,   159,   341,     0,     0,     0,   341,     0,     9,
       0,   160,   161,     0,   162,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   342,     0,   152,   153,   163,   164,
     341,     8,   154,   155,   341,   156,     0,     0,     0,   157,
     158,     0,     0,     0,   159,     0,     0,     0,     0,     0,
       0,     9,     0,   160,   161,     0,   162,     0,     0,     0,
       0,     0,     0,     0,     0,   152,   153,   163,   164,   341,
       8,   154,   155,     0,   156,  1262,     0,     0,   157,   158,
       0,     0,     0,   159,     0,     0,     0,     0,     0,     0,
       9,     0,   160,   161,     0,   162,     0,     0,     0,   152,
     153,  1080,     0,   341,     8,   154,   155,     0,   156,   163,
     164,     0,   157,   158,     0,     0,     0,   159,     0,     0,
       0,     0,     0,     0,     9,     0,   160,   161,     0,   162,
     152,   153,     0,     0,     0,     8,   154,   155,     0,   156,
       0,     0,     0,   157,   158,     0,     0,     0,   159,     0,
       0,   163,   164,     0,     0,     9,     0,   160,   161,     0,
     162,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     152,   153,     0,     0,  1522,     8,   154,   155,     0,   202,
       0,     0,     0,   157,   158,     0,     0,     0,   159,   757,
     163,   164,     0,     0,     0,     9,     0,   160,   161,     0,
     162,   152,   153,     0,   758,     0,     8,   154,   155,     0,
    1184,     0,     0,     0,   157,   158,     0,     0,     0,   159,
       0,     0,     0,     0,   163,   164,     9,     0,   160,   161,
       0,   162,   152,   153,     0,     0,     0,     8,   154,   155,
       0,  1320,     0,     0,     0,   157,   158,     0,     0,     0,
     159,     0,     0,   759,     0,   163,   164,     9,     0,   160,
     161,     0,   162,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   760,   556,   761,   762,   763,   764,
     765,   766,   767,     0,     0,    28,     0,     0,    29,     0,
       0,     0,     0,   768,     8,   163,   164,     0,     0,     0,
       0,   769,   770,     0,     0,     0,     0,   771,   772,   773,
     774,   775,   776,   777,     9,     0,     0,     0,     0,     0,
     552,   553,   554,     0,     0,     0,   163,   164,    30,    31,
      32,    33,    34,    35,     0,     0,     0,  1674,     0,    36,
     154,   155,    37,    38,     0,    39,     0,   324,   325,   326,
     327,   328,   329,   330,   331,   332,     0,   163,   164,     0,
       0,   333,   334,     0,     0,     0,     0,   555,     0,   556,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   557,     0,   558,    40,     0,   559,     0,
      41,   631,   632,   633,     0,     0,     0,   634,   324,   325,
     326,   327,   328,   329,   330,   331,   332,     0,    42,   631,
     632,   633,   333,   334,     0,   871,   324,   325,   326,   327,
     328,   329,   330,   331,   332,     0,   335,   631,   632,   633,
     333,   334,     0,   875,   324,   325,   326,   327,   328,   329,
     330,   331,   332,     0,     0,     0,     0,     0,   333,   334,
       0,     0,     0,     0,     0,     0,     0,   336,   337,   338,
     339,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   631,   632,   633,     0,     0,   335,  1220,   324,
     325,   326,   327,   328,   329,   330,   331,   332,     0,     0,
       0,     0,     0,   333,   334,   335,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   336,   337,
     338,   339,     0,   335,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   336,   337,   338,   339,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   336,   337,   338,   339,     0,     0,
       0,     0,     0,   631,   632,   633,     0,     0,   335,  1414,
     324,   325,   326,   327,   328,   329,   330,   331,   332,     0,
       0,     0,     0,     0,   333,   334,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   336,
     337,   338,   339,   154,   155,   395,     0,     0,     0,     0,
     324,   325,   326,   327,   328,   329,   330,   331,   332,   154,
     155,     0,     0,     0,   333,   334,   324,   325,   326,   327,
     328,   329,   330,   331,   332,     0,     0,     0,     0,     0,
     333,   334,     0,   510,   154,   155,   712,     0,     0,   335,
       0,   324,   325,   326,   327,   328,   329,   330,   331,   332,
       0,     0,     0,     0,     0,   333,   334,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     336,   337,   338,   339,     0,   154,   155,   864,     0,   335,
       0,     0,   324,   325,   326,   327,   328,   329,   330,   331,
     332,     0,     0,   154,   155,   335,   333,   334,     0,   875,
     324,   325,   326,   327,   328,   329,   330,   331,   332,     0,
     336,   337,   338,   339,   333,   334,     0,     0,     0,     0,
     335,     0,     0,   631,   632,   633,   336,   337,   338,   339,
     324,   325,   326,   327,   328,   329,   330,   331,   332,     0,
       0,     0,     0,     0,   333,   334,     0,     0,     0,     0,
       0,   336,   337,   338,   339,     0,     0,     0,     0,   154,
     155,   335,     0,   885,     0,     0,   324,   325,   326,   327,
     328,   329,   330,   331,   332,     0,     0,     0,     0,   335,
     333,   334,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   336,   337,   338,   339,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   335,
     336,   337,   338,   339,   154,   155,     0,     0,   886,     0,
       0,   324,   325,   326,   327,   328,   329,   330,   331,   332,
       0,     0,     0,     0,     0,   333,   334,     0,     0,     0,
     336,   337,   338,   339,     0,   335,     0,     0,     0,   154,
     155,     0,     0,   887,     0,     0,   324,   325,   326,   327,
     328,   329,   330,   331,   332,     0,     0,     0,     0,     0,
     333,   334,     0,     0,     0,     0,   336,   337,   338,   339,
       0,     0,     0,     0,   154,   155,     0,     0,   888,     0,
       0,   324,   325,   326,   327,   328,   329,   330,   331,   332,
     335,     0,     0,   154,   155,   333,   334,   889,     0,     0,
     324,   325,   326,   327,   328,   329,   330,   331,   332,     0,
       0,     0,     0,     0,   333,   334,     0,     0,     0,     0,
       0,   336,   337,   338,   339,   335,     0,     0,   154,   155,
       0,     0,   892,     0,     0,   324,   325,   326,   327,   328,
     329,   330,   331,   332,     0,     0,     0,     0,     0,   333,
     334,     0,     0,     0,     0,     0,   336,   337,   338,   339,
     335,     0,     0,   154,   155,     0,     0,   893,     0,     0,
     324,   325,   326,   327,   328,   329,   330,   331,   332,   335,
       0,     0,     0,     0,   333,   334,     0,     0,     0,     0,
       0,   336,   337,   338,   339,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     336,   337,   338,   339,   335,   154,   155,     0,     0,  1300,
       0,     0,   324,   325,   326,   327,   328,   329,   330,   331,
     332,     0,     0,     0,     0,     0,   333,   334,     0,     0,
       0,     0,     0,     0,     0,   336,   337,   338,   339,   335,
     154,   155,     0,     0,  1382,     0,     0,   324,   325,   326,
     327,   328,   329,   330,   331,   332,     0,     0,     0,     0,
       0,   333,   334,     0,     0,     0,     0,     0,     0,     0,
     336,   337,   338,   339,     0,   154,   155,     0,     0,  1445,
       0,     0,   324,   325,   326,   327,   328,   329,   330,   331,
     332,   335,     0,     0,   154,   155,   333,   334,  1446,     0,
       0,   324,   325,   326,   327,   328,   329,   330,   331,   332,
       0,     0,     0,     0,     0,   333,   334,     0,     0,     0,
       0,     0,   336,   337,   338,   339,   335,     0,     0,   154,
     155,     0,     0,  1584,     0,     0,   324,   325,   326,   327,
     328,   329,   330,   331,   332,     0,     0,     0,     0,     0,
     333,   334,     0,     0,     0,     0,     0,   336,   337,   338,
     339,   335,     0,     0,   154,   155,     0,     0,  1585,     0,
       0,   324,   325,   326,   327,   328,   329,   330,   331,   332,
     335,     0,     0,     0,     0,   333,   334,     0,     0,     0,
       0,     0,   336,   337,   338,   339,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   336,   337,   338,   339,   335,   154,   155,     0,     0,
    1587,     0,     0,   324,   325,   326,   327,   328,   329,   330,
     331,   332,     0,     0,     0,     0,     0,   333,   334,     0,
       0,     0,     0,     0,   154,   155,   336,   337,   338,   339,
     335,   324,   325,   326,   327,   328,   329,   330,   331,   332,
       0,     0,     0,     0,     0,   333,   334,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   154,
     155,   336,   337,   338,   339,     0,   324,   325,   326,   327,
     328,   329,   330,   331,   332,     0,     0,     0,     0,     0,
     333,   334,   335,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       8,     0,   252,     0,     0,     0,     0,     0,     0,  1609,
     335,     0,     0,   336,   337,   338,   339,   253,     0,   254,
       9,     0,     0,     0,     0,   113,   552,   588,   589,     0,
       0,     0,     0,     0,   898,    31,    32,    33,   255,     0,
       0,   336,   337,   338,   339,   335,     0,     0,     0,     0,
       0,     0,     0,   256,   257,   258,   259,   260,   261,   262,
       0,   263,   264,   265,   266,   267,   268,     0,     8,   269,
     252,   270,     0,     0,     0,     0,   336,   337,   338,   339,
       0,     0,     0,     0,     0,   253,     0,   254,     9,   590,
       0,   558,    40,   113,   552,     0,     0,     0,     0,     0,
       0,     0,   898,    31,    32,    33,   255,     0,     0,     0,
       0,     0,     0,     0,    42,     8,   758,     0,     0,     0,
       0,   256,   257,   258,   259,   260,   261,   262,     0,   263,
     264,   265,   266,   267,   268,     9,     0,   269,     0,   270,
     113,   552,     0,     0,     0,     0,     0,     0,     0,   898,
      31,    32,    33,     0,     0,     0,     0,     0,     0,   558,
      40,     0,     0,     0,     0,   759,     0,     0,  1362,   257,
     258,   259,  1363,  1364,  1365,     0,     0,     0,     0,     0,
     267,  1366,    42,     0,  1367,     0,  1002,   556,   761,   762,
     763,   764,   765,   766,   767,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   768,   558,    40,     0,     0,
       0,     0,     0,   769,   770,     0,     0,     0,     0,   771,
     772,   773,   774,   775,   776,   777,     0,     0,     0,    42
};

/* YYCONFLP[YYPACT[STATE-NUM]] -- Pointer into YYCONFL of start of
   list of conflicting reductions corresponding to action entry for
   state STATE-NUM in yytable.  0 means no conflicts.  The list in
   yyconfl is terminated by a rule number of 0.  */
static const unsigned char yyconflp[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0
};

/* YYCONFL[I] -- lists of conflicting rule numbers, each terminated by
   0, pointed into by YYCONFLP.  */
static const short int yyconfl[] =
{
       0
};

static const short int yycheck[] =
{
       0,   106,    88,     3,     4,    34,   431,   480,   552,   228,
     451,   162,   669,     0,   558,   234,   243,  1027,   777,   348,
      87,   572,   493,   461,   462,   770,   771,   772,    34,   360,
      82,   202,   738,     6,     6,   571,   580,   264,  1255,   743,
    1255,  1255,   480,   340,   552,    62,  1391,     6,     6,     6,
     558,   196,   113,   758,    40,  1107,   602,   554,    36,   828,
     557,    96,   608,   609,    99,   602,   142,  1092,    29,   480,
     156,   608,   609,   816,   476,    10,   169,  1184,   172,  1388,
     132,   885,    26,    89,  1393,   114,   115,    10,   892,   375,
       0,   420,   421,   379,   380,  1114,    18,   126,    10,   114,
     115,    17,    15,    15,     3,   129,     8,   811,   114,    10,
      12,   101,    14,    99,    15,   101,   202,    12,   360,    15,
      12,    89,    90,     6,    26,    47,    48,     0,    98,     1,
      57,    58,     1,    11,    17,    84,   142,    32,   128,   206,
      32,     1,  1487,    12,    22,   197,   198,    98,   215,   127,
      10,    23,     8,   139,    98,    22,    12,    13,    14,   129,
      16,     1,    11,    32,    65,    66,    10,    16,   579,    18,
      71,  1480,    12,    10,  1483,    98,    32,  1486,   129,   128,
      81,    37,   104,   183,   184,    98,    10,    15,    84,     1,
     663,    12,    32,   128,     6,    16,   347,    99,   527,   109,
     110,   128,   112,   102,   126,    26,    16,   680,    10,   101,
     239,    32,   128,  1320,   243,    98,   128,    29,   128,  1244,
      32,    33,    34,   520,   239,   663,   255,   128,    40,    41,
     306,   669,   128,   128,   220,   264,   265,   266,  1257,   207,
     391,  1260,   680,   388,   389,  1462,   340,  1462,  1462,   316,
      62,   212,   345,    65,   958,   959,   960,    10,    62,   294,
     100,    98,   593,    75,    76,   596,   597,   598,   599,   680,
      98,   976,   128,   675,    98,    87,  1080,    89,    90,   128,
    1049,    62,   260,   569,  1027,    10,  1029,    99,  1597,   101,
      10,    39,    40,   310,   311,  1000,    98,    10,    10,   277,
      10,   113,   114,   115,    10,    10,    16,   128,   594,   595,
     856,  1363,   417,   313,   126,  1019,  1020,  1021,   130,   371,
     817,   818,   859,   102,   128,  1335,    10,   139,  1380,   141,
     142,    10,   399,     1,   401,  1442,    17,     1,    84,   490,
       8,    10,    18,    11,    12,    98,    12,   128,    12,    17,
     436,   593,    18,   101,    18,   597,   356,   599,   419,   510,
     360,    19,   174,     1,    32,    10,    32,  1309,    32,    37,
       8,    39,    40,    98,    12,   375,   376,   528,    16,   379,
     380,   387,   128,    10,    10,    98,    98,    10,    26,    10,
     898,   364,   364,    98,   206,   207,    10,    17,   758,  1144,
     212,    17,   214,   215,   623,   364,   364,   364,   220,   769,
     770,   771,   772,   225,    98,   712,  1633,    98,  1633,  1633,
     232,   233,   451,  1475,  1130,  1229,  1230,   239,  1232,    98,
      10,   243,  1236,   101,  1138,   908,   102,    98,   102,    12,
      98,   612,   254,   255,    10,    18,    10,     8,  1105,   922,
      62,    12,   264,   265,   266,   267,    17,    72,   929,    32,
     128,    99,   462,  1206,     1,    26,    10,    11,   619,  1576,
     908,    98,    98,    10,    47,    98,    10,    98,    98,    17,
     480,   481,    98,    62,  1536,    65,    66,   299,   466,   820,
      18,    71,   304,  1044,   306,    10,  1200,   826,   310,   311,
      10,    81,   554,   315,   316,   557,  1042,    12,    10,    10,
      10,   842,   843,   128,    84,   172,   128,   552,   553,    47,
      10,   556,    10,   558,    10,    10,   612,    32,   580,   102,
     342,   104,    98,  1585,    98,  1587,    18,  1589,    99,    17,
      22,  1300,    17,    10,   356,  1290,     1,     8,   128,   128,
     617,    12,   364,     8,   705,   367,    11,    12,   128,  1501,
      98,  1503,  1106,  1670,    98,    26,  1508,  1509,  1510,   569,
    1512,  1513,  1514,  1515,   102,   387,   104,    32,   820,   579,
     580,   238,    37,    98,    39,    40,    10,   399,    98,   401,
      10,    17,  1335,   593,   594,   595,    98,   597,    98,   599,
     842,   843,   608,   609,     1,  1712,    36,   419,    98,    10,
      98,   756,    98,    98,     1,    12,   976,  1724,    20,    21,
      98,   433,  1729,    98,  1731,    12,  1733,  1052,  1735,    72,
    1737,    18,  1739,    84,  1107,    32,    10,   666,    99,   451,
    1000,    10,     1,    10,    17,    32,   101,   459,     1,    10,
      44,    45,   464,    80,    10,    10,   685,    16,    98,    12,
      47,    48,  1714,   663,   809,    18,  1411,  1105,    98,   669,
      10,    98,    98,   128,  1616,   487,    10,   128,    98,    32,
     680,    38,  1624,   661,    22,   128,    36,   665,   833,    46,
      47,    48,    49,  1438,    47,    48,     1,    98,    95,    96,
      97,   701,   702,   755,     8,    10,   684,  1450,    12,  1719,
    1367,   746,    16,   100,    10,   102,   751,   104,    10,     1,
      10,     1,    26,  1380,    98,    98,    17,     7,     8,    98,
      12,    98,    12,    13,    14,    10,    16,    98,   738,   126,
      20,    21,    98,    98,   556,    25,   103,   104,    98,   102,
      32,   104,    32,    18,    34,    35,   808,    37,    98,   571,
     572,    10,    18,    10,    98,   817,   818,    10,     8,   126,
      72,   583,    12,   126,  1247,   587,    16,   829,   864,   814,
      10,    13,    14,  1143,  1144,     8,    26,    13,    14,    12,
     602,    12,    15,    16,    26,    99,   608,   609,    10,  1240,
      26,  1226,    98,    26,    16,   617,    98,    98,    98,  1247,
    1556,    32,  1039,    95,    96,    97,   816,    29,    98,    59,
     820,  1150,    11,    98,   969,    36,   128,   982,   983,   816,
      84,   986,   987,    84,  1378,    18,     1,    12,     3,    22,
       7,     6,   842,   843,   999,    12,    16,    12,    36,    98,
      15,    98,   132,   133,   666,    98,  1602,    32,  1604,    99,
      17,    17,    64,   898,    34,    32,    98,    32,    98,    17,
    1015,    46,    98,   685,    95,    96,    99,   128,    10,  1536,
     692,    46,    47,    48,    49,    50,    51,    98,    17,    17,
       3,  1036,    57,  1038,    17,    60,    61,    17,    63,    12,
      65,    66,    72,  1048,    84,    18,    71,   885,   908,    17,
      98,   889,    22,    23,   892,   893,    81,    87,   896,    32,
    1345,     1,   922,   923,   736,   128,   738,   739,  1014,  1367,
    1290,   909,    12,    46,    36,  1295,     1,   749,    18,   104,
     918,    98,    98,   108,   114,   115,   758,   947,   128,   949,
      98,    16,    32,   123,    84,    62,   126,   769,   770,   771,
     772,   126,     1,   128,    22,    23,    46,    47,    48,    98,
      98,   141,     3,    12,    17,    98,  1719,    39,    98,    18,
      17,    12,  1725,  1035,    46,  1037,    10,    18,     1,   102,
      98,  1096,    16,    32,   806,  1468,    98,    84,   128,    12,
      17,    32,  1475,    16,  1039,    18,    37,   819,    47,    48,
    1039,    17,    17,   825,    29,    46,    29,     8,   830,    32,
      17,    12,   102,  1464,   104,    16,  1245,  1027,    17,  1029,
    1468,    44,    45,    10,     1,    26,   206,     4,     5,   101,
    1027,   853,  1029,    17,   856,   215,   126,   859,  1408,    39,
      40,  1411,  1412,    10,  1106,    98,    17,    47,    48,    17,
    1095,    98,    17,   102,  1209,   104,  1211,    17,    59,   239,
      17,   102,    17,   243,    41,    42,    43,  1222,  1438,  1439,
      10,    98,    17,     8,    17,   255,   898,   126,    84,   102,
     115,   116,    98,    98,   264,   265,   266,    12,  1184,    17,
      17,    98,  1080,    18,    98,  1105,  1251,  1107,    99,    98,
      17,   101,   102,    17,   104,  1588,    16,    32,  1606,  1097,
    1608,  1609,    17,  1123,    98,  1613,    17,  1615,    17,  1129,
    1130,  1619,   128,  1621,   304,  1623,   126,    98,   128,    10,
      98,    17,   954,    98,    17,    16,   316,    17,    98,  1304,
    1588,    98,  1307,    98,   966,  1310,  1311,  1312,  1313,  1314,
    1315,  1316,  1317,    98,   976,    98,    82,   979,     1,   981,
     982,   983,   984,   985,   986,   987,    16,     1,  1213,     1,
      98,    98,   352,    16,   996,   997,   998,   999,  1000,  1522,
      12,    98,    16,   127,    98,   111,    18,  1685,  1250,  1687,
    1012,   117,   118,    98,  1692,    24,  1206,    98,  1123,    98,
      32,  1240,     1,  1358,  1129,     4,     5,    13,    14,  1206,
    1306,    82,    98,    12,     1,    98,  1255,  1039,    98,   399,
    1042,   401,  1044,  1674,  1320,    12,    46,    47,    48,  1051,
      16,    29,    12,    32,  1577,  1578,    34,  1247,    37,  1582,
     111,  1229,  1230,     1,  1232,    32,   117,   118,  1236,     7,
       8,   431,    32,    11,    12,    13,    14,    10,    16,    39,
    1248,    11,    20,    21,    62,     8,    12,    25,    18,    12,
    1092,   451,    22,    10,    32,    12,    34,    35,    22,    37,
      24,     1,   102,    29,   104,  1446,    32,     7,     8,    32,
      47,    48,    12,    13,    14,    32,    16,    65,    66,    10,
      20,    21,    17,    71,    19,    25,   126,    98,  1130,  1131,
    1132,   102,    32,    81,    34,    35,  1378,    37,  1473,  1141,
       8,  1143,  1144,    11,    12,  1335,     8,  1423,    98,    52,
      12,    54,     1,    56,    16,     1,    12,  1159,  1335,   107,
       1,    98,    17,    12,    32,   102,    12,   104,    12,    37,
     530,    12,    16,  1363,   534,   535,    32,  1367,    10,    11,
     128,    37,    82,    32,    16,    29,    32,  1355,    32,   126,
    1380,    32,    98,  1195,   132,   133,    65,    66,    65,    66,
      17,  1203,    71,  1205,    71,  1540,   109,   110,  1210,   112,
    1212,  1213,    81,    17,    81,    84,     1,    84,    11,  1221,
      65,    66,    15,   538,   539,   128,    71,    12,    65,    66,
    1472,    17,   132,   133,    71,  1511,    81,    16,  1240,    84,
    1581,  1243,  1244,  1462,    81,  1464,    18,    32,     8,    18,
    1252,     1,    12,  1255,    24,  1445,  1258,   617,     1,   128,
    1450,   128,    12,  1265,    67,     1,    16,    16,  1445,    12,
      16,  1273,    32,  1450,  1276,  1277,    12,    37,  1468,    29,
      12,    16,    32,   128,    16,  1475,  1288,  1455,  1290,    32,
      16,   128,     1,  1295,    22,     8,    32,    29,    26,    12,
      32,  1469,  1304,    12,    17,  1307,   666,     1,  1310,  1311,
    1312,  1313,  1314,  1315,  1316,  1317,     1,     1,    12,    32,
       1,    16,  1324,    32,    37,   685,     8,    12,    12,     1,
      12,    12,  1522,   109,   110,  1337,   112,  1339,    32,     8,
      12,  1617,  1344,    12,    10,  1522,  1536,    32,    32,     7,
       8,    32,   128,    98,    12,    13,    14,  1359,    16,   162,
      32,    12,    20,    21,   724,    16,   881,    25,   883,  1537,
     730,    29,    16,    31,    32,    16,    34,    35,    29,    37,
      10,    32,    17,   743,    84,    85,    37,  1577,  1578,    52,
      22,    54,  1582,    56,  1584,  1585,    22,  1587,  1588,  1589,
    1577,  1578,    26,    13,    14,  1582,  1408,    17,    12,  1411,
    1412,     8,    70,   216,  1633,    12,    13,    14,    12,    16,
     589,   590,    16,   226,   227,    29,    12,    18,    32,    16,
      16,   887,   888,    37,    10,    32,  1438,  1439,    32,    12,
      37,   244,   245,    16,    13,    14,    32,     1,    17,     3,
      12,   811,     6,    12,    16,  1674,  1458,    16,    12,    32,
    1462,    10,  1464,     1,  1466,    53,     4,     5,    10,  1637,
      32,    17,  1474,    32,   132,   133,  1081,    98,    32,  1084,
    1085,    17,  1672,    10,    38,    39,    40,  1007,  1008,    10,
       5,     4,    46,    47,    48,    49,    50,    51,    98,    53,
      16,    15,    12,    57,    14,    17,    60,    61,  1307,    63,
      15,  1310,  1311,    19,    22,  1314,  1315,  1316,    10,    29,
      80,    31,    32,    80,  1714,    72,    84,    37,    22,  1719,
      17,    85,   335,    87,    98,  1725,    22,    98,    23,  1541,
      50,    24,  1719,    98,   347,   348,    22,   101,  1725,   103,
     104,   129,   106,    19,   108,    65,    66,    67,    68,    69,
      70,    71,    10,    73,    74,    75,    76,    77,    78,    98,
      17,    81,   126,    83,   128,   116,    39,    10,    98,    98,
     940,  1583,    18,     3,    46,    38,    17,    98,   391,    17,
    1592,   981,   395,    10,   984,   985,    98,    19,   958,   959,
     960,    17,    15,    15,    10,    10,   996,   997,   998,    17,
      10,    72,    12,    17,    16,    10,    17,   420,   421,    17,
      17,    98,    10,    98,    10,    19,   429,    10,    10,   432,
      10,  1633,    32,    10,   437,    10,    10,    37,    10,    10,
     443,   444,    86,   446,    22,   448,    16,   450,    16,   452,
      16,    16,    16,    16,   457,    16,    16,    16,    16,  1019,
    1020,  1021,    16,    16,    16,    65,    66,    67,    68,    69,
      70,    71,  1674,   476,    10,    22,   479,    77,    78,  1039,
      22,    81,     0,     1,    10,     3,    10,   490,     6,    22,
     493,    10,  1052,   107,    12,    16,    10,    10,    10,    19,
      17,   504,    17,    19,    10,    10,   509,   510,    10,    10,
     101,  1713,    16,    11,    32,    22,   168,   169,    18,    98,
      38,    39,    40,    10,   527,   528,    36,    10,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    10,    56,    57,
      10,    98,    60,    61,    10,    63,    10,    65,    66,    98,
      10,    16,   204,    71,    16,    16,    19,    38,    10,    31,
      98,    79,    80,    81,    22,   110,    84,    85,    79,    87,
      79,   101,    80,    10,    22,    24,    22,    24,  1138,    18,
      98,    19,    22,   101,   134,   103,   104,    17,   106,   107,
     108,   109,   110,    12,   112,    98,    84,    10,    10,    98,
      55,    98,    98,    98,    98,    98,    98,    98,   126,    98,
     128,    10,    98,    32,    13,    14,   619,   620,    37,   622,
      98,    20,    21,    22,    23,    24,    25,    26,    27,    28,
     633,    64,    58,    55,    17,    34,    35,    24,   641,   642,
    1200,    19,    24,    24,   647,    24,    65,    66,    67,    68,
      69,    70,    71,    16,   134,    24,    24,    17,    77,    78,
      10,    22,    81,    98,    17,    16,  1226,    16,    16,    16,
     673,   323,   675,    10,    10,    59,    22,    22,    16,     1,
    1240,     3,     8,    98,     6,     8,    84,    98,    98,    98,
      12,    98,    98,   345,    98,  1255,    98,    98,    98,    64,
      99,    15,   705,    15,    10,    10,    17,    17,    79,    10,
      32,    10,    64,    17,    10,    15,    38,    39,    40,    10,
      17,    15,    15,    98,    46,    47,    48,    49,    50,    51,
      17,   130,   131,   132,   133,    57,    98,    17,    60,    61,
      98,    63,     7,     8,    10,    17,    10,    12,    13,    14,
      10,    16,    10,    10,   406,    20,    21,    10,    10,    10,
      25,   413,   414,    85,    79,    87,    10,    32,    17,    34,
      35,    17,    37,    81,   426,    17,   428,    10,    10,   101,
      10,   103,   104,    10,   106,  1345,   108,    10,    10,    10,
      10,     1,    10,     3,    10,    10,     6,    10,    15,    10,
      98,    10,    12,    17,   126,    17,   128,   724,    98,    98,
      98,   536,    98,    98,    98,    80,   539,    82,     4,   186,
     186,   364,    32,   826,   825,   364,  1039,   364,    38,    39,
      40,    33,   225,   806,   853,  1012,    46,    47,    48,    49,
      50,    51,    39,  1107,   680,   580,   481,    57,   212,  1243,
      60,    61,   855,    63,   310,   214,   928,   311,   701,  1581,
     702,   949,  1583,  1397,  1129,  1393,   518,   132,   133,   872,
     873,   356,  1597,   525,   315,    85,  1672,    87,   881,  1087,
     883,   779,  1184,   886,   887,   888,  1412,  1300,   891,   983,
    1500,   101,  1611,   103,   104,   873,   106,  1159,   108,  1423,
     622,   633,  1462,    65,  1464,     9,   342,   910,    -1,   912,
      -1,    -1,    -1,   916,    -1,    -1,   126,    -1,   128,    -1,
      -1,    -1,    -1,    -1,    -1,   928,    -1,    -1,    -1,   932,
      -1,    -1,     1,    -1,     3,   419,    -1,     6,    -1,    -1,
      -1,    -1,    10,    12,    -1,    13,    14,    -1,    -1,    -1,
      -1,    -1,    20,    21,    22,    23,    24,    25,    26,    27,
      28,   613,    -1,    32,    -1,    -1,    34,    35,    -1,    38,
      39,    40,    -1,    -1,   626,   978,   628,    46,    47,    48,
      49,    50,    51,   635,    -1,   637,    -1,    -1,    57,    -1,
      -1,    60,    61,   645,    63,    -1,   648,   649,    -1,   651,
      -1,   653,   654,    -1,   656,    -1,   658,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    85,    -1,    87,    -1,
      -1,    -1,   674,    -1,    -1,    -1,    -1,   679,    -1,    -1,
      -1,    99,   101,    -1,   103,   104,    -1,   106,    -1,   108,
      -1,    -1,    -1,    -1,    -1,    -1,   698,    -1,    -1,    -1,
      -1,    -1,   704,    -1,   706,     1,    -1,   126,    -1,   128,
      -1,    -1,   130,   131,   132,   133,    12,   719,    14,    15,
      -1,    -1,    -1,  1633,    -1,    -1,    -1,    -1,  1081,    -1,
      -1,  1084,  1085,    29,    -1,    31,    32,    -1,    -1,    -1,
      -1,    37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    50,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1116,  1674,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    -1,    73,    74,    75,
      76,    77,    78,    -1,    -1,    81,    -1,    83,    84,    -1,
      -1,    -1,    -1,     7,     8,    -1,    -1,  1150,    12,    13,
      14,    -1,    16,    -1,    -1,    -1,    20,    21,    -1,    -1,
      -1,    25,    -1,    -1,    -1,    -1,     3,    -1,    32,     6,
      34,    35,     1,    37,    -1,    12,    -1,    -1,    -1,    -1,
      -1,    -1,   128,    12,    -1,    14,    15,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    32,    -1,    -1,  1201,  1202,
      29,    -1,    31,    32,    -1,    -1,    -1,    -1,    37,    46,
      47,    48,    49,    50,    51,   867,    80,    -1,    82,    -1,
      57,    50,    -1,    60,    61,    -1,    63,   879,   880,    -1,
      -1,    -1,   884,    -1,    -1,    -1,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      -1,     1,    81,    -1,    83,    -1,    -1,    -1,    -1,   911,
      10,   913,    12,    -1,    14,    -1,    -1,   104,   132,   133,
      -1,   108,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,
    1283,    31,    32,    -1,    -1,    -1,    -1,    37,    -1,   126,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   128,
      50,    -1,    -1,    -1,    -1,  1308,  1309,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,
      70,    71,   974,    73,    74,    75,    76,    77,    78,    -1,
      -1,    81,    -1,    83,    -1,    -1,    -1,    -1,    -1,     7,
       8,    -1,    -1,    -1,    12,    13,    14,    -1,    16,     1,
      -1,    -1,    20,    21,    -1,    -1,    -1,    25,    26,    -1,
      12,    -1,    14,    -1,    32,    -1,    34,    35,    -1,    37,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,   128,    31,
      32,    -1,    -1,    -1,    -1,    37,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1047,    -1,    -1,    50,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1061,
      -1,    -1,    -1,    65,    66,    67,    68,    69,    70,    71,
    1072,    73,    74,    75,    76,    77,    78,    95,    96,    81,
      -1,    83,    -1,    -1,    -1,    -1,  1088,    -1,    -1,    -1,
      -1,    -1,    -1,  1446,  1447,  1448,    -1,  1099,  1100,    -1,
      -1,  1103,    -1,    -1,    -1,    -1,    -1,  1460,    -1,    -1,
    1463,    -1,  1465,    -1,   132,   133,    -1,    -1,  1471,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   128,     1,    -1,     3,
      -1,    -1,     6,    -1,    -1,    -1,    -1,    -1,    12,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1501,  1151,
    1503,    -1,  1505,    -1,  1507,  1508,  1509,  1510,    32,  1512,
    1513,  1514,  1515,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    46,    47,    48,    49,    50,    51,    -1,    -1,
    1182,    -1,    -1,    57,    -1,    -1,    60,    61,    -1,    63,
      -1,    65,    66,    -1,    -1,    -1,    -1,    71,    -1,     7,
       8,  1554,    -1,  1556,    12,    13,    14,    81,    16,    -1,
      -1,    -1,    20,    21,    -1,    -1,    -1,    25,    -1,    -1,
      -1,    -1,    -1,    -1,    32,    -1,    34,    35,  1581,    37,
     104,    -1,    -1,  1586,   108,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1602,
      -1,  1604,   126,  1606,   128,  1608,  1609,    -1,  1611,    -1,
    1613,  1263,  1615,  1616,    -1,    -1,  1619,    -1,  1621,    -1,
    1623,  1624,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    95,    96,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1299,    -1,    -1,
      -1,    -1,     1,    -1,     3,    -1,    -1,     6,    -1,    -1,
      -1,    -1,    -1,    12,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   132,   133,    -1,    -1,  1330,  1331,
      -1,    -1,  1685,    32,  1687,    -1,    -1,    -1,    -1,  1692,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    46,    47,    48,
      49,    50,    51,    -1,    -1,    -1,    -1,    -1,    57,    -1,
      -1,    60,    61,    -1,    63,    -1,    65,    66,    -1,    -1,
       7,     8,    71,    -1,    -1,    12,    13,    14,    -1,    16,
      -1,    -1,    81,    20,    21,    -1,    -1,    -1,    25,    -1,
      -1,    -1,    -1,    -1,    -1,    32,    -1,    34,    35,  1401,
      37,    -1,  1404,    -1,    -1,   104,    -1,  1409,    -1,   108,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1428,   126,    -1,   128,
      -1,    -1,    -1,     7,     8,    -1,    -1,    -1,    12,    13,
      14,    -1,    16,    80,    -1,    82,    20,    21,    -1,    -1,
      -1,    25,    -1,    -1,    -1,    -1,    -1,    -1,    32,    -1,
      34,    35,    -1,    37,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,     7,     8,    -1,    -1,    -1,    12,    13,    14,
      -1,    16,    -1,    18,    -1,    20,    21,    -1,  1490,    -1,
      25,  1493,  1494,    -1,    -1,   132,   133,    32,    -1,    34,
      35,    -1,    37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     7,     8,    -1,    -1,    11,    12,
      13,    14,    -1,    16,  1526,  1527,    -1,    20,    21,    -1,
    1532,  1533,    25,  1535,    -1,    -1,    -1,  1539,    -1,    32,
      -1,    34,    35,    -1,    37,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   128,    -1,     7,     8,   132,   133,
    1562,    12,    13,    14,  1566,    16,    -1,    -1,    -1,    20,
      21,    -1,    -1,    -1,    25,    -1,    -1,    -1,    -1,    -1,
      -1,    32,    -1,    34,    35,    -1,    37,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,     7,     8,   132,   133,  1601,
      12,    13,    14,    -1,    16,    17,    -1,    -1,    20,    21,
      -1,    -1,    -1,    25,    -1,    -1,    -1,    -1,    -1,    -1,
      32,    -1,    34,    35,    -1,    37,    -1,    -1,    -1,     7,
       8,    82,    -1,  1635,    12,    13,    14,    -1,    16,   132,
     133,    -1,    20,    21,    -1,    -1,    -1,    25,    -1,    -1,
      -1,    -1,    -1,    -1,    32,    -1,    34,    35,    -1,    37,
       7,     8,    -1,    -1,    -1,    12,    13,    14,    -1,    16,
      -1,    -1,    -1,    20,    21,    -1,    -1,    -1,    25,    -1,
      -1,   132,   133,    -1,    -1,    32,    -1,    34,    35,    -1,
      37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
       7,     8,    -1,    -1,    82,    12,    13,    14,    -1,    16,
      -1,    -1,    -1,    20,    21,    -1,    -1,    -1,    25,     1,
     132,   133,    -1,    -1,    -1,    32,    -1,    34,    35,    -1,
      37,     7,     8,    -1,    16,    -1,    12,    13,    14,    -1,
      16,    -1,    -1,    -1,    20,    21,    -1,    -1,    -1,    25,
      -1,    -1,    -1,    -1,   132,   133,    32,    -1,    34,    35,
      -1,    37,     7,     8,    -1,    -1,    -1,    12,    13,    14,
      -1,    16,    -1,    -1,    -1,    20,    21,    -1,    -1,    -1,
      25,    -1,    -1,    65,    -1,   132,   133,    32,    -1,    34,
      35,    -1,    37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    86,    87,    88,    89,    90,    91,
      92,    93,    94,    -1,    -1,     3,    -1,    -1,     6,    -1,
      -1,    -1,    -1,   105,    12,   132,   133,    -1,    -1,    -1,
      -1,   113,   114,    -1,    -1,    -1,    -1,   119,   120,   121,
     122,   123,   124,   125,    32,    -1,    -1,    -1,    -1,    -1,
      38,    39,    40,    -1,    -1,    -1,   132,   133,    46,    47,
      48,    49,    50,    51,    -1,    -1,    -1,    10,    -1,    57,
      13,    14,    60,    61,    -1,    63,    -1,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    -1,   132,   133,    -1,
      -1,    34,    35,    -1,    -1,    -1,    -1,    85,    -1,    87,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   101,    -1,   103,   104,    -1,   106,    -1,
     108,    13,    14,    15,    -1,    -1,    -1,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,   126,    13,
      14,    15,    34,    35,    -1,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    99,    13,    14,    15,
      34,    35,    -1,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    -1,    -1,    -1,    -1,    -1,    34,    35,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,   131,   132,
     133,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    13,    14,    15,    -1,    -1,    99,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    -1,
      -1,    -1,    -1,    34,    35,    99,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,   131,
     132,   133,    -1,    99,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   130,   131,   132,   133,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   130,   131,   132,   133,    -1,    -1,
      -1,    -1,    -1,    13,    14,    15,    -1,    -1,    99,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      -1,    -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,
     131,   132,   133,    13,    14,    15,    -1,    -1,    -1,    -1,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    13,
      14,    -1,    -1,    -1,    34,    35,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,
      34,    35,    -1,    37,    13,    14,    15,    -1,    -1,    99,
      -1,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    -1,    -1,    -1,    -1,    34,    35,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     130,   131,   132,   133,    -1,    13,    14,    15,    -1,    99,
      -1,    -1,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    -1,    -1,    13,    14,    99,    34,    35,    -1,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
     130,   131,   132,   133,    34,    35,    -1,    -1,    -1,    -1,
      99,    -1,    -1,    13,    14,    15,   130,   131,   132,   133,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      -1,    -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,
      -1,   130,   131,   132,   133,    -1,    -1,    -1,    -1,    13,
      14,    99,    -1,    17,    -1,    -1,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    99,
      34,    35,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   130,   131,   132,   133,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    99,
     130,   131,   132,   133,    13,    14,    -1,    -1,    17,    -1,
      -1,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    -1,    -1,    -1,    -1,    34,    35,    -1,    -1,    -1,
     130,   131,   132,   133,    -1,    99,    -1,    -1,    -1,    13,
      14,    -1,    -1,    17,    -1,    -1,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,
      34,    35,    -1,    -1,    -1,    -1,   130,   131,   132,   133,
      -1,    -1,    -1,    -1,    13,    14,    -1,    -1,    17,    -1,
      -1,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      99,    -1,    -1,    13,    14,    34,    35,    17,    -1,    -1,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      -1,    -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,
      -1,   130,   131,   132,   133,    99,    -1,    -1,    13,    14,
      -1,    -1,    17,    -1,    -1,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,    34,
      35,    -1,    -1,    -1,    -1,    -1,   130,   131,   132,   133,
      99,    -1,    -1,    13,    14,    -1,    -1,    17,    -1,    -1,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    99,
      -1,    -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,
      -1,   130,   131,   132,   133,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     130,   131,   132,   133,    99,    13,    14,    -1,    -1,    17,
      -1,    -1,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    -1,    -1,    -1,    -1,    -1,    34,    35,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   130,   131,   132,   133,    99,
      13,    14,    -1,    -1,    17,    -1,    -1,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,
      -1,    34,    35,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     130,   131,   132,   133,    -1,    13,    14,    -1,    -1,    17,
      -1,    -1,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    99,    -1,    -1,    13,    14,    34,    35,    17,    -1,
      -1,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    -1,    -1,    -1,    -1,    34,    35,    -1,    -1,    -1,
      -1,    -1,   130,   131,   132,   133,    99,    -1,    -1,    13,
      14,    -1,    -1,    17,    -1,    -1,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,
      34,    35,    -1,    -1,    -1,    -1,    -1,   130,   131,   132,
     133,    99,    -1,    -1,    13,    14,    -1,    -1,    17,    -1,
      -1,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      99,    -1,    -1,    -1,    -1,    34,    35,    -1,    -1,    -1,
      -1,    -1,   130,   131,   132,   133,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   130,   131,   132,   133,    99,    13,    14,    -1,    -1,
      17,    -1,    -1,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    -1,    -1,    -1,    -1,    -1,    34,    35,    -1,
      -1,    -1,    -1,    -1,    13,    14,   130,   131,   132,   133,
      99,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    -1,    -1,    -1,    -1,    34,    35,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    13,
      14,   130,   131,   132,   133,    -1,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,
      34,    35,    99,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      12,    -1,    14,    -1,    -1,    -1,    -1,    -1,    -1,    98,
      99,    -1,    -1,   130,   131,   132,   133,    29,    -1,    31,
      32,    -1,    -1,    -1,    -1,    37,    38,    39,    40,    -1,
      -1,    -1,    -1,    -1,    46,    47,    48,    49,    50,    -1,
      -1,   130,   131,   132,   133,    99,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    65,    66,    67,    68,    69,    70,    71,
      -1,    73,    74,    75,    76,    77,    78,    -1,    12,    81,
      14,    83,    -1,    -1,    -1,    -1,   130,   131,   132,   133,
      -1,    -1,    -1,    -1,    -1,    29,    -1,    31,    32,   101,
      -1,   103,   104,    37,    38,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    46,    47,    48,    49,    50,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   126,    12,    16,    -1,    -1,    -1,
      -1,    65,    66,    67,    68,    69,    70,    71,    -1,    73,
      74,    75,    76,    77,    78,    32,    -1,    81,    -1,    83,
      37,    38,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    46,
      47,    48,    49,    -1,    -1,    -1,    -1,    -1,    -1,   103,
     104,    -1,    -1,    -1,    -1,    65,    -1,    -1,    65,    66,
      67,    68,    69,    70,    71,    -1,    -1,    -1,    -1,    -1,
      77,    78,   126,    -1,    81,    -1,    86,    87,    88,    89,
      90,    91,    92,    93,    94,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   105,   103,   104,    -1,    -1,
      -1,    -1,    -1,   113,   114,    -1,    -1,    -1,    -1,   119,
     120,   121,   122,   123,   124,   125,    -1,    -1,    -1,   126
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned short int yystos[] =
{
       0,   128,   136,   137,   138,   178,   448,     1,    12,    32,
     449,   450,   452,   453,     0,   109,   110,   112,   139,   140,
     141,   143,   144,   154,   155,   308,   448,   154,     3,     6,
      46,    47,    48,    49,    50,    51,    57,    60,    61,    63,
     104,   108,   126,   179,   180,   208,   209,   210,   211,   214,
     215,   217,   218,   243,   251,   270,   277,   278,   330,   334,
     337,   338,   452,   129,   453,    98,   129,    22,    10,   451,
     452,     1,    23,    52,    54,    56,   157,   158,     1,    16,
      44,    45,   212,   213,   221,   222,     1,    16,    29,   221,
     223,   271,   272,   273,   274,   275,   452,     1,   102,   247,
       1,   219,     1,   234,   235,   237,   452,     1,   227,   228,
     229,   452,    16,    37,   221,   223,   335,   336,   426,   443,
     451,   452,     1,   181,     1,   353,   448,   339,     1,   100,
     246,     1,   246,     1,   237,     1,   230,   452,     1,   216,
       1,    16,   221,   279,   282,   289,   290,   331,   332,   333,
     452,   450,     7,     8,    13,    14,    16,    20,    21,    25,
      34,    35,    37,   132,   133,   425,   434,   435,   436,   441,
     445,   446,   451,    10,    11,    10,     7,   142,   451,   309,
     452,   156,   452,    10,    16,    29,   162,   168,   170,    10,
       1,     4,     5,    41,    42,    43,   247,   212,   212,    10,
     276,   443,    16,   226,   436,   437,    16,   223,   272,   275,
     272,    10,    98,    10,    98,    16,    18,   242,    10,   237,
     242,    10,   237,    10,    10,    98,    18,    22,   220,   241,
      10,    10,    98,    98,   220,   426,   427,   428,   452,   223,
     335,   335,    10,    98,    22,    18,   430,    10,   233,   239,
     451,    84,    14,    29,    31,    50,    65,    66,    67,    68,
      69,    70,    71,    73,    74,    75,    76,    77,    78,    81,
      83,   340,   341,   342,   348,   349,   357,   358,   360,   361,
     362,   365,   366,   367,   369,   373,   374,   443,   451,   353,
      62,   252,   452,    64,   247,    10,    10,    10,    10,    98,
      10,   237,    84,   276,    16,   223,   225,   290,   331,    29,
     283,    98,   281,    16,    10,    98,    16,   242,   260,   437,
      20,    21,   433,   436,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    34,    35,    99,   130,   131,   132,   133,
     442,   445,   128,   434,   445,   447,     8,    16,    18,   429,
     430,   447,   127,   145,   452,    24,    16,     1,   159,   160,
     161,   176,   177,   178,   448,     1,    17,   169,   256,   257,
     258,   262,   448,     1,    16,    10,    16,   168,   170,    10,
      10,    17,    98,    98,    17,    17,    17,   260,   247,   247,
      17,    98,   224,   226,   437,    15,   276,   272,    10,    16,
      10,    16,   274,   275,   273,   276,   436,   439,    10,   237,
      10,   235,   431,   436,   436,   241,   452,   452,    36,    98,
      18,   430,   335,    10,    10,   336,   436,   432,   436,    18,
      10,    98,    22,    24,     8,    12,    16,    16,    26,   128,
     452,   347,   443,    16,    16,     1,    16,     1,    16,   353,
      16,    16,    16,   336,   443,   443,   452,    16,     1,    15,
      84,   350,   351,     1,    15,    72,   352,   353,     1,    10,
       1,    10,    10,    10,   353,   354,    22,    23,    10,    16,
      10,    16,    47,    48,   104,   126,   242,   245,   452,    10,
      98,   331,    10,    16,   282,   290,   289,    10,    17,   291,
     292,   293,   294,   295,   448,   332,   276,    17,    36,    98,
      37,    22,    22,    23,    22,    24,    26,    22,   436,   435,
     447,     1,   449,   434,   433,   436,   432,    18,    16,     1,
     148,   451,    82,   111,   117,   118,   146,   147,   149,   150,
      10,   310,   311,   315,   448,   452,    10,    53,   159,   177,
       1,    10,    38,    39,    40,    85,    87,   101,   103,   106,
     182,   188,   194,   195,   198,   201,   296,   376,    17,    10,
       8,    11,    37,   171,   172,   173,   175,   452,    17,    98,
      98,    47,    48,    98,   104,   126,   247,   265,    39,    40,
     101,    17,   163,   161,    10,    10,     1,   161,     1,   161,
       5,     4,   223,   227,   231,   232,   238,   452,   260,   260,
     433,    17,    98,   436,    10,   276,   276,    16,    17,    98,
      15,    10,    15,   220,   428,   432,   436,   432,   436,    10,
      19,    13,    14,    15,    19,   436,   239,   436,   452,   437,
      26,    95,    96,   363,   364,   436,    17,    22,   436,   436,
      80,   436,    80,   436,   436,   347,   436,    10,   436,    84,
     452,   352,    84,   253,   266,   352,   448,    72,     1,   452,
      72,   353,    70,   358,   436,    22,     1,    98,   375,   436,
     254,   255,   257,   266,   352,   448,   256,   244,   452,   433,
      10,     1,    11,   284,   285,   286,   287,   288,   436,   280,
      17,    98,    98,   288,   436,    98,   436,   433,    22,    23,
      24,    22,    15,   435,   129,   129,    17,    19,   432,   436,
     433,    10,    10,   451,   116,   151,   451,   451,   111,   147,
     115,   151,   152,   151,   152,    17,    98,    17,    98,    39,
      10,     1,   102,   189,   242,   265,   444,     3,    46,   203,
     204,   206,   207,   242,   444,   207,   247,     1,    16,    65,
      86,    88,    89,    90,    91,    92,    93,    94,   105,   113,
     114,   119,   120,   121,   122,   123,   124,   125,   194,   377,
     378,   379,   380,   381,   382,   383,   391,   392,   393,   397,
     399,   400,   401,   402,   403,   404,   405,   406,   407,   408,
     409,   410,   411,     1,   236,   240,   242,   452,   207,   247,
       1,   185,   242,   265,   444,     1,   297,    98,    98,    98,
     161,   173,   174,   175,    17,    98,    18,   257,   247,   262,
     265,   452,    46,   259,   452,     3,   261,   261,   261,    38,
     164,   159,   161,   161,   159,   159,   159,   159,    17,    17,
     231,   232,    10,    98,    10,    22,   223,   231,   232,   223,
     231,   232,    17,   226,    15,   276,   433,   436,   438,   431,
      19,    19,    15,    15,   438,    19,    10,    17,    17,   436,
     436,     6,    17,    98,   436,    17,    17,    17,    17,    17,
     359,    10,    17,    17,    84,   266,   352,    84,    46,   182,
     188,   208,   210,   214,   215,   218,   267,    72,   253,   352,
      16,   436,   358,   436,    17,    17,    98,   255,   352,    10,
      62,    17,    10,    16,    17,    17,   452,    17,    98,    98,
      10,   293,   448,   295,   448,   433,    36,   435,    19,    17,
     148,    10,   451,    10,    10,    10,    10,    10,   452,    10,
     312,   316,   448,   452,    46,   452,    10,   233,   192,   190,
     193,   242,   452,    47,   102,   104,   202,   205,   242,   247,
     260,    86,    95,    96,   384,   387,   396,   452,    16,    16,
       1,    16,    16,    16,    16,    16,    16,    16,   384,   385,
     387,     1,   385,   385,     1,   385,    16,    16,    16,    16,
      16,   382,    86,   378,    10,    22,    10,    22,    22,    10,
      10,    10,    98,   236,    22,   247,   260,    10,   233,   183,
     184,   186,   242,   107,    65,    66,    71,    81,   178,   298,
     300,   301,   302,   305,   307,   207,   247,   207,   247,    39,
     452,   159,    16,    36,    98,   172,   432,   436,   259,   247,
     452,   260,   165,    17,    98,   159,   159,    10,    10,   238,
     452,   436,   231,    10,    10,   232,    10,    10,   437,    17,
      19,    19,   436,   440,   440,   363,   363,     1,   354,     1,
      82,   370,   371,   433,   370,   370,   353,    17,   436,   354,
     353,    84,   242,   268,   269,   444,   452,   352,    72,   436,
     436,    10,    10,   436,    62,    10,   101,   248,   249,   263,
     264,   266,   448,   250,   448,    10,    16,   286,   288,    17,
      36,    15,   153,   313,   314,   315,   316,   317,   448,   313,
      98,    98,   101,   452,    10,   233,   233,   233,   191,   452,
     260,   196,    26,    98,   386,   398,   445,    22,   384,   387,
      18,   436,     1,    95,    96,    97,   387,   415,   417,   419,
     420,   423,    10,     1,   415,   417,   418,   418,   415,   415,
     417,   417,    10,    10,    10,    10,    10,    10,   415,   415,
     415,   417,   384,   387,    16,   388,   389,   390,   437,   388,
     388,   240,    10,   437,   260,   199,    10,   233,   233,   233,
     187,    16,    16,    16,     1,    15,   298,   107,   300,   247,
     260,   247,   260,   206,   336,   452,    17,   173,   175,    19,
      19,   260,   259,   452,   239,    38,   167,    10,    10,    79,
      79,    80,    15,   354,    80,   371,    15,    80,    80,   361,
      10,   268,    10,    98,   242,   220,    72,   253,   352,     1,
      46,   247,   265,   249,   355,   448,    10,    98,    98,    17,
      98,   264,    17,   436,   110,    57,    58,   314,   318,   319,
     322,    10,    10,    98,    10,    10,    98,    46,   318,   316,
     452,   452,   452,    22,    10,    10,    10,   233,   197,   452,
      24,   387,   385,    22,    26,    24,    26,    22,   432,   436,
      17,    17,    19,    18,    98,   423,   134,    98,    98,    98,
      98,    98,    98,    98,    98,    98,    98,    98,    26,    22,
      16,   389,   390,   437,   200,   452,    10,    10,    10,   233,
     436,   436,   306,   452,    84,   452,    84,   260,   452,   260,
     452,   452,    17,   452,   260,   166,   239,   354,   354,   354,
     354,   347,    10,   269,   268,   352,    62,    10,   247,   260,
     452,    64,    65,    69,    70,    71,    78,    81,   343,   345,
     356,   360,   368,   369,   372,   374,   443,   264,   101,   452,
      10,   264,    17,     1,   452,     1,     8,    12,    16,    26,
      99,   320,   321,   324,   325,   329,    55,    58,   452,   452,
      55,   436,    10,   452,   385,    17,    24,    24,    16,   387,
     394,    24,    24,    19,    19,   382,   391,     8,    12,   421,
     422,   416,   417,   134,   424,   437,   416,   414,   436,   414,
     416,   416,   417,   417,   416,   416,   416,   417,    24,    24,
     390,    17,    98,   452,    10,    17,    17,    10,    22,     1,
     298,   452,   452,   452,   239,    17,    10,    62,   260,   452,
      16,   355,   448,    16,    16,    16,    15,    84,   253,   352,
      10,    22,    46,   247,   265,   253,   355,    10,    22,    59,
     329,    59,   321,    15,   325,   329,    16,   320,    17,   445,
     387,    17,   445,   385,   387,   394,     8,    12,     8,    19,
      98,    98,   424,    98,    17,    98,    17,    98,    98,    98,
      98,    98,    98,    98,    98,    98,   385,   387,   390,    10,
     299,   300,    82,   303,   304,   433,   436,   436,    84,    84,
     353,   452,   436,   436,   347,   436,   452,   352,    84,   436,
     247,   260,   452,   355,    64,     8,   323,    17,   329,   326,
     328,   329,   329,    59,    15,   445,    15,   445,   421,   414,
     414,    10,   436,    10,   412,   413,   436,   414,   414,   414,
     437,   414,   414,   414,   414,    17,    98,    79,    15,   299,
      80,    98,    15,    10,    17,    17,    10,    17,   253,   346,
     355,    84,   260,   452,    64,    10,    17,    15,    10,    17,
     395,   436,    15,   395,    15,    17,    98,    17,    98,    98,
      17,    98,    17,    98,    17,    98,    98,    98,    17,    98,
      17,    98,    17,    98,    98,   390,   299,   299,   304,   299,
     306,   344,   355,   448,   355,   436,   355,   352,    84,   355,
     452,    14,   327,   328,   329,    17,   395,    17,   395,    10,
     412,    10,   412,   412,    10,   413,    10,   412,    10,   412,
     414,   437,    10,   412,    10,   412,    10,   412,   414,    17,
      98,    17,    79,    10,    10,    84,    10,    17,    17,    17,
      17,    17,    17,    17,    17,    98,    17,    98,    17,    17,
      17,    17,    98,   390,    81,   344,   347,    17,    10,    10,
      10,    10,    10,    10,   412,    10,   412,    10,    10,    10,
      10,   412,    98,    15,    17,    17,    17,    17,   390,   452,
     355,    10,    10,    10,    98,   298,   390,    84,    17,    98,
     390,    98,   390,    98,   390,    98,   390,    98,   390,    98,
     390,    17
};


/* Prevent warning if -Wmissing-prototypes.  */
int yyparse (void);

/* Error token number */
#define YYTERROR 1

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */


#define YYRHSLOC(Rhs, K) ((Rhs)[K].yystate.yyloc)
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (N)								\
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (0)

/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# define YY_LOCATION_PRINT(File, Loc)			\
    fprintf (File, "%d.%d-%d.%d",			\
             (Loc).first_line, (Loc).first_column,	\
             (Loc).last_line,  (Loc).last_column)
#endif


#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */
#define YYLEX yylex ()

YYSTYPE yylval;

YYLTYPE yylloc;

int yynerrs;
int yychar;

static const int YYEOF = 0;
static const int YYEMPTY = -2;

typedef enum { yyok, yyaccept, yyabort, yyerr } YYRESULTTAG;

#define YYCHK(YYE)							     \
   do { YYRESULTTAG yyflag = YYE; if (yyflag != yyok) return yyflag; }	     \
   while (0)

#if YYDEBUG

#if ! defined (YYFPRINTF)
#  define YYFPRINTF fprintf
#endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");

# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr,					\
                  Type, Value, Location);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;

#else /* !YYDEBUG */

# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)

#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYMAXDEPTH * sizeof (GLRStackItem)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

/* Minimum number of free items on the stack allowed after an
   allocation.  This is to allow allocation and initialization
   to be completed by functions that call yyexpandGLRStack before the
   stack is expanded, thus insuring that all necessary pointers get
   properly redirected to new data. */
#define YYHEADROOM 2

#ifndef YYSTACKEXPANDABLE
# if (! defined (__cplusplus) \
      || (defined (YYLTYPE_IS_TRIVIAL) && YYLTYPE_IS_TRIVIAL \
	  && defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL))
#  define YYSTACKEXPANDABLE 1
# else
#  define YYSTACKEXPANDABLE 0
# endif
#endif

#if YYERROR_VERBOSE

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static size_t
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      size_t yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return strlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

#endif /* !YYERROR_VERBOSE */

/** State numbers, as in LALR(1) machine */
typedef int yyStateNum;

/** Rule numbers, as in LALR(1) machine */
typedef int yyRuleNum;

/** Grammar symbol */
typedef short int yySymbol;

/** Item references, as in LALR(1) machine */
typedef short int yyItemNum;

typedef struct yyGLRState yyGLRState;
typedef struct yySemanticOption yySemanticOption;
typedef union yyGLRStackItem yyGLRStackItem;
typedef struct yyGLRStack yyGLRStack;
typedef struct yyGLRStateSet yyGLRStateSet;

struct yyGLRState {
  /** Type tag: always true. */
  yybool yyisState;
  /** Type tag for yysemantics. If true, yysval applies, otherwise
   *  yyfirstVal applies. */
  yybool yyresolved;
  /** Number of corresponding LALR(1) machine state. */
  yyStateNum yylrState;
  /** Preceding state in this stack */
  yyGLRState* yypred;
  /** Source position of the first token produced by my symbol */
  size_t yyposn;
  union {
    /** First in a chain of alternative reductions producing the
     *  non-terminal corresponding to this state, threaded through
     *  yynext. */
    yySemanticOption* yyfirstVal;
    /** Semantic value for this state. */
    YYSTYPE yysval;
  } yysemantics;
  /** Source location for this state. */
  YYLTYPE yyloc;
};

struct yyGLRStateSet {
  yyGLRState** yystates;
  size_t yysize, yycapacity;
};

struct yySemanticOption {
  /** Type tag: always false. */
  yybool yyisState;
  /** Rule number for this reduction */
  yyRuleNum yyrule;
  /** The last RHS state in the list of states to be reduced. */
  yyGLRState* yystate;
  /** Next sibling in chain of options. To facilitate merging,
   *  options are chained in decreasing order by address. */
  yySemanticOption* yynext;
};

/** Type of the items in the GLR stack. The yyisState field
 *  indicates which item of the union is valid. */
union yyGLRStackItem {
  yyGLRState yystate;
  yySemanticOption yyoption;
};

struct yyGLRStack {
  int yyerrState;
  /* To compute the location of the error token.  */
  yyGLRStackItem yyerror_range[3];

  yySymbol* yytokenp;
  YYJMP_BUF yyexception_buffer;
  yyGLRStackItem* yyitems;
  yyGLRStackItem* yynextFree;
  size_t yyspaceLeft;
  yyGLRState* yysplitPoint;
  yyGLRState* yylastDeleted;
  yyGLRStateSet yytops;
};

static void yyexpandGLRStack (yyGLRStack* yystack);

static void yyFail (yyGLRStack* yystack, const char* yymsg)
  __attribute__ ((__noreturn__));
static void
yyFail (yyGLRStack* yystack, const char* yymsg)
{
  if (yymsg != NULL)
    yyerror (yymsg);
  YYLONGJMP (yystack->yyexception_buffer, 1);
}

static void yyMemoryExhausted (yyGLRStack* yystack)
  __attribute__ ((__noreturn__));
static void
yyMemoryExhausted (yyGLRStack* yystack)
{
  YYLONGJMP (yystack->yyexception_buffer, 2);
}

#if YYDEBUG || YYERROR_VERBOSE
/** A printable representation of TOKEN.  */
static inline const char*
yytokenName (yySymbol yytoken)
{
  if (yytoken == YYEMPTY)
    return "";

  return yytname[yytoken];
}
#endif

/** Fill in YYVSP[YYLOW1 .. YYLOW0-1] from the chain of states starting
 *  at YYVSP[YYLOW0].yystate.yypred.  Leaves YYVSP[YYLOW1].yystate.yypred
 *  containing the pointer to the next state in the chain. Assumes
 *  YYLOW1 < YYLOW0.  */
static void yyfillin (yyGLRStackItem *, int, int) __attribute__ ((__unused__));
static void
yyfillin (yyGLRStackItem *yyvsp, int yylow0, int yylow1)
{
  yyGLRState* s;
  int i;
  s = yyvsp[yylow0].yystate.yypred;
  for (i = yylow0-1; i >= yylow1; i -= 1)
    {
      YYASSERT (s->yyresolved);
      yyvsp[i].yystate.yyresolved = yytrue;
      yyvsp[i].yystate.yysemantics.yysval = s->yysemantics.yysval;
      yyvsp[i].yystate.yyloc = s->yyloc;
      s = yyvsp[i].yystate.yypred = s->yypred;
    }
}

/* Do nothing if YYNORMAL or if *YYLOW <= YYLOW1.  Otherwise, fill in
   YYVSP[YYLOW1 .. *YYLOW-1] as in yyfillin and set *YYLOW = YYLOW1.
   For convenience, always return YYLOW1.  */
static inline int yyfill (yyGLRStackItem *, int *, int, yybool)
     __attribute__ ((__unused__));
static inline int
yyfill (yyGLRStackItem *yyvsp, int *yylow, int yylow1, yybool yynormal)
{
  if (!yynormal && yylow1 < *yylow)
    {
      yyfillin (yyvsp, *yylow, yylow1);
      *yylow = yylow1;
    }
  return yylow1;
}

/** Perform user action for rule number YYN, with RHS length YYRHSLEN,
 *  and top stack item YYVSP.  YYLVALP points to place to put semantic
 *  value ($$), and yylocp points to place for location information
 *  (@$). Returns yyok for normal return, yyaccept for YYACCEPT,
 *  yyerr for YYERROR, yyabort for YYABORT. */
static YYRESULTTAG
yyuserAction (yyRuleNum yyn, int yyrhslen, yyGLRStackItem* yyvsp,
	      YYSTYPE* yyvalp,
	      YYLTYPE* YYOPTIONAL_LOC (yylocp),
	      yyGLRStack* yystack
              )
{
  yybool yynormal __attribute__ ((__unused__)) =
    (yystack->yysplitPoint == NULL);
  int yylow;

# undef yyerrok
# define yyerrok (yystack->yyerrState = 0)
# undef YYACCEPT
# define YYACCEPT return yyaccept
# undef YYABORT
# define YYABORT return yyabort
# undef YYERROR
# define YYERROR return yyerrok, yyerr
# undef YYRECOVERING
# define YYRECOVERING (yystack->yyerrState != 0)
# undef yyclearin
# define yyclearin (yychar = *(yystack->yytokenp) = YYEMPTY)
# undef YYFILL
# define YYFILL(N) yyfill (yyvsp, &yylow, N, yynormal)
# undef YYBACKUP
# define YYBACKUP(Token, Value)						     \
  return yyerror (YY_("syntax error: cannot back up")),     \
	 yyerrok, yyerr

  yylow = 1;
  if (yyrhslen == 0)
    *yyvalp = yyval_default;
  else
    *yyvalp = yyvsp[YYFILL (1-yyrhslen)].yystate.yysemantics.yysval;
  YYLLOC_DEFAULT (*yylocp, yyvsp - yyrhslen, yyrhslen);
  yystack->yyerror_range[1].yystate.yyloc = *yylocp;

  switch (yyn)
    {
        case 3:
#line 130 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {identVerilog.resize(0);;}
    break;

  case 5:
#line 131 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {identVerilog.resize(0);;}
    break;

  case 36:
#line 212 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 52:
#line 239 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
                                    yydebug=0; //sets parser in debug mode
                                    if(!parseCode) { 
							              
											 lastModule=VerilogDocGen::makeNewEntry("",Entry::CLASS_SEC,VerilogDocGen::MODULE);
                                            currentVerilog=lastModule;
                                             currentVerilog->protection=Public;
					                         parseModule();
							                 CurrState=VerilogDocGen::STATE_MODULE;
				                             
										    }
                                            else {
											      parseModule();
                                         		  }
                               currVerilogType=0;						       
							   vbufreset();
							 ;}
    break;

  case 53:
#line 258 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
            if(!parseCode){ 
			        int ll=getVerilogLine();
	                currentVerilog->endBodyLine=ll;
			       } 	 
              vbufreset(); 
		   ;}
    break;

  case 54:
#line 264 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currentVerilog=0;vbufreset();;}
    break;

  case 57:
#line 274 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=VerilogDocGen::PORT;;}
    break;

  case 58:
#line 274 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 60:
#line 278 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 61:
#line 278 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 62:
#line 279 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 63:
#line 279 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 64:
#line 280 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 65:
#line 280 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 66:
#line 286 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=VerilogDocGen::PORT;;}
    break;

  case 67:
#line 286 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 68:
#line 287 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 69:
#line 291 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 70:
#line 295 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 71:
#line 296 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 83:
#line 318 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;vbufreset();;}
    break;

  case 84:
#line 319 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;vbufreset();;}
    break;

  case 85:
#line 320 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;vbufreset();;}
    break;

  case 86:
#line 321 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 89:
#line 330 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 90:
#line 331 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 93:
#line 334 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 95:
#line 339 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 96:
#line 340 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 97:
#line 341 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 98:
#line 342 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 99:
#line 343 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 100:
#line 344 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 101:
#line 345 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 110:
#line 356 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 111:
#line 357 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 112:
#line 358 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 113:
#line 362 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { if(parseCode) currVerilogType=VerilogDocGen::DEFPARAM;;}
    break;

  case 114:
#line 362 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); if(parseCode) currVerilogType=0; ;}
    break;

  case 115:
#line 363 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); if(parseCode) currVerilogType=0;;}
    break;

  case 116:
#line 371 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 117:
#line 371 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 118:
#line 372 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 119:
#line 372 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 120:
#line 373 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 121:
#line 373 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 122:
#line 374 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 123:
#line 374 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 124:
#line 375 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 125:
#line 375 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 127:
#line 379 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 128:
#line 379 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 129:
#line 380 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 130:
#line 380 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 131:
#line 381 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 132:
#line 381 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 133:
#line 382 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 134:
#line 382 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 135:
#line 383 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 136:
#line 383 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 137:
#line 384 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 138:
#line 387 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 139:
#line 388 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 141:
#line 396 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INOUT; ;}
    break;

  case 142:
#line 396 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 143:
#line 397 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INOUT; ;}
    break;

  case 144:
#line 397 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 145:
#line 398 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 146:
#line 399 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 147:
#line 402 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT; ;}
    break;

  case 148:
#line 402 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 149:
#line 403 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT; ;}
    break;

  case 150:
#line 403 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 151:
#line 404 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 152:
#line 405 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 153:
#line 410 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT; ;}
    break;

  case 154:
#line 410 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 155:
#line 411 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT; ;}
    break;

  case 156:
#line 411 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 157:
#line 413 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT; ;}
    break;

  case 158:
#line 413 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 160:
#line 416 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 161:
#line 417 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 162:
#line 418 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 173:
#line 446 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 174:
#line 447 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 177:
#line 454 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 179:
#line 459 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 180:
#line 460 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 181:
#line 461 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 182:
#line 462 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 183:
#line 463 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 184:
#line 464 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 185:
#line 465 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 186:
#line 466 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 187:
#line 467 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 188:
#line 468 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 189:
#line 469 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 194:
#line 482 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currVerilogType=0;;}
    break;

  case 195:
#line 483 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 196:
#line 485 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::TIME; ;}
    break;

  case 197:
#line 485 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currVerilogType=0;;}
    break;

  case 198:
#line 486 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 199:
#line 489 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 200:
#line 490 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 201:
#line 491 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 202:
#line 494 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::TIME; ;}
    break;

  case 203:
#line 494 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currVerilogType=0;;}
    break;

  case 204:
#line 495 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 213:
#line 524 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 220:
#line 543 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 221:
#line 546 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 222:
#line 547 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 238:
#line 586 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {
                                                                   							parseReg(currentVerilog);}
																							vbufreset();;}
    break;

  case 239:
#line 589 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) parseReg(currentVerilog);vbufreset();;}
    break;

  case 240:
#line 597 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 241:
#line 599 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
                          			 if(currVerilogType==VerilogDocGen::PARAMETER && !parseCode)
									 parseParam(currentVerilog);
									 vbufreset();
	                   ;}
    break;

  case 245:
#line 628 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog)
						                                {
														  currentFunctionVerilog->endBodyLine=getVerilogPrevLine();
														} vbufreset(); ;}
    break;

  case 246:
#line 636 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog){currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset(); ;}
    break;

  case 248:
#line 640 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 249:
#line 644 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {  if(!parseCode){
                             //    printf("\n  funcname [%s] --\n",getVerilogString());
                                 currentFunctionVerilog=VerilogDocGen::makeNewEntry("",Entry::FUNCTION_SEC,VerilogDocGen::FUNCTION);
								 currentFunctionVerilog->fileName=getVerilogParsingFile();
								 parseFunction(currentFunctionVerilog);
								 CurrState=VerilogDocGen::STATE_FUNCTION;
								 }
								 vbufreset();
							   ;}
    break;

  case 263:
#line 680 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;;}
    break;

  case 266:
#line 694 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog) { currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset();;}
    break;

  case 268:
#line 698 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog) { currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset();;}
    break;

  case 269:
#line 700 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog) { currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset();;}
    break;

  case 270:
#line 701 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 271:
#line 704 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {  if(!parseCode){
                             //    printf("\n  funcname [%s] --\n",getVerilogString());
                                 currentFunctionVerilog=VerilogDocGen::makeNewEntry("",Entry::FUNCTION_SEC,VerilogDocGen::TASK);
								 currentFunctionVerilog->fileName=getVerilogParsingFile();
								 parseFunction(currentFunctionVerilog);
								 CurrState=VerilogDocGen::STATE_FUNCTION;
								 }
								 vbufreset();
							   ;}
    break;

  case 281:
#line 740 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
                             if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                     ;}
    break;

  case 282:
#line 745 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                      ;}
    break;

  case 283:
#line 749 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                       ;}
    break;

  case 284:
#line 754 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
                             if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                   ;}
    break;

  case 285:
#line 759 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
                             if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                    ;}
    break;

  case 292:
#line 777 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode )currVerilogType=VerilogDocGen::INOUT;;}
    break;

  case 293:
#line 778 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode)currVerilogType=VerilogDocGen::OUTPUT;;}
    break;

  case 294:
#line 779 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode)currVerilogType=VerilogDocGen::INPUT;;}
    break;

  case 295:
#line 780 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode){parsePortDir(currentVerilog,3);vbufreset();};}
    break;

  case 298:
#line 788 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 299:
#line 789 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 300:
#line 790 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 301:
#line 791 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 302:
#line 792 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 303:
#line 793 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 304:
#line 794 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 305:
#line 795 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 318:
#line 819 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 319:
#line 820 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 320:
#line 821 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 330:
#line 842 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 343:
#line 884 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { 
                    						;}
    break;

  case 344:
#line 885 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 346:
#line 886 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 354:
#line 900 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 357:
#line 907 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { ;}
    break;

  case 359:
#line 912 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 360:
#line 913 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 361:
#line 917 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); currVerilogType=0;;}
    break;

  case 362:
#line 918 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); currVerilogType=0;;}
    break;

  case 363:
#line 921 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { 
                            const char *name=(((yyGLRStackItem const *)yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.cstr);
                            QCString first(name);
							QCString sec(getVerilogString());
						     QCString ll=getLastLetter();
							
							 parseModuleInst(first,sec);
							     if(parseCode){
							  currVerilogType=VerilogDocGen::COMPONENT;
							  vbufreset();
							  }
							  ;}
    break;

  case 372:
#line 963 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {CurrState=VerilogDocGen::STATE_GENERATE;generateItem=true;;}
    break;

  case 373:
#line 963 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {CurrState=0;generateItem=false;;}
    break;

  case 374:
#line 964 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {CurrState=0;generateItem=false;;}
    break;

  case 379:
#line 977 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 380:
#line 978 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 381:
#line 979 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 382:
#line 980 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 383:
#line 981 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 396:
#line 1009 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 397:
#line 1010 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 398:
#line 1019 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currentVerilog=0;;}
    break;

  case 400:
#line 1025 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode) { 
							               //  printf("\n  name_of_mod [%s] [%d]--\n",getVerilogString(),getVerilogLine());
                                            lastModule=VerilogDocGen::makeNewEntry("",Entry::CLASS_SEC,VerilogDocGen::MODULE);
                                             currentVerilog=lastModule;
                                             currentVerilog->protection=Private;
					                        //  currentVerilog->stat=TRUE;
					                         parseModule();
							                 CurrState=VerilogDocGen::STATE_MODULE;

										    }
                                            else {
											      parseModule();
                                              //    currVerilogType=VerilogDocGen::MODULE;
												  }
						        vbufreset();
							 ;}
    break;

  case 401:
#line 1047 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 402:
#line 1048 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 413:
#line 1069 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 414:
#line 1070 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 415:
#line 1071 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 416:
#line 1072 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 417:
#line 1075 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 418:
#line 1076 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 419:
#line 1078 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) parseReg(currentVerilog);vbufreset();;}
    break;

  case 420:
#line 1079 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) parseReg(currentVerilog);vbufreset();;}
    break;

  case 422:
#line 1089 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 423:
#line 1090 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 424:
#line 1091 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 429:
#line 1104 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 430:
#line 1105 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 431:
#line 1108 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr);writeDigit(); ;}
    break;

  case 443:
#line 1133 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr);writeDigit(); ;}
    break;

  case 462:
#line 1178 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 463:
#line 1179 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();  ;}
    break;

  case 464:
#line 1182 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
                               currVerilogType=VerilogDocGen::ALWAYS;
                     		   ;}
    break;

  case 465:
#line 1184 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
                                            if(!parseCode && currentFunctionVerilog)
											 {
											  currentFunctionVerilog->endBodyLine=getVerilogEndLine();
											  if( currentFunctionVerilog->endBodyLine<currentFunctionVerilog->startLine || c_lloc.first_line>currentFunctionVerilog->endBodyLine ) // awlays without end
											   currentFunctionVerilog->endBodyLine=c_lloc.first_line;
											  currVerilogType=0;
											  } vbufreset();;}
    break;

  case 466:
#line 1192 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();currVerilogType=0;;}
    break;

  case 470:
#line 1199 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 474:
#line 1205 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 496:
#line 1257 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currVerilogType==VerilogDocGen::ALWAYS)parseAlways(true);;}
    break;

  case 503:
#line 1266 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
                                            if(!parseCode){
                                             if(currentFunctionVerilog && currentFunctionVerilog->spec==VerilogDocGen::ALWAYS){
                                             VerilogDocGen::adjustMemberName(prevName); 
                                             currentFunctionVerilog->name=prevName;
                                            }
                                          }
                                         ;}
    break;

  case 516:
#line 1294 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 531:
#line 1321 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 534:
#line 1326 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 535:
#line 1326 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 537:
#line 1332 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 538:
#line 1333 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 539:
#line 1334 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 540:
#line 1335 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 541:
#line 1336 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 557:
#line 1375 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 559:
#line 1377 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 561:
#line 1379 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 583:
#line 1431 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 584:
#line 1432 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 585:
#line 1436 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 586:
#line 1437 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 587:
#line 1441 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 588:
#line 1442 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 589:
#line 1443 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 590:
#line 1444 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 591:
#line 1445 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 780:
#line 1858 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr);writeDigit(); ;}
    break;

  case 781:
#line 1859 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {if(parseCode) {writePrevVerilogWords(identVerilog);writeVerilogFont("vhdllogic",identVerilog.data());identVerilog.resize(0);};}
    break;

  case 782:
#line 1870 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 783:
#line 1871 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 785:
#line 1875 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 786:
#line 1876 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 792:
#line 1888 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
										 ;}
    break;

  case 793:
#line 1892 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    { parseString(); ;}
    break;

  case 794:
#line 1895 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {
                    	//if(parseCode) 
						      identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr); 
						  //    fprintf(stderr,"\n String: %s",identVerilog.data());
							 ;}
    break;

  case 795:
#line 1900 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;


      default: break;
    }

  return yyok;
# undef yyerrok
# undef YYABORT
# undef YYACCEPT
# undef YYERROR
# undef YYBACKUP
# undef yyclearin
# undef YYRECOVERING
/* Line 872 of glr.c.  */
#line 5342 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.cpp"
}


static void
yyuserMerge (int yyn, YYSTYPE* yy0, YYSTYPE* yy1)
{
  /* `Use' the arguments.  */
  (void) yy0;
  (void) yy1;

  switch (yyn)
    {
      
      default: break;
    }
}

			      /* Bison grammar-table manipulation.  */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
        break;
    }
}

/** Number of symbols composing the right hand side of rule #RULE.  */
static inline int
yyrhsLength (yyRuleNum yyrule)
{
  return yyr2[yyrule];
}

static void
yydestroyGLRState (char const *yymsg, yyGLRState *yys)
{
  if (yys->yyresolved)
    yydestruct (yymsg, yystos[yys->yylrState],
		&yys->yysemantics.yysval, &yys->yyloc);
  else
    {
#if YYDEBUG
      if (yydebug)
	{
	  YYFPRINTF (stderr, "%s unresolved ", yymsg);
	  yysymprint (stderr, yystos[yys->yylrState],
		      &yys->yysemantics.yysval, &yys->yyloc);
	  YYFPRINTF (stderr, "\n");
	}
#endif

      if (yys->yysemantics.yyfirstVal)
        {
          yySemanticOption *yyoption = yys->yysemantics.yyfirstVal;
          yyGLRState *yyrh;
          int yyn;
          for (yyrh = yyoption->yystate, yyn = yyrhsLength (yyoption->yyrule);
               yyn > 0;
               yyrh = yyrh->yypred, yyn -= 1)
            yydestroyGLRState (yymsg, yyrh);
        }
    }
}

/** Left-hand-side symbol for rule #RULE. */
static inline yySymbol
yylhsNonterm (yyRuleNum yyrule)
{
  return yyr1[yyrule];
}

#define yyis_pact_ninf(yystate) \
  ((yystate) == YYPACT_NINF)

/** True iff LR state STATE has only a default reduction (regardless
 *  of token). */
static inline yybool
yyisDefaultedState (yyStateNum yystate)
{
  return yyis_pact_ninf (yypact[yystate]);
}

/** The default reduction for STATE, assuming it has one. */
static inline yyRuleNum
yydefaultAction (yyStateNum yystate)
{
  return yydefact[yystate];
}

#define yyis_table_ninf(yytable_value) \
  0

/** Set *YYACTION to the action to take in YYSTATE on seeing YYTOKEN.
 *  Result R means
 *    R < 0:  Reduce on rule -R.
 *    R = 0:  Error.
 *    R > 0:  Shift to state R.
 *  Set *CONFLICTS to a pointer into yyconfl to 0-terminated list of
 *  conflicting reductions.
 */
static inline void
yygetLRActions (yyStateNum yystate, int yytoken,
	        int* yyaction, const short int** yyconflicts)
{
  int yyindex = yypact[yystate] + yytoken;
  if (yyindex < 0 || YYLAST < yyindex || yycheck[yyindex] != yytoken)
    {
      *yyaction = -yydefact[yystate];
      *yyconflicts = yyconfl;
    }
  else if (! yyis_table_ninf (yytable[yyindex]))
    {
      *yyaction = yytable[yyindex];
      *yyconflicts = yyconfl + yyconflp[yyindex];
    }
  else
    {
      *yyaction = 0;
      *yyconflicts = yyconfl + yyconflp[yyindex];
    }
}

static inline yyStateNum
yyLRgotoState (yyStateNum yystate, yySymbol yylhs)
{
  int yyr;
  yyr = yypgoto[yylhs - YYNTOKENS] + yystate;
  if (0 <= yyr && yyr <= YYLAST && yycheck[yyr] == yystate)
    return yytable[yyr];
  else
    return yydefgoto[yylhs - YYNTOKENS];
}

static inline yybool
yyisShiftAction (int yyaction)
{
  return 0 < yyaction;
}

static inline yybool
yyisErrorAction (int yyaction)
{
  return yyaction == 0;
}

				/* GLRStates */

static void
yyaddDeferredAction (yyGLRStack* yystack, yyGLRState* yystate,
		     yyGLRState* rhs, yyRuleNum yyrule)
{
  yySemanticOption* yynewItem;
  yynewItem = &yystack->yynextFree->yyoption;
  yystack->yyspaceLeft -= 1;
  yystack->yynextFree += 1;
  yynewItem->yyisState = yyfalse;
  yynewItem->yystate = rhs;
  yynewItem->yyrule = yyrule;
  yynewItem->yynext = yystate->yysemantics.yyfirstVal;
  yystate->yysemantics.yyfirstVal = yynewItem;
  if (yystack->yyspaceLeft < YYHEADROOM)
    yyexpandGLRStack (yystack);
}

				/* GLRStacks */

/** Initialize SET to a singleton set containing an empty stack. */
static yybool
yyinitStateSet (yyGLRStateSet* yyset)
{
  yyset->yysize = 1;
  yyset->yycapacity = 16;
  yyset->yystates = (yyGLRState**) YYMALLOC (16 * sizeof yyset->yystates[0]);
  if (! yyset->yystates)
    return yyfalse;
  yyset->yystates[0] = NULL;
  return yytrue;
}

static void yyfreeStateSet (yyGLRStateSet* yyset)
{
  YYFREE (yyset->yystates);
}

/** Initialize STACK to a single empty stack, with total maximum
 *  capacity for all stacks of SIZE. */
static yybool
yyinitGLRStack (yyGLRStack* yystack, size_t yysize)
{
  yystack->yyerrState = 0;
  yynerrs = 0;
  yystack->yyspaceLeft = yysize;
  yystack->yyitems =
    (yyGLRStackItem*) YYMALLOC (yysize * sizeof yystack->yynextFree[0]);
  if (!yystack->yyitems)
    return yyfalse;
  yystack->yynextFree = yystack->yyitems;
  yystack->yysplitPoint = NULL;
  yystack->yylastDeleted = NULL;
  return yyinitStateSet (&yystack->yytops);
}

#define YYRELOC(YYFROMITEMS,YYTOITEMS,YYX,YYTYPE) \
  &((YYTOITEMS) - ((YYFROMITEMS) - (yyGLRStackItem*) (YYX)))->YYTYPE

/** If STACK is expandable, extend it.  WARNING: Pointers into the
    stack from outside should be considered invalid after this call.
    We always expand when there are 1 or fewer items left AFTER an
    allocation, so that we can avoid having external pointers exist
    across an allocation. */
static void
yyexpandGLRStack (yyGLRStack* yystack)
{
#if YYSTACKEXPANDABLE
  yyGLRStackItem* yynewItems;
  yyGLRStackItem* yyp0, *yyp1;
  size_t yysize, yynewSize;
  size_t yyn;
  yysize = yystack->yynextFree - yystack->yyitems;
  if (YYMAXDEPTH <= yysize)
    yyMemoryExhausted (yystack);
  yynewSize = 2*yysize;
  if (YYMAXDEPTH < yynewSize)
    yynewSize = YYMAXDEPTH;
  yynewItems = (yyGLRStackItem*) YYMALLOC (yynewSize * sizeof yynewItems[0]);
  if (! yynewItems)
    yyMemoryExhausted (yystack);
  for (yyp0 = yystack->yyitems, yyp1 = yynewItems, yyn = yysize;
       0 < yyn;
       yyn -= 1, yyp0 += 1, yyp1 += 1)
    {
      *yyp1 = *yyp0;
      if (*(yybool *) yyp0)
	{
	  yyGLRState* yys0 = &yyp0->yystate;
	  yyGLRState* yys1 = &yyp1->yystate;
	  if (yys0->yypred != NULL)
	    yys1->yypred =
	      YYRELOC (yyp0, yyp1, yys0->yypred, yystate);
	  if (! yys0->yyresolved && yys0->yysemantics.yyfirstVal != NULL)
	    yys1->yysemantics.yyfirstVal =
	      YYRELOC(yyp0, yyp1, yys0->yysemantics.yyfirstVal, yyoption);
	}
      else
	{
	  yySemanticOption* yyv0 = &yyp0->yyoption;
	  yySemanticOption* yyv1 = &yyp1->yyoption;
	  if (yyv0->yystate != NULL)
	    yyv1->yystate = YYRELOC (yyp0, yyp1, yyv0->yystate, yystate);
	  if (yyv0->yynext != NULL)
	    yyv1->yynext = YYRELOC (yyp0, yyp1, yyv0->yynext, yyoption);
	}
    }
  if (yystack->yysplitPoint != NULL)
    yystack->yysplitPoint = YYRELOC (yystack->yyitems, yynewItems,
				 yystack->yysplitPoint, yystate);

  for (yyn = 0; yyn < yystack->yytops.yysize; yyn += 1)
    if (yystack->yytops.yystates[yyn] != NULL)
      yystack->yytops.yystates[yyn] =
	YYRELOC (yystack->yyitems, yynewItems,
		 yystack->yytops.yystates[yyn], yystate);
  YYFREE (yystack->yyitems);
  yystack->yyitems = yynewItems;
  yystack->yynextFree = yynewItems + yysize;
  yystack->yyspaceLeft = yynewSize - yysize;

#else
  yyMemoryExhausted (yystack);
#endif
}

static void
yyfreeGLRStack (yyGLRStack* yystack)
{
  YYFREE (yystack->yyitems);
  yyfreeStateSet (&yystack->yytops);
}

/** Assuming that S is a GLRState somewhere on STACK, update the
 *  splitpoint of STACK, if needed, so that it is at least as deep as
 *  S. */
static inline void
yyupdateSplit (yyGLRStack* yystack, yyGLRState* yys)
{
  if (yystack->yysplitPoint != NULL && yystack->yysplitPoint > yys)
    yystack->yysplitPoint = yys;
}

/** Invalidate stack #K in STACK. */
static inline void
yymarkStackDeleted (yyGLRStack* yystack, size_t yyk)
{
  if (yystack->yytops.yystates[yyk] != NULL)
    yystack->yylastDeleted = yystack->yytops.yystates[yyk];
  yystack->yytops.yystates[yyk] = NULL;
}

/** Undelete the last stack that was marked as deleted.  Can only be
    done once after a deletion, and only when all other stacks have
    been deleted. */
static void
yyundeleteLastStack (yyGLRStack* yystack)
{
  if (yystack->yylastDeleted == NULL || yystack->yytops.yysize != 0)
    return;
  yystack->yytops.yystates[0] = yystack->yylastDeleted;
  yystack->yytops.yysize = 1;
  YYDPRINTF ((stderr, "Restoring last deleted stack as stack #0.\n"));
  yystack->yylastDeleted = NULL;
}

static inline void
yyremoveDeletes (yyGLRStack* yystack)
{
  size_t yyi, yyj;
  yyi = yyj = 0;
  while (yyj < yystack->yytops.yysize)
    {
      if (yystack->yytops.yystates[yyi] == NULL)
	{
	  if (yyi == yyj)
	    {
	      YYDPRINTF ((stderr, "Removing dead stacks.\n"));
	    }
	  yystack->yytops.yysize -= 1;
	}
      else
	{
	  yystack->yytops.yystates[yyj] = yystack->yytops.yystates[yyi];
	  if (yyj != yyi)
	    {
	      YYDPRINTF ((stderr, "Rename stack %lu -> %lu.\n",
			  (unsigned long int) yyi, (unsigned long int) yyj));
	    }
	  yyj += 1;
	}
      yyi += 1;
    }
}

/** Shift to a new state on stack #K of STACK, corresponding to LR state
 * LRSTATE, at input position POSN, with (resolved) semantic value SVAL. */
static inline void
yyglrShift (yyGLRStack* yystack, size_t yyk, yyStateNum yylrState,
	    size_t yyposn,
	    YYSTYPE yysval, YYLTYPE* yylocp)
{
  yyGLRStackItem* yynewItem;

  yynewItem = yystack->yynextFree;
  yystack->yynextFree += 1;
  yystack->yyspaceLeft -= 1;
  yynewItem->yystate.yyisState = yytrue;
  yynewItem->yystate.yylrState = yylrState;
  yynewItem->yystate.yyposn = yyposn;
  yynewItem->yystate.yyresolved = yytrue;
  yynewItem->yystate.yypred = yystack->yytops.yystates[yyk];
  yystack->yytops.yystates[yyk] = &yynewItem->yystate;
  yynewItem->yystate.yysemantics.yysval = yysval;
  yynewItem->yystate.yyloc = *yylocp;
  if (yystack->yyspaceLeft < YYHEADROOM)
    yyexpandGLRStack (yystack);
}

/** Shift stack #K of YYSTACK, to a new state corresponding to LR
 *  state YYLRSTATE, at input position YYPOSN, with the (unresolved)
 *  semantic value of YYRHS under the action for YYRULE. */
static inline void
yyglrShiftDefer (yyGLRStack* yystack, size_t yyk, yyStateNum yylrState,
		 size_t yyposn, yyGLRState* rhs, yyRuleNum yyrule)
{
  yyGLRStackItem* yynewItem;

  yynewItem = yystack->yynextFree;
  yynewItem->yystate.yyisState = yytrue;
  yynewItem->yystate.yylrState = yylrState;
  yynewItem->yystate.yyposn = yyposn;
  yynewItem->yystate.yyresolved = yyfalse;
  yynewItem->yystate.yypred = yystack->yytops.yystates[yyk];
  yynewItem->yystate.yysemantics.yyfirstVal = NULL;
  yystack->yytops.yystates[yyk] = &yynewItem->yystate;
  yystack->yynextFree += 1;
  yystack->yyspaceLeft -= 1;
  yyaddDeferredAction (yystack, &yynewItem->yystate, rhs, yyrule);
}

/** Pop the symbols consumed by reduction #RULE from the top of stack
 *  #K of STACK, and perform the appropriate semantic action on their
 *  semantic values.  Assumes that all ambiguities in semantic values
 *  have been previously resolved. Set *VALP to the resulting value,
 *  and *LOCP to the computed location (if any).  Return value is as
 *  for userAction. */
static inline YYRESULTTAG
yydoAction (yyGLRStack* yystack, size_t yyk, yyRuleNum yyrule,
	    YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  int yynrhs = yyrhsLength (yyrule);

  if (yystack->yysplitPoint == NULL)
    {
      /* Standard special case: single stack. */
      yyGLRStackItem* rhs = (yyGLRStackItem*) yystack->yytops.yystates[yyk];
      YYASSERT (yyk == 0);
      yystack->yynextFree -= yynrhs;
      yystack->yyspaceLeft += yynrhs;
      yystack->yytops.yystates[0] = & yystack->yynextFree[-1].yystate;
      return yyuserAction (yyrule, yynrhs, rhs,
			   yyvalp, yylocp, yystack);
    }
  else
    {
      int yyi;
      yyGLRState* yys;
      yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
      yys = yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred
	= yystack->yytops.yystates[yyk];
      for (yyi = 0; yyi < yynrhs; yyi += 1)
	{
	  yys = yys->yypred;
	  YYASSERT (yys);
	}
      yyupdateSplit (yystack, yys);
      yystack->yytops.yystates[yyk] = yys;
      return yyuserAction (yyrule, yynrhs, yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
			   yyvalp, yylocp, yystack);
    }
}

#if !YYDEBUG
# define YY_REDUCE_PRINT(K, Rule)
#else
# define YY_REDUCE_PRINT(K, Rule)	\
do {					\
  if (yydebug)				\
    yy_reduce_print (K, Rule);		\
} while (0)

/*----------------------------------------------------------.
| Report that the RULE is going to be reduced on stack #K.  |
`----------------------------------------------------------*/

static inline void
yy_reduce_print (size_t yyk, yyRuleNum yyrule)
{
  int yyi;
  YYFPRINTF (stderr, "Reducing stack %lu by rule %d (line %lu), ",
	     (unsigned long int) yyk, yyrule - 1,
	     (unsigned long int) yyrline[yyrule]);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytokenName (yyrhs[yyi]));
  YYFPRINTF (stderr, "-> %s\n", yytokenName (yyr1[yyrule]));
}
#endif

/** Pop items off stack #K of STACK according to grammar rule RULE,
 *  and push back on the resulting nonterminal symbol.  Perform the
 *  semantic action associated with RULE and store its value with the
 *  newly pushed state, if FORCEEVAL or if STACK is currently
 *  unambiguous.  Otherwise, store the deferred semantic action with
 *  the new state.  If the new state would have an identical input
 *  position, LR state, and predecessor to an existing state on the stack,
 *  it is identified with that existing state, eliminating stack #K from
 *  the STACK. In this case, the (necessarily deferred) semantic value is
 *  added to the options for the existing state's semantic value.
 */
static inline YYRESULTTAG
yyglrReduce (yyGLRStack* yystack, size_t yyk, yyRuleNum yyrule,
             yybool yyforceEval)
{
  size_t yyposn = yystack->yytops.yystates[yyk]->yyposn;

  if (yyforceEval || yystack->yysplitPoint == NULL)
    {
      YYSTYPE yysval;
      YYLTYPE yyloc;

      YY_REDUCE_PRINT (yyk, yyrule);
      YYCHK (yydoAction (yystack, yyk, yyrule, &yysval, &yyloc));
      yyglrShift (yystack, yyk,
		  yyLRgotoState (yystack->yytops.yystates[yyk]->yylrState,
				 yylhsNonterm (yyrule)),
		  yyposn, yysval, &yyloc);
    }
  else
    {
      size_t yyi;
      int yyn;
      yyGLRState* yys, *yys0 = yystack->yytops.yystates[yyk];
      yyStateNum yynewLRState;

      for (yys = yystack->yytops.yystates[yyk], yyn = yyrhsLength (yyrule);
	   0 < yyn; yyn -= 1)
	{
	  yys = yys->yypred;
	  YYASSERT (yys);
	}
      yyupdateSplit (yystack, yys);
      yynewLRState = yyLRgotoState (yys->yylrState, yylhsNonterm (yyrule));
      YYDPRINTF ((stderr,
		  "Reduced stack %lu by rule #%d; action deferred. Now in state %d.\n",
		  (unsigned long int) yyk, yyrule - 1, yynewLRState));
      for (yyi = 0; yyi < yystack->yytops.yysize; yyi += 1)
	if (yyi != yyk && yystack->yytops.yystates[yyi] != NULL)
	  {
	    yyGLRState* yyp, *yysplit = yystack->yysplitPoint;
	    yyp = yystack->yytops.yystates[yyi];
	    while (yyp != yys && yyp != yysplit && yyp->yyposn >= yyposn)
	      {
		if (yyp->yylrState == yynewLRState && yyp->yypred == yys)
		  {
		    yyaddDeferredAction (yystack, yyp, yys0, yyrule);
		    yymarkStackDeleted (yystack, yyk);
		    YYDPRINTF ((stderr, "Merging stack %lu into stack %lu.\n",
				(unsigned long int) yyk,
				(unsigned long int) yyi));
		    return yyok;
		  }
		yyp = yyp->yypred;
	      }
	  }
      yystack->yytops.yystates[yyk] = yys;
      yyglrShiftDefer (yystack, yyk, yynewLRState, yyposn, yys0, yyrule);
    }
  return yyok;
}

static size_t
yysplitStack (yyGLRStack* yystack, size_t yyk)
{
  if (yystack->yysplitPoint == NULL)
    {
      YYASSERT (yyk == 0);
      yystack->yysplitPoint = yystack->yytops.yystates[yyk];
    }
  if (yystack->yytops.yysize >= yystack->yytops.yycapacity)
    {
      yyGLRState** yynewStates;
      if (! ((yystack->yytops.yycapacity
	      <= (YYSIZEMAX / (2 * sizeof yynewStates[0])))
	     && (yynewStates =
		 (yyGLRState**) YYREALLOC (yystack->yytops.yystates,
					   ((yystack->yytops.yycapacity *= 2)
					    * sizeof yynewStates[0])))))
	yyMemoryExhausted (yystack);
      yystack->yytops.yystates = yynewStates;
    }
  yystack->yytops.yystates[yystack->yytops.yysize]
    = yystack->yytops.yystates[yyk];
  yystack->yytops.yysize += 1;
  return yystack->yytops.yysize-1;
}

/** True iff Y0 and Y1 represent identical options at the top level.
 *  That is, they represent the same rule applied to RHS symbols
 *  that produce the same terminal symbols. */
static yybool
yyidenticalOptions (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  if (yyy0->yyrule == yyy1->yyrule)
    {
      yyGLRState *yys0, *yys1;
      int yyn;
      for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
	   yyn = yyrhsLength (yyy0->yyrule);
	   yyn > 0;
	   yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
	if (yys0->yyposn != yys1->yyposn)
	  return yyfalse;
      return yytrue;
    }
  else
    return yyfalse;
}

/** Assuming identicalOptions (Y0,Y1), destructively merge the
 *  alternative semantic values for the RHS-symbols of Y1 and Y0. */
static void
yymergeOptionSets (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  yyGLRState *yys0, *yys1;
  int yyn;
  for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
       yyn = yyrhsLength (yyy0->yyrule);
       yyn > 0;
       yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
    {
      if (yys0 == yys1)
	break;
      else if (yys0->yyresolved)
	{
	  yys1->yyresolved = yytrue;
	  yys1->yysemantics.yysval = yys0->yysemantics.yysval;
	}
      else if (yys1->yyresolved)
	{
	  yys0->yyresolved = yytrue;
	  yys0->yysemantics.yysval = yys1->yysemantics.yysval;
	}
      else
	{
	  yySemanticOption** yyz0p;
	  yySemanticOption* yyz1;
	  yyz0p = &yys0->yysemantics.yyfirstVal;
	  yyz1 = yys1->yysemantics.yyfirstVal;
	  while (yytrue)
	    {
	      if (yyz1 == *yyz0p || yyz1 == NULL)
		break;
	      else if (*yyz0p == NULL)
		{
		  *yyz0p = yyz1;
		  break;
		}
	      else if (*yyz0p < yyz1)
		{
		  yySemanticOption* yyz = *yyz0p;
		  *yyz0p = yyz1;
		  yyz1 = yyz1->yynext;
		  (*yyz0p)->yynext = yyz;
		}
	      yyz0p = &(*yyz0p)->yynext;
	    }
	  yys1->yysemantics.yyfirstVal = yys0->yysemantics.yyfirstVal;
	}
    }
}

/** Y0 and Y1 represent two possible actions to take in a given
 *  parsing state; return 0 if no combination is possible,
 *  1 if user-mergeable, 2 if Y0 is preferred, 3 if Y1 is preferred. */
static int
yypreference (yySemanticOption* y0, yySemanticOption* y1)
{
  yyRuleNum r0 = y0->yyrule, r1 = y1->yyrule;
  int p0 = yydprec[r0], p1 = yydprec[r1];

  if (p0 == p1)
    {
      if (yymerger[r0] == 0 || yymerger[r0] != yymerger[r1])
	return 0;
      else
	return 1;
    }
  if (p0 == 0 || p1 == 0)
    return 0;
  if (p0 < p1)
    return 3;
  if (p1 < p0)
    return 2;
  return 0;
}

static YYRESULTTAG yyresolveValue (yySemanticOption* yyoptionList,
				   yyGLRStack* yystack, YYSTYPE* yyvalp,
				   YYLTYPE* yylocp);

static YYRESULTTAG
yyresolveStates (yyGLRState* yys, int yyn, yyGLRStack* yystack)
{
  YYRESULTTAG yyflag;
  if (0 < yyn)
    {
      YYASSERT (yys->yypred);
      yyflag = yyresolveStates (yys->yypred, yyn-1, yystack);
      if (yyflag != yyok)
	return yyflag;
      if (! yys->yyresolved)
	{
	  yyflag = yyresolveValue (yys->yysemantics.yyfirstVal, yystack,
				   &yys->yysemantics.yysval, &yys->yyloc
				  );
	  if (yyflag != yyok)
	    return yyflag;
	  yys->yyresolved = yytrue;
	}
    }
  return yyok;
}

static YYRESULTTAG
yyresolveAction (yySemanticOption* yyopt, yyGLRStack* yystack,
	         YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
  int yynrhs;

  yynrhs = yyrhsLength (yyopt->yyrule);
  YYCHK (yyresolveStates (yyopt->yystate, yynrhs, yystack));
  yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred = yyopt->yystate;
  return yyuserAction (yyopt->yyrule, yynrhs,
		       yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
		       yyvalp, yylocp, yystack);
}

#if YYDEBUG
static void
yyreportTree (yySemanticOption* yyx, int yyindent)
{
  int yynrhs = yyrhsLength (yyx->yyrule);
  int yyi;
  yyGLRState* yys;
  yyGLRState* yystates[YYMAXRHS];
  yyGLRState yyleftmost_state;

  for (yyi = yynrhs, yys = yyx->yystate; 0 < yyi; yyi -= 1, yys = yys->yypred)
    yystates[yyi] = yys;
  if (yys == NULL)
    {
      yyleftmost_state.yyposn = 0;
      yystates[0] = &yyleftmost_state;
    }
  else
    yystates[0] = yys;

  if (yyx->yystate->yyposn < yys->yyposn + 1)
    YYFPRINTF (stderr, "%*s%s -> <Rule %d, empty>\n",
	       yyindent, "", yytokenName (yylhsNonterm (yyx->yyrule)),
	       yyx->yyrule);
  else
    YYFPRINTF (stderr, "%*s%s -> <Rule %d, tokens %lu .. %lu>\n",
	       yyindent, "", yytokenName (yylhsNonterm (yyx->yyrule)),
	       yyx->yyrule, (unsigned long int) (yys->yyposn + 1),
	       (unsigned long int) yyx->yystate->yyposn);
  for (yyi = 1; yyi <= yynrhs; yyi += 1)
    {
      if (yystates[yyi]->yyresolved)
	{
	  if (yystates[yyi-1]->yyposn+1 > yystates[yyi]->yyposn)
	    YYFPRINTF (stderr, "%*s%s <empty>\n", yyindent+2, "",
		       yytokenName (yyrhs[yyprhs[yyx->yyrule]+yyi-1]));
	  else
	    YYFPRINTF (stderr, "%*s%s <tokens %lu .. %lu>\n", yyindent+2, "",
		       yytokenName (yyrhs[yyprhs[yyx->yyrule]+yyi-1]),
		       (unsigned long int) (yystates[yyi - 1]->yyposn + 1),
		       (unsigned long int) yystates[yyi]->yyposn);
	}
      else
	yyreportTree (yystates[yyi]->yysemantics.yyfirstVal, yyindent+2);
    }
}
#endif

static void yyreportAmbiguity (yySemanticOption* yyx0, yySemanticOption* yyx1,
			       yyGLRStack* yystack)
  __attribute__ ((__noreturn__));
static void
yyreportAmbiguity (yySemanticOption* yyx0, yySemanticOption* yyx1,
		   yyGLRStack* yystack)
{
  /* `Unused' warnings.  */
  (void) yyx0;
  (void) yyx1;

#if YYDEBUG
  YYFPRINTF (stderr, "Ambiguity detected.\n");
  YYFPRINTF (stderr, "Option 1,\n");
  yyreportTree (yyx0, 2);
  YYFPRINTF (stderr, "\nOption 2,\n");
  yyreportTree (yyx1, 2);
  YYFPRINTF (stderr, "\n");
#endif
  yyFail (yystack, YY_("syntax is ambiguous"));
}


/** Resolve the ambiguity represented by OPTIONLIST, perform the indicated
 *  actions, and return the result. */
static YYRESULTTAG
yyresolveValue (yySemanticOption* yyoptionList, yyGLRStack* yystack,
		YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  yySemanticOption* yybest;
  yySemanticOption** yypp;
  yybool yymerge;

  yybest = yyoptionList;
  yymerge = yyfalse;
  for (yypp = &yyoptionList->yynext; *yypp != NULL; )
    {
      yySemanticOption* yyp = *yypp;

      if (yyidenticalOptions (yybest, yyp))
	{
	  yymergeOptionSets (yybest, yyp);
	  *yypp = yyp->yynext;
	}
      else
	{
	  switch (yypreference (yybest, yyp))
	    {
	    case 0:
	      yyreportAmbiguity (yybest, yyp, yystack);
	      break;
	    case 1:
	      yymerge = yytrue;
	      break;
	    case 2:
	      break;
	    case 3:
	      yybest = yyp;
	      yymerge = yyfalse;
	      break;
	    default:
	      /* This cannot happen so it is not worth a YYASSERT (yyfalse),
	         but some compilers complain if the default case is
		 omitted.  */
	      break;
	    }
	  yypp = &yyp->yynext;
	}
    }

  if (yymerge)
    {
      yySemanticOption* yyp;
      int yyprec = yydprec[yybest->yyrule];
      YYCHK (yyresolveAction (yybest, yystack, yyvalp, yylocp));
      for (yyp = yybest->yynext; yyp != NULL; yyp = yyp->yynext)
	{
	  if (yyprec == yydprec[yyp->yyrule])
	    {
	      YYSTYPE yyval1;
	      YYLTYPE yydummy;
	      YYCHK (yyresolveAction (yyp, yystack, &yyval1, &yydummy));
	      yyuserMerge (yymerger[yyp->yyrule], yyvalp, &yyval1);
	    }
	}
      return yyok;
    }
  else
    return yyresolveAction (yybest, yystack, yyvalp, yylocp);
}

static YYRESULTTAG
yyresolveStack (yyGLRStack* yystack)
{
  if (yystack->yysplitPoint != NULL)
    {
      yyGLRState* yys;
      int yyn;

      for (yyn = 0, yys = yystack->yytops.yystates[0];
	   yys != yystack->yysplitPoint;
	   yys = yys->yypred, yyn += 1)
	continue;
      YYCHK (yyresolveStates (yystack->yytops.yystates[0], yyn, yystack
			     ));
    }
  return yyok;
}

static void
yycompressStack (yyGLRStack* yystack)
{
  yyGLRState* yyp, *yyq, *yyr;

  if (yystack->yytops.yysize != 1 || yystack->yysplitPoint == NULL)
    return;

  for (yyp = yystack->yytops.yystates[0], yyq = yyp->yypred, yyr = NULL;
       yyp != yystack->yysplitPoint;
       yyr = yyp, yyp = yyq, yyq = yyp->yypred)
    yyp->yypred = yyr;

  yystack->yyspaceLeft += yystack->yynextFree - yystack->yyitems;
  yystack->yynextFree = ((yyGLRStackItem*) yystack->yysplitPoint) + 1;
  yystack->yyspaceLeft -= yystack->yynextFree - yystack->yyitems;
  yystack->yysplitPoint = NULL;
  yystack->yylastDeleted = NULL;

  while (yyr != NULL)
    {
      yystack->yynextFree->yystate = *yyr;
      yyr = yyr->yypred;
      yystack->yynextFree->yystate.yypred = & yystack->yynextFree[-1].yystate;
      yystack->yytops.yystates[0] = &yystack->yynextFree->yystate;
      yystack->yynextFree += 1;
      yystack->yyspaceLeft -= 1;
    }
}

static YYRESULTTAG
yyprocessOneStack (yyGLRStack* yystack, size_t yyk,
	           size_t yyposn, YYSTYPE* yylvalp, YYLTYPE* yyllocp
		  )
{
  int yyaction;
  const short int* yyconflicts;
  yyRuleNum yyrule;
  yySymbol* const yytokenp = yystack->yytokenp;

  while (yystack->yytops.yystates[yyk] != NULL)
    {
      yyStateNum yystate = yystack->yytops.yystates[yyk]->yylrState;
      YYDPRINTF ((stderr, "Stack %lu Entering state %d\n",
		  (unsigned long int) yyk, yystate));

      YYASSERT (yystate != YYFINAL);

      if (yyisDefaultedState (yystate))
	{
	  yyrule = yydefaultAction (yystate);
	  if (yyrule == 0)
	    {
	      YYDPRINTF ((stderr, "Stack %lu dies.\n",
			  (unsigned long int) yyk));
	      yymarkStackDeleted (yystack, yyk);
	      return yyok;
	    }
	  YYCHK (yyglrReduce (yystack, yyk, yyrule, yyfalse));
	}
      else
	{
	  if (*yytokenp == YYEMPTY)
	    {
	      YYDPRINTF ((stderr, "Reading a token: "));
	      yychar = YYLEX;
	      *yytokenp = YYTRANSLATE (yychar);
	      YY_SYMBOL_PRINT ("Next token is", *yytokenp, yylvalp, yyllocp);
	    }
	  yygetLRActions (yystate, *yytokenp, &yyaction, &yyconflicts);

	  while (*yyconflicts != 0)
	    {
	      size_t yynewStack = yysplitStack (yystack, yyk);
	      YYDPRINTF ((stderr, "Splitting off stack %lu from %lu.\n",
			  (unsigned long int) yynewStack,
			  (unsigned long int) yyk));
	      YYCHK (yyglrReduce (yystack, yynewStack,
				  *yyconflicts, yyfalse));
	      YYCHK (yyprocessOneStack (yystack, yynewStack, yyposn,
					yylvalp, yyllocp));
	      yyconflicts += 1;
	    }

	  if (yyisShiftAction (yyaction))
	    {
	      YYDPRINTF ((stderr, "On stack %lu, ", (unsigned long int) yyk));
	      YY_SYMBOL_PRINT ("shifting", *yytokenp, yylvalp, yyllocp);
	      yyglrShift (yystack, yyk, yyaction, yyposn+1,
			  *yylvalp, yyllocp);
	      YYDPRINTF ((stderr, "Stack %lu now in state #%d\n",
			  (unsigned long int) yyk,
			  yystack->yytops.yystates[yyk]->yylrState));
	      break;
	    }
	  else if (yyisErrorAction (yyaction))
	    {
	      YYDPRINTF ((stderr, "Stack %lu dies.\n",
			  (unsigned long int) yyk));
	      yymarkStackDeleted (yystack, yyk);
	      break;
	    }
	  else
	    YYCHK (yyglrReduce (yystack, yyk, -yyaction, yyfalse));
	}
    }
  return yyok;
}

static void
yyreportSyntaxError (yyGLRStack* yystack,
		     YYSTYPE* yylvalp, YYLTYPE* yyllocp)
{
  /* `Unused' warnings. */
  (void) yylvalp;
  (void) yyllocp;

  if (yystack->yyerrState == 0)
    {
#if YYERROR_VERBOSE
      yySymbol* const yytokenp = yystack->yytokenp;
      int yyn;
      yyn = yypact[yystack->yytops.yystates[0]->yylrState];
      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  size_t yysize0 = yytnamerr (NULL, yytokenName (*yytokenp));
	  size_t yysize = yysize0;
	  size_t yysize1;
	  yybool yysize_overflow = yyfalse;
	  char* yymsg = NULL;
	  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
	  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
	  int yyx;
	  char *yyfmt;
	  char const *yyf;
	  static char const yyunexpected[] = "syntax error, unexpected %s";
	  static char const yyexpecting[] = ", expecting %s";
	  static char const yyor[] = " or %s";
	  char yyformat[sizeof yyunexpected
			+ sizeof yyexpecting - 1
			+ ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
			   * (sizeof yyor - 1))];
	  char const *yyprefix = yyexpecting;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 1;

	  yyarg[0] = yytokenName (*yytokenp);
	  yyfmt = yystpcpy (yyformat, yyunexpected);

	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
		  {
		    yycount = 1;
		    yysize = yysize0;
		    yyformat[sizeof yyunexpected - 1] = '\0';
		    break;
		  }
		yyarg[yycount++] = yytokenName (yyx);
		yysize1 = yysize + yytnamerr (NULL, yytokenName (yyx));
		yysize_overflow |= yysize1 < yysize;
		yysize = yysize1;
		yyfmt = yystpcpy (yyfmt, yyprefix);
		yyprefix = yyor;
	      }

	  yyf = YY_(yyformat);
	  yysize1 = yysize + strlen (yyf);
	  yysize_overflow |= yysize1 < yysize;
	  yysize = yysize1;

	  if (!yysize_overflow)
	    yymsg = (char *) YYMALLOC (yysize);

	  if (yymsg)
	    {
	      char *yyp = yymsg;
	      int yyi = 0;
	      while ((*yyp = *yyf))
		{
		  if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		    {
		      yyp += yytnamerr (yyp, yyarg[yyi++]);
		      yyf += 2;
		    }
		  else
		    {
		      yyp++;
		      yyf++;
		    }
		}
	      yyerror (yymsg);
	      YYFREE (yymsg);
	    }
	  else
	    {
	      yyerror (YY_("syntax error"));
	      yyMemoryExhausted (yystack);
	    }
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror (YY_("syntax error"));
      yynerrs += 1;
    }
}

/* Recover from a syntax error on YYSTACK, assuming that YYTOKENP,
   YYLVALP, and YYLLOCP point to the syntactic category, semantic
   value, and location of the look-ahead.  */
static void
yyrecoverSyntaxError (yyGLRStack* yystack,
		      YYSTYPE* yylvalp,
		      YYLTYPE* YYOPTIONAL_LOC (yyllocp)
		      )
{
  yySymbol* const yytokenp = yystack->yytokenp;
  size_t yyk;
  int yyj;

  if (yystack->yyerrState == 3)
    /* We just shifted the error token and (perhaps) took some
       reductions.  Skip tokens until we can proceed.  */
    while (yytrue)
      {
	if (*yytokenp == YYEOF)
	  yyFail (yystack, NULL);
	if (*yytokenp != YYEMPTY)
	  {
	    /* We throw away the lookahead, but the error range
	       of the shifted error token must take it into account. */
	    yyGLRState *yys = yystack->yytops.yystates[0];
	    yyGLRStackItem yyerror_range[3];
	    yyerror_range[1].yystate.yyloc = yys->yyloc;
	    yyerror_range[2].yystate.yyloc = *yyllocp;
	    YYLLOC_DEFAULT (yys->yyloc, yyerror_range, 2);
	    yydestruct ("Error: discarding",
			*yytokenp, yylvalp, yyllocp);
	  }
	YYDPRINTF ((stderr, "Reading a token: "));
	yychar = YYLEX;
	*yytokenp = YYTRANSLATE (yychar);
	YY_SYMBOL_PRINT ("Next token is", *yytokenp, yylvalp, yyllocp);
	yyj = yypact[yystack->yytops.yystates[0]->yylrState];
	if (yyis_pact_ninf (yyj))
	  return;
	yyj += *yytokenp;
	if (yyj < 0 || YYLAST < yyj || yycheck[yyj] != *yytokenp)
	  {
	    if (yydefact[yystack->yytops.yystates[0]->yylrState] != 0)
	      return;
	  }
	else if (yytable[yyj] != 0 && ! yyis_table_ninf (yytable[yyj]))
	  return;
      }

  /* Reduce to one stack.  */
  for (yyk = 0; yyk < yystack->yytops.yysize; yyk += 1)
    if (yystack->yytops.yystates[yyk] != NULL)
      break;
  if (yyk >= yystack->yytops.yysize)
    yyFail (yystack, NULL);
  for (yyk += 1; yyk < yystack->yytops.yysize; yyk += 1)
    yymarkStackDeleted (yystack, yyk);
  yyremoveDeletes (yystack);
  yycompressStack (yystack);

  /* Now pop stack until we find a state that shifts the error token. */
  yystack->yyerrState = 3;
  while (yystack->yytops.yystates[0] != NULL)
    {
      yyGLRState *yys = yystack->yytops.yystates[0];
      yyj = yypact[yys->yylrState];
      if (! yyis_pact_ninf (yyj))
	{
	  yyj += YYTERROR;
	  if (0 <= yyj && yyj <= YYLAST && yycheck[yyj] == YYTERROR
	      && yyisShiftAction (yytable[yyj]))
	    {
	      /* Shift the error token having adjusted its location.  */
	      YYLTYPE yyerrloc;
	      yystack->yyerror_range[2].yystate.yyloc = *yyllocp;
	      YYLLOC_DEFAULT (yyerrloc, yystack->yyerror_range, 2);
	      YY_SYMBOL_PRINT ("Shifting", yystos[yytable[yyj]],
			       yylvalp, &yyerrloc);
	      yyglrShift (yystack, 0, yytable[yyj],
			  yys->yyposn, *yylvalp, &yyerrloc);
	      yys = yystack->yytops.yystates[0];
	      break;
	    }
	}
      yystack->yyerror_range[1].yystate.yyloc = yys->yyloc;
      yydestroyGLRState ("Error: popping", yys);
      yystack->yytops.yystates[0] = yys->yypred;
      yystack->yynextFree -= 1;
      yystack->yyspaceLeft += 1;
    }
  if (yystack->yytops.yystates[0] == NULL)
    yyFail (yystack, NULL);
}

#define YYCHK1(YYE)							     \
  do {									     \
    switch (YYE) {							     \
    case yyok:								     \
      break;								     \
    case yyabort:							     \
      goto yyabortlab;							     \
    case yyaccept:							     \
      goto yyacceptlab;							     \
    case yyerr:								     \
      goto yyuser_error;						     \
    default:								     \
      goto yybuglab;							     \
    }									     \
  } while (0)


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
  int yyresult;
  yySymbol yytoken;
  yyGLRStack yystack;
  size_t yyposn;


  YYSTYPE* const yylvalp = &yylval;
  YYLTYPE* const yyllocp = &yylloc;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yytoken = YYEMPTY;
  yylval = yyval_default;

#if YYLTYPE_IS_TRIVIAL
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 0;
#endif


  if (! yyinitGLRStack (&yystack, YYINITDEPTH))
    goto yyexhaustedlab;
  switch (YYSETJMP (yystack.yyexception_buffer))
    {
    case 0: break;
    case 1: goto yyabortlab;
    case 2: goto yyexhaustedlab;
    default: goto yybuglab;
    }
  yystack.yytokenp = &yytoken;
  yyglrShift (&yystack, 0, 0, 0, yylval, &yylloc);
  yyposn = 0;

  while (yytrue)
    {
      /* For efficiency, we have two loops, the first of which is
	 specialized to deterministic operation (single stack, no
	 potential ambiguity).  */
      /* Standard mode */
      while (yytrue)
	{
	  yyRuleNum yyrule;
	  int yyaction;
	  const short int* yyconflicts;

	  yyStateNum yystate = yystack.yytops.yystates[0]->yylrState;
          YYDPRINTF ((stderr, "Entering state %d\n", yystate));
	  if (yystate == YYFINAL)
	    goto yyacceptlab;
	  if (yyisDefaultedState (yystate))
	    {
	      yyrule = yydefaultAction (yystate);
	      if (yyrule == 0)
		{
		  yystack.yyerror_range[1].yystate.yyloc = *yyllocp;
		  yyreportSyntaxError (&yystack, yylvalp, yyllocp);
		  goto yyuser_error;
		}
	      YYCHK1 (yyglrReduce (&yystack, 0, yyrule, yytrue));
	    }
	  else
	    {
	      if (yytoken == YYEMPTY)
		{
		  YYDPRINTF ((stderr, "Reading a token: "));
		  yychar = YYLEX;
		  yytoken = YYTRANSLATE (yychar);
                  YY_SYMBOL_PRINT ("Next token is", yytoken, yylvalp, yyllocp);
		}
	      yygetLRActions (yystate, yytoken, &yyaction, &yyconflicts);
	      if (*yyconflicts != 0)
		break;
	      if (yyisShiftAction (yyaction))
		{
		  YY_SYMBOL_PRINT ("Shifting", yytoken, yylvalp, yyllocp);
		  if (yytoken != YYEOF)
		    yytoken = YYEMPTY;
		  yyposn += 1;
		  yyglrShift (&yystack, 0, yyaction, yyposn, yylval, yyllocp);
		  if (0 < yystack.yyerrState)
		    yystack.yyerrState -= 1;
		}
	      else if (yyisErrorAction (yyaction))
		{
		  yystack.yyerror_range[1].yystate.yyloc = *yyllocp;
		  yyreportSyntaxError (&yystack, yylvalp, yyllocp);
		  goto yyuser_error;
		}
	      else
		YYCHK1 (yyglrReduce (&yystack, 0, -yyaction, yytrue));
	    }
	}

      while (yytrue)
	{
	  size_t yys;
	  size_t yyn = yystack.yytops.yysize;
	  for (yys = 0; yys < yyn; yys += 1)
	    YYCHK1 (yyprocessOneStack (&yystack, yys, yyposn,
				       yylvalp, yyllocp));
	  yytoken = YYEMPTY;
	  yyposn += 1;
	  yyremoveDeletes (&yystack);
	  if (yystack.yytops.yysize == 0)
	    {
	      yyundeleteLastStack (&yystack);
	      if (yystack.yytops.yysize == 0)
		yyFail (&yystack, YY_("syntax error"));
	      YYCHK1 (yyresolveStack (&yystack));
	      YYDPRINTF ((stderr, "Returning to deterministic operation.\n"));
	      yystack.yyerror_range[1].yystate.yyloc = *yyllocp;
	      yyreportSyntaxError (&yystack, yylvalp, yyllocp);
	      goto yyuser_error;
	    }
	  else if (yystack.yytops.yysize == 1)
	    {
	      YYCHK1 (yyresolveStack (&yystack));
	      YYDPRINTF ((stderr, "Returning to deterministic operation.\n"));
	      yycompressStack (&yystack);
	      break;
	    }
	}
      continue;
    yyuser_error:
      yyrecoverSyntaxError (&yystack, yylvalp, yyllocp);
      yyposn = yystack.yytops.yystates[0]->yyposn;
    }

 yyacceptlab:
  yyresult = 0;
  goto yyreturn;

 yybuglab:
  YYASSERT (yyfalse);
  /* Fall through.  */

 yyabortlab:
  yyresult = 1;
  goto yyreturn;

 yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */

 yyreturn:
  if (yytoken != YYEOF && yytoken != YYEMPTY)
    yydestruct ("Cleanup: discarding lookahead",
                yytoken, yylvalp, yyllocp);

  /* If the stack is well-formed, pop the stack until it is empty,
     destroying its entries as we go.  But free the stack regardless
     of whether it is well-formed.  */
  if (yystack.yyitems)
    {
      yyGLRState** yystates = yystack.yytops.yystates;
      if (yystates)
	while (yystates[0])
	  {
	    yyGLRState *yys = yystates[0];
	  yystack.yyerror_range[1].yystate.yyloc = yys->yyloc;
	    yydestroyGLRState ("Cleanup: popping", yys);
	    yystates[0] = yys->yypred;
	    yystack.yynextFree -= 1;
	    yystack.yyspaceLeft += 1;
	  }
      yyfreeGLRStack (&yystack);
    }

  return yyresult;
}

/* DEBUGGING ONLY */
#ifdef YYDEBUG
static void yypstack (yyGLRStack* yystack, size_t yyk)
  __attribute__ ((__unused__));
static void yypdumpstack (yyGLRStack* yystack) __attribute__ ((__unused__));

static void
yy_yypstack (yyGLRState* yys)
{
  if (yys->yypred)
    {
      yy_yypstack (yys->yypred);
      fprintf (stderr, " -> ");
    }
  fprintf (stderr, "%d@%lu", yys->yylrState, (unsigned long int) yys->yyposn);
}

static void
yypstates (yyGLRState* yyst)
{
  if (yyst == NULL)
    fprintf (stderr, "<null>");
  else
    yy_yypstack (yyst);
  fprintf (stderr, "\n");
}

static void
yypstack (yyGLRStack* yystack, size_t yyk)
{
  yypstates (yystack->yytops.yystates[yyk]);
}

#define YYINDEX(YYX)							     \
    ((YYX) == NULL ? -1 : (yyGLRStackItem*) (YYX) - yystack->yyitems)


static void
yypdumpstack (yyGLRStack* yystack)
{
  yyGLRStackItem* yyp;
  size_t yyi;
  for (yyp = yystack->yyitems; yyp < yystack->yynextFree; yyp += 1)
    {
      fprintf (stderr, "%3lu. ", (unsigned long int) (yyp - yystack->yyitems));
      if (*(yybool *) yyp)
	{
	  fprintf (stderr, "Res: %d, LR State: %d, posn: %lu, pred: %ld",
		   yyp->yystate.yyresolved, yyp->yystate.yylrState,
		   (unsigned long int) yyp->yystate.yyposn,
		   (long int) YYINDEX (yyp->yystate.yypred));
	  if (! yyp->yystate.yyresolved)
	    fprintf (stderr, ", firstVal: %ld",
		     (long int) YYINDEX (yyp->yystate.yysemantics.yyfirstVal));
	}
      else
	{
	  fprintf (stderr, "Option. rule: %d, state: %ld, next: %ld",
		   yyp->yyoption.yyrule,
		   (long int) YYINDEX (yyp->yyoption.yystate),
		   (long int) YYINDEX (yyp->yyoption.yynext));
	}
      fprintf (stderr, "\n");
    }
  fprintf (stderr, "Tops:");
  for (yyi = 0; yyi < yystack->yytops.yysize; yyi += 1)
    fprintf (stderr, "%lu: %ld; ", (unsigned long int) yyi,
	     (long int) YYINDEX (yystack->yytops.yystates[yyi]));
  fprintf (stderr, "\n");
}
#endif


#line 1907 "g:\\VerilogProject\\doxygen-1.5.8\\src\\\\..\\src\\verilogparser.y"

//------ ------------------------------------------------------------------------------------------------

 Entry* getCurrVerilogEntry(){return current;}
 Entry* getCurrVerilog(){return currentVerilog; }
 QCString getCurrVerilogParsingClass(){return currVerilogClass; }

 void initVerilogParser(Entry* ee,bool pc){
  currVerilogInst.resize(0);
  currVerilogClass.resize(0);
  prevDocEntryVerilog.reset();
  currentVerilog=0;
  generateItem=false;
  currentFunctionVerilog=0;
  parseCode=pc;
if(pc) return;
  current_rootVerilog=ee;
  lastModule=0;
  current=new Entry;
  VerilogDocGen::initEntry(current);
  current_rootVerilog->name=QCString("XXX"); // dummy name for root
}

 Entry* VerilogDocGen::makeNewEntry(char* name,int sec,int spec,int line,bool add){
 
  Entry *e=current;
 
 if(parseCode) // should not happend!
 assert(0);

if(add){ // features like 'include xxx or 'define xxx must not be inserted here
 if(lastModule)
    addSubEntry(lastModule,e); 
  else
    addSubEntry(current_rootVerilog,e); 
}
   if(line){
  	  e->bodyLine=line;
      e->startLine=line;
  }else
   {
     e->bodyLine=getVerilogPrevLine();
     e->startLine=getVerilogPrevLine();
   }
   
  e->section=sec;
  e->spec=spec;
  e->name=name;

  current=new Entry;
  VerilogDocGen::initEntry(current);
  
  return e;
 }

void addSubEntry(Entry* root, Entry* e) {
 if(e==NULL || root==NULL) return;
  root->addSubEntry(e);
 } 




//-------------------------------------------------------------------------

// extracts module/primitive name

void parseModule(){
 
 QCString mod(getVerilogString());
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,' ');
 VhdlDocGen::deleteAllChars(mod,';');
 VhdlDocGen::deleteAllChars(mod,'(');
 
 QRegExp reg("[^_a-zA-Z0-9$]");

 int ll=mod.find(reg);

 if(ll>-1){
//  char c=mod.at(ll);
  QCString val=mod.remove(ll,1);

 }

//if(mod.len>80)

 if(parseCode) {
 //generateVerilogClassOrGlobalLink(mod.data());
 currVerilogClass=mod;
 return;
 }
  currentVerilog->name=mod;
 }//parseModuleName


// extracts module instances [ module_name name,module_name #(...) name]

void parseModuleInst(QCString& first, QCString& sec) {
 
if(currVerilogType==VerilogDocGen::DEFPARAM || generateItem ) return;

 VhdlDocGen::deleteAllChars(sec,'(');
 VhdlDocGen::deleteAllChars(sec,'\n');
 VhdlDocGen::deleteAllChars(sec,')');
 VhdlDocGen::deleteAllChars(sec,' ');
 VhdlDocGen::deleteAllChars(sec,',');
 VhdlDocGen::deleteAllChars(sec,';');
 QCString temp=sec;
//while(sec.stripPrefix(" "));

if(sec!=first && (sec.contains("#")==0))
{ 
 //QStringList ql=QStringList::split(first.data(),sec,false);
int oo=sec.findRev(first.data());
if(oo>0) 
 sec=sec.left(oo);
}
else
 sec=getLastLetter();

if(temp.contains("#"))
{ 
 int ii=temp.find("#");
 sec=temp.left(ii);
while(sec.stripPrefix(" "));
}

 if(parseCode){
     VhdlDocGen::deleteAllChars(sec,'\t');
   currVerilogInst=sec;
   return;
  }
 else {
  Entry* pTemp=VerilogDocGen::makeNewEntry(first.data(),Entry::VARIABLE_SEC,VerilogDocGen::COMPONENT,c_lloc.first_line);
  pTemp->type=sec;
 
 if(sec==first)return;
if(currentVerilog)
 if(!findExtendsComponent(currentVerilog->extends,sec)){	
  	BaseInfo *bb=new BaseInfo(sec,Private,Normal);
    currentVerilog->extends->append(bb);						
   }
  }
}


void parseListOfPorts() {
 
  QCString type;

 QCString mod(getVerilogString());
 
 VhdlDocGen::deleteAllChars(mod,' ');
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,';');
 VhdlDocGen::deleteAllChars(mod,')');
 VhdlDocGen::deleteAllChars(mod,'(');
  QStringList ql=QStringList::split(",",mod,false);
  QCString name=(QCString)ql[0];
if(!parseCode) {
  for(uint j=0;j<ql.count();j++) {
  QCString name=(QCString)ql[j];
   int i=name.find('[');
  if(i > 0){
    type=mod.right(mod.length()-i);
    name=mod.left(i);
  }
  
 name.prepend(VhdlDocGen::getRecordNumber().data());
 Entry* pTemp=VerilogDocGen::makeNewEntry(name.data(),Entry::VARIABLE_SEC,VerilogDocGen::PORT,c_lloc.first_line);
  pTemp->type=type; 
   }
  return;
 }	

 }//parseListOfPorts



void parseReg(Entry* e){

// "reg"|"integer\real\event"|wire"|"tri"|"tri1"|"supply0"|"wand"|"triand"|"tri0"|"supply1"|"wor"|"trior"|"trireg"

static QCString prevType;
static QCString sigType;
static QRegExp qregg("[ \\[]");
QCString regType;
QCString qcs;

int p,l;
     

 if((generateItem || CurrState==VerilogDocGen::STATE_FUNCTION || CurrState==VerilogDocGen::STATE_TASK )) return;

QCString mod(getVerilogString());

int port_type=0;

VhdlDocGen::deleteAllChars(mod,'(');
VhdlDocGen::deleteAllChars(mod,')');
VhdlDocGen::deleteAllChars(mod,';');
VhdlDocGen::deleteAllChars(mod,'\n');
VhdlDocGen::deleteAllChars(mod,',');

if(mod.contains("="))
{
 int i=mod.find("=");
 //qcs=mod.right(mod.length()-i-1);
 VhdlDocGen::deleteAllChars(qcs,' ');
 mod=mod.left(i);
}
  
 mod=mod.simplifyWhiteSpace(); 
  
//while(mod.stripPrefix(" "));
  p=qregg.match(mod,0,&l);

 if(p>0){
  sigType=mod.left(p);
  prevType.resize(0);
  mod.stripPrefix(sigType.data());
  while(mod.stripPrefix(" "));
  if(!mod.stripPrefix("signed ")){
  if(mod.stripPrefix("signed["))
    {mod.prepend("[");sigType.append(" signed ");}
  if(mod.stripPrefix("scalared "))
   sigType.append(" scalared ");
  if(mod.stripPrefix("vectored "))
    sigType.append(" vectored ");
 }
// else
  
}

 
 while(mod.stripPrefix(" "));
 

VhdlDocGen::deleteAllChars(mod,' ');

  int i=mod.find(']');
  int h=mod.find('[');

  if(h==0){
  	prevType+=mod.left(i+1);
  	mod=mod.right(mod.length()-i-1);
  h=mod.find('[');
  }

  if(h > 0){
   if(port_type!=2){ 
	regType=mod.right(mod.length()-h);
    mod=mod.left(h);
   }
   else {
    int ii=mod.find('[');
	if(ii>0){
  	prevType=mod.mid(ii,mod.length());
   	mod=mod.left(ii);
   }
  }
 }

  QStringList ql=QStringList::split(",",mod,false);
 uint len=ql.count() ;
 for(uint j=0;j<len;j++) {
  QCString name=(QCString)ql[j];
  name.prepend(VhdlDocGen::getRecordNumber().data());
 
  Entry* pTemp=VerilogDocGen::makeNewEntry(name.data(),Entry::VARIABLE_SEC,getVerilogPrevLine());
 // pTemp->type=prevType;
 
  if((prevType.isEmpty() && len==1) || (!regType.isEmpty() && len==1))
     pTemp->type=regType;
 else
  pTemp->args=regType;
    
  pTemp->args+=sigType+prevType; 
 // if(!prevType.isEmpty() && !regType.isEmpty())
 // pTemp->args+=prevType; 

 pTemp->args+=qcs;
  pTemp->spec=VerilogDocGen::SIGNAL;//currVerilogType;
  
  regType=prevType;
  if(getVerilogToken()==SEM_TOK)
   { prevType="";sigType="";}
  
  }
} // parsReg


// extracts function/task prototype 

void parseFunction(Entry* curF)
{
  QCString mod(getVerilogString());
  QCString type; 
 
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,';');
  while(mod.stripPrefix(" "));
 
  int i=mod.findRev(']');
  if(i > 0){
    type=mod.left(i+1);
   	mod=mod.right(mod.length()-i-1);
  }
  else {
  QStringList ql=QStringList::split(" ",mod,false);
  if(ql.count()>1) {
    type=(QCString)ql[0];
	mod=(QCString)ql[1];
  }
  }
 
 VhdlDocGen::deleteAllChars(mod,' ');
 VhdlDocGen::deleteAllChars(type,' ');

  curF->name+=mod;
  if(type.stripPrefix("automatic"))
   curF->type+="automatic "+type; 
   else
  curF->type+=type;
}
							   

// extract (local)parameter declaration 

void parseParam(Entry* e)
{
   QCString prevType,qcs;
  QRegExp regg("[ \t]");

  if((CurrState==VerilogDocGen::STATE_FUNCTION || CurrState==VerilogDocGen::STATE_TASK  || generateItem)) return;
  
  QCString mod(getVerilogString());
  VhdlDocGen::deleteAllChars(mod,';');
  VhdlDocGen::deleteAllChars(mod,'\n');
  VhdlDocGen::deleteAllChars(mod,',');

if(mod.contains("="))
{
 int i=mod.find("=");
 qcs=mod.right(mod.length()-i-1);
 while(qcs.stripPrefix(" "));
 mod=mod.left(i);
}

 while(mod.stripPrefix(" "));

 int j=mod.find(regg,0);
			 if(j>0){
			 bool bb=false;
			 QCString sem=mod.mid(0,j);
			 if(sem=="integer"){ prevType=sem;bb=true;}
			 else if(sem=="real"){prevType=sem;bb=true;}
			 else if(sem=="realtime"){prevType=sem;bb=true;}
			 else if(sem=="time"){prevType=sem;bb=true;}
			 else if(sem=="signed"){prevType=sem;bb=true;}
			 else if(sem=="wire"){prevType=sem;bb=true;}
			 if(bb)
			 mod.stripPrefix(sem.data());
			 }

 
 while(mod.stripPrefix(" "));
  
  int i=mod.find(']');
  if(i > 0){
    prevType+=" ";
	prevType+=mod.left(i+1);
   	mod=mod.right(mod.length()-i-1);
  }
 

  VhdlDocGen::deleteAllChars(mod,' ');


// each local member must get its unique number, because in Verilog
// two local variables can have the same identifier.
// ( input Q, reg Q)
  mod.prepend(VhdlDocGen::getRecordNumber().data());
 
  Entry* pTemp=VerilogDocGen::makeNewEntry(mod.data(),Entry::VARIABLE_SEC,VerilogDocGen::PARAMETER,getVerilogPrevLine());
  //pTemp->fileName+=getVerilogParsingFile();
  pTemp->type=prevType;
  pTemp->args=qcs;
  
  
}

// extract  input/output ports

void parsePortDir(Entry* e,int port)
{

static QCString prevType;
static QCString type; 

QCString mod(getVerilogString());
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,')');
 VhdlDocGen::deleteAllChars(mod,'(');
 VhdlDocGen::deleteAllChars(mod,';');
 VhdlDocGen::deleteAllChars(mod,',');

 while(mod.stripPrefix(" "));


if(mod.stripPrefix("input"))
 prevType="";
else if(mod.stripPrefix("output"))
  prevType=""; 
else if(mod.stripPrefix("inout"))
  prevType="";
else {
             QRegExp regg("[ \\[]");
  			 int j=mod.find(regg,0);
			 if(j>0){
			 type=mod.mid(0,j);
			 mod.stripPrefix(type.data());
			 }
	 } 


while(mod.stripPrefix(" "));
 
QRegExp regg("[ \t]");
 int j=mod.find(regg,0);
			 if(j>0){
			 bool bb=false;
			 QCString sem=mod.mid(0,j);
			 if(sem=="integer"){ prevType=sem;bb=true;}
			 else if(sem=="real"){prevType=sem;bb=true;}
			 else if(sem=="realtime"){prevType=sem;bb=true;}
			 else if(sem=="time"){prevType=sem;bb=true;}
			 else if(sem=="signed"){prevType=sem;bb=true;}
			 else if(sem=="wire"){prevType=sem;bb=true;}
			 if(bb)
			 mod.stripPrefix(sem.data());
			 }

while(mod.stripPrefix(" "));
  
  int i=mod.findRev(']');
  if(i > 0){
    prevType+=" ";
	prevType+=mod.left(i+1);
   	mod=mod.right(mod.length()-i-1);
  }
  else{ 
  int j=mod.find(regg,0);
   if(j>0){
    QCString sem=mod.mid(0,j);
	if(sem=="reg"){		
     mod=mod.right(mod.length()-j-1);
     prevType+=" reg";
     }
    }
   }
  
  VhdlDocGen::deleteAllChars(mod,' ');
  mod.prepend(VhdlDocGen::getRecordNumber().data());
  if(CurrState==VerilogDocGen::STATE_MODULE){  
  Entry* pTemp=VerilogDocGen::makeNewEntry(mod.data(),Entry::VARIABLE_SEC,0,c_lloc.first_line);
  pTemp->type=prevType;
  pTemp->args=type;
   assert(currVerilogType!=0);
  pTemp->spec=currVerilogType;
//   VerilogDocGen::addSubEntry(currentVerilog,pTemp);
  }
  else
  { 
   if(CurrState==VerilogDocGen::STATE_FUNCTION){
      Argument *arg=new Argument;
      
      switch(currVerilogType) {
      
      case VerilogDocGen::INPUT: arg->type="Input";break;
      case VerilogDocGen::INOUT:arg->type="Inout";break;         
      case VerilogDocGen::OUTPUT:arg->type="Output";break;         
      default:break;
      }                           
        arg->defval=prevType;                         
        arg->name=mod;//(QCString)ql[j];	
	  currentFunctionVerilog->argList->append(arg);
	  VerilogDocGen::adjustMemberName(mod); 
	  currentFunctionVerilog->args+=mod;//(QCString)ql[j]+",";
  } 
 }
 

  if(getVerilogToken()==SEM_TOK)//end of line
  {prevType="";type="";}
}

void parseAlways(bool bBody)
{

if(currVerilogType!=VerilogDocGen::ALWAYS || generateItem) return ;

QRegExp regg1("[ \t]or[ \t]");

QCString mod(getVerilogString());
QCString type; 
QStringList ql;
bool sem=false;

 VhdlDocGen::deleteAllChars(mod,'@');
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,'(');
 VhdlDocGen::deleteAllChars(mod,')');
 VhdlDocGen::deleteAllChars(mod,';'); 

if(mod.contains(","))
  ql=QStringList::split(",",mod,false);
 else
  ql=QStringList::split(regg1,mod,false);
 

 if(!parseCode) {
 currentFunctionVerilog=VerilogDocGen::makeNewEntry(VhdlDocGen::getProcessNumber().data(),Entry::FUNCTION_SEC,VerilogDocGen::ALWAYS);
  currentFunctionVerilog->stat=TRUE;
  currentFunctionVerilog->fileName=getVerilogParsingFile();
  if(!bBody)
  for(uint j=0;j<ql.count();j++) {
  QCString ll=(QCString)ql[j];
  if(ll=="or" || ll=="and") continue; 
  if(sem)
	  currentFunctionVerilog->args+=',';
	  Argument *arg=new Argument;
      arg->name=ll;	
	  currentFunctionVerilog->argList->append(arg);
      currentFunctionVerilog->args+=ll; 
      sem = true;
 }
 return;
}


}//parseAlways



 // sets the current parsing module (only for parsing inline_sources)             
 void VerilogDocGen::setCurrVerilogClass(QCString& cl){ currVerilogClass = cl;}
   
 //-------------------------------------------------------------------------------------------  
           
 int MyParserConv::parse(MyParserConv* conv){
  myconv=conv;
  assert(myconv);
  return c_parse();
 } 
        
int c_lex(void){
 return myconv->doLex(); 
}


void c_error(const char * err){
   if(err && !parseCode){
 // fprintf(stderr,"\n\nerror occurred at line [%d]... : in file [%s]\n\n",c_lloc.first_line,getVerilogParsingFile());
  vbufreset();
 // exit(0);
  }
   } 
    
int getVerilogToken(){return c_char;}
 //------------------------------------------------------------------------------------------------  

// writes a digit to the source

void writeDigit()
 {
   if(parseCode) {
     writePrevVerilogWords(identVerilog);
	 writeVerilogFont("vhdllogic",identVerilog.data());
	 identVerilog.resize(0);
	 printVerilogBuffer(true);
	 }
 }// writeDigit

// prints and links the parsed identifiers  

void parseString(){				
					 				
					if(parseCode ) { 
					 //   printVerilogStringList();
						 identVerilog=identVerilog.stripWhiteSpace();
				   	  writePrevVerilogWords(identVerilog);
						 bool b=false;
					 
					 if(currVerilogType==VerilogDocGen::DEFPARAM){
				       QCString s(getVerilogString());
                       if(s.contains(".")==0)
                           b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::COMPONENT);
				       else if(s.contains("="))
                           b=generateVerilogMemLink(currVerilogClass,identVerilog,-1);
                       else
				         b=generateVerilogMemLink(currVerilogInst,identVerilog,-1);	       
				     }
					 else if(currVerilogType==VerilogDocGen::COMPONENT){
					    QCString tt(getVerilogString());
					    if(tt.contains('('))
					     b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::PORT);
				        else if(!b)   
				         b=generateVerilogMemLink(currVerilogInst,identVerilog,VerilogDocGen::PORT);
				        if(!b)   
				         b=generateVerilogMemLink(currVerilogClass,identVerilog,-1);    
					   }
				    /*
				      else if(currVerilogType==VerilogDocGen::NETTYPE){
                       QCString tt(getVerilogString());
                      if(tt.contains("["))
                         b=generateVerilogMemLink(currVerilogClass,identVerilog,-1);
                       else{
                      	 codifyVerilogString(identVerilog.data(),"vhdlcharacter");
				         b=true;
				          }
                      	 }
				      */
				      else if(currVerilogType==VerilogDocGen::PORT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::PORT);
				     else if(currVerilogType==VerilogDocGen::PARAMETER)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::PARAMETER);
				     else if(currVerilogType==VerilogDocGen::SIGNAL)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::SIGNAL);
				     else if(currVerilogType==VerilogDocGen::INPUT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::INPUT);				       
         		     else if(currVerilogType==VerilogDocGen::OUTPUT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::OUTPUT);
				     else if(currVerilogType==VerilogDocGen::INOUT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::INOUT);
				   
				     else if(currVerilogType==VerilogDocGen::ALWAYS)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::ALWAYS);
						
				     if(!b){
					   b =  generateVerilogMemLink(currVerilogClass,identVerilog,-1); 
					   if(!b && getClass(identVerilog.data()))
                       b=generateVerilogClassOrGlobalLink(identVerilog.data());
					  if(!b){
					   int  col=VerilogDocGen::findKeyWord(identVerilog.data());
					   if(col==1)
					    codifyVerilogString(identVerilog.data(),"vhdldigit");
					   else if(col==2)
					     codifyVerilogString(identVerilog.data(),"comment"); 
					    else
					   codifyVerilogString(identVerilog.data(),"vhdlchar");
					   }   
					 }
					   printVerilogBuffer(true);
					  }
				    prevName=identVerilog; 
				   identVerilog.resize(0);
				 
}// parseString

// inits the parser

 //---------------------------------------------------------------------------------------------------  


// do not include the same class twice 

bool findExtendsComponent(QList<BaseInfo> *extend,QCString& compName)
{
 for(uint j=0;j<extend->count();j++){
  BaseInfo *bb=extend->at(j);
  if(bb->name==compName)
   return true;
 }
 return false;
}// findExtendsComponent


