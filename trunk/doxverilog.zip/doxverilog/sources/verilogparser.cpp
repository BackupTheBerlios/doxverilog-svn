/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for GLR parsing with Bison,
   Copyright (C) 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* This is the parser code for GLR (Generalized LR) parser. */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "glr.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 1

/* Substitute the variable and function names.  */
#define yyparse c_parse
#define yylex   c_lex
#define yyerror c_error
#define yylval  c_lval
#define yychar  c_char
#define yydebug c_debug
#define yynerrs c_nerrs
#define yylloc c_lloc

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NET_TOK = 258,
     STR0_TOK = 259,
     STR1_TOK = 260,
     GATE_TOK = 261,
     STRING_TOK = 262,
     DIGIT_TOK = 263,
     UNDERSCORE_TOK = 264,
     SEM_TOK = 265,
     DOT_TOK = 266,
     LETTER_TOK = 267,
     PLUS_TOK = 268,
     MINUS_TOK = 269,
     COLON_TOK = 270,
     LBRACE_TOK = 271,
     RBRACE_TOK = 272,
     LBRACKET_TOK = 273,
     RBRACKET_TOK = 274,
     AND_TOK = 275,
     OR_TOK = 276,
     EQU_TOK = 277,
     GT_TOK = 278,
     LT_TOK = 279,
     NOT_TOK = 280,
     MULT_TOK = 281,
     PERCENTAL_TOK = 282,
     ENV_TOK = 283,
     PARA_TOK = 284,
     CHAR_TOK = 285,
     AT_TOK = 286,
     DOLLAR_TOK = 287,
     BASE_TOK = 288,
     SN_TOK = 289,
     EXCLAMATION_TOK = 290,
     RRAM_TOK = 291,
     LRAM_TOK = 292,
     PARAMETER_TOK = 293,
     OUTPUT_TOK = 294,
     INOUT_TOK = 295,
     SMALL_TOK = 296,
     MEDIUM_TOK = 297,
     LARGE_TOK = 298,
     VEC_TOK = 299,
     SCALAR_TOK = 300,
     REG_TOK = 301,
     TIME_TOK = 302,
     REAL_TOK = 303,
     EVENT_TOK = 304,
     ASSIGN_TOK = 305,
     DEFPARAM_TOK = 306,
     MODUL_TOK = 307,
     ENDMODUL_TOK = 308,
     MACRO_MODUL_TOK = 309,
     ENDPRIMITIVE_TOK = 310,
     PRIMITIVE_TOK = 311,
     INITIAL_TOK = 312,
     TABLE_TOK = 313,
     ENDTABLE_TOK = 314,
     ALWAYS_TOK = 315,
     TASK_TOK = 316,
     ENDTASK_TOK = 317,
     FUNC_TOK = 318,
     ENDFUNC_TOK = 319,
     IF_TOK = 320,
     CASE_TOK = 321,
     CASEX_TOK = 322,
     CASEZ_TOK = 323,
     FOREVER_TOK = 324,
     REPEAT_TOK = 325,
     FOR_TOK = 326,
     JOIN_TOK = 327,
     WAIT_TOK = 328,
     FORCE_TOK = 329,
     RELEASE_TOK = 330,
     DEASSIGN_TOK = 331,
     DISABLE_TOK = 332,
     WHILE_TOK = 333,
     ELSE_TOK = 334,
     ENDCASE_TOK = 335,
     BEGIN_TOK = 336,
     DEFAULT_TOK = 337,
     FORK_TOK = 338,
     END_TOK = 339,
     SPECIFY_TOK = 340,
     ENDSPECIFY_TOK = 341,
     SPECPARAM_TOK = 342,
     DSETUP_TOK = 343,
     DHOLD_TOK = 344,
     DWIDTH_TOK = 345,
     DPERIOD_TOK = 346,
     DSKEW_TOK = 347,
     DRECOVERY_TOK = 348,
     DSETUPHOLD_TOK = 349,
     POSEDGE_TOK = 350,
     NEGEDGE_TOK = 351,
     EDGE_TOK = 352,
     COMMA_TOK = 353,
     QUESTION_TOK = 354,
     AUTO_TOK = 355,
     INPUT_TOK = 356,
     SIGNED_TOK = 357,
     LOCALPARAM_TOK = 358,
     INTEGER_TOK = 359,
     NOCHANGE_TOK = 360,
     GENERATE_TOK = 361,
     ENDGENERATE_TOK = 362,
     GENVAR_TOK = 363,
     LIBRARY_TOK = 364,
     CONFIG_TOK = 365,
     ENDCONFIG_TOK = 366,
     INCLUDE_TOK = 367,
     PULSEON_DETECT_TOK = 368,
     PULSEONE_EVENT_TOK = 369,
     USE_TOK = 370,
     LIBLIST_TOK = 371,
     INSTANCE_TOK = 372,
     CELL_TOK = 373,
     SHOWCANCEL_TOK = 374,
     NOSHOWCANCEL_TOK = 375,
     REMOVAL_TOK = 376,
     FULLSKEW_TOK = 377,
     TIMESKEW_TOK = 378,
     RECREM_TOK = 379,
     IFNONE_TOK = 380,
     REALTIME_TOK = 381,
     DESIGN_TOK = 382,
     ATL_TOK = 383,
     ATR_TOK = 384,
     OOR_TOK = 385,
     AAND_TOK = 386,
     SNNOT_TOK = 387,
     NOTSN_TOK = 388,
     AAAND_TOK = 389
   };
#endif
/* Tokens.  */
#define NET_TOK 258
#define STR0_TOK 259
#define STR1_TOK 260
#define GATE_TOK 261
#define STRING_TOK 262
#define DIGIT_TOK 263
#define UNDERSCORE_TOK 264
#define SEM_TOK 265
#define DOT_TOK 266
#define LETTER_TOK 267
#define PLUS_TOK 268
#define MINUS_TOK 269
#define COLON_TOK 270
#define LBRACE_TOK 271
#define RBRACE_TOK 272
#define LBRACKET_TOK 273
#define RBRACKET_TOK 274
#define AND_TOK 275
#define OR_TOK 276
#define EQU_TOK 277
#define GT_TOK 278
#define LT_TOK 279
#define NOT_TOK 280
#define MULT_TOK 281
#define PERCENTAL_TOK 282
#define ENV_TOK 283
#define PARA_TOK 284
#define CHAR_TOK 285
#define AT_TOK 286
#define DOLLAR_TOK 287
#define BASE_TOK 288
#define SN_TOK 289
#define EXCLAMATION_TOK 290
#define RRAM_TOK 291
#define LRAM_TOK 292
#define PARAMETER_TOK 293
#define OUTPUT_TOK 294
#define INOUT_TOK 295
#define SMALL_TOK 296
#define MEDIUM_TOK 297
#define LARGE_TOK 298
#define VEC_TOK 299
#define SCALAR_TOK 300
#define REG_TOK 301
#define TIME_TOK 302
#define REAL_TOK 303
#define EVENT_TOK 304
#define ASSIGN_TOK 305
#define DEFPARAM_TOK 306
#define MODUL_TOK 307
#define ENDMODUL_TOK 308
#define MACRO_MODUL_TOK 309
#define ENDPRIMITIVE_TOK 310
#define PRIMITIVE_TOK 311
#define INITIAL_TOK 312
#define TABLE_TOK 313
#define ENDTABLE_TOK 314
#define ALWAYS_TOK 315
#define TASK_TOK 316
#define ENDTASK_TOK 317
#define FUNC_TOK 318
#define ENDFUNC_TOK 319
#define IF_TOK 320
#define CASE_TOK 321
#define CASEX_TOK 322
#define CASEZ_TOK 323
#define FOREVER_TOK 324
#define REPEAT_TOK 325
#define FOR_TOK 326
#define JOIN_TOK 327
#define WAIT_TOK 328
#define FORCE_TOK 329
#define RELEASE_TOK 330
#define DEASSIGN_TOK 331
#define DISABLE_TOK 332
#define WHILE_TOK 333
#define ELSE_TOK 334
#define ENDCASE_TOK 335
#define BEGIN_TOK 336
#define DEFAULT_TOK 337
#define FORK_TOK 338
#define END_TOK 339
#define SPECIFY_TOK 340
#define ENDSPECIFY_TOK 341
#define SPECPARAM_TOK 342
#define DSETUP_TOK 343
#define DHOLD_TOK 344
#define DWIDTH_TOK 345
#define DPERIOD_TOK 346
#define DSKEW_TOK 347
#define DRECOVERY_TOK 348
#define DSETUPHOLD_TOK 349
#define POSEDGE_TOK 350
#define NEGEDGE_TOK 351
#define EDGE_TOK 352
#define COMMA_TOK 353
#define QUESTION_TOK 354
#define AUTO_TOK 355
#define INPUT_TOK 356
#define SIGNED_TOK 357
#define LOCALPARAM_TOK 358
#define INTEGER_TOK 359
#define NOCHANGE_TOK 360
#define GENERATE_TOK 361
#define ENDGENERATE_TOK 362
#define GENVAR_TOK 363
#define LIBRARY_TOK 364
#define CONFIG_TOK 365
#define ENDCONFIG_TOK 366
#define INCLUDE_TOK 367
#define PULSEON_DETECT_TOK 368
#define PULSEONE_EVENT_TOK 369
#define USE_TOK 370
#define LIBLIST_TOK 371
#define INSTANCE_TOK 372
#define CELL_TOK 373
#define SHOWCANCEL_TOK 374
#define NOSHOWCANCEL_TOK 375
#define REMOVAL_TOK 376
#define FULLSKEW_TOK 377
#define TIMESKEW_TOK 378
#define RECREM_TOK 379
#define IFNONE_TOK 380
#define REALTIME_TOK 381
#define DESIGN_TOK 382
#define ATL_TOK 383
#define ATR_TOK 384
#define OOR_TOK 385
#define AAND_TOK 386
#define SNNOT_TOK 387
#define NOTSN_TOK 388
#define AAAND_TOK 389




/* Copy the first part of user declarations.  */
#line 33 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "verilogdocgen.h"
#include "membergroup.h"
//#include "verilogparser.hpp"
#include "vhdldocgen.h"
#include "doxygen.h"
#include "searchindex.h"
#include "verilogscanner.h"
#include "commentscan.h"

#define YYMAXDEPTH 15000

static MyParserConv* myconv=0;

static int CurrState;
static int          currVerilogType;
static Entry*       current=0;
static Entry*		current_rootVerilog  ;
static Entry*		currentVerilog=0  ;
static Entry*       currentFunctionVerilog=0;
static Entry*       lastModule=0;

static Entry        prevDocEntryVerilog;

static bool         parseCode=FALSE; 

static QCString     currVerilogClass;
static QCString     identVerilog; // last written word
static QCString     currVerilogInst;

int c_lex (void);
void c_error (char const *);


// functions for  verilog parser ---------------------

static void parseString();
static void writeDigit();
static void initVerilogParser();
static void parseModule();
static void parseFunction(Entry* e);
static void parseReg(Entry* e);
static void parsePortDir(Entry* e,int type);
static void parseParam(Entry* e);
static void parseListOfPorts();
static void parseAlways(bool b=false);
static void parseModuleInst(QCString& first,QCString& sec);

bool findExtendsComponent(QList<BaseInfo> *extend,QCString& compName);
void addSubEntry(Entry* root, Entry* e);


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 89 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
typedef union YYSTYPE {
	int itype;	/* for count */
	char ctype;	/* for char */
	char cstr[1024];
	} YYSTYPE;
/* Line 186 of glr.c.  */
#line 410 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.cpp"
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{

  int first_line;
  int first_column;
  int last_line;
  int last_column;

} YYLTYPE;
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

/* Default (constant) value used for initialization for null
   right-hand sides.  Unlike the standard yacc.c template,
   here we set the default value of $$ to a zeroed-out value.
   Since the default value is undefined, this behavior is
   technically correct. */
static YYSTYPE yyval_default;

/* Copy the second part of user declarations.  */


/* Line 217 of glr.c.  */
#line 440 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.cpp"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

#ifndef YYFREE
# define YYFREE free
#endif
#ifndef YYMALLOC
# define YYMALLOC malloc
#endif
#ifndef YYREALLOC
# define YYREALLOC realloc
#endif

#define YYSIZEMAX ((size_t) -1)

#ifdef __cplusplus
   typedef bool yybool;
#else
   typedef unsigned char yybool;
#endif
#define yytrue 1
#define yyfalse 0

#ifndef YYSETJMP
# include <setjmp.h>
# define YYJMP_BUF jmp_buf
# define YYSETJMP(env) setjmp (env)
# define YYLONGJMP(env, val) longjmp (env, val)
#endif

/*-----------------.
| GCC extensions.  |
`-----------------*/

#ifndef __attribute__
/* This feature is available in gcc versions 2.5 and later.  */
# if (!defined (__GNUC__) || __GNUC__ < 2 \
      || (__GNUC__ == 2 && __GNUC_MINOR__ < 5) || __STRICT_ANSI__)
#  define __attribute__(Spec) /* empty */
# endif
#endif

#define YYOPTIONAL_LOC(Name) Name

#ifndef YYASSERT
# define YYASSERT(condition) ((void) ((condition) || (abort (), 0)))
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  70
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   4934

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  135
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  321
/* YYNRULES -- Number of rules. */
#define YYNRULES  794
/* YYNRULES -- Number of states. */
#define YYNSTATES  1732
/* YYMAXRHS -- Maximum number of symbols on right-hand side of rule. */
#define YYMAXRHS 25
/* YYMAXLEFT -- Maximum number of symbols to the left of a handle
   accessed by $0, $-1, etc., in any rule. */
#define YYMAXLEFT 0

/* YYTRANSLATE(X) -- Bison symbol number corresponding to X.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   389

#define YYTRANSLATE(YYX)						\
  ((YYX <= 0) ? YYEOF :							\
   (unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short int yyprhs[] =
{
       0,     0,     3,     5,     6,     9,    12,    14,    16,    18,
      20,    22,    25,    27,    29,    35,    39,    46,    52,    56,
      60,    62,    65,    69,    73,    77,    81,    85,    87,    90,
      93,    96,    98,   101,   105,   106,   109,   111,   113,   115,
     121,   126,   133,   140,   147,   154,   161,   169,   177,   185,
     187,   189,   191,   194,   195,   198,   200,   203,   204,   210,
     214,   215,   219,   220,   226,   227,   232,   233,   238,   242,
     246,   248,   252,   254,   259,   265,   267,   271,   275,   277,
     279,   281,   286,   291,   294,   297,   300,   303,   305,   308,
     312,   315,   318,   321,   324,   327,   329,   332,   335,   338,
     341,   344,   347,   350,   352,   354,   356,   358,   360,   362,
     364,   366,   368,   370,   371,   376,   380,   381,   387,   388,
     394,   395,   400,   401,   407,   408,   415,   419,   420,   425,
     426,   432,   433,   440,   441,   447,   448,   454,   458,   463,
     467,   471,   472,   478,   479,   486,   492,   499,   500,   506,
     507,   514,   520,   527,   528,   533,   534,   538,   542,   547,
     551,   557,   562,   564,   566,   568,   570,   572,   574,   577,
     580,   583,   585,   589,   593,   597,   601,   605,   609,   616,
     623,   631,   639,   648,   656,   664,   672,   681,   689,   693,
     694,   696,   698,   700,   704,   708,   709,   714,   718,   724,
     729,   733,   734,   739,   743,   745,   748,   754,   760,   764,
     768,   772,   776,   781,   784,   786,   790,   792,   794,   796,
     798,   800,   804,   807,   812,   814,   818,   820,   824,   826,
     828,   832,   834,   838,   841,   843,   845,   849,   851,   855,
     859,   863,   867,   873,   879,   889,   902,   906,   908,   909,
     911,   913,   915,   917,   919,   920,   922,   923,   925,   927,
     930,   932,   935,   937,   942,   950,   957,   968,   978,   982,
     984,   987,   989,   992,   994,   996,   999,  1001,  1005,  1007,
    1013,  1017,  1022,  1029,  1037,  1038,  1040,  1041,  1043,  1044,
    1046,  1050,  1054,  1058,  1062,  1064,  1068,  1073,  1079,  1083,
    1087,  1094,  1102,  1108,  1112,  1114,  1116,  1118,  1120,  1123,
    1126,  1129,  1132,  1135,  1138,  1141,  1144,  1149,  1155,  1159,
    1161,  1165,  1167,  1170,  1175,  1179,  1184,  1190,  1194,  1198,
    1200,  1204,  1206,  1210,  1217,  1223,  1228,  1232,  1235,  1237,
    1239,  1241,  1242,  1243,  1250,  1251,  1256,  1258,  1262,  1267,
    1273,  1275,  1277,  1279,  1283,  1285,  1287,  1291,  1297,  1302,
    1307,  1311,  1314,  1316,  1318,  1320,  1324,  1327,  1329,  1333,
    1336,  1337,  1342,  1346,  1348,  1351,  1352,  1355,  1357,  1359,
    1361,  1363,  1365,  1367,  1373,  1381,  1388,  1390,  1394,  1398,
    1402,  1405,  1406,  1417,  1421,  1427,  1431,  1435,  1441,  1452,
    1463,  1465,  1467,  1471,  1475,  1477,  1481,  1485,  1487,  1490,
    1493,  1496,  1499,  1502,  1506,  1511,  1518,  1522,  1526,  1530,
    1534,  1538,  1540,  1544,  1548,  1553,  1555,  1558,  1563,  1570,
    1576,  1580,  1582,  1584,  1586,  1589,  1592,  1596,  1601,  1606,
    1608,  1610,  1612,  1614,  1616,  1618,  1620,  1622,  1628,  1633,
    1637,  1639,  1643,  1644,  1652,  1658,  1660,  1666,  1671,  1675,
    1680,  1682,  1686,  1690,  1693,  1697,  1698,  1702,  1706,  1711,
    1715,  1719,  1722,  1728,  1733,  1738,  1741,  1744,  1747,  1750,
    1753,  1757,  1759,  1762,  1766,  1773,  1779,  1784,  1787,  1789,
    1792,  1796,  1800,  1807,  1813,  1816,  1821,  1825,  1826,  1831,
    1838,  1844,  1847,  1852,  1856,  1858,  1861,  1865,  1868,  1871,
    1874,  1877,  1880,  1884,  1887,  1891,  1894,  1897,  1900,  1903,
    1905,  1907,  1911,  1914,  1917,  1920,  1923,  1926,  1929,  1931,
    1934,  1937,  1942,  1944,  1946,  1947,  1954,  1958,  1961,  1966,
    1969,  1974,  1979,  1981,  1984,  1987,  1989,  1993,  1997,  2000,
    2006,  2012,  2020,  2028,  2034,  2042,  2049,  2056,  2063,  2067,
    2074,  2078,  2080,  2083,  2087,  2091,  2094,  2097,  2103,  2109,
    2119,  2122,  2128,  2134,  2144,  2150,  2156,  2159,  2161,  2165,
    2168,  2170,  2174,  2177,  2181,  2183,  2186,  2188,  2190,  2192,
    2194,  2196,  2200,  2204,  2208,  2212,  2216,  2220,  2223,  2226,
    2229,  2233,  2240,  2246,  2253,  2255,  2259,  2261,  2265,  2269,
    2271,  2276,  2281,  2283,  2287,  2289,  2295,  2303,  2317,  2343,
    2345,  2349,  2353,  2360,  2366,  2377,  2387,  2393,  2401,  2403,
    2405,  2407,  2413,  2419,  2422,  2424,  2426,  2428,  2430,  2432,
    2434,  2436,  2438,  2440,  2442,  2444,  2446,  2448,  2460,  2470,
    2482,  2492,  2506,  2518,  2530,  2540,  2545,  2557,  2567,  2571,
    2585,  2597,  2609,  2619,  2631,  2641,  2653,  2663,  2675,  2689,
    2701,  2709,  2717,  2727,  2729,  2733,  2735,  2737,  2739,  2741,
    2746,  2749,  2753,  2755,  2757,  2759,  2761,  2763,  2768,  2771,
    2774,  2777,  2780,  2782,  2786,  2788,  2790,  2794,  2799,  2803,
    2805,  2809,  2814,  2819,  2823,  2825,  2827,  2831,  2836,  2840,
    2845,  2847,  2851,  2856,  2861,  2863,  2867,  2870,  2875,  2877,
    2880,  2884,  2886,  2888,  2890,  2892,  2894,  2897,  2901,  2903,
    2907,  2912,  2918,  2920,  2926,  2928,  2930,  2932,  2934,  2936,
    2938,  2940,  2943,  2945,  2947,  2950,  2952,  2954,  2956,  2958,
    2961,  2965,  2968,  2972,  2974,  2976,  2978,  2980,  2983,  2986,
    2989,  2992,  2994,  2996,  2998,  3000,  3002,  3004,  3006,  3008,
    3011,  3015,  3019,  3024,  3027,  3029,  3031,  3033,  3035,  3037,
    3039,  3042,  3046,  3050,  3051,  3055,  3059,  3061,  3065,  3069,
    3071,  3073,  3077,  3079,  3081
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short int yyrhs[] =
{
     136,     0,    -1,   137,    -1,    -1,   138,   154,    -1,   137,
     154,    -1,   178,    -1,   140,    -1,   141,    -1,   143,    -1,
     144,    -1,   109,    10,    -1,   453,    -1,     7,    -1,   112,
      23,   142,    24,    10,    -1,   112,     1,    10,    -1,   110,
     453,    10,   145,   146,   111,    -1,   110,   453,    10,   145,
     111,    -1,   127,   148,    10,    -1,   127,     1,    10,    -1,
     147,    -1,   146,   147,    -1,    82,   151,    10,    -1,   149,
     151,    10,    -1,   149,   152,    10,    -1,   150,   151,    10,
      -1,   150,   152,    10,    -1,   453,    -1,   148,   453,    -1,
     117,   453,    -1,   118,   453,    -1,   116,    -1,   116,   148,
      -1,   115,   453,   153,    -1,    -1,    15,   110,    -1,   155,
      -1,   309,    -1,   139,    -1,   450,   158,    10,   161,   159,
      -1,   450,   158,    10,   159,    -1,   450,   158,   162,    10,
     161,   159,    -1,   450,   158,   168,    10,   161,   159,    -1,
     450,   158,   170,    10,   161,   159,    -1,   450,   158,   170,
      10,     1,   159,    -1,   450,   158,   168,    10,     1,   159,
      -1,   450,   158,    16,    17,    10,   161,   159,    -1,   450,
     158,   162,   168,    10,   161,   159,    -1,   450,   158,   162,
     170,    10,   161,   159,    -1,   454,    -1,    52,    -1,    54,
      -1,   157,   156,    -1,    -1,   160,    53,    -1,   177,    -1,
     161,   177,    -1,    -1,    29,    16,   163,   164,    17,    -1,
      29,     1,    17,    -1,    -1,    38,   165,   238,    -1,    -1,
     164,    98,    38,   166,   238,    -1,    -1,   164,    98,   167,
     238,    -1,    -1,    16,   169,   171,    17,    -1,    16,     1,
      17,    -1,    16,   255,    17,    -1,   172,    -1,   171,    98,
     172,    -1,   173,    -1,    11,   173,    16,    17,    -1,    11,
     173,    16,   173,    17,    -1,   175,    -1,    37,   174,    36,
      -1,   174,    98,   175,    -1,   175,    -1,   454,    -1,     8,
      -1,   454,    18,   438,    19,    -1,   454,    18,   434,    19,
      -1,   450,   195,    -1,   450,   198,    -1,   450,   201,    -1,
       1,    10,    -1,   178,    -1,   176,    10,    -1,   176,     1,
      10,    -1,   450,   295,    -1,   450,   182,    -1,   450,   188,
      -1,   450,   377,    -1,   450,   194,    -1,   179,    -1,   450,
     180,    -1,   450,   336,    -1,   450,   269,    -1,   450,   331,
      -1,   450,   276,    -1,   450,   339,    -1,   450,   340,    -1,
     210,    -1,   216,    -1,   209,    -1,   213,    -1,   217,    -1,
     214,    -1,   207,    -1,   208,    -1,   250,    -1,   242,    -1,
      -1,    51,   181,   232,    10,    -1,    51,     1,    10,    -1,
      -1,   103,   241,   183,   232,    10,    -1,    -1,   103,   264,
     184,   232,    10,    -1,    -1,   103,   185,   232,    10,    -1,
      -1,   103,   446,   186,   232,    10,    -1,    -1,   103,   446,
     241,   187,   232,    10,    -1,   103,     1,    10,    -1,    -1,
      38,   189,   232,    10,    -1,    -1,    38,   264,   190,   232,
      10,    -1,    -1,    38,   446,   241,   191,   232,    10,    -1,
      -1,    38,   241,   192,   232,    10,    -1,    -1,    38,   446,
     193,   232,    10,    -1,    38,     1,    10,    -1,    87,   241,
     235,    10,    -1,    87,   235,    10,    -1,    87,     1,    10,
      -1,    -1,    40,   246,   259,   196,   454,    -1,    -1,    40,
     206,   246,   259,   197,   454,    -1,   195,    98,   246,   259,
     454,    -1,   195,    98,   206,   246,   259,   454,    -1,    -1,
     101,   246,   259,   199,   454,    -1,    -1,   101,   206,   246,
     259,   200,   454,    -1,   198,    98,   246,   259,   454,    -1,
     198,    98,   206,   246,   259,   454,    -1,    -1,    39,   205,
     202,   454,    -1,    -1,    39,   203,   454,    -1,    39,   201,
     338,    -1,   201,    98,    39,   338,    -1,   201,    98,   454,
      -1,   201,    98,    39,   205,   454,    -1,   201,    98,    39,
     454,    -1,    47,    -1,   104,    -1,   206,    -1,   241,    -1,
     446,    -1,    46,    -1,   205,   102,    -1,   205,   241,    -1,
     205,   204,    -1,     3,    -1,    49,   226,    10,    -1,    49,
       1,    10,    -1,   108,   229,    10,    -1,   108,     1,    10,
      -1,   104,   236,    10,    -1,   104,     1,    10,    -1,     3,
     211,   246,   259,   231,    10,    -1,     3,   211,   246,   259,
     230,    10,    -1,     3,   211,   246,   259,   222,   230,    10,
      -1,     3,   211,   246,   259,   222,   231,    10,    -1,     3,
     220,   211,   246,   259,   222,   230,    10,    -1,     3,   220,
     211,   246,   259,   230,    10,    -1,     3,   220,   211,   246,
     259,   231,    10,    -1,     3,   221,   211,   246,   259,   231,
      10,    -1,     3,   221,   211,   246,   259,   222,   231,    10,
      -1,     3,   221,   211,   246,   259,   230,    10,    -1,     3,
       1,    10,    -1,    -1,   212,    -1,    44,    -1,    45,    -1,
      48,   236,    10,    -1,    48,     1,    10,    -1,    -1,   126,
     215,   236,    10,    -1,   126,     1,    10,    -1,    46,   246,
     241,   236,    10,    -1,    46,   246,   236,    10,    -1,    46,
       1,    10,    -1,    -1,    47,   218,   236,    10,    -1,    47,
       1,    10,    -1,   240,    -1,   219,   240,    -1,    16,     4,
      98,     5,    17,    -1,    16,     5,    98,     4,    17,    -1,
      16,     1,    17,    -1,    16,    41,    17,    -1,    16,    42,
      17,    -1,    16,    43,    17,    -1,    29,    16,   223,    17,
      -1,    29,   225,    -1,   225,    -1,   223,    98,   225,    -1,
     222,    -1,   439,    -1,   227,    -1,   228,    -1,   454,    -1,
     227,    98,   454,    -1,   454,   219,    -1,   228,    98,   454,
     219,    -1,   454,    -1,   229,    98,   454,    -1,   237,    -1,
     230,    98,   237,    -1,   226,    -1,   238,    -1,   232,    98,
     238,    -1,   454,    -1,   454,    22,   438,    -1,   454,   219,
      -1,   233,    -1,   239,    -1,   235,    98,   239,    -1,   234,
      -1,   236,    98,   234,    -1,   454,    22,   438,    -1,   453,
      22,   438,    -1,   454,    22,   439,    -1,    18,   433,    15,
     433,    19,    -1,    18,   441,    15,   440,    19,    -1,    63,
     245,   246,   244,   243,    10,   247,   356,    64,    -1,    63,
     245,   246,   244,   243,    16,   249,    17,    10,   247,   356,
      64,    -1,    63,     1,    64,    -1,   454,    -1,    -1,   241,
      -1,   104,    -1,    48,    -1,    47,    -1,   126,    -1,    -1,
     100,    -1,    -1,   102,    -1,   248,    -1,   247,   248,    -1,
     265,    -1,   262,    10,    -1,   263,    -1,   249,    98,   450,
     263,    -1,    61,   245,   251,    10,   253,   353,    62,    -1,
      61,   245,   251,    10,   353,    62,    -1,    61,   245,   251,
      16,   255,    17,    10,   252,   353,    62,    -1,    61,   245,
     251,    16,   255,    17,    10,   353,    62,    -1,    61,     1,
      62,    -1,   454,    -1,   252,   265,    -1,   265,    -1,   253,
     254,    -1,   254,    -1,   265,    -1,   256,    10,    -1,   256,
      -1,   255,    98,   256,    -1,   257,    -1,   261,   246,   258,
     259,   454,    -1,   261,   264,   454,    -1,   257,    98,   264,
     454,    -1,   257,    98,   246,   258,   259,   454,    -1,   257,
      98,   261,   246,   258,   259,   454,    -1,    -1,    46,    -1,
      -1,   241,    -1,    -1,     3,    -1,   450,    40,   260,    -1,
     450,    39,   260,    -1,   450,   101,   260,    -1,   261,    98,
     454,    -1,   263,    -1,   262,    98,   263,    -1,   101,   246,
     259,   454,    -1,   101,    46,   246,   259,   454,    -1,   101,
     264,   454,    -1,   263,    98,   454,    -1,   263,    98,   101,
     246,   259,   454,    -1,   263,    98,   101,    46,   246,   259,
     454,    -1,   263,    98,   101,   264,   454,    -1,   101,     1,
      10,    -1,    47,    -1,    48,    -1,   126,    -1,   104,    -1,
     450,   266,    -1,   450,   207,    -1,   450,   209,    -1,   450,
     182,    -1,   450,   188,    -1,   450,   213,    -1,   450,   214,
      -1,   450,   217,    -1,    46,   241,   267,    10,    -1,    46,
     446,   241,   267,    10,    -1,    46,   267,    10,    -1,   268,
      -1,   267,    98,   268,    -1,   454,    -1,   454,   219,    -1,
       6,   222,   271,    10,    -1,     6,   271,    10,    -1,     6,
     220,   271,    10,    -1,     6,   220,   222,   271,    10,    -1,
       6,   270,    10,    -1,     6,     1,    10,    -1,   273,    -1,
     270,    98,   273,    -1,   272,    -1,   271,    98,   272,    -1,
     274,    16,   275,    98,   435,    17,    -1,    16,   275,    98,
     435,    17,    -1,   274,    16,   275,    17,    -1,    16,   275,
      17,    -1,   454,   241,    -1,   454,    -1,   445,    -1,   277,
      -1,    -1,    -1,   454,   278,   282,   281,   279,    10,    -1,
      -1,   454,   281,   280,    10,    -1,   288,    -1,   281,    98,
     288,    -1,    29,    16,   283,    17,    -1,    29,    16,     1,
      17,    10,    -1,   284,    -1,   286,    -1,   285,    -1,   284,
      98,   285,    -1,   438,    -1,   287,    -1,   286,    98,   287,
      -1,    11,   454,    16,   438,    17,    -1,    11,   454,    16,
      17,    -1,   289,    16,   290,    17,    -1,   289,    16,    17,
      -1,   454,   259,    -1,   291,    -1,   293,    -1,   292,    -1,
     291,    98,   292,    -1,   450,   438,    -1,   294,    -1,   293,
      98,   294,    -1,   450,   287,    -1,    -1,   106,   296,   297,
     107,    -1,   106,     1,   107,    -1,   300,    -1,   297,   300,
      -1,    -1,   299,   300,    -1,    10,    -1,   301,    -1,   302,
      -1,   305,    -1,   308,    -1,   178,    -1,    65,    16,   438,
      17,   298,    -1,    65,    16,   438,    17,   298,    79,   298,
      -1,    66,    16,   438,    17,   303,    80,    -1,   304,    -1,
     303,    98,   304,    -1,   435,    15,   298,    -1,    82,    15,
     298,    -1,    82,   298,    -1,    -1,    71,    16,   307,    10,
     438,    10,   307,    17,   306,   308,    -1,   454,    22,   438,
      -1,    81,    15,   454,   297,    84,    -1,    81,   297,    84,
      -1,    81,     1,    84,    -1,    81,    15,   454,     1,    84,
      -1,   450,    56,   310,    16,   311,    17,    10,   314,   319,
      55,    -1,   450,    56,   310,    16,   312,    17,    10,   314,
     319,    55,    -1,   454,    -1,   454,    -1,   311,    98,   454,
      -1,   316,    98,   313,    -1,   317,    -1,   313,    98,   317,
      -1,   313,    98,   454,    -1,   315,    -1,   314,   315,    -1,
     316,    10,    -1,   317,    10,    -1,   318,    10,    -1,   315,
      10,    -1,   450,    39,   454,    -1,   450,    39,    46,   454,
      -1,   450,    39,    46,   454,    22,   438,    -1,   316,    98,
     454,    -1,   450,   101,   454,    -1,   317,    98,   454,    -1,
     450,    46,   454,    -1,   318,    98,   454,    -1,   320,    -1,
      58,   321,    59,    -1,    58,     1,    59,    -1,   323,    58,
     321,    59,    -1,   322,    -1,   321,   322,    -1,   325,    15,
     329,    10,    -1,   325,    15,   327,    15,   328,    10,    -1,
      57,   454,    22,   324,    10,    -1,    57,     1,    10,    -1,
       8,    -1,   326,    -1,   330,    -1,   325,   326,    -1,   325,
     330,    -1,    16,   330,    17,    -1,    16,   330,   330,    17,
      -1,   326,    16,   330,    17,    -1,   330,    -1,   329,    -1,
      14,    -1,   330,    -1,     8,    -1,    99,    -1,    26,    -1,
      12,    -1,   454,   220,   224,   332,    10,    -1,   454,   220,
     332,    10,    -1,   454,   332,    10,    -1,   333,    -1,   332,
      98,   333,    -1,    -1,   334,   335,    16,   275,    98,   435,
      17,    -1,    16,   275,    98,   435,    17,    -1,   289,    -1,
      50,   220,   222,   337,    10,    -1,    50,   222,   337,    10,
      -1,    50,   337,    10,    -1,    50,   220,   337,    10,    -1,
     338,    -1,   337,    98,   338,    -1,   445,    22,   438,    -1,
      57,   354,    -1,    57,     1,    84,    -1,    -1,    60,   341,
     354,    -1,   340,     1,    84,    -1,   445,    22,   359,   438,
      -1,   445,    22,   438,    -1,   445,    22,   359,    -1,   342,
       1,    -1,   445,    23,    22,   359,   438,    -1,   445,    23,
      22,   438,    -1,   445,    23,    22,   359,    -1,   343,     1,
      -1,    50,   349,    -1,    76,   445,    -1,    74,   338,    -1,
      75,   445,    -1,   445,    22,   438,    -1,   356,    -1,   450,
      10,    -1,    81,   353,    84,    -1,    81,    15,   454,   252,
     353,    84,    -1,    81,    15,   454,   348,    84,    -1,    81,
     252,   353,    84,    -1,    81,    84,    -1,   356,    -1,   348,
     356,    -1,   445,    22,   438,    -1,    83,   353,    72,    -1,
      83,    15,   454,   252,   353,    72,    -1,    83,    15,   454,
     353,    72,    -1,    83,    72,    -1,    83,    15,     1,    72,
      -1,    83,     1,    72,    -1,    -1,    81,   352,   353,    84,
      -1,    81,    15,   454,   252,   353,    84,    -1,    81,    15,
     454,   353,    84,    -1,    81,    84,    -1,    81,    15,   454,
      84,    -1,    81,     1,    84,    -1,   354,    -1,   353,   354,
      -1,   450,   342,    10,    -1,   450,   370,    -1,   450,   368,
      -1,   450,   361,    -1,   450,   363,    -1,   450,   374,    -1,
     450,   343,    10,    -1,   450,   350,    -1,   450,   344,    10,
      -1,   450,   366,    -1,   450,   351,    -1,   450,   375,    -1,
     450,   367,    -1,   354,    -1,    10,    -1,   450,   345,    10,
      -1,   450,   357,    -1,   450,   369,    -1,   450,   373,    -1,
     450,   347,    -1,   450,   361,    -1,   450,   375,    -1,   370,
      -1,    29,     8,    -1,    29,    12,    -1,    29,    16,   439,
      17,    -1,   358,    -1,   362,    -1,    -1,    70,    16,   438,
     360,    17,   362,    -1,    77,   454,    10,    -1,    31,   454,
      -1,    31,    16,   365,    17,    -1,    31,    26,    -1,    31,
      16,    26,    17,    -1,    14,    24,   454,    10,    -1,   438,
      -1,    95,   438,    -1,    96,   438,    -1,   364,    -1,   365,
      98,   364,    -1,   365,     6,   364,    -1,   359,   355,    -1,
      73,    16,   438,    17,   355,    -1,    65,    16,   438,    17,
     355,    -1,    65,    16,   438,    17,   355,    79,   355,    -1,
      65,    16,   438,    17,     1,    79,   355,    -1,    65,    16,
     438,    17,   346,    -1,    65,    16,   438,    17,   346,    79,
     346,    -1,    66,    16,   438,    17,   371,    80,    -1,    66,
      16,   438,    17,     1,    80,    -1,    68,    16,   438,    17,
     371,    80,    -1,    68,     1,    80,    -1,    67,    16,   438,
      17,   371,    80,    -1,    67,     1,    80,    -1,   372,    -1,
     371,   372,    -1,   435,    15,   355,    -1,    82,    15,   355,
      -1,    82,   355,    -1,    69,   356,    -1,    70,    16,   438,
      17,   356,    -1,    78,    16,   438,    17,   356,    -1,    71,
      16,   349,    10,   438,    10,   349,    17,   356,    -1,    69,
     354,    -1,    70,    16,   438,    17,   354,    -1,    78,    16,
     438,    17,   354,    -1,    71,    16,   349,    10,   438,    10,
     349,    17,   354,    -1,   453,    16,   376,    17,    10,    -1,
     453,    16,     1,    17,    10,    -1,   453,    10,    -1,   438,
      -1,   376,    98,   438,    -1,   376,    98,    -1,    98,    -1,
      85,   378,    86,    -1,    85,    86,    -1,    85,     1,    86,
      -1,   379,    -1,   378,   379,    -1,   194,    -1,   382,    -1,
     400,    -1,   380,    -1,   381,    -1,   113,   386,    10,    -1,
     114,   386,    10,    -1,   114,     1,    10,    -1,   119,   386,
      10,    -1,   120,   386,    10,    -1,   120,     1,    10,    -1,
     383,    10,    -1,   392,    10,    -1,   398,    10,    -1,   384,
      22,   389,    -1,    16,   388,    22,    24,   388,    17,    -1,
      16,   385,   387,   386,    17,    -1,    16,   385,    26,    24,
     386,    17,    -1,   388,    -1,   385,    98,   388,    -1,   385,
      -1,   399,    22,    24,    -1,   399,    26,    24,    -1,   454,
      -1,   454,    18,   434,    19,    -1,   454,    18,   438,    19,
      -1,   390,    -1,    16,   390,    17,    -1,   391,    -1,    16,
     391,    98,   391,    17,    -1,    16,   391,    98,   391,    98,
     391,    17,    -1,    16,   391,    98,   391,    98,   391,    98,
     391,    98,   391,    98,   391,    17,    -1,    16,   391,    98,
     391,    98,   391,    98,   391,    98,   391,    98,   391,    98,
     391,    98,   391,    98,   391,    98,   391,    98,   391,    98,
     391,    17,    -1,   439,    -1,   393,    22,   389,    -1,   394,
      22,   389,    -1,    16,   397,   388,    22,    24,   395,    -1,
      16,   388,    22,    24,   395,    -1,    16,   397,   385,    26,
      24,   386,   447,    15,   396,    17,    -1,    16,   385,    26,
      24,   386,   447,    15,   396,    17,    -1,   388,   447,    15,
     396,    17,    -1,    16,   388,   447,    15,   396,    17,    17,
      -1,   438,    -1,    95,    -1,    96,    -1,    65,    16,   438,
      17,   383,    -1,    65,    16,   438,    17,   392,    -1,   125,
     383,    -1,   447,    -1,   404,    -1,   405,    -1,   406,    -1,
     407,    -1,   408,    -1,   409,    -1,   412,    -1,   411,    -1,
     410,    -1,   403,    -1,   401,    -1,   402,    -1,   122,    16,
     416,    98,   417,    98,   415,    98,   413,    17,    10,    -1,
     122,    16,   416,    98,   417,    98,   415,    17,    10,    -1,
     123,    16,   416,    98,   417,    98,   415,    98,   413,    17,
      10,    -1,   123,    16,   416,    98,   417,    98,   415,    17,
      10,    -1,   124,    16,   418,    98,   418,    98,   415,    98,
     415,    98,   413,    17,    10,    -1,   124,    16,   418,    98,
     418,    98,   415,    98,   415,    17,    10,    -1,    88,    16,
     416,    98,   417,    98,   415,    98,   413,    17,    10,    -1,
      88,    16,   416,    98,   417,    98,   415,    17,    10,    -1,
      88,    16,     1,    17,    -1,    89,    16,   416,    98,   417,
      98,   415,    98,   413,    17,    10,    -1,    89,    16,   416,
      98,   417,    98,   415,    17,    10,    -1,    89,     1,    10,
      -1,    94,    16,   418,    98,   418,    98,   415,    98,   415,
      98,   413,    17,    10,    -1,    94,    16,   418,    98,   418,
      98,   415,    98,   415,    17,    10,    -1,    93,    16,   416,
      98,   417,    98,   415,    98,   413,    17,    10,    -1,    93,
      16,   416,    98,   417,    98,   415,    17,    10,    -1,   121,
      16,   416,    98,   417,    98,   415,    98,   413,    17,    10,
      -1,   121,    16,   416,    98,   417,    98,   415,    17,    10,
      -1,    92,    16,   416,    98,   417,    98,   415,    98,   413,
      17,    10,    -1,    92,    16,   416,    98,   417,    98,   415,
      17,    10,    -1,   105,    16,   418,    98,   418,    98,   439,
      98,   439,    17,    10,    -1,   105,    16,   418,    98,   418,
      98,   439,    98,   439,    98,   413,    17,    10,    -1,    90,
      16,   419,    98,   415,    98,   438,    98,   413,    17,    10,
      -1,    90,    16,   419,    98,   415,    17,    10,    -1,    91,
      16,   419,    98,   415,    17,    10,    -1,    91,    16,   419,
      98,   415,    98,   413,    17,    10,    -1,   414,    -1,   413,
      98,   414,    -1,   438,    -1,   438,    -1,   418,    -1,   418,
      -1,   420,   424,   134,   425,    -1,   420,   424,    -1,   424,
     134,   425,    -1,   424,    -1,   418,    -1,    95,    -1,    96,
      -1,   421,    -1,    97,    18,   423,    19,    -1,     1,    19,
      -1,     8,     8,    -1,     8,    12,    -1,    12,     8,    -1,
     422,    -1,   423,    98,   422,    -1,   388,    -1,   439,    -1,
      37,   435,    36,    -1,    37,   438,   426,    36,    -1,    37,
     429,    36,    -1,   430,    -1,   429,    98,   430,    -1,   454,
      18,   434,    19,    -1,   454,    18,   438,    19,    -1,   454,
     432,   434,    -1,   428,    -1,   454,    -1,    16,   435,    17,
      -1,   449,    16,   435,    17,    -1,    18,   438,    19,    -1,
     432,    18,   438,    19,    -1,   438,    -1,   438,    15,   440,
      -1,   438,    13,    15,   442,    -1,   438,    14,    15,   442,
      -1,   438,    -1,   435,    98,   438,    -1,   453,   432,    -1,
     453,    18,   434,    19,    -1,   453,    -1,   453,   431,    -1,
      16,   439,    17,    -1,   426,    -1,   427,    -1,   448,    -1,
     436,    -1,     7,    -1,   443,   436,    -1,   443,   449,   436,
      -1,   437,    -1,   438,   444,   437,    -1,   438,   444,   449,
     437,    -1,   438,    99,   438,    15,   437,    -1,   438,    -1,
     438,    15,   438,    15,   439,    -1,   438,    -1,   438,    -1,
     438,    -1,    35,    -1,    20,    -1,    25,    -1,    34,    -1,
      34,    20,    -1,   132,    -1,    21,    -1,    34,    21,    -1,
     447,    -1,   133,    -1,    27,    -1,   447,    -1,    22,    22,
      -1,    22,    22,    22,    -1,    35,    22,    -1,    35,    22,
      22,    -1,   131,    -1,   130,    -1,    24,    -1,    23,    -1,
      23,    23,    -1,    23,    22,    -1,    24,    22,    -1,    24,
      24,    -1,    26,    -1,    28,    -1,    25,    -1,    20,    -1,
      21,    -1,    34,    -1,   132,    -1,   133,    -1,    26,    26,
      -1,    23,    23,    23,    -1,    24,    24,    24,    -1,   454,
      18,   434,    19,    -1,   454,   432,    -1,   428,    -1,   453,
      -1,   102,    -1,    14,    -1,    13,    -1,     8,    -1,   447,
       8,    -1,   129,   451,   128,    -1,   129,     1,   128,    -1,
      -1,   129,   451,   128,    -1,   129,     1,   128,    -1,   452,
      -1,   451,    98,   452,    -1,   454,    22,   438,    -1,   454,
      -1,   454,    -1,   453,    11,   454,    -1,   455,    -1,    12,
      -1,    32,   455,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short int yyrline[] =
{
       0,   125,   125,   127,   127,   128,   129,   137,   139,   140,
     141,   144,   147,   148,   151,   152,   158,   159,   163,   164,
     169,   170,   174,   175,   176,   177,   178,   182,   183,   187,
     190,   194,   195,   198,   201,   202,   209,   210,   211,   215,
     216,   217,   219,   220,   221,   222,   223,   224,   225,   230,
     233,   234,   236,   255,   255,   263,   264,   271,   271,   272,
     275,   275,   276,   276,   277,   277,   283,   283,   284,   288,
     292,   293,   296,   297,   298,   301,   302,   305,   306,   309,
     310,   311,   312,   315,   316,   317,   318,   325,   326,   327,
     328,   329,   330,   331,   332,   336,   337,   338,   339,   340,
     341,   342,   343,   346,   347,   348,   349,   350,   351,   352,
     353,   354,   355,   359,   359,   360,   368,   368,   369,   369,
     370,   370,   371,   371,   372,   372,   373,   376,   376,   377,
     377,   378,   378,   379,   379,   380,   380,   381,   384,   385,
     386,   393,   393,   394,   394,   395,   396,   399,   399,   400,
     400,   401,   402,   407,   407,   408,   408,   409,   410,   411,
     412,   413,   421,   422,   426,   427,   428,   429,   430,   431,
     432,   437,   441,   442,   445,   446,   449,   450,   454,   455,
     456,   457,   458,   459,   460,   461,   462,   463,   464,   468,
     469,   473,   474,   477,   478,   480,   480,   481,   484,   485,
     486,   489,   489,   490,   493,   494,   501,   502,   503,   508,
     509,   510,   519,   520,   523,   524,   527,   530,   537,   538,
     541,   542,   546,   547,   551,   552,   555,   556,   559,   562,
     563,   568,   569,   570,   573,   577,   578,   581,   584,   592,
     594,   601,   609,   612,   620,   628,   632,   636,   649,   650,
     651,   652,   653,   654,   658,   659,   662,   663,   666,   667,
     671,   672,   676,   677,   685,   687,   689,   691,   693,   696,
     708,   709,   712,   713,   717,   718,   722,   723,   728,   732,
     737,   741,   746,   751,   759,   760,   762,   763,   765,   766,
     769,   770,   771,   772,   776,   777,   780,   781,   782,   783,
     784,   785,   786,   787,   791,   792,   793,   794,   801,   802,
     803,   804,   805,   806,   807,   808,   811,   812,   813,   817,
     818,   821,   822,   829,   830,   831,   832,   833,   834,   837,
     838,   841,   842,   847,   848,   853,   854,   857,   858,   866,
     873,   876,   877,   876,   878,   878,   881,   882,   885,   886,
     888,   889,   892,   893,   896,   899,   900,   904,   905,   909,
     910,   913,   929,   930,   933,   934,   937,   941,   942,   945,
     955,   955,   956,   959,   960,   964,   964,   965,   969,   970,
     971,   972,   973,   976,   977,   980,   983,   984,   987,   988,
     989,   993,   993,   996,   999,  1000,  1001,  1002,  1010,  1012,
    1017,  1039,  1040,  1042,  1045,  1046,  1047,  1050,  1051,  1054,
    1055,  1056,  1058,  1061,  1062,  1063,  1064,  1067,  1068,  1070,
    1071,  1077,  1081,  1082,  1083,  1086,  1087,  1090,  1091,  1096,
    1097,  1100,  1104,  1105,  1106,  1107,  1110,  1111,  1112,  1116,
    1118,  1119,  1122,  1125,  1126,  1127,  1128,  1136,  1137,  1138,
    1141,  1142,  1145,  1145,  1146,  1149,  1157,  1158,  1159,  1160,
    1163,  1164,  1167,  1170,  1171,  1174,  1174,  1184,  1188,  1189,
    1190,  1191,  1194,  1195,  1196,  1197,  1204,  1205,  1206,  1207,
    1210,  1214,  1215,  1223,  1224,  1225,  1226,  1227,  1232,  1233,
    1236,  1239,  1240,  1241,  1242,  1243,  1244,  1249,  1248,  1251,
    1252,  1253,  1254,  1255,  1258,  1259,  1267,  1268,  1269,  1270,
    1271,  1272,  1273,  1274,  1275,  1276,  1277,  1278,  1279,  1282,
    1283,  1287,  1288,  1289,  1290,  1291,  1292,  1293,  1296,  1302,
    1303,  1304,  1307,  1308,  1309,  1309,  1312,  1315,  1316,  1317,
    1318,  1321,  1324,  1325,  1326,  1329,  1330,  1331,  1334,  1336,
    1342,  1343,  1344,  1348,  1349,  1356,  1357,  1358,  1359,  1360,
    1361,  1365,  1366,  1370,  1371,  1372,  1379,  1380,  1381,  1382,
    1386,  1387,  1388,  1389,  1397,  1398,  1399,  1402,  1403,  1404,
    1405,  1412,  1413,  1414,  1418,  1419,  1423,  1424,  1425,  1426,
    1427,  1431,  1432,  1433,  1437,  1438,  1439,  1446,  1447,  1448,
    1452,  1457,  1458,  1459,  1462,  1463,  1466,  1469,  1470,  1480,
    1481,  1482,  1486,  1487,  1491,  1492,  1493,  1494,  1495,  1503,
    1506,  1507,  1511,  1512,  1516,  1518,  1524,  1525,  1529,  1531,
    1532,  1536,  1537,  1538,  1542,  1551,  1552,  1553,  1554,  1555,
    1556,  1557,  1558,  1559,  1560,  1561,  1562,  1566,  1567,  1570,
    1571,  1575,  1576,  1580,  1581,  1582,  1585,  1586,  1587,  1591,
    1592,  1595,  1596,  1598,  1599,  1603,  1604,  1607,  1608,  1611,
    1612,  1616,  1617,  1620,  1621,  1624,  1632,  1634,  1637,  1640,
    1641,  1642,  1643,  1646,  1650,  1651,  1652,  1655,  1656,  1659,
    1660,  1661,  1664,  1665,  1668,  1672,  1680,  1682,  1684,  1686,
    1687,  1690,  1691,  1692,  1693,  1694,  1703,  1704,  1712,  1713,
    1717,  1721,  1722,  1723,  1726,  1727,  1735,  1736,  1737,  1738,
    1739,  1740,  1741,  1742,  1746,  1747,  1748,  1749,  1752,  1753,
    1754,  1755,  1758,  1759,  1762,  1764,  1766,  1773,  1774,  1775,
    1776,  1777,  1778,  1779,  1780,  1781,  1782,  1786,  1787,  1789,
    1790,  1791,  1792,  1793,  1794,  1795,  1796,  1797,  1798,  1799,
    1800,  1801,  1802,  1803,  1804,  1805,  1806,  1807,  1808,  1809,
    1810,  1811,  1819,  1820,  1821,  1822,  1828,  1831,  1832,  1836,
    1837,  1848,  1849,  1852,  1853,  1854,  1857,  1858,  1861,  1862,
    1865,  1866,  1870,  1873,  1877
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "NET_TOK", "STR0_TOK", "STR1_TOK",
  "GATE_TOK", "STRING_TOK", "DIGIT_TOK", "UNDERSCORE_TOK", "SEM_TOK",
  "DOT_TOK", "LETTER_TOK", "PLUS_TOK", "MINUS_TOK", "COLON_TOK",
  "LBRACE_TOK", "RBRACE_TOK", "LBRACKET_TOK", "RBRACKET_TOK", "AND_TOK",
  "OR_TOK", "EQU_TOK", "GT_TOK", "LT_TOK", "NOT_TOK", "MULT_TOK",
  "PERCENTAL_TOK", "ENV_TOK", "PARA_TOK", "CHAR_TOK", "AT_TOK",
  "DOLLAR_TOK", "BASE_TOK", "SN_TOK", "EXCLAMATION_TOK", "RRAM_TOK",
  "LRAM_TOK", "PARAMETER_TOK", "OUTPUT_TOK", "INOUT_TOK", "SMALL_TOK",
  "MEDIUM_TOK", "LARGE_TOK", "VEC_TOK", "SCALAR_TOK", "REG_TOK",
  "TIME_TOK", "REAL_TOK", "EVENT_TOK", "ASSIGN_TOK", "DEFPARAM_TOK",
  "MODUL_TOK", "ENDMODUL_TOK", "MACRO_MODUL_TOK", "ENDPRIMITIVE_TOK",
  "PRIMITIVE_TOK", "INITIAL_TOK", "TABLE_TOK", "ENDTABLE_TOK",
  "ALWAYS_TOK", "TASK_TOK", "ENDTASK_TOK", "FUNC_TOK", "ENDFUNC_TOK",
  "IF_TOK", "CASE_TOK", "CASEX_TOK", "CASEZ_TOK", "FOREVER_TOK",
  "REPEAT_TOK", "FOR_TOK", "JOIN_TOK", "WAIT_TOK", "FORCE_TOK",
  "RELEASE_TOK", "DEASSIGN_TOK", "DISABLE_TOK", "WHILE_TOK", "ELSE_TOK",
  "ENDCASE_TOK", "BEGIN_TOK", "DEFAULT_TOK", "FORK_TOK", "END_TOK",
  "SPECIFY_TOK", "ENDSPECIFY_TOK", "SPECPARAM_TOK", "DSETUP_TOK",
  "DHOLD_TOK", "DWIDTH_TOK", "DPERIOD_TOK", "DSKEW_TOK", "DRECOVERY_TOK",
  "DSETUPHOLD_TOK", "POSEDGE_TOK", "NEGEDGE_TOK", "EDGE_TOK", "COMMA_TOK",
  "QUESTION_TOK", "AUTO_TOK", "INPUT_TOK", "SIGNED_TOK", "LOCALPARAM_TOK",
  "INTEGER_TOK", "NOCHANGE_TOK", "GENERATE_TOK", "ENDGENERATE_TOK",
  "GENVAR_TOK", "LIBRARY_TOK", "CONFIG_TOK", "ENDCONFIG_TOK",
  "INCLUDE_TOK", "PULSEON_DETECT_TOK", "PULSEONE_EVENT_TOK", "USE_TOK",
  "LIBLIST_TOK", "INSTANCE_TOK", "CELL_TOK", "SHOWCANCEL_TOK",
  "NOSHOWCANCEL_TOK", "REMOVAL_TOK", "FULLSKEW_TOK", "TIMESKEW_TOK",
  "RECREM_TOK", "IFNONE_TOK", "REALTIME_TOK", "DESIGN_TOK", "ATL_TOK",
  "ATR_TOK", "OOR_TOK", "AAND_TOK", "SNNOT_TOK", "NOTSN_TOK", "AAAND_TOK",
  "$accept", "file", "lines", "@1", "library_text", "library_descriptions",
  "library_declaration", "file_path_spec", "include_statement",
  "config_declaration", "design_statement", "config_rule_statement_list",
  "config_rule_statement", "aidentifier_list", "inst_clause",
  "cell_clause", "liblist_clause", "use_clause", "config", "description",
  "module_declaration", "name_of_module", "module_type", "module_keyword",
  "end_mod", "@2", "module_option", "module_parameter_port_list", "@3",
  "parameter_declaration_list", "@4", "@5", "@6", "list_of_ports", "@7",
  "list_of_port_declarations", "port_list", "port", "port_expression",
  "port_reference_list", "port_reference", "port_declaration",
  "module_item", "module_or_generate_item",
  "module_or_generate_item_declaration", "parameter_override", "@8",
  "local_parameter_declaration", "@9", "@10", "@11", "@12", "@13",
  "parameter_declaration", "@14", "@15", "@16", "@17", "@18",
  "specparam_declaration", "inout_declaration", "@19", "@20",
  "input_declaration", "@21", "@22", "output_declaration", "@23", "@24",
  "output_var_type", "s_type", "net_type", "event_declaration",
  "genvar_declaration", "integer_declaration", "net_declaration",
  "xscalared", "scalared", "real_declaration", "realtime_declaration",
  "@25", "reg_declaration", "time_declaration", "@26", "dimension_list",
  "drive_strength", "charge_strength", "delay3", "delay_value_list",
  "delay2", "delay_value", "list_of_event_identifiers",
  "list_of_event_lists", "dim_list", "list_of_genvar_identifiers",
  "list_of_net_decl_assignments", "list_of_net_identifiers",
  "list_of_param_assignments", "real_type", "variable_type",
  "list_of_specparam_assignments", "list_of_variable_identifiers",
  "net_decl_assignment", "param_assignment", "specparam_assignment",
  "dimension", "range", "function_declaration", "name_of_function",
  "range_or_type", "automatic", "xsigned",
  "function_item_declaration_list", "function_item_declaration",
  "function_port_list", "task_declaration", "name_of_task",
  "block_item_declaration_list", "task_item_declaration_list",
  "task_item_declaration", "task_port_list", "task_port_item",
  "tf_port_declaration", "xreg", "xrange", "xnettype", "tf_port_dir",
  "tf_input_declaration_list", "tf_input_declaration", "task_port_type",
  "block_item_declaration", "block_reg_declaration",
  "list_of_block_variable_identifiers", "block_variable_type",
  "gate_instantiation", "pull_gate_instance_list",
  "cmos_switch_instance_list", "cmos_switch_instance",
  "pull_gate_instance", "name_of_gate_instance", "output_terminal",
  "module_instantiation", "module_identifier", "@27", "@28", "@29",
  "module_instance_list", "parameter_value_assignment",
  "list_of_parameter_assignments", "ordered_parameter_assignment_list",
  "ordered_parameter_assignment", "named_parameter_assignment_list",
  "named_parameter_assignment", "module_instance", "identifier11",
  "list_of_port_connections", "ordered_port_connection_list",
  "ordered_port_connection", "named_port_connection_list",
  "named_port_connection", "generated_instantiation", "@30",
  "generate_item_list", "generate_item_or_null", "@31", "generate_item",
  "generate_conditional_statement", "generate_case_statement",
  "genvar_module_case_item_list", "genvar_case_item",
  "generate_loop_statement", "@32", "genvar_assignment", "generate_block",
  "udp_declaration", "name_of_udp", "udp_port_list",
  "udp_declaration_port_list", "udp_input_declaration_list",
  "udp_port_declaration_list", "udp_port_declaration",
  "udp_output_declaration", "udp_input_declaration", "udp_reg_declaration",
  "udp_body", "combinational_body", "combinational_entry_list",
  "combinational_entry", "udp_initial_statement", "init_val",
  "edge_input_list", "edge_indicator", "current_state", "next_state",
  "output_symbol", "level_symbol", "udp_instantiation",
  "udp_instance_list", "udp_instance", "@33", "name_of_instance",
  "continuous_assign", "list_of_net_assignments", "net_assignment",
  "initial_construct", "always_construct", "@34", "blocking_assignment",
  "nonblocking_assignment", "procedural_continuous_assignments",
  "function_blocking_assignment", "function_statement_or_null",
  "function_seq_block", "function_statement_list", "variable_assignment",
  "par_block", "seq_block", "@35", "statement_list", "statement",
  "statement_or_null", "function_statement", "function_case_statement",
  "delay_control", "delay_or_event_control", "@36", "disable_statement",
  "event_control", "event_trigger", "event_expression",
  "event_expression_list", "procedural_timing_control_statement",
  "wait_statement", "conditional_statement",
  "function_conditional_statement", "case_statement", "case_item_list",
  "case_item", "function_loop_statement", "loop_statement",
  "system_task_enable", "expression_list_null", "specify_block",
  "specify_item_list", "specify_item", "pulsestyle_declaration",
  "showcancelled_declaration", "path_declaration",
  "simple_path_declaration", "parallel_path_description",
  "list_of_path_inputs", "list_of_path_outputs", "connection",
  "specify_input_terminal_descriptor", "path_delay_value",
  "list_of_path_delay_expressions", "path_delay_expression",
  "edge_sensitive_path_declaration",
  "parallel_edge_sensitive_path_description",
  "full_edge_sensitive_path_description", "example",
  "data_source_expression", "edge_identifier",
  "state_dependent_path_declaration", "polarity_operator",
  "system_timing_check", "fullskew_timing_check",
  "timingskew_timing_check", "recrem_timing_check", "setup_timing_check",
  "hold_timing_check", "setuphold_timing_check", "recovery_timing_check",
  "removal_timing_check", "skew_timing_check", "nochange_timing_check",
  "width_timing_check", "period_timing_check", "notify_register_list",
  "notify_register", "timing_check_limit", "data_event", "reference_event",
  "timing_check_event", "controlled_timing_check_event",
  "timing_check_event_control", "edge_control_specifier",
  "edge_descriptor", "edge_descriptor_list", "specify_terminal_descriptor",
  "timing_check_condition", "concatenation", "multiple_concatenation",
  "net_concatenation", "net_concatenation_value_list",
  "net_concatenation_value", "function_call", "expression_bracket_list",
  "dimension_constant_expression", "range_expression", "expression_list",
  "primary", "unprim", "expression", "mintypemax_expression",
  "lsb_constant_expression", "msb_constant_expression",
  "width_constant_expression", "unary_operator", "binary_operator",
  "net_lvalue", "signed", "pol_op", "number", "attribute_instance11",
  "attribute_instance", "attr_spec_list", "attr_spec", "simple_identifier",
  "identifier", "ident", 0
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned short int yyr1[] =
{
       0,   135,   136,   138,   137,   137,   137,   139,   140,   140,
     140,   141,   142,   142,   143,   143,   144,   144,   145,   145,
     146,   146,   147,   147,   147,   147,   147,   148,   148,   149,
     150,   151,   151,   152,   153,   153,   154,   154,   154,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   156,
     157,   157,   158,   160,   159,   161,   161,   163,   162,   162,
     165,   164,   166,   164,   167,   164,   169,   168,   168,   170,
     171,   171,   172,   172,   172,   173,   173,   174,   174,   175,
     175,   175,   175,   176,   176,   176,   176,   177,   177,   177,
     177,   177,   177,   177,   177,   178,   178,   178,   178,   178,
     178,   178,   178,   179,   179,   179,   179,   179,   179,   179,
     179,   179,   179,   181,   180,   180,   183,   182,   184,   182,
     185,   182,   186,   182,   187,   182,   182,   189,   188,   190,
     188,   191,   188,   192,   188,   193,   188,   188,   194,   194,
     194,   196,   195,   197,   195,   195,   195,   199,   198,   200,
     198,   198,   198,   202,   201,   203,   201,   201,   201,   201,
     201,   201,   204,   204,   205,   205,   205,   205,   205,   205,
     205,   206,   207,   207,   208,   208,   209,   209,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   210,   210,   211,
     211,   212,   212,   213,   213,   215,   214,   214,   216,   216,
     216,   218,   217,   217,   219,   219,   220,   220,   220,   221,
     221,   221,   222,   222,   223,   223,   224,   225,   226,   226,
     227,   227,   228,   228,   229,   229,   230,   230,   231,   232,
     232,   233,   233,   233,   234,   235,   235,   236,   236,   237,
     238,   239,   240,   241,   242,   242,   242,   243,   244,   244,
     244,   244,   244,   244,   245,   245,   246,   246,   247,   247,
     248,   248,   249,   249,   250,   250,   250,   250,   250,   251,
     252,   252,   253,   253,   254,   254,   255,   255,   256,   257,
     257,   257,   257,   257,   258,   258,   259,   259,   260,   260,
     261,   261,   261,   261,   262,   262,   263,   263,   263,   263,
     263,   263,   263,   263,   264,   264,   264,   264,   265,   265,
     265,   265,   265,   265,   265,   265,   266,   266,   266,   267,
     267,   268,   268,   269,   269,   269,   269,   269,   269,   270,
     270,   271,   271,   272,   272,   273,   273,   274,   274,   275,
     276,   278,   279,   277,   280,   277,   281,   281,   282,   282,
     283,   283,   284,   284,   285,   286,   286,   287,   287,   288,
     288,   289,   290,   290,   291,   291,   292,   293,   293,   294,
     296,   295,   295,   297,   297,   299,   298,   298,   300,   300,
     300,   300,   300,   301,   301,   302,   303,   303,   304,   304,
     304,   306,   305,   307,   308,   308,   308,   308,   309,   309,
     310,   311,   311,   312,   313,   313,   313,   314,   314,   315,
     315,   315,   315,   316,   316,   316,   316,   317,   317,   318,
     318,   319,   320,   320,   320,   321,   321,   322,   322,   323,
     323,   324,   325,   325,   325,   325,   326,   326,   326,   327,
     328,   328,   329,   330,   330,   330,   330,   331,   331,   331,
     332,   332,   334,   333,   333,   335,   336,   336,   336,   336,
     337,   337,   338,   339,   339,   341,   340,   340,   342,   342,
     342,   342,   343,   343,   343,   343,   344,   344,   344,   344,
     345,   346,   346,   347,   347,   347,   347,   347,   348,   348,
     349,   350,   350,   350,   350,   350,   350,   352,   351,   351,
     351,   351,   351,   351,   353,   353,   354,   354,   354,   354,
     354,   354,   354,   354,   354,   354,   354,   354,   354,   355,
     355,   356,   356,   356,   356,   356,   356,   356,   357,   358,
     358,   358,   359,   359,   360,   359,   361,   362,   362,   362,
     362,   363,   364,   364,   364,   365,   365,   365,   366,   367,
     368,   368,   368,   369,   369,   370,   370,   370,   370,   370,
     370,   371,   371,   372,   372,   372,   373,   373,   373,   373,
     374,   374,   374,   374,   375,   375,   375,   376,   376,   376,
     376,   377,   377,   377,   378,   378,   379,   379,   379,   379,
     379,   380,   380,   380,   381,   381,   381,   382,   382,   382,
     383,   384,   384,   384,   385,   385,   386,   387,   387,   388,
     388,   388,   389,   389,   390,   390,   390,   390,   390,   391,
     392,   392,   393,   393,   394,   394,   395,   395,   396,   397,
     397,   398,   398,   398,   399,   400,   400,   400,   400,   400,
     400,   400,   400,   400,   400,   400,   400,   401,   401,   402,
     402,   403,   403,   404,   404,   404,   405,   405,   405,   406,
     406,   407,   407,   408,   408,   409,   409,   410,   410,   411,
     411,   412,   412,   413,   413,   414,   415,   416,   417,   418,
     418,   418,   418,   419,   420,   420,   420,   421,   421,   422,
     422,   422,   423,   423,   424,   425,   426,   427,   428,   429,
     429,   430,   430,   430,   430,   430,   431,   431,   432,   432,
     433,   434,   434,   434,   435,   435,   436,   436,   436,   436,
     436,   436,   436,   436,   437,   437,   437,   437,   438,   438,
     438,   438,   439,   439,   440,   441,   442,   443,   443,   443,
     443,   443,   443,   443,   443,   443,   443,   444,   444,   444,
     444,   444,   444,   444,   444,   444,   444,   444,   444,   444,
     444,   444,   444,   444,   444,   444,   444,   444,   444,   444,
     444,   444,   445,   445,   445,   445,   446,   447,   447,   448,
     448,   449,   449,   450,   450,   450,   451,   451,   452,   452,
     453,   453,   454,   455,   455
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     0,     2,     2,     1,     1,     1,     1,
       1,     2,     1,     1,     5,     3,     6,     5,     3,     3,
       1,     2,     3,     3,     3,     3,     3,     1,     2,     2,
       2,     1,     2,     3,     0,     2,     1,     1,     1,     5,
       4,     6,     6,     6,     6,     6,     7,     7,     7,     1,
       1,     1,     2,     0,     2,     1,     2,     0,     5,     3,
       0,     3,     0,     5,     0,     4,     0,     4,     3,     3,
       1,     3,     1,     4,     5,     1,     3,     3,     1,     1,
       1,     4,     4,     2,     2,     2,     2,     1,     2,     3,
       2,     2,     2,     2,     2,     1,     2,     2,     2,     2,
       2,     2,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     0,     4,     3,     0,     5,     0,     5,
       0,     4,     0,     5,     0,     6,     3,     0,     4,     0,
       5,     0,     6,     0,     5,     0,     5,     3,     4,     3,
       3,     0,     5,     0,     6,     5,     6,     0,     5,     0,
       6,     5,     6,     0,     4,     0,     3,     3,     4,     3,
       5,     4,     1,     1,     1,     1,     1,     1,     2,     2,
       2,     1,     3,     3,     3,     3,     3,     3,     6,     6,
       7,     7,     8,     7,     7,     7,     8,     7,     3,     0,
       1,     1,     1,     3,     3,     0,     4,     3,     5,     4,
       3,     0,     4,     3,     1,     2,     5,     5,     3,     3,
       3,     3,     4,     2,     1,     3,     1,     1,     1,     1,
       1,     3,     2,     4,     1,     3,     1,     3,     1,     1,
       3,     1,     3,     2,     1,     1,     3,     1,     3,     3,
       3,     3,     5,     5,     9,    12,     3,     1,     0,     1,
       1,     1,     1,     1,     0,     1,     0,     1,     1,     2,
       1,     2,     1,     4,     7,     6,    10,     9,     3,     1,
       2,     1,     2,     1,     1,     2,     1,     3,     1,     5,
       3,     4,     6,     7,     0,     1,     0,     1,     0,     1,
       3,     3,     3,     3,     1,     3,     4,     5,     3,     3,
       6,     7,     5,     3,     1,     1,     1,     1,     2,     2,
       2,     2,     2,     2,     2,     2,     4,     5,     3,     1,
       3,     1,     2,     4,     3,     4,     5,     3,     3,     1,
       3,     1,     3,     6,     5,     4,     3,     2,     1,     1,
       1,     0,     0,     6,     0,     4,     1,     3,     4,     5,
       1,     1,     1,     3,     1,     1,     3,     5,     4,     4,
       3,     2,     1,     1,     1,     3,     2,     1,     3,     2,
       0,     4,     3,     1,     2,     0,     2,     1,     1,     1,
       1,     1,     1,     5,     7,     6,     1,     3,     3,     3,
       2,     0,    10,     3,     5,     3,     3,     5,    10,    10,
       1,     1,     3,     3,     1,     3,     3,     1,     2,     2,
       2,     2,     2,     3,     4,     6,     3,     3,     3,     3,
       3,     1,     3,     3,     4,     1,     2,     4,     6,     5,
       3,     1,     1,     1,     2,     2,     3,     4,     4,     1,
       1,     1,     1,     1,     1,     1,     1,     5,     4,     3,
       1,     3,     0,     7,     5,     1,     5,     4,     3,     4,
       1,     3,     3,     2,     3,     0,     3,     3,     4,     3,
       3,     2,     5,     4,     4,     2,     2,     2,     2,     2,
       3,     1,     2,     3,     6,     5,     4,     2,     1,     2,
       3,     3,     6,     5,     2,     4,     3,     0,     4,     6,
       5,     2,     4,     3,     1,     2,     3,     2,     2,     2,
       2,     2,     3,     2,     3,     2,     2,     2,     2,     1,
       1,     3,     2,     2,     2,     2,     2,     2,     1,     2,
       2,     4,     1,     1,     0,     6,     3,     2,     4,     2,
       4,     4,     1,     2,     2,     1,     3,     3,     2,     5,
       5,     7,     7,     5,     7,     6,     6,     6,     3,     6,
       3,     1,     2,     3,     3,     2,     2,     5,     5,     9,
       2,     5,     5,     9,     5,     5,     2,     1,     3,     2,
       1,     3,     2,     3,     1,     2,     1,     1,     1,     1,
       1,     3,     3,     3,     3,     3,     3,     2,     2,     2,
       3,     6,     5,     6,     1,     3,     1,     3,     3,     1,
       4,     4,     1,     3,     1,     5,     7,    13,    25,     1,
       3,     3,     6,     5,    10,     9,     5,     7,     1,     1,
       1,     5,     5,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,    11,     9,    11,
       9,    13,    11,    11,     9,     4,    11,     9,     3,    13,
      11,    11,     9,    11,     9,    11,     9,    11,    13,    11,
       7,     7,     9,     1,     3,     1,     1,     1,     1,     4,
       2,     3,     1,     1,     1,     1,     1,     4,     2,     2,
       2,     2,     1,     3,     1,     1,     3,     4,     3,     1,
       3,     4,     4,     3,     1,     1,     3,     4,     3,     4,
       1,     3,     4,     4,     1,     3,     2,     4,     1,     2,
       3,     1,     1,     1,     1,     1,     2,     3,     1,     3,
       4,     5,     1,     5,     1,     1,     1,     1,     1,     1,
       1,     2,     1,     1,     2,     1,     1,     1,     1,     2,
       3,     2,     3,     1,     1,     1,     1,     2,     2,     2,
       2,     1,     1,     1,     1,     1,     1,     1,     1,     2,
       3,     3,     4,     2,     1,     1,     1,     1,     1,     1,
       2,     3,     3,     0,     3,     3,     1,     3,     3,     1,
       1,     3,     1,     1,     2
};

/* YYDPREC[RULE-NUM] -- Dynamic precedence of rule #RULE-NUM (0 if none). */
static const unsigned char yydprec[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0
};

/* YYMERGER[RULE-NUM] -- Index of merging function for rule #RULE-NUM. */
static const unsigned char yymerger[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0
};

/* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
   doesn't specify something else to do.  Zero means the default is an
   error.  */
static const unsigned short int yydefact[] =
{
     783,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   783,   783,     6,    95,   109,   110,   105,
     103,   106,   108,   104,   107,   112,   111,     0,     0,     0,
     191,   192,   256,   190,   189,   189,     0,   257,     0,     0,
       0,     0,   793,     0,   234,   237,     0,   231,   792,     0,
       0,   218,   219,   220,     0,   255,     0,     0,   256,     0,
       0,     0,     0,   224,     0,     0,     0,     0,   786,   789,
       1,     0,     0,     0,    38,     7,     8,     9,    10,     5,
      36,    37,     0,     4,     0,     0,     0,     0,   465,    96,
      98,   100,   340,    99,    97,   101,     0,   341,   188,     0,
       0,     0,     0,     0,     0,   286,   256,   256,   200,     0,
       0,     0,   203,     0,   194,   794,   193,     0,     0,     0,
     233,   204,   173,   172,     0,     0,   222,   268,     0,   269,
     246,   248,   177,   176,   175,   174,     0,   197,     0,   785,
       0,   784,     0,    11,     0,   790,     0,     0,    50,    51,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     331,   329,     0,   338,     0,     0,     0,     0,     0,   460,
     774,     0,   775,   790,     0,     0,     0,   463,     0,   783,
       0,     0,   452,     0,   344,   346,     0,     0,   450,     0,
     286,   208,     0,     0,   209,   210,   211,   287,     0,   286,
     286,   725,   779,   778,   777,     0,   738,   743,   739,   740,
     737,     0,   742,   746,   721,   722,   724,   728,   735,     0,
       0,   745,   723,   718,   199,     0,   202,   238,     0,   710,
     232,   205,   221,     0,   783,   783,   252,   251,   250,   253,
     249,     0,   225,   196,   787,   788,     0,     0,    15,    13,
       0,    12,     0,   400,    52,    49,     0,     0,     0,     0,
       0,     0,   328,     0,   339,     0,   213,   732,   217,     0,
       0,     0,     0,     0,   327,     0,   324,     0,     0,   337,
     704,     0,   699,   705,     0,     0,     0,   458,     0,     0,
       0,   773,   115,     0,   229,     0,   464,     0,     0,     0,
       0,     0,     0,     0,     0,   783,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   513,
     516,   532,   783,   509,   533,   510,   515,   518,   508,   507,
     511,   517,     0,   775,   466,   467,     0,     0,   216,   452,
       0,     0,     0,     0,     0,   783,   449,   452,   455,     0,
     361,     0,     0,     0,   228,     0,     0,   226,   220,     0,
       0,     0,   741,   744,     0,   714,   764,   765,     0,   756,
     755,   763,   761,   747,   762,   766,     0,     0,   754,   753,
     767,   768,     0,   748,     0,     0,   726,     0,     0,   780,
       0,     0,   719,   716,     0,   198,     0,   223,   783,   273,
       0,   278,   256,   274,   783,   504,     0,     0,   276,     0,
       0,   247,     0,     0,   791,     0,   783,     0,    40,     0,
       0,     0,    55,    87,     0,     0,     0,     0,     0,     0,
      57,     0,     0,     0,     0,     0,     0,   336,     0,     0,
     214,   217,     0,     0,     0,   325,     0,   323,     0,   330,
       0,   332,     0,   698,     0,     0,     0,     0,   459,   457,
     461,   462,     0,     0,     0,   114,     0,     0,     0,   529,
     530,     0,     0,   539,   537,   476,     0,     0,     0,     0,
       0,     0,     0,   570,     0,     0,     0,   478,   479,   477,
       0,     0,     0,     0,   501,   783,     0,     0,   494,   783,
     471,   506,   475,   512,   514,   520,   519,   548,     0,     0,
     576,     0,     0,     0,   448,     0,   342,   347,   345,   360,
       0,   362,   364,   363,   367,     0,   451,     0,   206,   207,
       0,     0,   179,     0,   178,     0,     0,     0,     0,     0,
       0,     0,   720,   696,     0,     0,     0,   749,   758,   757,
     759,   760,   769,   751,     0,   729,     0,   734,     0,     0,
       0,   727,     0,   714,     0,     0,     0,   272,   783,   275,
     256,   304,   305,     0,   307,   306,   284,     0,   265,   505,
       0,   288,   288,     0,   288,     0,   311,   312,   309,   310,
     313,   314,   315,   308,     0,   783,   783,     0,     0,     0,
      27,     0,    17,     0,     0,     0,    20,     0,     0,    14,
       0,     0,     0,     0,   401,    86,    54,    39,    56,     0,
      88,   155,   256,     0,     0,   256,     0,    91,    92,    94,
      83,    84,    85,    90,    93,    68,     0,    80,     0,     0,
       0,    70,    72,    75,    79,    69,    59,     0,     0,     0,
       0,    53,     0,    53,     0,     0,   212,     0,     0,   326,
       0,     0,     0,   335,     0,   700,     0,     0,   703,     0,
     456,   772,   778,   777,     0,   708,     0,   230,   240,     0,
       0,     0,     0,     0,   545,     0,   542,     0,     0,     0,
     560,     0,   558,     0,     0,     0,     0,   536,     0,   503,
     783,   783,   496,     0,   783,   491,     0,   470,   469,     0,
       0,   580,     0,   577,     0,   447,     0,     0,     0,   350,
     352,   351,   355,   354,     0,   359,   783,   783,   369,   366,
       0,   180,   181,   227,     0,   239,     0,   183,   184,     0,
     187,   185,   715,   697,   750,   770,   771,   752,     0,   730,
     243,   782,   781,   706,   717,     0,   242,   264,   284,   256,
       0,   293,   285,   286,   280,     0,   776,     0,   133,   129,
     135,   289,   291,   290,     0,     0,   319,     0,   321,   292,
       0,     0,   116,   118,   122,   783,   277,     0,   783,   258,
       0,   294,   260,     0,     0,   262,    19,    18,    28,    31,
       0,    29,    30,    16,    21,     0,     0,     0,     0,     0,
       0,     0,     0,   783,     0,    89,   171,   167,     0,     0,
     153,   164,   165,   166,   256,   286,     0,     0,     0,   582,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   586,     0,   584,
     589,   590,   587,     0,     0,     0,     0,     0,     0,   588,
     645,   646,   644,   635,   636,   637,   638,   639,   640,   643,
     642,   641,     0,     0,   235,     0,     0,   256,   286,     0,
     783,   256,   256,     0,     0,     0,     0,    78,    67,     0,
       0,    60,     0,    41,     0,     0,    45,    42,    44,    43,
     334,   215,     0,     0,     0,   701,   708,     0,     0,   711,
     709,   541,   531,   540,   543,   544,     0,   538,     0,   490,
       0,     0,     0,     0,   783,     0,     0,   783,   783,   502,
     783,   271,   783,     0,   498,   495,   783,   783,     0,   468,
     474,   473,     0,     0,   579,   454,     0,     0,   348,     0,
       0,   343,   365,     0,   368,     0,     0,   182,   186,   731,
     707,   286,   284,   281,     0,   137,     0,     0,     0,     0,
     131,     0,   318,     0,     0,   322,   126,     0,     0,     0,
       0,   124,   783,   783,     0,   256,   286,     0,   259,     0,
       0,   261,     0,     0,     0,   783,    32,    22,    34,    23,
      24,    25,    26,   783,   402,   783,   403,   404,     0,   416,
       0,   413,   157,   156,   162,   168,   163,     0,   170,   169,
     286,   141,   583,   629,   630,     0,   604,     0,   609,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   606,
       0,   604,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   633,   581,   585,   597,     0,   598,     0,     0,
     599,   140,   139,     0,     0,     0,   286,   147,   372,     0,
       0,     0,     0,   382,   783,   373,   378,   379,   380,   381,
     256,   286,   256,   286,     0,   159,    46,     0,    76,     0,
      71,     0,     0,     0,    58,    64,    47,    48,   733,   333,
     736,   712,   713,   547,   546,     0,   550,     0,   783,     0,
     561,     0,     0,     0,   571,     0,     0,   549,   572,   270,
     783,   500,   783,   493,   534,   472,   575,   574,   578,   349,
       0,   353,   356,     0,     0,   286,   279,   128,     0,     0,
       0,     0,   316,   320,     0,   121,     0,     0,     0,     0,
     783,   267,   303,   286,     0,   298,   244,     0,   783,     0,
       0,     0,   783,     0,   525,   522,   526,   523,   528,   524,
     527,     0,   295,   256,   299,   783,     0,     0,    33,   783,
     407,     0,     0,     0,     0,   783,   783,     0,     0,   414,
     154,   143,     0,     0,     0,     0,     0,   634,     0,     0,
     604,     0,     0,     0,   684,   685,     0,   694,     0,   677,
       0,   686,   682,   658,     0,     0,   683,     0,     0,     0,
       0,     0,     0,   591,   593,   592,   594,   596,   595,     0,
       0,     0,     0,     0,   604,     0,   600,   612,   614,   619,
     620,   621,   236,   138,   241,   149,     0,     0,     0,     0,
       0,     0,   783,   371,   374,   286,     0,   286,     0,     0,
     158,   161,    73,     0,    77,    82,    81,    61,    62,     0,
     783,   783,   556,   783,   565,   555,   562,   783,   559,   557,
     535,     0,   499,   492,   358,     0,   453,   282,     0,   134,
     130,   136,     0,   317,   117,   119,   123,     0,   266,     0,
     296,     0,   566,     0,     0,     0,     0,     0,   487,   783,
     783,   521,     0,   256,   286,     0,   783,   263,    35,     0,
       0,   408,     0,   421,     0,   412,   409,     0,   410,   411,
       0,     0,     0,   405,   406,   418,   417,     0,     0,   142,
       0,   605,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   655,   688,     0,     0,   680,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   614,   619,     0,   148,     0,     0,     0,     0,
     396,     0,   395,     0,   145,     0,   151,   160,    74,     0,
      65,   552,   551,   564,   563,     0,   357,   283,   132,   125,
     297,     0,     0,     0,     0,   783,   783,   483,   480,   286,
       0,   302,     0,     0,     0,     0,   443,   446,     0,   445,
     444,     0,   425,     0,   432,   433,   398,     0,   420,   419,
     399,   415,   144,     0,   602,   607,   608,     0,     0,   623,
       0,     0,   610,   611,   631,   632,     0,     0,   692,     0,
       0,   678,     0,   681,   695,     0,     0,   676,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     613,     0,   150,   375,     0,     0,     0,     0,   783,   146,
     152,    63,   783,   783,   783,     0,   783,   783,   783,   488,
     486,     0,   300,   245,   430,     0,   423,     0,   422,   426,
       0,   434,   435,     0,     0,   603,     0,     0,   601,     0,
       0,     0,   622,   689,   690,   691,   687,     0,     0,   679,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   377,   383,   783,   375,
       0,   386,     0,     0,   393,   397,   394,   573,   553,   481,
       0,   567,     0,   568,   783,   485,   489,   301,   431,     0,
     436,     0,     0,     0,   439,     0,   424,     0,     0,     0,
       0,   693,     0,     0,   670,     0,   671,     0,   673,   675,
       0,     0,     0,     0,     0,     0,     0,     0,   615,     0,
     375,   376,   375,   390,   385,     0,   375,     0,   783,   482,
       0,   484,   429,   437,     0,   427,   438,     0,   628,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   384,   389,   387,   388,     0,   554,     0,
     441,     0,   440,   442,   625,     0,   626,     0,   654,     0,
     657,     0,     0,   672,   674,   666,     0,   662,     0,     0,
       0,   664,     0,   648,     0,   650,     0,     0,   616,     0,
     391,   783,   428,     0,   624,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   569,   627,   653,   656,   669,   665,   661,   660,     0,
     667,     0,   663,   647,   649,   652,     0,     0,   392,     0,
       0,     0,     0,   659,   668,   651,     0,     0,   617,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   618
};

/* YYPDEFGOTO[NTERM-NUM]. */
static const short int yydefgoto[] =
{
      -1,    12,    13,    14,    74,    75,    76,   250,    77,    78,
     413,   605,   606,   599,   607,   608,   800,   807,  1178,    79,
      80,   254,   151,   152,   418,   419,   420,   259,   647,   892,
    1093,  1389,  1269,   260,   427,   261,   640,   641,   642,   886,
     643,   421,   422,   423,    16,    89,   175,   586,   978,   979,
     781,   980,  1149,   587,   767,   968,  1141,   967,   969,   847,
     630,  1192,  1338,   631,  1246,  1374,   632,  1017,   819,  1018,
     820,   821,    17,    18,    19,    20,    32,    33,    21,    22,
      65,    23,    24,    40,   126,    34,    35,   157,   439,   339,
     266,   354,    51,    52,    62,   355,   356,   293,    44,    45,
     873,    46,   357,   294,   874,   121,   197,    25,   410,   241,
      56,    38,   788,   789,   794,    26,   128,   930,   398,   399,
     428,   408,   401,   763,   198,   772,   402,   790,   791,   577,
     931,   593,   775,   776,    90,   158,   159,   160,   161,   272,
     336,    91,    92,   183,   724,   344,   184,   342,   718,   719,
     720,   721,   728,   185,   186,   520,   521,   522,   523,   524,
     633,   880,  1074,  1537,  1538,  1075,  1076,  1077,  1540,  1541,
    1078,  1690,  1378,  1079,    81,   252,   610,   611,  1006,  1179,
    1180,  1181,  1182,  1183,  1322,  1323,  1421,  1422,  1324,  1559,
    1423,  1424,  1562,  1641,  1563,  1425,    93,   187,   188,   189,
     349,    94,   168,   169,    95,    96,   179,   316,   317,   318,
    1163,  1548,  1164,  1488,   475,   319,   320,   495,   404,   405,
     507,  1549,  1165,   321,   322,   925,   323,   324,   325,   684,
     685,   326,   327,   328,  1167,   329,  1109,  1110,  1169,   330,
     331,   712,   634,   848,   849,   850,   851,   852,   853,   854,
    1039,  1040,  1195,  1207,  1236,  1237,  1238,   855,   856,   857,
    1439,  1607,  1027,   858,  1196,   859,   860,   861,   862,   863,
     864,   865,   866,   867,   868,   869,   870,   871,  1577,  1578,
    1456,  1208,  1450,  1209,  1217,  1210,  1211,  1448,  1449,  1212,
    1453,   214,   215,   170,   281,   282,   392,   291,   228,   462,
    1111,   216,   217,   267,  1239,   558,   219,  1101,   220,   382,
     264,   823,   221,   222,   388,   178,    67,    68,   223,   145,
      48
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -1311
static const short int yypact[] =
{
    1006,   565,   149,   124,  1105,  1110,   208,   867,  1151,  1208,
    1209,  1217,   132,    82,  1318, -1311, -1311, -1311, -1311, -1311,
   -1311, -1311, -1311, -1311, -1311, -1311, -1311,  1137,   169,  1194,
   -1311, -1311,   120, -1311,   325,   325,   333, -1311,  1370,   336,
     674,   386, -1311,   674, -1311, -1311,   104,  1248, -1311,   439,
     498,   422,   458,   550,   576, -1311,   674,   623,   120,   653,
     112,   712,   156, -1311,   728,   674,   656,    18, -1311,   739,
   -1311,   764,   674,   599, -1311, -1311, -1311, -1311, -1311, -1311,
   -1311, -1311,   956, -1311,  1139,  1109,  1253,  2691, -1311, -1311,
   -1311, -1311, -1311, -1311, -1311, -1311,  1576,  1290, -1311,   815,
     750,   776,   873,   930,   953,   957,   120,   120, -1311,  3332,
     163,   674, -1311,   211, -1311, -1311, -1311,   674,  3332,  3332,
     550, -1311, -1311, -1311,   674,   674,   550, -1311,   935, -1311,
   -1311,   100, -1311, -1311, -1311, -1311,   674, -1311,   226, -1311,
     674, -1311,  3332, -1311,  1228, -1311,   976,   316, -1311, -1311,
     674,   674,  1251,   990,  1210,  3404,  1360,  1394,   228,   267,
   -1311, -1311,  1018,   957,  1510,  1047,  1276,  1047,   294, -1311,
   -1311,  1046,  1060,  1071,  1095,   674,  1036, -1311,  4851,  1010,
    1063,  1210,   610,  1083,  1086, -1311,  1134,   297, -1311,   674,
     957, -1311,  1185,  1201, -1311, -1311, -1311, -1311,  1219,   957,
     957, -1311, -1311, -1311, -1311,  3332, -1311, -1311, -1311,  1291,
   -1311,  3332, -1311, -1311, -1311, -1311, -1311, -1311,  4596,  1215,
     414,  1237, -1311,    76, -1311,   312, -1311, -1311,  1263,  4596,
    4596, -1311, -1311,   550,  1010,  1010, -1311, -1311, -1311, -1311,
   -1311,   674, -1311, -1311, -1311,  4596,  1096,   674, -1311, -1311,
    1260,  1060,  1287, -1311, -1311, -1311,  1736,   367,   298,  1087,
    1348,  1355, -1311,    80, -1311,  3332, -1311,  3823, -1311,  1047,
    1394,   354,  1357,   364, -1311,  1406, -1311,  1394,  1047, -1311,
   -1311,    79, -1311,  1353,  1047,   373,   399, -1311,  1047,  3332,
    3332,  1362, -1311,   427, -1311,   830, -1311,  1387,  1444,  1180,
    1047,  1374,  1415,   960,   962,  1010,  1417,  1420,  1435,  1047,
    1047,  1047,   674,  1437,  2057,  2401,  1028,  1034,  1448, -1311,
   -1311, -1311,    56, -1311, -1311, -1311, -1311, -1311, -1311, -1311,
   -1311, -1311,  1373,  1479, -1311, -1311,  1372,  1047, -1311,  1469,
     438,  1481,   674,   674,  1496,    57, -1311,  1469, -1311,  1493,
   -1311,  1495,  1509,   674, -1311,   440,  1521, -1311,  1279,  1219,
    1219,  1517, -1311, -1311,   397,  3839, -1311, -1311,  1515,  1441,
    1066, -1311,  1514, -1311, -1311, -1311,  1525,  3332, -1311, -1311,
   -1311, -1311,  2529, -1311,  3332,  1259, -1311,  1237,  1354, -1311,
    3332,  3332, -1311,  1362,  1535, -1311,  3332,   550,  1010, -1311,
    1544,  1464,   959, -1311,    78, -1311,  4674,   252, -1311,    41,
    1166, -1311,  1275,   932, -1311,  1550,    74,  1554, -1311,  1513,
    1736,  1077, -1311, -1311,  2695,  1555,  1568,  1366,   349,  1569,
   -1311,  1845,   629,  1575,  1577,  2202,  2295, -1311,  3332,   368,
   -1311,  1517,  3332,  1491,   455, -1311,  1047, -1311,  1047, -1311,
    1574, -1311,   425, -1311,  1047,  3332,  2488,   465, -1311, -1311,
   -1311,  4596,  1572,  3657,  3332, -1311,   674,  3332,   674, -1311,
   -1311,  3332,  2415, -1311, -1311, -1311,  1570,  3332,  3332,  1516,
    3332,  1519,  3332, -1311,  3332,  1047,  3332, -1311, -1311, -1311,
    1583,  3332,  1511,   674, -1311,  1010,  1528,  1278, -1311,   340,
   -1311, -1311, -1311, -1311, -1311, -1311, -1311, -1311,  1536,  1579,
   -1311,  1261,  3332,   467, -1311,  1316,  1086, -1311, -1311, -1311,
    1580,  1505, -1311,  1506, -1311,  3085, -1311,  1047, -1311, -1311,
     469,  1584, -1311,   674, -1311,  3332,   674,   484,  1595,   674,
     492,  1597, -1311, -1311,  3332,  3332,  1573,  1588, -1311,  1589,
   -1311,  1587, -1311,  1596,  3864, -1311,  3332,  4596,  1598,  1492,
     518, -1311,   547,  4596,  1600,  3332,  1602, -1311,   218, -1311,
    1052, -1311, -1311,   674, -1311, -1311,  1585,   674, -1311, -1311,
     646,  1631,  1631,   339,  1631,  1313, -1311, -1311, -1311, -1311,
   -1311, -1311, -1311, -1311,  1625,  1010,    20,  1537,  1630,  1015,
    1060,  1527, -1311,   674,   674,   991, -1311,  1386,  1386, -1311,
     555,  1628,  1548,  1609, -1311, -1311, -1311, -1311, -1311,  1639,
   -1311,    87,    70,  3498,  1112,    70,  2827, -1311, -1311, -1311,
    1552,  1553,  1560, -1311, -1311, -1311,  1845, -1311,  1196,  1331,
     662, -1311, -1311, -1311,  1641, -1311, -1311,  1624,  1736,  1845,
    1845,  1554,  1736,  1554,  1736,   665, -1311,  3332,  3889, -1311,
    1566,  1648,  1047, -1311,  3332, -1311,  1647,  3675, -1311,  3978,
   -1311, -1311,  1657,  1660,  3332, -1311,  4004, -1311,  4596,  1666,
    1661,  1664,  3332,  3332, -1311,   117,  4596,  3332,  4020,  4039,
   -1311,  4058, -1311,  4179,  4195,  1677,  4214, -1311,  4230, -1311,
     212,   491, -1311,  1617,  1010, -1311,  1675,  3332,  4596,  1536,
    1676, -1311,   675,  4596,   688, -1311,  1678,   674,  1679,  1594,
   -1311,  1601, -1311,  4596,  1684, -1311,  1010,  1010, -1311,  4596,
    1603, -1311, -1311, -1311,  1681,  4596,   500, -1311, -1311,  1688,
   -1311, -1311,  4596, -1311, -1311, -1311, -1311, -1311,  3332, -1311,
   -1311, -1311, -1311, -1311, -1311,   694, -1311, -1311,  1585,  1242,
     674, -1311, -1311,   957, -1311,  1690, -1311,   674, -1311, -1311,
     957, -1311, -1311, -1311,   674,   501, -1311,   957,   550, -1311,
    1694,   674, -1311, -1311,   957,  1010, -1311,   355,    20, -1311,
     505,  1608, -1311,   686,   700,  1608, -1311, -1311,  1060,   674,
    1698,  1060,  1060, -1311, -1311,   674,  1699,  1709,  1710,  1711,
    1712,   674,  1713,    74,   969, -1311, -1311, -1311,   744,   674,
     595, -1311, -1311, -1311,   120,   957,  1638,   150,  1695, -1311,
    1716,   983,  1717,  1718,  1719,  1720,  1722,  1724,   674,  1288,
     674,  1314,  1725,  1728,  1729,  1730,  1731, -1311,  3854, -1311,
   -1311, -1311, -1311,  1715,  1704,  1739,  1732,  1733,  1740, -1311,
   -1311, -1311, -1311, -1311, -1311, -1311, -1311, -1311, -1311, -1311,
   -1311, -1311,  1741,   506, -1311,   674,  1734,   120,   957,  1645,
    2915,    70,    70,  1044,  1736,  1737,   659, -1311, -1311,  1366,
    3332, -1311,   723, -1311,  1736,  1736, -1311, -1311, -1311, -1311,
   -1311, -1311,  3332,  1742,   737, -1311,   868,  3332,  3332, -1311,
   -1311, -1311, -1311, -1311,  4596,  4596,  2581, -1311,  2581,  4596,
    2502,  1400,  3130,  3130,  1010,  1743,  3332,    56,  1010, -1311,
    1010, -1311,   685,  4742, -1311, -1311,  1010,   490,  3332,  4596,
    3332,  4596,  1747,  1748,  3332, -1311,  1751,  1746, -1311,  3332,
    1752, -1311, -1311,  3332, -1311,  1752,  3332, -1311, -1311, -1311,
   -1311,   957,  1585, -1311,   674, -1311,   529,   674,   674,   674,
   -1311,   534, -1311,   674,   674,   550, -1311,   536,   674,   674,
     674, -1311,  1010,   296,  1755,   120,   957,   674, -1311,  1702,
    4789, -1311,  1537,    95,  1760,  1010,   674, -1311,  1341, -1311,
   -1311, -1311, -1311,  1010, -1311,  1010,  1673,  1674,  1672, -1311,
     674, -1311, -1311, -1311, -1311, -1311, -1311,   674, -1311, -1311,
     957, -1311, -1311, -1311, -1311,   789,  1756,   674,  1759,  3332,
     348,  1769,   575,   575,   575,   575,   575,   575,   575,  1682,
    1771, -1311,  1778,  1780,  1781,  1782,  1784,   575,   575,   575,
     575,   674, -1311, -1311, -1311, -1311,  3435, -1311,  3435,  3435,
   -1311, -1311, -1311,   674,   559,  3332,   957, -1311, -1311,  1779,
    1785,  1786,  2775, -1311,  3234, -1311, -1311, -1311, -1311, -1311,
     120,   957,   120,   957,   288, -1311, -1311,  1392, -1311,  1331,
   -1311,  1787,  3702,   674, -1311,  1762, -1311, -1311, -1311, -1311,
    4596, -1311, -1311, -1311, -1311,  1726,  1738,  1723,    69,  1968,
   -1311,   114,  3008,  3049, -1311,  1767,  3497, -1311, -1311, -1311,
     710, -1311,   637, -1311,  4596,  4596, -1311, -1311,  4596, -1311,
    3171, -1311, -1311,   742,   674,   957, -1311, -1311,   564,   579,
     583,   674, -1311, -1311,   605, -1311,   614,   618,   621,   674,
     378, -1311, -1311,   957,   674, -1311, -1311,  1788,  1010,  1791,
    1792,  1793,    55,  1801, -1311, -1311, -1311, -1311, -1311, -1311,
   -1311,  1790,  1608,   892, -1311,    20,  1537,  1703, -1311,   916,
    1805,   625,   633,   649,   483,   916,    74,   674,   674,  1794,
   -1311, -1311,   674,  1798,   674,   674,  1361, -1311,  1800,   657,
    1796,  3332,  4249,  1172, -1311, -1311,  1807, -1311,  1735, -1311,
     674, -1311,  1692, -1311,  1808,  1749, -1311,  1754,  1757,  1758,
    1761,  1763,  1765, -1311, -1311, -1311, -1311, -1311, -1311,  1766,
    1772,  1773,  1775,   836,  1806,  3466, -1311, -1311, -1311, -1311,
   -1311, -1311, -1311, -1311, -1311, -1311,   674,  3332,  3332,   674,
    1745,   674,  1396, -1311, -1311,   957,   674,   957,   674,   678,
   -1311,   807, -1311,  1813, -1311, -1311, -1311, -1311, -1311,   674,
      56,    56, -1311,    56, -1311, -1311, -1311,    56, -1311, -1311,
   -1311,  1047, -1311, -1311, -1311,  4370, -1311, -1311,   674, -1311,
   -1311, -1311,   655, -1311, -1311, -1311, -1311,   670, -1311,   674,
   -1311,  3332, -1311,  4478,  3332,  1047,  3332,   674, -1311,  1010,
     715, -1311,  3332,   120,   957,   674,    20,  1608, -1311,  1337,
     289,  1805,  1776, -1311,  1774, -1311, -1311,   674, -1311, -1311,
     674,   674,  1783,  1674, -1311, -1311, -1311,  3332,   674, -1311,
     674, -1311,  1818,  1812,  1817,  1434,  1821,  1825,  1831,  3796,
    1837, -1311, -1311,  1411,   575,  1744,  3332,   575,  3332,  3332,
     575,   575,   575,   575,   575,   575,   575,   575,  1830,  1834,
    3332,  1843,  1789,  1517,   674, -1311,  4386,  4405,  1859,  1854,
   -1311,  2922, -1311,   674, -1311,   674, -1311, -1311, -1311,   674,
   -1311, -1311, -1311, -1311, -1311,  1862, -1311, -1311, -1311, -1311,
   -1311,  4421,  4440,  1870,  4561,  1010,   769, -1311,  4596,   957,
     674, -1311,  1822,  1871,  1860,  1829, -1311, -1311,   143, -1311,
   -1311,   519, -1311,   277,  1873, -1311, -1311,   493, -1311, -1311,
   -1311,  4596, -1311,  1462, -1311, -1311, -1311,   674,  1522, -1311,
     674,  1434, -1311, -1311, -1311, -1311,  1484,  1889, -1311,   255,
    1802, -1311,  3332, -1311, -1311,  1803,   745,  4596,   761,  1809,
    1811,  1815,  1816,  1819,  1820,  1823,  1824,   674,   674,  1789,
   -1311,  3332, -1311,  1888,  3240,  3332,  3332,  1826,  2801, -1311,
   -1311, -1311,  1010,  1010,  1010,  3332,  1010,  1010,   858, -1311,
   -1311,   674, -1311, -1311, -1311,  1891, -1311,   374, -1311, -1311,
     143,  1873, -1311,   143,   767, -1311,  1896,  1545, -1311,  1900,
    1545,  1545, -1311, -1311, -1311, -1311, -1311,  1411,  3332, -1311,
    3332,  1893,  3332,  1894,  3332,  3332,  3332,  3332,  3332,  3332,
    3332,  3332,  3332,  1899,  1902,   778, -1311,  1841,  2915,  1031,
      73, -1311,   185,  3621,  4596, -1311, -1311, -1311,  1844, -1311,
    4287, -1311,  3640, -1311,   875, -1311, -1311, -1311, -1311,  1914,
   -1311,  1908,  1912,  1918,  1923,  1917, -1311,  3332,  1920,  3332,
    1922, -1311,   779,   784, -1311,  4577, -1311,   790, -1311,  4596,
     791,   794,  1842,  1846,   805,   810,   811,  1847, -1311,  3332,
    1888, -1311,  1888, -1311, -1311,  3240,  1888,   674,  1010, -1311,
    1047, -1311, -1311, -1311,   217, -1311, -1311,  1924,  4596,  3332,
    1925,  3332,  1933,  3332,  1937,  3332,  3332,  1940,  3332,  1942,
    3332,  1944,  3332,  3332,  3332,  1945,  3332,  1946,  3332,  1947,
    3332,  3332,   837, -1311, -1311, -1311, -1311,  1941, -1311,  1943,
   -1311,  1949, -1311, -1311, -1311,  1948, -1311,  1950, -1311,   839,
   -1311,   843,   846, -1311, -1311, -1311,   848, -1311,   850,   854,
     855, -1311,   856, -1311,   864, -1311,   874,   879, -1311,  3332,
   -1311,  1010, -1311,  1952, -1311,  1953,  1954,  1956,  1960,  1962,
    1963,  3332,  1967,  3332,  1976,  1982,  1984,  1986,  3332,  1864,
    1897, -1311, -1311, -1311, -1311, -1311, -1311, -1311, -1311,   885,
   -1311,   890, -1311, -1311, -1311, -1311,   899,  3332, -1311,  1987,
    1988,  1991,  1906, -1311, -1311, -1311,  3332,   900, -1311,  3332,
    1910,  3332,  1911,  3332,  1915,  3332,  1916,  3332,  1919,  3332,
    1989, -1311
};

/* YYPGOTO[NTERM-NUM].  */
static const short int yypgoto[] =
{
   -1311, -1311, -1311, -1311, -1311, -1311, -1311, -1311, -1311, -1311,
   -1311, -1311,  1407,  1216, -1311, -1311,   967,  1408, -1311,  2005,
   -1311, -1311, -1311, -1311,  -381, -1311,  -368, -1311, -1311, -1311,
   -1311, -1311, -1311,  1764, -1311,  1768, -1311,  1132,  -602, -1311,
    -605, -1311,  -335,     3, -1311, -1311, -1311,  1604, -1311, -1311,
   -1311, -1311, -1311,  1605, -1311, -1311, -1311, -1311, -1311,  1606,
   -1311, -1311, -1311, -1311, -1311, -1311,  1401, -1311, -1311, -1311,
     940,  -571,  -385, -1311,  -382, -1311,  1489, -1311,  -379,  -378,
   -1311, -1311,  -376, -1311,   -36,  1250, -1311,   -28, -1311, -1311,
    -223,  2021, -1311, -1311, -1311,  -284,  -264,  -720, -1311,  1921,
    1156,   103,  1499,  -460,   970,  -111,   -33, -1311, -1311, -1311,
    2028,    51,   861,  -755, -1311, -1311, -1311,  -692, -1311,  1651,
    1804,  -190, -1311,  -696,   -55,   545,  1482, -1311,  -574,  -548,
    -215, -1311,  -709,  1078, -1311, -1311,   -53,  1797,  1795,   -31,
    -104, -1311, -1311, -1311, -1311, -1311,  1714, -1311, -1311, -1311,
    1104, -1311,  -474,  1721,  1866, -1311, -1311,  1333, -1311,  1330,
   -1311, -1311, -1027,  -526, -1311, -1039, -1311, -1311, -1311,   466,
   -1311, -1311,   463,   372, -1311, -1311, -1311, -1311, -1311,  1061,
     -18,  1652,  -767, -1311,   882, -1311,   648, -1220, -1311, -1311,
   -1311,   650, -1311, -1311,   472, -1310, -1311,  -123,  1799, -1311,
   -1311, -1311,   -89,  -278, -1311, -1311, -1311, -1311, -1311, -1311,
   -1311,   479, -1311, -1311,  -481, -1311, -1311, -1311,  -307,   -27,
    -810,  -745, -1311, -1311,  -459, -1311,  -970,   964, -1311,   376,
   -1311, -1311, -1311, -1311, -1311,  -965,   658,   433, -1311, -1311,
    -964, -1311, -1311, -1311,  1232, -1311, -1311, -1311,  -817, -1311,
    -772,  -823, -1311,  -739,   525,   847, -1195,   731, -1311, -1311,
     642, -1282, -1311, -1311, -1311, -1311, -1311, -1311, -1311, -1311,
   -1311, -1311, -1311, -1311, -1311, -1311, -1311, -1311,  -456,   475,
    -607,   481,   108,  -874,  1050, -1311, -1311,   570, -1311,   886,
     643,  1750, -1311,  -117, -1311,  1644, -1311,   259,  1706,  -384,
    -210,  -164,  -324,  1701,  -153,  1425, -1311,  1195, -1311, -1311,
     -47,   925,  2002, -1311,  -159,     0,  1727,  1964,    52,   680,
    2062
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -791
static const short int yytable[] =
{
      27,   364,   268,    15,   695,   111,   677,   564,   499,   231,
     460,   120,   936,    82,    82,   231,  1043,  1044,  1046,   403,
    1166,   588,   760,   795,   589,  1168,  1170,   590,   591,  1052,
     592,   487,   769,   988,   887,  1254,   885,   783,   171,   617,
    1372,   722,   440,   989,   400,  1252,  1007,   966,   280,   707,
     263,   824,   361,   162,   877,  1025,   386,   167,   555,   340,
     177,   977,   961,   648,   394,   971,   505,   652,   654,   530,
    1307,   666,   668,   816,   519,   537,   540,   285,   286,   505,
     581,   582,    -2,   105,  1273,   618,    42,   247,  1026,   531,
     816,   568,   390,   982,   391,   538,   541,   437,   240,  1041,
    1041,  1041,  1041,   271,   273,   109,    43,    42,  1497,   131,
    1106,    60,   441,  1502,   116,   453,   140,  1117,   109,   171,
     171,   787,   133,   916,   144,    39,   621,    43,   270,  1277,
     279,   332,    70,   817,   917,   350,  -201,   172,   284,  1308,
     578,   110,   584,   113,   359,   360,   141,   236,   237,    11,
      36,  1416,   334,  1594,   338,  1417,  -201,   199,   200,  1216,
    1216,  -256,    42,  1221,  1222,   443,   135,  -256,   138,  1419,
     353,  1595,    37,   224,   452,  1469,  1232,   454,   438,    98,
     562,  -256,    43,   403,    11,    11,    11,  1561,   701,   766,
    1564,    71,    72,  1565,    73,   457,  1173,   397,    11,   251,
    1596,  1499,   117,    11,   238,   385,   172,    11,   400,    54,
     117,    11,   544,  1254,   225,   918,   513,   444,   172,   172,
    -254,   226,    37,   556,   561,  1416,   239,   295,   655,  1417,
     333,  1640,   749,   172,   406,   409,   243,   171,   274,   987,
    -254,   171,  1420,  1419,   450,  1023,  1024,  1138,  1139,  1140,
     940,    37,   736,   476,   136,  1199,   424,   409,  1146,  1147,
    1148,   117,   171,   488,   489,  1144,  1135,   893,   884,   594,
     896,   897,   898,   899,  1516,   739,  1535,   276,   483,  1233,
     757,   894,   895,   544,  1499,  1416,   231,  1610,  1200,  1417,
    1415,   816,  1500,  1418,  1643,   506,   929,  1416,  1274,   429,
      42,  1417,   714,  1419,   287,  1418,   109,   346,    55,   117,
    1080,  1082,  1234,   618,   430,  1419,  1420,   618,   680,   618,
      43,   172,   395,   249,   117,   165,   275,  1645,    42,  1647,
     172,   536,   539,  1166,   817,   364,   172,   280,  1168,  1170,
     172,    11,   660,   108,   661,   525,   112,    11,    43,  1203,
     595,    42,   172,  1517,  1478,   755,   984,   109,  1151,   332,
      42,   172,   172,   172,   445,   277,   645,  -256,   425,    30,
      31,    43,  1342,  -256,   447,   -66,  1420,   579,   -66,   -66,
      43,   792,  1416,   458,   426,   656,  1417,  -256,  1420,   172,
     766,  1560,   288,   932,  1632,   347,   114,   937,   406,   -66,
    1419,   985,   571,   572,   -66,   786,  -783,  -783,   588,   459,
     117,   589,   705,  1302,   590,   591,   613,   592,  1172,  1333,
     424,  1292,   202,   730,   959,    11,    42,   203,   204,  1297,
     205,   424,   409,   543,   901,   424,   424,   465,   476,  1254,
    1298,   766,   663,  1204,  1205,  1206,    43,   595,   514,   122,
     532,   211,   277,   576,   904,  1341,  1041,    37,   333,   574,
    1391,  1392,   277,  1393,   600,   659,   657,  1394,  -783,    11,
    1309,   288,   579,  1420,  1689,   670,  1132,   715,   983,   731,
    1451,   575,   393,  1451,  1264,  1263,  1451,  1451,  1461,  1462,
    1451,  1451,  1451,  1466,   737,   544,    11,   288,   172,  1591,
     172,  1416,   740,  1086,   268,  1417,  1091,    11,   123,  1418,
     957,   972,  1712,  1096,  1097,   991,  1062,  1433,   295,  1419,
     124,  1717,   814,   664,  1720,   466,  1722,  1416,  1724,  1331,
    1726,  1417,  1728,  1444,  1730,  1418,   347,   172,   533,  1137,
    1012,   579,   456,   385,  1142,  1419,  1145,   768,   588,   618,
     774,   589,   782,   277,   590,   591,   125,   592,   903,   618,
     618,   988,  1123,   288,   753,   347,    28,   533,   118,  1243,
     409,  1412,   810,   792,  1289,   934,  1214,  -189,  1498,   172,
    1166,    29,   533,  -189,  1188,  1168,  1170,    42,   822,  1290,
     533,   875,  1420,  1291,  -189,   409,   793,  -189,   533,   973,
     146,  1041,  1317,   992,  1063,   588,  1438,    43,   589,    30,
      31,   590,   591,   109,   592,  1293,   140,  1510,  1420,    11,
      11,   758,   147,  1120,  1294,  1315,   337,   466,  1295,  1122,
     425,  1296,   973,  1267,   466,  1326,   424,   -66,   127,   155,
     -66,   -66,  1014,  1328,  1533,   544,   752,   765,   424,   424,
     424,   798,   424,   811,   424,   801,   802,  1063,  -127,  1329,
    1489,   -66,   466,   132,   109,  1398,   -66,  -189,  -783,  -783,
    1204,  1205,  1206,   825,   579,  1150,   878,   466,  -127,   888,
    1399,   466,   900,  1346,    47,    53,    42,   130,    47,    63,
      42,    69,   943,   571,   572,  1088,   109,  1015,  1507,  1016,
     933,  1041,  1511,   973,   933,   945,    43,    97,   964,  1283,
      43,   960,   466,  1487,   172,  1119,   466,   994,    47,   466,
      47,  1119,   134,  1327,   580,  1014,   953,   955,  1041,  1534,
    -783,  1187,   583,     3,     4,     5,   129,   970,   137,  1551,
    1094,  1553,   975,  1556,   974,    47,  1133,  1330,   766,  1098,
     574,   981,  1458,   466,  1099,  1194,    42,  1089,    11,  1286,
     889,   142,  1521,   544,   163,   173,    11,  1119,   466,  1121,
    1021,   171,   575,   944,   143,  1416,    43,   190,  1523,  1417,
    1015,   165,  1016,  1418,   139,   933,   544,  1019,   990,   585,
       8,    47,   544,  1419,  1282,  1588,  1612,    47,   995,  1407,
    1395,  1614,   203,   204,   232,   233,  1260,  1617,  1619,  1390,
     962,  1621,    10,  1008,    11,  1193,   242,  1348,  -790,   295,
      69,  1095,  1625,  1067,  1403,   290,  1566,  1627,  1629,  -790,
     253,   255,   191,   295,   173,   544,   163,   163,   986,    11,
     544,   247,   883,  1522,    11,   283,   173,   173,   192,   203,
     204,   600,   467,  1490,  1668,  1310,  1675,   998,   173,  1524,
    1676,   173,  1368,  1677,   231,  1678,  1420,  1679,    57,   190,
     172,  1680,  1682,  1684,   193,  1020,  1589,  1613,   358,  -254,
      27,  1685,  1615,  1073,   424,  -254,   332,  1194,  1618,  1620,
     194,  1686,  1622,   506,   424,   424,  1687,  1114,    11,  -254,
     506,  1118,  1709,  1626,  -702,   579,  1134,  1710,  1628,  1630,
     579,  1572,  1244,  1573,  -254,  -254,  1711,  1718,  1580,  1581,
    1582,   411,  1584,  1585,  1586,  1587,  1691,   414,  1066,  1481,
     933,  1154,  1081,  1083,  1194,  1669,   933,  1618,  1313,   571,
     572,  1618,  1555,  1171,  1618,   234,  1618,   195,  1618,   173,
     163,   235,  1681,  1683,  1618,   163,   579,   163,   173,  1601,
     792,   479,  1618,   481,   173,  1191,  -702,    55,   173,  -254,
     196,  -254,  1618,  1319,  1320,   109,   480,  1688,   482,   474,
     173,    42,   933,  1618,  1031,   333,   248,    11,  1618,   173,
     173,   173,   490,  -254,    37,  1176,   574,  1618,  1719,  1032,
     262,    43,  1406,  1184,    11,  1184,   571,   572,   148,     1,
     149,  1245,   150,  1593,   601,  1010,  1659,   173,   575,   295,
     295,   295,   190,   190,  1667,   797,  1256,    42,  1258,   500,
     295,   295,   295,   358,   278,   502,  1153,   171,   501,   358,
     358,  1536,   333,   602,   503,    11,  1592,    43,   798,   603,
     604,   822,     2,     3,     4,     5,    42,   573,    -3,    42,
      -3,    37,    -3,   574,  1633,    69,  1634,     6,   289,     7,
    1636,   247,    27,   601,    27,  1073,    43,  1073,   619,    43,
    1288,   506,  1373,  1084,   165,   575,   173,   620,   550,   290,
     551,  -783,  -783,   579,  1119,   579,   614,   431,  1299,   571,
     572,   792,   803,   432,    97,   292,    41,   644,   603,   604,
       8,    49,   341,   872,     9,    -3,    -3,    42,    -3,  1639,
     296,    42,    42,   579,    42,   164,   173,   773,   173,   779,
     109,  1255,    10,  1257,   283,    11,   172,    43,   155,    11,
     153,    43,    43,    84,    43,   295,   165,   335,   679,    42,
     345,    42,    59,  -783,    37,   154,   574,  1649,  1303,  1651,
    1652,  1321,   933,    42,  1656,   173,  1658,  1321,   155,    43,
    1662,    43,  1664,   700,  1666,   793,   596,   704,   575,  1184,
    1554,    11,   597,    43,   343,  1184,  1008,    85,    86,  1351,
     351,  1352,    42,   295,    87,    99,   472,    88,   100,   101,
    1383,   295,  1385,  1454,   637,   352,   473,   173,    42,    61,
      64,    99,    43,   734,   100,   101,   734,  1373,    66,    53,
      42,  -195,    42,   412,  1314,  1699,  1019,  1701,    43,    42,
     384,    42,  1706,   639,   476,   102,   103,   104,   246,   247,
      43,  -195,    43,   506,   506,   389,   506,   165,   155,    43,
     506,    43,    27,   761,   174,  1073,  1171,   764,   476,  1410,
     559,   256,   710,   778,  1542,  -113,   118,   257,   201,   202,
     119,    42,  1119,    42,   203,   204,   598,   205,   396,   703,
     258,   206,   207,   579,   415,  -113,   208,    42,    42,  1042,
      42,    43,  1103,    43,  1104,   209,   210,   118,   211,  1454,
      42,   535,    42,   416,   876,   155,   181,    43,    43,   933,
      43,   362,   363,   165,   780,  1045,   990,   716,   644,   644,
      43,   295,    43,   201,   202,  -120,    42,   717,    42,   203,
     204,   109,   205,   172,   156,   166,   206,   207,  1413,   637,
     573,   208,   173,    42,    37,  -120,    43,   182,    43,    42,
     209,   210,   247,   211,  1491,   333,  1177,   172,   435,   711,
     571,   572,   202,    43,  1409,   436,    42,   203,   204,    43,
     205,   455,    42,   446,   637,  1583,   269,   638,    42,   579,
     464,    27,    42,  1343,  1073,  1542,    43,  1344,   109,   155,
     477,   211,    43,   212,   213,   508,   509,   947,    43,     1,
     637,  1107,    43,   639,    42,   990,    42,   201,   202,  1262,
     269,   468,    42,   203,   204,   766,   205,   574,    42,  1446,
     206,   207,   448,  1447,    43,   208,    43,    71,    72,   639,
      73,   478,    43,   484,   209,   210,   485,   211,    43,   575,
     963,   295,     2,     3,     4,     5,    42,    11,   212,   213,
    1437,   486,   469,   491,   778,  1547,   470,     6,   504,     7,
     471,  1069,  1070,   548,   549,  1455,    43,  1071,  1459,  1460,
     512,  1660,  1463,  1464,  1465,   203,   204,  1072,    27,  1505,
    1382,  1073,  1108,  1550,  1303,   337,  1303,   933,  1303,   510,
     247,  1004,  1513,  1009,  1011,   511,  1514,   515,   173,  1013,
       8,   805,   799,  1171,     9,   770,   518,  1028,   777,   527,
     784,    99,   528,  1215,   100,   101,  1219,  1220,  1028,  1028,
    1028,  1028,    10,   106,   107,    11,   529,   579,  1229,  1230,
    1231,   534,   212,   213,   542,   203,   204,   547,    27,  1508,
     552,  1073,  1276,   201,   202,  1276,  1276,   553,    42,   203,
     204,   565,   205,   476,   569,   876,   206,   207,   203,   204,
     609,   208,   570,  1085,   615,   298,   616,   299,    43,   644,
     209,   210,   635,   211,   806,   808,  -102,   180,   636,  -102,
    1112,  1113,  -102,  1240,  1241,   649,   646,   650,  -102,   438,
     662,   671,   687,   697,   732,   699,   690,   725,  1550,   692,
     702,   709,   333,   726,   727,   738,   706,   741,  -102,   743,
     744,   746,   745,   173,  -102,  -102,  -102,   750,   747,   754,
     751,   756,  -102,  -102,  -102,  -102,  -102,  -102,  -102,  -102,
    -102,   762,  -102,  -102,   771,   785,  -102,  -102,   787,  -102,
     796,  -102,  -102,   799,  1136,   812,   813,  -102,   814,   815,
     881,   882,   172,   778,   778,  -102,  -102,  -102,   883,   890,
    -102,  -102,   891,  -102,   664,   437,   905,  1155,   212,   213,
     173,  1303,   907,  1174,  -102,   908,   911,  -102,   912,  -102,
    -102,   913,  -102,  -102,  -102,  -102,  -102,   926,  -102,   935,
    1189,   938,   949,   942,   951,   946,   948,  1190,   958,   950,
     965,   956,  -102,   535,   976,  -102,   993,  1028,   997,   999,
    1028,  1029,  1028,  1028,  1028,  1028,  1028,  1028,  1028,  1000,
    1001,  1002,  1003,  1005,  1022,  1055,  1056,  1028,  1028,  1028,
    1028,  1028,  1030,  1033,  1034,  1035,  1036,   417,  1037,     1,
    1038,  1047,  -783,   876,  1048,  1049,  1050,  1051,  -783,  1057,
    1060,  1061,  1068,  1087,  1058,  1059,  1065,  1126,  1127,   663,
    1115,  1129,  1130,   717,  1261,  1152,  1156,   644,  -783,   644,
    1175,  1186,  1187,  1188,  -783,  -783,  -783,  1201,  1198,  1213,
    1194,  1223,     2,     3,     4,     5,  -783,  -783,  1224,   -53,
    1225,  1226,  1227,  -783,  1228,  1247,  -783,     6,   299,     7,
    1268,  1248,  1249,  1272,  1301,  1270,  1265,  1304,  1305,  1306,
     218,  1311,  1312,  1318,  1287,  1325,  1337,  1271,  1347,   229,
     230,  -783,  1340,  -783,  1345,  1353,  1356,  1352,  1369,  1380,
    1388,  1426,  1427,  1354,  1300,  1434,  1435,  -783,  1430,  -783,
       8,  1436,  -783,   245,     9,  1440,   417,  1357,     1,  1441,
    1442,  -783,  1358,   827,  1467,  1359,  1360,  -783,  1468,  1361,
    1470,  1362,    10,  1363,  1364,    11,  1334,  1335,  1336,  1475,
    1365,  1366,  1339,  1367,  1028,  1028,  1476,  -783,  1452,  1482,
    1485,  1494,  1495,  -783,  -783,  -783,  1493,  1471,  1496,  1503,
    1028,     2,     3,     4,     5,  -783,  -783,  1515,  1536,  1558,
    1518,  1520,  -783,  1574,  1576,  -783,     6,  1525,     7,  1526,
    1545,  1567,   365,  1527,  1528,  1569,  1505,  1529,  1530,  1508,
    1590,  1531,  1532,  1598,  1602,  1603,  1375,  1604,  1605,  1379,
    -783,  1381,  -783,  -442,  1606,  1609,  1384,  1611,  1386,  1387,
    1623,  1644,  1646,  1648,  1624,  1631,  -783,  1650,  -783,     8,
    1653,  -783,  1655,     9,  1657,  1661,  1663,  1665,  1670,  1672,
    1671,   173,  1707,  1693,  1694,  1673,  1695,  1674,  1397,  1692,
    1696,    10,  1697,  1698,    11,   201,   202,  1700,  1072,  1400,
      42,   203,   204,   173,   205,   173,  1702,  1405,   206,   207,
     461,   463,  1703,   208,  1704,  1411,  1705,  1713,  1714,  1414,
      43,  1715,   209,   210,  1716,   211,  1731,  1009,  1721,  1723,
    1428,  1429,   804,  1725,  1727,   996,   809,  1729,  1432,    83,
    1028,  1090,   818,   433,  1259,  1028,    50,   434,   627,   628,
     629,  1064,   733,  1242,  1028,    58,  1316,  1028,   227,   407,
    1028,  1028,  1028,  1028,  1028,  1028,  1028,  1028,  1275,   567,
    1108,  1143,   759,  1131,  1472,   348,   516,   954,   492,   952,
    1637,  1635,  1708,  1479,   517,  1480,  1185,  1332,   612,  -497,
     449,  -497,   493,  1501,   451,  1504,  1642,  1638,   554,  1280,
    1054,  1445,  1371,  1512,  1218,   557,  -497,  1571,  -497,  -497,
    1492,   563,   463,  1654,  -497,  1519,  1355,   229,   665,   909,
     212,   213,   566,  1102,   244,   115,     0,  -497,     0,     0,
       0,     0,   560,     0,     0,   546,     0,  1028,     0,     0,
    1028,  1028,  -497,  -497,  -497,  -497,  -497,  -497,  -497,     0,
    -497,  -497,  -497,  -497,  -497,  -497,     0,     0,  -497,   563,
    -497,   494,     0,   658,     0,     0,   526,  1028,  1028,     0,
       0,     0,     0,     0,     0,     0,   667,   669,     0,     0,
       0,     0,     0,     0,     0,   676,     0,     0,   678,     0,
       0,  1557,     0,   686,     0,     0,     0,     0,   688,   689,
       0,   691,     0,   693,     0,   694,  -497,   696,     0,     0,
       0,     0,   698,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   651,     0,     1,     0,     0,  -783,   708,
       0,     0,   713,   563,  -783,     0,   723,     0,     0,     0,
     383,     0,   387,     0,     0,     0,   729,     0,     0,     0,
     173,   383,   383,     0,  -783,     0,   735,     0,     0,     0,
    -783,  -783,  -783,     0,     0,   742,   563,   383,     2,     3,
       4,     5,  -783,  -783,     0,     0,     0,     0,     0,  -783,
       0,     0,  -783,     6,     0,     7,   563,     0,     0,   383,
       0,     0,     0,     0,     0,     0,     0,  1379,     0,     0,
     173,     0,     0,     0,     0,     0,     0,  -783,     0,  -783,
       0,     0,     0,     0,     0,     0,   653,     0,     1,     0,
       0,  -783,     0,  -783,     0,  -783,     8,  -783,  -783,     0,
       9,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  -783,    10,     0,
       0,    11,     0,  -783,  -783,  -783,     0,     0,     0,     0,
       0,     2,     3,     4,     5,  -783,  -783,     0,     0,     0,
       0,     0,  -783,     0,     0,  -783,     6,     0,     7,     0,
       0,     0,     0,     0,     0,   563,     0,   383,     0,     0,
       0,     0,     0,     0,     0,   557,     0,     0,     0,     0,
    -783,     0,  -783,   914,   915,     0,     0,     0,   919,     0,
     387,     0,     0,     0,     0,     0,  -783,     0,  -783,     8,
       0,  -783,   496,     9,     0,     0,     0,     0,   939,     0,
     941,     0,     0,  -783,     0,  -783,   497,     0,     0,     0,
       0,    10,   201,   202,    11,     0,     0,    42,   203,   204,
    -783,   205,  -783,  -783,     0,   206,   207,     0,  -783,     0,
     208,   681,     0,     0,     0,     0,     0,    43,     0,   209,
     210,  -783,   211,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   383,     0,   383,  -783,  -783,  -783,  -783,
    -783,  -783,  -783,   498,  -783,  -783,  -783,  -783,  -783,  -783,
       0,     0,  -783,     0,  -783,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   201,   202,     0,     0,     0,
      42,   203,   204,  1105,   205,     0,   464,     0,   206,   207,
     682,   683,   505,   208,  -783,     0,  -783,     0,     0,     0,
      43,     0,   209,   210,     0,   211,     0,     0,     0,     0,
      11,  -783,     0,  -783,  -783,     0,   201,   202,     0,  -783,
       0,    42,   203,   204,     0,   205,     0,   212,   213,   206,
     207,     0,  -783,     0,   208,     0,   383,     0,     0,   383,
       0,    43,     0,   209,   210,   383,   211,  -783,  -783,  -783,
    -783,  -783,  -783,  -783,     0,  -783,  -783,  -783,  -783,  -783,
    -783,     0,     0,  -783,     0,  -783,     0,     0,   201,   202,
       0,  1092,     0,    42,   203,   204,     0,   205,     0,     0,
       0,   206,   207,     0,     0,     0,   208,     0,  1100,  1100,
       0,     0,     0,    43,     0,   209,   210,   686,   211,   686,
     212,   213,   563,   563,   563,     0,     0,  1116,     0,     0,
       0,    11,     0,     0,     0,     0,     0,     0,     0,  1124,
       0,  1125,     0,     0,     0,  1128,     0,     0,     0,     0,
     723,     0,     0,     0,   729,     0,     0,   563,   385,     0,
     383,   212,   213,     0,     0,     0,     0,     0,     0,   383,
       0,   383,     0,     0,     0,     0,   682,   683,   383,     0,
     383,     0,     0,     0,     0,     0,     0,     0,   383,     0,
     383,   383,   176,   383,     0,   383,   383,     0,   383,     0,
     383,    84,     0,  -783,     0,  -783,     0,    42,     0,     0,
     383,     0,     0,   212,   213,   383,     0,     0,     0,     0,
    -783,     0,  -783,  -783,     0,   383,     0,    43,  -783,     0,
    1202,   383,     0,   580,   621,   622,     0,   383,     0,     0,
       0,  -783,     0,     0,   383,    85,    86,     0,     0,     0,
       0,     0,    87,     0,     0,    88,  -783,  -783,  -783,  -783,
    -783,  -783,  -783,     0,  -783,  -783,  -783,  -783,  -783,  -783,
       0,     0,  -783,     0,  -783,     0,  1250,     0,     1,     0,
     623,  -783,   624,     0,     0,     0,     0,  -783,     0,     0,
    1251,     0,     0,     0,     0,     0,   625,     0,   585,     0,
       0,   626,     0,     0,     1,     0,     0,  -783,     0,     0,
     563,     0,     0,   563,   563,     0,     0,     0,     0,     0,
      11,     2,     3,     4,     5,  -783,  -783,     0,   879,     0,
    -370,  1285,  -783,  -370,     0,  -783,     6,     0,     7,  -370,
    1069,  1070,     0,     0,     0,     0,  1071,     2,     3,     4,
       5,     0,     0,     0,     0,     0,  1072,     0,     0,  -370,
       0,     0,     6,     0,     7,     0,  1069,  1070,     0,     0,
       0,     0,  1071,  -370,  -370,  -370,  -370,  -370,  -370,     8,
       0,     0,  1072,     9,  -370,  1546,     0,  -370,  -370,     0,
    -370,     0,  -370,  -370,     0,     0,     0,     0,  -370,     0,
       0,    10,  1349,     0,    11,     8,     0,     0,  -370,     9,
       0,     0,     0,     0,     0,     0,   383,   383,     1,     0,
       0,   383,     0,  1477,     0,     1,     0,    10,  -783,     0,
      11,  -370,     0,     0,  -783,  -370,     0,     0,     0,     0,
       0,   383,     0,   383,     0,     0,     0,     0,  1376,  1377,
       0,     0,     0,  -370,  -783,     0,  -370,     0,     0,     0,
       0,     2,     3,     4,     5,     0,     0,     0,     2,     3,
       4,     5,  -783,  -783,     0,     0,     6,     0,     7,  -783,
    1069,  1070,  -783,     6,     0,     7,  1071,  1069,  1070,     0,
       0,     0,     0,  1071,     0,     0,  1072,     0,     0,     0,
       0,     0,  1401,  1072,     0,  1402,     0,  1404,     0,     0,
       0,     0,     0,  1408,     0,   201,   202,     0,     0,     8,
      42,   203,   204,     9,   205,     0,     8,  1197,   206,   207,
       9,     0,     0,   208,     0,     0,     0,     0,  1431,     0,
      43,    10,   209,   210,    11,   211,     0,     0,    10,     0,
       0,    11,     0,     0,     0,     0,   201,   202,     0,  1457,
    1457,    42,   203,   204,     0,   205,     0,     0,     0,   206,
     207,     0,     0,     0,   208,     0,     0,     0,     0,     0,
       0,    43,     0,   209,   210,     0,   211,     0,  1278,     0,
    1108,     0,   201,   202,   383,     0,   717,    42,   203,   204,
       0,   205,   383,     0,     0,   206,   207,     0,     0,     0,
     208,     0,     0,     0,     0,     0,     0,    43,   383,   209,
     210,     0,   211,     0,     0,     0,   383,   383,     0,  1279,
     383,  1108,     0,     0,     0,     0,     0,   201,   202,     0,
     212,   213,    42,   203,   204,     0,   205,     0,     0,     0,
     206,   207,     0,     0,     0,   208,     0,     0,     0,     0,
       0,     0,    43,     0,   209,   210,     0,   211,     0,     0,
       0,     0,     0,     0,     0,   563,  1543,  1544,   201,   202,
       0,   212,   213,    42,   203,   204,  1552,   205,  1284,     0,
       0,   206,   207,     0,     0,     0,   208,     0,     0,     0,
       0,     0,     0,    43,   383,   209,   210,     0,   211,     0,
       0,     0,  1108,     0,     0,     0,     0,   212,   213,  1457,
       0,  1457,     0,  1575,     0,  1579,  1457,  1457,  1457,     0,
    1457,  1457,  1457,  1457,     0,  1197,     0,     1,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   201,   202,     0,
       0,     0,    42,   203,   204,     0,   205,     0,     0,     0,
     206,   207,   212,   213,     0,   208,     0,     0,  1608,     0,
    1608,     0,    43,     0,   209,   210,     0,   211,     0,     0,
       2,     3,     4,     5,     0,     0,     0,   383,     0,     0,
       0,     0,     0,     0,     0,     6,   563,     7,     0,  1069,
    1070,     0,     0,   212,   213,  1071,     0,     0,     0,     0,
    1608,     0,  1608,     0,  1579,  1072,  1579,  1579,     0,  1579,
       0,  1579,  1539,  1579,  1457,     0,     0,  1579,     0,  1579,
       0,  1579,  1457,     0,     0,     0,     0,     0,     8,   201,
     202,  1253,     9,     0,    42,   203,   204,     0,   205,     0,
       0,   383,   206,   207,     0,     0,     0,   208,     0,     0,
      10,     0,     0,    11,    43,     0,   209,   210,     0,   211,
       0,     0,   212,   213,     0,     0,     0,     0,   383,   383,
       0,     0,  1579,     0,  1579,     0,     0,     0,     0,  1579,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   383,   383,     0,   383,     0,     0,     0,
     383,   201,   202,     0,     0,     0,    42,   203,   204,     0,
     265,     0,     0,     0,   206,   207,     0,     0,     0,   208,
       0,     0,     0,   383,     0,  1506,    43,     0,   209,   210,
    1509,   211,   201,   202,     0,     0,     0,    42,   203,   204,
       0,  1235,     0,     0,     0,   206,   207,     0,     0,   383,
     208,     0,     0,     0,   212,   213,     0,    43,     0,   209,
     210,     0,   211,   201,   202,     0,     0,     0,    42,   203,
     204,     0,  1370,     0,     0,     0,   206,   207,     0,     0,
       0,   208,     0,     0,     0,     0,     0,     0,    43,   826,
     209,   210,     0,   211,     0,     0,     0,  1281,     0,  1568,
     203,   204,  1570,  1509,   827,     0,     0,   366,   367,   368,
     369,   370,   371,   372,   373,   374,     0,     0,     0,     0,
       0,   375,   376,     0,     0,     0,   212,   213,     0,     0,
       0,     0,     0,     0,     0,   383,   383,     0,     0,     0,
       0,     0,     0,     0,   383,     0,     0,     0,     0,     0,
       0,     0,     0,   828,     0,     0,     0,   212,   213,     0,
       0,     0,     0,     0,     0,     0,     0,   383,     0,     0,
       0,   383,     0,     0,   829,   624,   830,   831,   832,   833,
     834,   835,   836,     0,     0,     0,   377,     0,   212,   213,
       0,     0,     0,   837,     0,     0,     0,     0,     0,     0,
     383,   838,   839,     0,     0,     0,     0,   840,   841,   842,
     843,   844,   845,   846,     0,     0,     0,   378,   379,   380,
     381,  1597,     0,     0,   203,   204,     0,     0,     0,     0,
       0,   366,   367,   368,   369,   370,   371,   372,   373,   374,
    1600,     0,     0,   203,   204,   375,   376,     0,     0,     0,
     366,   367,   368,   369,   370,   371,   372,   373,   374,     0,
     672,   673,   674,     0,   375,   376,   675,   366,   367,   368,
     369,   370,   371,   372,   373,   374,     0,     0,   672,   673,
     674,   375,   376,     0,   906,   366,   367,   368,   369,   370,
     371,   372,   373,   374,     0,     0,     0,     0,     0,   375,
     376,     0,     0,     0,     0,   672,   673,   674,     0,     0,
     377,  1266,   366,   367,   368,   369,   370,   371,   372,   373,
     374,     0,     0,     0,     0,     0,   375,   376,     0,   377,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   378,   379,   380,   381,     0,   377,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     378,   379,   380,   381,   377,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   378,   379,   380,
     381,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   377,     0,     0,     0,   378,   379,   380,   381,   672,
     673,   674,     0,     0,     0,  1443,   366,   367,   368,   369,
     370,   371,   372,   373,   374,     0,     0,     0,     0,     0,
     375,   376,   378,   379,   380,   381,   203,   204,   442,     0,
       0,     0,     0,   366,   367,   368,   369,   370,   371,   372,
     373,   374,   203,   204,     0,     0,     0,   375,   376,   366,
     367,   368,   369,   370,   371,   372,   373,   374,     0,     0,
     827,     0,     0,   375,   376,     0,   545,   203,   204,   748,
       0,     0,     0,     0,   366,   367,   368,   369,   370,   371,
     372,   373,   374,     0,     0,   377,     0,     0,   375,   376,
       0,     0,   203,   204,   902,     0,     0,     0,     0,   366,
     367,   368,   369,   370,   371,   372,   373,   374,     0,   828,
       0,     0,   377,   375,   376,     0,   378,   379,   380,   381,
       0,     0,     0,     0,     0,     0,     0,     0,   377,     0,
    1053,   624,   830,   831,   832,   833,   834,   835,   836,     0,
       0,     0,     0,   378,   379,   380,   381,     0,     0,   837,
       0,     0,     0,   377,     0,     0,     0,   838,   839,   378,
     379,   380,   381,   840,   841,   842,   843,   844,   845,   846,
       0,     0,     0,     0,     0,     0,     0,     0,   377,     0,
       0,   672,   673,   674,   378,   379,   380,   381,   366,   367,
     368,   369,   370,   371,   372,   373,   374,     0,     0,     0,
       0,     0,   375,   376,     0,     0,     0,   203,   204,   378,
     379,   380,   381,   910,   366,   367,   368,   369,   370,   371,
     372,   373,   374,   203,   204,     0,     0,   920,   375,   376,
     366,   367,   368,   369,   370,   371,   372,   373,   374,     0,
       0,     0,   203,   204,   375,   376,   921,     0,     0,   366,
     367,   368,   369,   370,   371,   372,   373,   374,     0,     0,
       0,   203,   204,   375,   376,   922,     0,   377,   366,   367,
     368,   369,   370,   371,   372,   373,   374,     0,     0,     0,
       0,     0,   375,   376,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   377,     0,     0,     0,     0,   378,   379,
     380,   381,     0,     0,     0,     0,     0,     0,     0,   377,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   378,   379,   380,   381,   377,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     378,   379,   380,   381,     0,     0,     0,   377,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   378,
     379,   380,   381,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   378,   379,
     380,   381,   203,   204,     0,     0,   923,     0,     0,   366,
     367,   368,   369,   370,   371,   372,   373,   374,   203,   204,
       0,     0,   924,   375,   376,   366,   367,   368,   369,   370,
     371,   372,   373,   374,     0,     0,     0,   203,   204,   375,
     376,   927,     0,     0,   366,   367,   368,   369,   370,   371,
     372,   373,   374,   203,   204,     0,     0,   928,   375,   376,
     366,   367,   368,   369,   370,   371,   372,   373,   374,     0,
       0,     0,   203,   204,   375,   376,  1350,     0,     0,   366,
     367,   368,   369,   370,   371,   372,   373,   374,   377,     0,
       0,     0,     0,   375,   376,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   377,     0,     0,  1599,     0,    42,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   378,
     379,   380,   381,   377,     0,     0,     0,     0,     0,    43,
       0,     0,     0,     0,   165,   378,   379,   380,   381,   377,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   378,   379,   380,   381,   377,     0,
       0,     0,  1157,   302,   303,   304,  1158,  1159,  1160,     0,
     378,   379,   380,   381,   312,  1161,     0,     0,  1162,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   378,
     379,   380,   381,   203,   204,     0,     0,  1396,     0,     0,
     366,   367,   368,   369,   370,   371,   372,   373,   374,   203,
     204,     0,     0,  1473,   375,   376,   366,   367,   368,   369,
     370,   371,   372,   373,   374,     0,     0,     0,   203,   204,
     375,   376,  1474,     0,     0,   366,   367,   368,   369,   370,
     371,   372,   373,   374,   203,   204,     0,     0,  1483,   375,
     376,   366,   367,   368,   369,   370,   371,   372,   373,   374,
       0,     0,     0,   203,   204,   375,   376,  1484,     0,     0,
     366,   367,   368,   369,   370,   371,   372,   373,   374,   377,
       0,     0,     0,     0,   375,   376,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   377,     0,     0,     0,     0,
      42,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     378,   379,   380,   381,   377,     0,     0,     0,     0,     0,
      43,     0,     0,     0,     0,   165,   378,   379,   380,   381,
     377,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   378,   379,   380,   381,   377,
       0,     0,     0,  1157,   302,   303,   304,  1158,  1159,  1160,
       0,   378,   379,   380,   381,   312,  1161,     0,     0,  1162,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     378,   379,   380,   381,   203,   204,     0,     0,  1486,     0,
       0,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     203,   204,     0,     0,     0,   375,   376,   366,   367,   368,
     369,   370,   371,   372,   373,   374,     0,     0,     0,   203,
     204,   375,   376,     0,     0,     0,   366,   367,   368,   369,
     370,   371,   372,   373,   374,     0,     0,     0,     0,     0,
     375,   376,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     377,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1616,   377,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    42,     0,   297,     0,
       0,   378,   379,   380,   381,   377,     0,     0,     0,     0,
       0,     0,     0,   298,     0,   299,    43,   378,   379,   380,
     381,   165,   580,   581,   582,     0,     0,     0,     0,     0,
     583,     3,     4,     5,   300,     0,   378,   379,   380,   381,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   301,
     302,   303,   304,   305,   306,   307,     0,   308,   309,   310,
     311,   312,   313,     0,    42,   314,   297,   315,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   298,     0,   299,    43,   584,     0,   585,     8,   165,
     580,     0,     0,     0,     0,     0,     0,     0,   583,     3,
       4,     5,   300,     0,     0,     0,     0,     0,     0,     0,
      10,    42,     0,     0,     0,     0,     0,   301,   302,   303,
     304,   305,   306,   307,     0,   308,   309,   310,   311,   312,
     313,    43,     0,   314,     0,   315,   165,   580,     0,     0,
       0,     0,     0,     0,     0,   583,     3,     4,     5,     0,
       0,     0,     0,     0,     0,   585,     8,     0,     0,     0,
       0,     0,     0,     0,  1157,   302,   303,   304,  1158,  1159,
    1160,     0,     0,    42,     0,   297,   312,  1161,    10,     0,
    1162,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     298,     0,   299,    43,     0,     0,     0,     0,   165,     0,
       0,     0,   585,     8,     0,     0,     0,     0,     0,     0,
       0,   300,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    10,   301,   302,   303,   304,
     305,   306,   307,     0,   308,   309,   310,   311,   312,   313,
       0,     0,   314,     0,   315
};

/* YYCONFLP[YYPACT[STATE-NUM]] -- Pointer into YYCONFL of start of
   list of conflicting reductions corresponding to action entry for
   state STATE-NUM in yytable.  0 means no conflicts.  The list in
   yyconfl is terminated by a rule number of 0.  */
static const unsigned char yyconflp[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0
};

/* YYCONFL[I] -- lists of conflicting rule numbers, each terminated by
   0, pointed into by YYCONFLP.  */
static const short int yyconfl[] =
{
       0
};

static const short int yycheck[] =
{
       0,   211,   155,     0,   485,    38,   466,   391,   315,   120,
     288,    47,   704,    13,    14,   126,   839,   840,   841,   234,
     990,   406,   570,   597,   406,   990,   990,   406,   406,   846,
     406,   309,   580,   788,   639,  1074,   638,   585,    85,   420,
    1235,   515,   265,   788,   234,  1072,   813,   767,   165,   508,
     154,   622,   205,    84,   625,   827,   220,    85,   382,   182,
      87,   781,   758,   431,   223,   774,    10,   435,   436,   353,
      15,   455,   456,     3,    17,   359,   360,   166,   167,    10,
      39,    40,     0,    32,    15,   420,    12,    11,   827,   353,
       3,   398,    16,   785,    18,   359,   360,    17,   131,   838,
     839,   840,   841,   156,   157,    18,    32,    12,  1418,    58,
     920,     8,   265,  1423,    10,    36,    98,   927,    18,   166,
     167,   101,    10,     6,    72,     1,    39,    32,   156,    15,
     163,   178,     0,    46,    17,   190,    12,    85,   166,    84,
      62,    38,   101,    40,   199,   200,   128,    47,    48,   129,
       1,     8,   179,    80,   182,    12,    32,   106,   107,  1033,
    1034,    12,    12,  1037,  1038,   269,    10,    18,    65,    26,
     198,    98,   102,    10,   278,  1370,  1050,    98,    98,    10,
     390,    32,    32,   398,   129,   129,   129,  1497,   495,   102,
    1500,   109,   110,  1503,   112,   284,   101,   233,   129,   147,
      15,  1421,    98,   129,   104,   129,   154,   129,   398,     1,
      98,   129,    98,  1252,   111,    98,   339,   270,   166,   167,
      12,    10,   102,   382,   388,     8,   126,   175,   438,    12,
     178,    14,   556,   181,   234,   235,    10,   284,    10,   787,
      32,   288,    99,    26,   275,    95,    96,   967,   968,   969,
     709,   102,   536,   300,    98,  1027,   256,   257,   978,   979,
     980,    98,   309,   310,   311,   974,   962,   648,   636,    17,
     651,   652,   653,   654,    19,   539,  1471,    10,   305,  1051,
      62,   649,   650,    98,  1504,     8,   397,  1569,  1027,    12,
       1,     3,    15,    16,  1604,   322,    84,     8,  1108,     1,
      12,    12,   512,    26,    10,    16,    18,    10,   100,    98,
     881,   882,  1051,   648,    16,    26,    99,   652,   471,   654,
      32,   269,    10,     7,    98,    37,    98,  1609,    12,  1611,
     278,   359,   360,  1303,    46,   545,   284,   454,  1303,  1303,
     288,   129,   446,    10,   448,   345,    10,   129,    32,     1,
      98,    12,   300,    98,  1381,   565,     1,    18,    62,   406,
      12,   309,   310,   311,    10,    98,    17,    12,     1,    44,
      45,    32,  1195,    18,    10,     8,    99,   404,    11,    12,
      32,   596,     8,    10,    17,    17,    12,    32,    99,   337,
     102,    17,    98,   700,  1589,    98,    10,   704,   398,    32,
      26,    46,    47,    48,    37,   595,    39,    40,   793,    10,
      98,   793,    72,  1158,   793,   793,   416,   793,   992,  1186,
     420,  1141,     8,   527,   748,   129,    12,    13,    14,  1149,
      16,   431,   432,    36,   657,   435,   436,    10,   485,  1478,
      62,   102,    17,    95,    96,    97,    32,    98,    10,    10,
      10,    37,    98,   402,   664,  1194,  1195,   102,   406,   104,
    1270,  1271,    98,  1273,   412,    10,    98,  1277,   101,   129,
    1162,    98,   499,    99,  1669,    10,   950,    10,   785,    10,
    1354,   126,   223,  1357,  1089,  1087,  1360,  1361,  1362,  1363,
    1364,  1365,  1366,  1367,    10,    98,   129,    98,   446,  1538,
     448,     8,    10,   884,   657,    12,   890,   129,    10,    16,
      10,    10,  1707,   894,   895,    10,    10,  1340,   466,    26,
      98,  1716,    39,    98,  1719,    98,  1721,     8,  1723,    46,
    1725,    12,  1727,  1350,  1729,    16,    98,   485,    98,    10,
     818,   568,   283,   129,    10,    26,    10,   580,   933,   884,
     583,   933,   585,    98,   933,   933,    98,   933,   662,   894,
     895,  1316,    72,    98,    17,    98,     1,    98,    18,    10,
     570,  1316,    17,   788,    10,    84,     1,    12,    59,   527,
    1550,    16,    98,    18,   101,  1550,  1550,    12,   621,    10,
      98,   624,    99,    10,    29,   595,   596,    32,    98,    98,
       1,  1340,  1176,    98,    98,   990,  1345,    32,   990,    44,
      45,   990,   990,    18,   990,    10,    98,  1440,    99,   129,
     129,   570,    23,   930,    10,  1173,    16,    98,    10,   936,
       1,    10,    98,  1093,    98,    10,   636,     8,    62,    29,
      11,    12,    47,    10,  1467,    98,   128,     1,   648,   649,
     650,   599,   652,    98,   654,   603,   604,    98,    12,    10,
    1405,    32,    98,    10,    18,    10,    37,   102,    39,    40,
      95,    96,    97,   622,   701,   982,   625,    98,    32,    17,
      10,    98,    17,    26,     4,     5,    12,    64,     8,     9,
      12,    11,    17,    47,    48,    36,    18,   102,  1437,   104,
     700,  1440,  1441,    98,   704,    17,    32,    27,   763,    72,
      32,    17,    98,  1405,   662,   930,    98,    17,    38,    98,
      40,   936,    10,    98,    38,    47,   726,   727,  1467,  1468,
     101,    98,    46,    47,    48,    49,    56,   770,    10,  1484,
      17,  1486,   778,  1488,   777,    65,   956,    98,   102,   902,
     104,   784,  1359,    98,    17,    98,    12,    98,   129,    17,
      98,    22,    17,    98,    84,    85,   129,   982,    98,    84,
     825,   818,   126,    98,    10,     8,    32,    97,    17,    12,
     102,    37,   104,    16,   128,   785,    98,   820,   788,   103,
     104,   111,    98,    26,    84,    17,    17,   117,    98,    84,
    1281,    17,    13,    14,   124,   125,  1084,    17,    17,  1269,
     759,    17,   126,   813,   129,    26,   136,  1201,    11,   767,
     140,    98,    17,   878,  1305,    18,    59,    17,    17,    22,
     150,   151,    17,   781,   154,    98,   156,   157,   787,   129,
      98,    11,    98,    98,   129,   165,   166,   167,    98,    13,
      14,   799,    22,    84,    17,  1162,    17,   805,   178,    98,
      17,   181,    26,    17,   975,    17,    99,    17,     1,   189,
     818,    17,    17,    17,    98,   824,    98,    98,   198,    12,
     880,    17,    98,   880,   884,    18,   933,    98,    98,    98,
      17,    17,    98,   920,   894,   895,    17,   924,   129,    32,
     927,   928,    17,    98,    36,   932,   961,    17,    98,    98,
     937,  1518,  1065,  1520,    47,    48,    17,    17,  1525,  1526,
    1527,   241,  1529,  1530,  1531,  1532,  1671,   247,   877,  1389,
     930,   986,   881,   882,    98,    98,   936,    98,    46,    47,
      48,    98,    84,   990,    98,    10,    98,    17,    98,   269,
     270,    16,    98,    98,    98,   275,   983,   277,   278,    84,
    1175,     1,    98,     1,   284,  1020,    98,   100,   288,   102,
      17,   104,    98,    57,    58,    18,    16,    98,    16,   299,
     300,    12,   982,    98,     1,   933,    10,   129,    98,   309,
     310,   311,   312,   126,   102,   995,   104,    98,    98,    16,
      10,    32,  1309,  1003,   129,  1005,    47,    48,    52,     3,
      54,  1066,    56,  1539,    82,    46,  1623,   337,   126,   967,
     968,   969,   342,   343,  1631,    10,  1081,    12,  1083,     1,
     978,   979,   980,   353,    16,     1,   985,  1084,    10,   359,
     360,    10,   990,   111,    10,   129,    15,    32,   996,   117,
     118,  1084,    46,    47,    48,    49,    12,    98,    52,    12,
      54,   102,    56,   104,  1590,   385,  1592,    61,    22,    63,
    1596,    11,  1072,    82,  1074,  1072,    32,  1074,     1,    32,
    1135,  1108,  1235,    39,    37,   126,   406,    10,    22,    18,
      24,    39,    40,  1120,  1309,  1122,   416,    10,  1153,    47,
      48,  1316,   111,    16,   424,    10,     1,   427,   117,   118,
     104,     1,    29,     1,   108,   109,   110,    12,   112,  1600,
      84,    12,    12,  1150,    12,    16,   446,   582,   448,   584,
      18,  1080,   126,  1082,   454,   129,  1084,    32,    29,   129,
       1,    32,    32,     6,    32,  1093,    37,    84,   468,    12,
      16,    12,     1,   101,   102,    16,   104,  1613,  1158,  1615,
    1616,  1179,  1162,    12,  1620,   485,  1622,  1185,    29,    32,
    1626,    32,  1628,   493,  1630,  1175,    10,   497,   126,  1179,
    1487,   129,    16,    32,    98,  1185,  1186,    50,    51,    17,
       5,    19,    12,  1141,    57,     1,    16,    60,     4,     5,
    1255,  1149,  1257,  1356,     8,     4,    26,   527,    12,     1,
       1,     1,    32,   533,     4,     5,   536,  1370,     1,   539,
      12,    12,    12,   127,  1173,  1681,  1259,  1683,    32,    12,
      15,    12,  1688,    37,  1281,    41,    42,    43,    10,    11,
      32,    32,    32,  1270,  1271,     8,  1273,    37,    29,    32,
    1277,    32,  1252,   573,     1,  1252,  1303,   577,  1305,  1314,
       1,    10,     1,   583,  1474,    12,    18,    16,     7,     8,
      22,    12,  1487,    12,    13,    14,     1,    16,    15,     1,
      29,    20,    21,  1310,    24,    32,    25,    12,    12,     1,
      12,    32,   916,    32,   918,    34,    35,    18,    37,  1452,
      12,    22,    12,    16,   624,    29,    16,    32,    32,  1309,
      32,    20,    21,    37,     1,     1,  1316,     1,   638,   639,
      32,  1269,    32,     7,     8,    12,    12,    11,    12,    13,
      14,    18,    16,  1281,    84,    85,    20,    21,     1,     8,
      98,    25,   662,    12,   102,    32,    32,    97,    32,    12,
      34,    35,    11,    37,  1409,  1303,    15,  1305,    10,    98,
      47,    48,     8,    32,  1313,    10,    12,    13,    14,    32,
      16,    18,    12,    16,     8,  1528,    16,    11,    12,  1406,
      18,  1381,    12,    22,  1381,  1595,    32,    26,    18,    29,
      16,    37,    32,   132,   133,    22,    23,   717,    32,     3,
       8,     1,    32,    37,    12,  1405,    12,     7,     8,    17,
      16,    24,    12,    13,    14,   102,    16,   104,    12,     8,
      20,    21,    16,    12,    32,    25,    32,   109,   110,    37,
     112,    16,    32,    16,    34,    35,    16,    37,    32,   126,
     760,  1389,    46,    47,    48,    49,    12,   129,   132,   133,
      16,    16,     8,    16,   774,  1482,    12,    61,    10,    63,
      16,    65,    66,    22,    23,  1357,    32,    71,  1360,  1361,
      98,  1624,  1364,  1365,  1366,    13,    14,    81,  1478,    17,
      84,  1478,    82,  1483,  1484,    16,  1486,  1487,  1488,    10,
      11,   811,     8,   813,   814,    16,    12,    16,   818,   819,
     104,   115,   116,  1550,   108,   580,    10,   827,   583,    16,
     585,     1,    17,  1032,     4,     5,  1035,  1036,   838,   839,
     840,   841,   126,    34,    35,   129,    17,  1554,  1047,  1048,
    1049,    10,   132,   133,    17,    13,    14,    22,  1538,    17,
      26,  1538,  1109,     7,     8,  1112,  1113,    22,    12,    13,
      14,    16,    16,  1600,    10,   875,    20,    21,    13,    14,
      10,    25,    98,   883,    10,    29,    53,    31,    32,   889,
      34,    35,    17,    37,   607,   608,     0,     1,    10,     3,
     922,   923,     6,  1058,  1059,    10,    17,    10,    12,    98,
      16,    19,    22,    10,    10,    84,    80,    17,  1598,    80,
      72,    22,  1550,    98,    98,    10,    70,    10,    32,    36,
      22,    24,    23,   933,    38,    39,    40,    19,    22,    19,
     128,    19,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    46,    56,    57,     3,    10,    60,    61,   101,    63,
      10,    65,    66,   116,   964,    17,    98,    71,    39,    10,
      98,    98,  1600,   973,   974,    79,    80,    81,    98,    18,
      84,    85,    38,    87,    98,    17,    19,   987,   132,   133,
     990,  1671,    15,   993,    98,    15,    10,   101,    17,   103,
     104,    17,   106,   107,   108,   109,   110,    10,   112,    72,
    1010,    16,    98,    17,    10,    17,    17,  1017,    10,    98,
      10,    98,   126,    22,    10,   129,    98,  1027,    10,    10,
    1030,    16,  1032,  1033,  1034,  1035,  1036,  1037,  1038,    10,
      10,    10,    10,    10,    86,    10,    22,  1047,  1048,  1049,
    1050,  1051,    16,    16,    16,    16,    16,     1,    16,     3,
      16,    16,     6,  1063,    16,    16,    16,    16,    12,    10,
      10,    10,   107,    16,    22,    22,    22,    10,    10,    17,
      17,    10,    16,    11,  1084,    10,    64,  1087,    32,  1089,
      10,    98,    98,   101,    38,    39,    40,    18,    22,    10,
      98,    10,    46,    47,    48,    49,    50,    51,    10,    53,
      10,    10,    10,    57,    10,    16,    60,    61,    31,    63,
      38,    16,    16,    80,    16,    79,    19,    16,    16,    16,
     109,    10,    22,   110,  1134,    10,    22,    79,    22,   118,
     119,    85,    24,    87,    24,    18,   134,    19,    22,    84,
      17,    55,    58,    98,  1154,    17,    24,   101,    55,   103,
     104,    24,   106,   142,   108,    24,     1,    98,     3,    24,
      19,     6,    98,    16,    24,    98,    98,    12,    24,    98,
      17,    98,   126,    98,    98,   129,  1186,  1187,  1188,    10,
      98,    98,  1192,    98,  1194,  1195,    22,    32,   134,    17,
      10,    10,    22,    38,    39,    40,    64,    98,    59,    16,
    1210,    46,    47,    48,    49,    50,    51,     8,    10,     8,
      98,    98,    57,    10,    10,    60,    61,    98,    63,    98,
      84,    15,   211,    98,    98,    15,    17,    98,    98,    17,
      79,    98,    98,    79,    10,    17,  1246,    15,    10,  1249,
      85,  1251,    87,    10,    17,    15,  1256,    15,  1258,  1259,
      98,    17,    17,    10,    98,    98,   101,    10,   103,   104,
      10,   106,    10,   108,    10,    10,    10,    10,    17,    10,
      17,  1281,    98,    10,    10,    17,    10,    17,  1288,    17,
      10,   126,    10,    10,   129,     7,     8,    10,    81,  1299,
      12,    13,    14,  1303,    16,  1305,    10,  1307,    20,    21,
     289,   290,    10,    25,    10,  1315,    10,    10,    10,  1319,
      32,    10,    34,    35,    98,    37,    17,  1327,    98,    98,
    1330,  1331,   605,    98,    98,   799,   608,    98,  1338,    14,
    1340,   889,   621,   259,  1084,  1345,     5,   259,   424,   424,
     424,   875,   533,  1063,  1354,     7,  1175,  1357,   117,   235,
    1360,  1361,  1362,  1363,  1364,  1365,  1366,  1367,    80,   398,
      82,   973,   570,   949,  1374,   189,   342,   727,     1,   726,
    1597,  1595,  1690,  1383,   343,  1385,  1005,  1185,   416,    12,
     275,    14,    15,  1423,   277,  1427,  1604,  1598,   377,  1115,
     848,  1350,  1235,  1441,  1034,   384,    29,  1517,    31,    32,
    1410,   390,   391,  1618,    37,  1452,  1210,   396,   454,   674,
     132,   133,   396,   908,   140,    43,    -1,    50,    -1,    -1,
      -1,    -1,   385,    -1,    -1,   365,    -1,  1437,    -1,    -1,
    1440,  1441,    65,    66,    67,    68,    69,    70,    71,    -1,
      73,    74,    75,    76,    77,    78,    -1,    -1,    81,   438,
      83,    84,    -1,   442,    -1,    -1,   347,  1467,  1468,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   455,   456,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   464,    -1,    -1,   467,    -1,
      -1,  1491,    -1,   472,    -1,    -1,    -1,    -1,   477,   478,
      -1,   480,    -1,   482,    -1,   484,   129,   486,    -1,    -1,
      -1,    -1,   491,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,     1,    -1,     3,    -1,    -1,     6,   508,
      -1,    -1,   511,   512,    12,    -1,   515,    -1,    -1,    -1,
     218,    -1,   220,    -1,    -1,    -1,   525,    -1,    -1,    -1,
    1550,   229,   230,    -1,    32,    -1,   535,    -1,    -1,    -1,
      38,    39,    40,    -1,    -1,   544,   545,   245,    46,    47,
      48,    49,    50,    51,    -1,    -1,    -1,    -1,    -1,    57,
      -1,    -1,    60,    61,    -1,    63,   565,    -1,    -1,   267,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1597,    -1,    -1,
    1600,    -1,    -1,    -1,    -1,    -1,    -1,    85,    -1,    87,
      -1,    -1,    -1,    -1,    -1,    -1,     1,    -1,     3,    -1,
      -1,     6,    -1,   101,    -1,   103,   104,    12,   106,    -1,
     108,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    32,   126,    -1,
      -1,   129,    -1,    38,    39,    40,    -1,    -1,    -1,    -1,
      -1,    46,    47,    48,    49,    50,    51,    -1,    -1,    -1,
      -1,    -1,    57,    -1,    -1,    60,    61,    -1,    63,    -1,
      -1,    -1,    -1,    -1,    -1,   664,    -1,   365,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   674,    -1,    -1,    -1,    -1,
      85,    -1,    87,   682,   683,    -1,    -1,    -1,   687,    -1,
     388,    -1,    -1,    -1,    -1,    -1,   101,    -1,   103,   104,
      -1,   106,     1,   108,    -1,    -1,    -1,    -1,   707,    -1,
     709,    -1,    -1,    12,    -1,    14,    15,    -1,    -1,    -1,
      -1,   126,     7,     8,   129,    -1,    -1,    12,    13,    14,
      29,    16,    31,    32,    -1,    20,    21,    -1,    37,    -1,
      25,    26,    -1,    -1,    -1,    -1,    -1,    32,    -1,    34,
      35,    50,    37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   461,    -1,   463,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      -1,    -1,    81,    -1,    83,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,     7,     8,    -1,    -1,    -1,
      12,    13,    14,     1,    16,    -1,    18,    -1,    20,    21,
      95,    96,    10,    25,    12,    -1,    14,    -1,    -1,    -1,
      32,    -1,    34,    35,    -1,    37,    -1,    -1,    -1,    -1,
     129,    29,    -1,    31,    32,    -1,     7,     8,    -1,    37,
      -1,    12,    13,    14,    -1,    16,    -1,   132,   133,    20,
      21,    -1,    50,    -1,    25,    -1,   554,    -1,    -1,   557,
      -1,    32,    -1,    34,    35,   563,    37,    65,    66,    67,
      68,    69,    70,    71,    -1,    73,    74,    75,    76,    77,
      78,    -1,    -1,    81,    -1,    83,    -1,    -1,     7,     8,
      -1,   890,    -1,    12,    13,    14,    -1,    16,    -1,    -1,
      -1,    20,    21,    -1,    -1,    -1,    25,    -1,   907,   908,
      -1,    -1,    -1,    32,    -1,    34,    35,   916,    37,   918,
     132,   133,   921,   922,   923,    -1,    -1,   926,    -1,    -1,
      -1,   129,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   938,
      -1,   940,    -1,    -1,    -1,   944,    -1,    -1,    -1,    -1,
     949,    -1,    -1,    -1,   953,    -1,    -1,   956,   129,    -1,
     658,   132,   133,    -1,    -1,    -1,    -1,    -1,    -1,   667,
      -1,   669,    -1,    -1,    -1,    -1,    95,    96,   676,    -1,
     678,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   686,    -1,
     688,   689,     1,   691,    -1,   693,   694,    -1,   696,    -1,
     698,     6,    -1,    12,    -1,    14,    -1,    12,    -1,    -1,
     708,    -1,    -1,   132,   133,   713,    -1,    -1,    -1,    -1,
      29,    -1,    31,    32,    -1,   723,    -1,    32,    37,    -1,
    1029,   729,    -1,    38,    39,    40,    -1,   735,    -1,    -1,
      -1,    50,    -1,    -1,   742,    50,    51,    -1,    -1,    -1,
      -1,    -1,    57,    -1,    -1,    60,    65,    66,    67,    68,
      69,    70,    71,    -1,    73,    74,    75,    76,    77,    78,
      -1,    -1,    81,    -1,    83,    -1,     1,    -1,     3,    -1,
      85,     6,    87,    -1,    -1,    -1,    -1,    12,    -1,    -1,
      15,    -1,    -1,    -1,    -1,    -1,   101,    -1,   103,    -1,
      -1,   106,    -1,    -1,     3,    -1,    -1,    32,    -1,    -1,
    1109,    -1,    -1,  1112,  1113,    -1,    -1,    -1,    -1,    -1,
     129,    46,    47,    48,    49,    50,    51,    -1,     1,    -1,
       3,  1130,    57,     6,    -1,    60,    61,    -1,    63,    12,
      65,    66,    -1,    -1,    -1,    -1,    71,    46,    47,    48,
      49,    -1,    -1,    -1,    -1,    -1,    81,    -1,    -1,    32,
      -1,    -1,    61,    -1,    63,    -1,    65,    66,    -1,    -1,
      -1,    -1,    71,    46,    47,    48,    49,    50,    51,   104,
      -1,    -1,    81,   108,    57,    84,    -1,    60,    61,    -1,
      63,    -1,    65,    66,    -1,    -1,    -1,    -1,    71,    -1,
      -1,   126,  1201,    -1,   129,   104,    -1,    -1,    81,   108,
      -1,    -1,    -1,    -1,    -1,    -1,   914,   915,     3,    -1,
      -1,   919,    -1,     1,    -1,     3,    -1,   126,     6,    -1,
     129,   104,    -1,    -1,    12,   108,    -1,    -1,    -1,    -1,
      -1,   939,    -1,   941,    -1,    -1,    -1,    -1,  1247,  1248,
      -1,    -1,    -1,   126,    32,    -1,   129,    -1,    -1,    -1,
      -1,    46,    47,    48,    49,    -1,    -1,    -1,    46,    47,
      48,    49,    50,    51,    -1,    -1,    61,    -1,    63,    57,
      65,    66,    60,    61,    -1,    63,    71,    65,    66,    -1,
      -1,    -1,    -1,    71,    -1,    -1,    81,    -1,    -1,    -1,
      -1,    -1,  1301,    81,    -1,  1304,    -1,  1306,    -1,    -1,
      -1,    -1,    -1,  1312,    -1,     7,     8,    -1,    -1,   104,
      12,    13,    14,   108,    16,    -1,   104,  1025,    20,    21,
     108,    -1,    -1,    25,    -1,    -1,    -1,    -1,  1337,    -1,
      32,   126,    34,    35,   129,    37,    -1,    -1,   126,    -1,
      -1,   129,    -1,    -1,    -1,    -1,     7,     8,    -1,  1358,
    1359,    12,    13,    14,    -1,    16,    -1,    -1,    -1,    20,
      21,    -1,    -1,    -1,    25,    -1,    -1,    -1,    -1,    -1,
      -1,    32,    -1,    34,    35,    -1,    37,    -1,    80,    -1,
      82,    -1,     7,     8,  1092,    -1,    11,    12,    13,    14,
      -1,    16,  1100,    -1,    -1,    20,    21,    -1,    -1,    -1,
      25,    -1,    -1,    -1,    -1,    -1,    -1,    32,  1116,    34,
      35,    -1,    37,    -1,    -1,    -1,  1124,  1125,    -1,    80,
    1128,    82,    -1,    -1,    -1,    -1,    -1,     7,     8,    -1,
     132,   133,    12,    13,    14,    -1,    16,    -1,    -1,    -1,
      20,    21,    -1,    -1,    -1,    25,    -1,    -1,    -1,    -1,
      -1,    -1,    32,    -1,    34,    35,    -1,    37,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1474,  1475,  1476,     7,     8,
      -1,   132,   133,    12,    13,    14,  1485,    16,    17,    -1,
      -1,    20,    21,    -1,    -1,    -1,    25,    -1,    -1,    -1,
      -1,    -1,    -1,    32,  1202,    34,    35,    -1,    37,    -1,
      -1,    -1,    82,    -1,    -1,    -1,    -1,   132,   133,  1518,
      -1,  1520,    -1,  1522,    -1,  1524,  1525,  1526,  1527,    -1,
    1529,  1530,  1531,  1532,    -1,  1233,    -1,     3,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,     7,     8,    -1,
      -1,    -1,    12,    13,    14,    -1,    16,    -1,    -1,    -1,
      20,    21,   132,   133,    -1,    25,    -1,    -1,  1567,    -1,
    1569,    -1,    32,    -1,    34,    35,    -1,    37,    -1,    -1,
      46,    47,    48,    49,    -1,    -1,    -1,  1285,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    61,  1595,    63,    -1,    65,
      66,    -1,    -1,   132,   133,    71,    -1,    -1,    -1,    -1,
    1609,    -1,  1611,    -1,  1613,    81,  1615,  1616,    -1,  1618,
      -1,  1620,    82,  1622,  1623,    -1,    -1,  1626,    -1,  1628,
      -1,  1630,  1631,    -1,    -1,    -1,    -1,    -1,   104,     7,
       8,   107,   108,    -1,    12,    13,    14,    -1,    16,    -1,
      -1,  1349,    20,    21,    -1,    -1,    -1,    25,    -1,    -1,
     126,    -1,    -1,   129,    32,    -1,    34,    35,    -1,    37,
      -1,    -1,   132,   133,    -1,    -1,    -1,    -1,  1376,  1377,
      -1,    -1,  1681,    -1,  1683,    -1,    -1,    -1,    -1,  1688,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1401,  1402,    -1,  1404,    -1,    -1,    -1,
    1408,     7,     8,    -1,    -1,    -1,    12,    13,    14,    -1,
      16,    -1,    -1,    -1,    20,    21,    -1,    -1,    -1,    25,
      -1,    -1,    -1,  1431,    -1,  1433,    32,    -1,    34,    35,
    1438,    37,     7,     8,    -1,    -1,    -1,    12,    13,    14,
      -1,    16,    -1,    -1,    -1,    20,    21,    -1,    -1,  1457,
      25,    -1,    -1,    -1,   132,   133,    -1,    32,    -1,    34,
      35,    -1,    37,     7,     8,    -1,    -1,    -1,    12,    13,
      14,    -1,    16,    -1,    -1,    -1,    20,    21,    -1,    -1,
      -1,    25,    -1,    -1,    -1,    -1,    -1,    -1,    32,     1,
      34,    35,    -1,    37,    -1,    -1,    -1,    10,    -1,  1507,
      13,    14,  1510,  1511,    16,    -1,    -1,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,
      -1,    34,    35,    -1,    -1,    -1,   132,   133,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1543,  1544,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1552,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    65,    -1,    -1,    -1,   132,   133,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1575,    -1,    -1,
      -1,  1579,    -1,    -1,    86,    87,    88,    89,    90,    91,
      92,    93,    94,    -1,    -1,    -1,    99,    -1,   132,   133,
      -1,    -1,    -1,   105,    -1,    -1,    -1,    -1,    -1,    -1,
    1608,   113,   114,    -1,    -1,    -1,    -1,   119,   120,   121,
     122,   123,   124,   125,    -1,    -1,    -1,   130,   131,   132,
     133,    10,    -1,    -1,    13,    14,    -1,    -1,    -1,    -1,
      -1,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      10,    -1,    -1,    13,    14,    34,    35,    -1,    -1,    -1,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      13,    14,    15,    -1,    34,    35,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    -1,    -1,    13,    14,
      15,    34,    35,    -1,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,    34,
      35,    -1,    -1,    -1,    -1,    13,    14,    15,    -1,    -1,
      99,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    -1,    -1,    -1,    -1,    -1,    34,    35,    -1,    99,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   130,   131,   132,   133,    -1,    99,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     130,   131,   132,   133,    99,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,   131,   132,
     133,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    99,    -1,    -1,    -1,   130,   131,   132,   133,    13,
      14,    15,    -1,    -1,    -1,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,
      34,    35,   130,   131,   132,   133,    13,    14,    15,    -1,
      -1,    -1,    -1,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    13,    14,    -1,    -1,    -1,    34,    35,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    -1,
      16,    -1,    -1,    34,    35,    -1,    37,    13,    14,    15,
      -1,    -1,    -1,    -1,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    -1,    -1,    99,    -1,    -1,    34,    35,
      -1,    -1,    13,    14,    15,    -1,    -1,    -1,    -1,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    65,
      -1,    -1,    99,    34,    35,    -1,   130,   131,   132,   133,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    99,    -1,
      86,    87,    88,    89,    90,    91,    92,    93,    94,    -1,
      -1,    -1,    -1,   130,   131,   132,   133,    -1,    -1,   105,
      -1,    -1,    -1,    99,    -1,    -1,    -1,   113,   114,   130,
     131,   132,   133,   119,   120,   121,   122,   123,   124,   125,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    99,    -1,
      -1,    13,    14,    15,   130,   131,   132,   133,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,    -1,    -1,
      -1,    -1,    34,    35,    -1,    -1,    -1,    13,    14,   130,
     131,   132,   133,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    13,    14,    -1,    -1,    17,    34,    35,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      -1,    -1,    13,    14,    34,    35,    17,    -1,    -1,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    -1,
      -1,    13,    14,    34,    35,    17,    -1,    99,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,    -1,    -1,
      -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    99,    -1,    -1,    -1,    -1,   130,   131,
     132,   133,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    99,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   130,   131,   132,   133,    99,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     130,   131,   132,   133,    -1,    -1,    -1,    99,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,
     131,   132,   133,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,   131,
     132,   133,    13,    14,    -1,    -1,    17,    -1,    -1,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    13,    14,
      -1,    -1,    17,    34,    35,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    -1,    -1,    -1,    13,    14,    34,
      35,    17,    -1,    -1,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    13,    14,    -1,    -1,    17,    34,    35,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      -1,    -1,    13,    14,    34,    35,    17,    -1,    -1,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    99,    -1,
      -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    99,    -1,    -1,    10,    -1,    12,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,
     131,   132,   133,    99,    -1,    -1,    -1,    -1,    -1,    32,
      -1,    -1,    -1,    -1,    37,   130,   131,   132,   133,    99,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   130,   131,   132,   133,    99,    -1,
      -1,    -1,    65,    66,    67,    68,    69,    70,    71,    -1,
     130,   131,   132,   133,    77,    78,    -1,    -1,    81,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,
     131,   132,   133,    13,    14,    -1,    -1,    17,    -1,    -1,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    13,
      14,    -1,    -1,    17,    34,    35,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    13,    14,
      34,    35,    17,    -1,    -1,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    13,    14,    -1,    -1,    17,    34,
      35,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    -1,    -1,    13,    14,    34,    35,    17,    -1,    -1,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    99,
      -1,    -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    99,    -1,    -1,    -1,    -1,
      12,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     130,   131,   132,   133,    99,    -1,    -1,    -1,    -1,    -1,
      32,    -1,    -1,    -1,    -1,    37,   130,   131,   132,   133,
      99,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   130,   131,   132,   133,    99,
      -1,    -1,    -1,    65,    66,    67,    68,    69,    70,    71,
      -1,   130,   131,   132,   133,    77,    78,    -1,    -1,    81,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     130,   131,   132,   133,    13,    14,    -1,    -1,    17,    -1,
      -1,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      13,    14,    -1,    -1,    -1,    34,    35,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    -1,    -1,    -1,    13,
      14,    34,    35,    -1,    -1,    -1,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,
      34,    35,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      99,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    98,    99,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    12,    -1,    14,    -1,
      -1,   130,   131,   132,   133,    99,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    29,    -1,    31,    32,   130,   131,   132,
     133,    37,    38,    39,    40,    -1,    -1,    -1,    -1,    -1,
      46,    47,    48,    49,    50,    -1,   130,   131,   132,   133,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    -1,    73,    74,    75,
      76,    77,    78,    -1,    12,    81,    14,    83,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    29,    -1,    31,    32,   101,    -1,   103,   104,    37,
      38,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    46,    47,
      48,    49,    50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     126,    12,    -1,    -1,    -1,    -1,    -1,    65,    66,    67,
      68,    69,    70,    71,    -1,    73,    74,    75,    76,    77,
      78,    32,    -1,    81,    -1,    83,    37,    38,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    46,    47,    48,    49,    -1,
      -1,    -1,    -1,    -1,    -1,   103,   104,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,    70,
      71,    -1,    -1,    12,    -1,    14,    77,    78,   126,    -1,
      81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      29,    -1,    31,    32,    -1,    -1,    -1,    -1,    37,    -1,
      -1,    -1,   103,   104,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   126,    65,    66,    67,    68,
      69,    70,    71,    -1,    73,    74,    75,    76,    77,    78,
      -1,    -1,    81,    -1,    83
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned short int yystos[] =
{
       0,     3,    46,    47,    48,    49,    61,    63,   104,   108,
     126,   129,   136,   137,   138,   178,   179,   207,   208,   209,
     210,   213,   214,   216,   217,   242,   250,   450,     1,    16,
      44,    45,   211,   212,   220,   221,     1,   102,   246,     1,
     218,     1,    12,    32,   233,   234,   236,   454,   455,     1,
     226,   227,   228,   454,     1,   100,   245,     1,   245,     1,
     236,     1,   229,   454,     1,   215,     1,   451,   452,   454,
       0,   109,   110,   112,   139,   140,   141,   143,   144,   154,
     155,   309,   450,   154,     6,    50,    51,    57,    60,   180,
     269,   276,   277,   331,   336,   339,   340,   454,    10,     1,
       4,     5,    41,    42,    43,   246,   211,   211,    10,    18,
     236,   241,    10,   236,    10,   455,    10,    98,    18,    22,
     219,   240,    10,    10,    98,    98,   219,    62,   251,   454,
      64,   246,    10,    10,    10,    10,    98,    10,   236,   128,
      98,   128,    22,    10,   453,   454,     1,    23,    52,    54,
      56,   157,   158,     1,    16,    29,   220,   222,   270,   271,
     272,   273,   274,   454,    16,    37,   220,   222,   337,   338,
     428,   445,   453,   454,     1,   181,     1,   354,   450,   341,
       1,    16,   220,   278,   281,   288,   289,   332,   333,   334,
     454,    17,    98,    98,    17,    17,    17,   241,   259,   246,
     246,     7,     8,    13,    14,    16,    20,    21,    25,    34,
      35,    37,   132,   133,   426,   427,   436,   437,   438,   441,
     443,   447,   448,   453,    10,   236,    10,   234,   433,   438,
     438,   240,   454,   454,    10,    16,    47,    48,   104,   126,
     241,   244,   454,    10,   452,   438,    10,    11,    10,     7,
     142,   453,   310,   454,   156,   454,    10,    16,    29,   162,
     168,   170,    10,   275,   445,    16,   225,   438,   439,    16,
     222,   271,   274,   271,    10,    98,    10,    98,    16,   241,
     428,   429,   430,   454,   222,   337,   337,    10,    98,    22,
      18,   432,    10,   232,   238,   453,    84,    14,    29,    31,
      50,    65,    66,    67,    68,    69,    70,    71,    73,    74,
      75,    76,    77,    78,    81,    83,   342,   343,   344,   350,
     351,   358,   359,   361,   362,   363,   366,   367,   368,   370,
     374,   375,   445,   453,   354,    84,   275,    16,   222,   224,
     332,    29,   282,    98,   280,    16,    10,    98,   289,   335,
     259,     5,     4,   222,   226,   230,   231,   237,   454,   259,
     259,   439,    20,    21,   435,   438,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    34,    35,    99,   130,   131,
     132,   133,   444,   447,    15,   129,   436,   447,   449,     8,
      16,    18,   431,   432,   449,    10,    15,   219,   253,   254,
     256,   257,   261,   265,   353,   354,   450,   255,   256,   450,
     243,   454,   127,   145,   454,    24,    16,     1,   159,   160,
     161,   176,   177,   178,   450,     1,    17,   169,   255,     1,
      16,    10,    16,   168,   170,    10,    10,    17,    98,   223,
     225,   439,    15,   275,   271,    10,    16,    10,    16,   273,
     274,   272,   275,    36,    98,    18,   432,   337,    10,    10,
     338,   438,   434,   438,    18,    10,    98,    22,    24,     8,
      12,    16,    16,    26,   454,   349,   445,    16,    16,     1,
      16,     1,    16,   354,    16,    16,    16,   338,   445,   445,
     454,    16,     1,    15,    84,   352,     1,    15,    72,   353,
       1,    10,     1,    10,    10,    10,   354,   355,    22,    23,
      10,    16,    98,   332,    10,    16,   281,   288,    10,    17,
     290,   291,   292,   293,   294,   450,   333,    16,    17,    17,
     230,   231,    10,    98,    10,    22,   222,   230,   231,   222,
     230,   231,    17,    36,    98,    37,   426,    22,    22,    23,
      22,    24,    26,    22,   438,   437,   449,   438,   440,     1,
     451,   436,   435,   438,   434,    16,   433,   254,   353,    10,
      98,    47,    48,    98,   104,   126,   246,   264,    62,   354,
      38,    39,    40,    46,   101,   103,   182,   188,   207,   209,
     213,   214,   217,   266,    17,    98,    10,    16,     1,   148,
     453,    82,   111,   117,   118,   146,   147,   149,   150,    10,
     311,   312,   316,   450,   454,    10,    53,   159,   177,     1,
      10,    39,    40,    85,    87,   101,   106,   182,   188,   194,
     195,   198,   201,   295,   377,    17,    10,     8,    11,    37,
     171,   172,   173,   175,   454,    17,    17,   163,   161,    10,
      10,     1,   161,     1,   161,   435,    17,    98,   438,    10,
     275,   275,    16,    17,    98,   430,   434,   438,   434,   438,
      10,    19,    13,    14,    15,    19,   438,   238,   438,   454,
     439,    26,    95,    96,   364,   365,   438,    22,   438,   438,
      80,   438,    80,   438,   438,   349,   438,    10,   438,    84,
     454,   353,    72,     1,   454,    72,    70,   359,   438,    22,
       1,    98,   376,   438,   435,    10,     1,    11,   283,   284,
     285,   286,   287,   438,   279,    17,    98,    98,   287,   438,
     275,    10,    10,   237,   454,   438,   230,    10,    10,   231,
      10,    10,   438,    36,    22,    23,    24,    22,    15,   437,
      19,   128,   128,    17,    19,   435,    19,    62,   246,   261,
     264,   454,    46,   258,   454,     1,   102,   189,   241,   264,
     446,     3,   260,   260,   241,   267,   268,   446,   454,   260,
       1,   185,   241,   264,   446,    10,   256,   101,   247,   248,
     262,   263,   265,   450,   249,   263,    10,    10,   453,   116,
     151,   453,   453,   111,   147,   115,   151,   152,   151,   152,
      17,    98,    17,    98,    39,    10,     3,    46,   201,   203,
     205,   206,   241,   446,   206,   246,     1,    16,    65,    86,
      88,    89,    90,    91,    92,    93,    94,   105,   113,   114,
     119,   120,   121,   122,   123,   124,   125,   194,   378,   379,
     380,   381,   382,   383,   384,   392,   393,   394,   398,   400,
     401,   402,   403,   404,   405,   406,   407,   408,   409,   410,
     411,   412,     1,   235,   239,   241,   454,   206,   246,     1,
     296,    98,    98,    98,   161,   173,   174,   175,    17,    98,
      18,    38,   164,   159,   161,   161,   159,   159,   159,   159,
      17,   225,    15,   275,   435,    19,    19,    15,    15,   440,
      19,    10,    17,    17,   438,   438,     6,    17,    98,   438,
      17,    17,    17,    17,    17,   360,    10,    17,    17,    84,
     252,   265,   353,   450,    84,    72,   252,   353,    16,   438,
     359,   438,    17,    17,    98,    17,    17,   454,    17,    98,
      98,    10,   292,   450,   294,   450,    98,    10,    10,   437,
      17,   258,   246,   454,   259,    10,   232,   192,   190,   193,
     241,   267,    10,    98,   241,   219,    10,   232,   183,   184,
     186,   241,   252,   353,     1,    46,   246,   264,   248,   356,
     450,    10,    98,    98,    17,    98,   148,    10,   453,    10,
      10,    10,    10,    10,   454,    10,   313,   317,   450,   454,
      46,   454,   338,   454,    47,   102,   104,   202,   204,   241,
     246,   259,    86,    95,    96,   385,   388,   397,   454,    16,
      16,     1,    16,    16,    16,    16,    16,    16,    16,   385,
     386,   388,     1,   386,   386,     1,   386,    16,    16,    16,
      16,    16,   383,    86,   379,    10,    22,    10,    22,    22,
      10,    10,    10,    98,   235,    22,   246,   259,   107,    65,
      66,    71,    81,   178,   297,   300,   301,   302,   305,   308,
     206,   246,   206,   246,    39,   454,   159,    16,    36,    98,
     172,   434,   438,   165,    17,    98,   159,   159,   439,    17,
     438,   442,   442,   364,   364,     1,   355,     1,    82,   371,
     372,   435,   371,   371,   354,    17,   438,   355,   354,   265,
     353,    84,   353,    72,   438,   438,    10,    10,   438,    10,
      16,   285,   287,   435,   259,   258,   454,    10,   232,   232,
     232,   191,    10,   268,   267,    10,   232,   232,   232,   187,
     353,    62,    10,   246,   259,   454,    64,    65,    69,    70,
      71,    78,    81,   345,   347,   357,   361,   369,   370,   373,
     375,   445,   263,   101,   454,    10,   450,    15,   153,   314,
     315,   316,   317,   318,   450,   314,    98,    98,   101,   454,
     454,   259,   196,    26,    98,   387,   399,   447,    22,   385,
     388,    18,   438,     1,    95,    96,    97,   388,   416,   418,
     420,   421,   424,    10,     1,   416,   418,   419,   419,   416,
     416,   418,   418,    10,    10,    10,    10,    10,    10,   416,
     416,   416,   418,   385,   388,    16,   389,   390,   391,   439,
     389,   389,   239,    10,   439,   259,   199,    16,    16,    16,
       1,    15,   297,   107,   300,   246,   259,   246,   259,   205,
     338,   454,    17,   173,   175,    19,    19,   238,    38,   167,
      79,    79,    80,    15,   355,    80,   372,    15,    80,    80,
     362,    10,    84,    72,    17,   438,    17,   454,   259,    10,
      10,    10,   232,    10,    10,    10,    10,   232,    62,   259,
     454,    16,   356,   450,    16,    16,    16,    15,    84,   252,
     353,    10,    22,    46,   246,   264,   247,   263,   110,    57,
      58,   315,   319,   320,   323,    10,    10,    98,    10,    10,
      98,    46,   319,   317,   454,   454,   454,    22,   197,   454,
      24,   388,   386,    22,    26,    24,    26,    22,   434,   438,
      17,    17,    19,    18,    98,   424,   134,    98,    98,    98,
      98,    98,    98,    98,    98,    98,    98,    98,    26,    22,
      16,   390,   391,   439,   200,   454,   438,   438,   307,   454,
      84,   454,    84,   259,   454,   259,   454,   454,    17,   166,
     238,   355,   355,   355,   355,   349,    17,   454,    10,    10,
     454,   438,   438,   349,   438,   454,   353,    84,   438,   246,
     259,   454,   356,     1,   454,     1,     8,    12,    16,    26,
      99,   321,   322,   325,   326,   330,    55,    58,   454,   454,
      55,   438,   454,   386,    17,    24,    24,    16,   388,   395,
      24,    24,    19,    19,   383,   392,     8,    12,   422,   423,
     417,   418,   134,   425,   439,   417,   415,   438,   415,   417,
     417,   418,   418,   417,   417,   417,   418,    24,    24,   391,
      17,    98,   454,    17,    17,    10,    22,     1,   297,   454,
     454,   238,    17,    17,    17,    10,    17,   252,   348,   356,
      84,   259,   454,    64,    10,    22,    59,   330,    59,   322,
      15,   326,   330,    16,   321,    17,   447,   388,    17,   447,
     386,   388,   395,     8,    12,     8,    19,    98,    98,   425,
      98,    17,    98,    17,    98,    98,    98,    98,    98,    98,
      98,    98,    98,   386,   388,   391,    10,   298,   299,    82,
     303,   304,   435,   438,   438,    84,    84,   354,   346,   356,
     450,   356,   438,   356,   353,    84,   356,   454,     8,   324,
      17,   330,   327,   329,   330,   330,    59,    15,   447,    15,
     447,   422,   415,   415,    10,   438,    10,   413,   414,   438,
     415,   415,   415,   439,   415,   415,   415,   415,    17,    98,
      79,   300,    15,   298,    80,    98,    15,    10,    79,    10,
      10,    84,    10,    17,    15,    10,    17,   396,   438,    15,
     396,    15,    17,    98,    17,    98,    98,    17,    98,    17,
      98,    17,    98,    98,    98,    17,    98,    17,    98,    17,
      98,    98,   391,   298,   298,   304,   298,   307,   346,   349,
      14,   328,   329,   330,    17,   396,    17,   396,    10,   413,
      10,   413,   413,    10,   414,    10,   413,    10,   413,   415,
     439,    10,   413,    10,   413,    10,   413,   415,    17,    98,
      17,    17,    10,    17,    17,    17,    17,    17,    17,    17,
      17,    98,    17,    98,    17,    17,    17,    17,    98,   391,
     306,   356,    17,    10,    10,    10,    10,    10,    10,   413,
      10,   413,    10,    10,    10,    10,   413,    98,   308,    17,
      17,    17,   391,    10,    10,    10,    98,   391,    17,    98,
     391,    98,   391,    98,   391,    98,   391,    98,   391,    98,
     391,    17
};


/* Prevent warning if -Wmissing-prototypes.  */
int yyparse (void);

/* Error token number */
#define YYTERROR 1

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */


#define YYRHSLOC(Rhs, K) ((Rhs)[K].yystate.yyloc)
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (N)								\
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (0)

/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# define YY_LOCATION_PRINT(File, Loc)			\
    fprintf (File, "%d.%d-%d.%d",			\
             (Loc).first_line, (Loc).first_column,	\
             (Loc).last_line,  (Loc).last_column)
#endif


#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */
#define YYLEX yylex ()

YYSTYPE yylval;

YYLTYPE yylloc;

int yynerrs;
int yychar;

static const int YYEOF = 0;
static const int YYEMPTY = -2;

typedef enum { yyok, yyaccept, yyabort, yyerr } YYRESULTTAG;

#define YYCHK(YYE)							     \
   do { YYRESULTTAG yyflag = YYE; if (yyflag != yyok) return yyflag; }	     \
   while (0)

#if YYDEBUG

#if ! defined (YYFPRINTF)
#  define YYFPRINTF fprintf
#endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");

# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr,					\
                  Type, Value, Location);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;

#else /* !YYDEBUG */

# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)

#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYMAXDEPTH * sizeof (GLRStackItem)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

/* Minimum number of free items on the stack allowed after an
   allocation.  This is to allow allocation and initialization
   to be completed by functions that call yyexpandGLRStack before the
   stack is expanded, thus insuring that all necessary pointers get
   properly redirected to new data. */
#define YYHEADROOM 2

#ifndef YYSTACKEXPANDABLE
# if (! defined (__cplusplus) \
      || (defined (YYLTYPE_IS_TRIVIAL) && YYLTYPE_IS_TRIVIAL \
	  && defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL))
#  define YYSTACKEXPANDABLE 1
# else
#  define YYSTACKEXPANDABLE 0
# endif
#endif

#if YYERROR_VERBOSE

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static size_t
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      size_t yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return strlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

#endif /* !YYERROR_VERBOSE */

/** State numbers, as in LALR(1) machine */
typedef int yyStateNum;

/** Rule numbers, as in LALR(1) machine */
typedef int yyRuleNum;

/** Grammar symbol */
typedef short int yySymbol;

/** Item references, as in LALR(1) machine */
typedef short int yyItemNum;

typedef struct yyGLRState yyGLRState;
typedef struct yySemanticOption yySemanticOption;
typedef union yyGLRStackItem yyGLRStackItem;
typedef struct yyGLRStack yyGLRStack;
typedef struct yyGLRStateSet yyGLRStateSet;

struct yyGLRState {
  /** Type tag: always true. */
  yybool yyisState;
  /** Type tag for yysemantics. If true, yysval applies, otherwise
   *  yyfirstVal applies. */
  yybool yyresolved;
  /** Number of corresponding LALR(1) machine state. */
  yyStateNum yylrState;
  /** Preceding state in this stack */
  yyGLRState* yypred;
  /** Source position of the first token produced by my symbol */
  size_t yyposn;
  union {
    /** First in a chain of alternative reductions producing the
     *  non-terminal corresponding to this state, threaded through
     *  yynext. */
    yySemanticOption* yyfirstVal;
    /** Semantic value for this state. */
    YYSTYPE yysval;
  } yysemantics;
  /** Source location for this state. */
  YYLTYPE yyloc;
};

struct yyGLRStateSet {
  yyGLRState** yystates;
  size_t yysize, yycapacity;
};

struct yySemanticOption {
  /** Type tag: always false. */
  yybool yyisState;
  /** Rule number for this reduction */
  yyRuleNum yyrule;
  /** The last RHS state in the list of states to be reduced. */
  yyGLRState* yystate;
  /** Next sibling in chain of options. To facilitate merging,
   *  options are chained in decreasing order by address. */
  yySemanticOption* yynext;
};

/** Type of the items in the GLR stack. The yyisState field
 *  indicates which item of the union is valid. */
union yyGLRStackItem {
  yyGLRState yystate;
  yySemanticOption yyoption;
};

struct yyGLRStack {
  int yyerrState;
  /* To compute the location of the error token.  */
  yyGLRStackItem yyerror_range[3];

  yySymbol* yytokenp;
  YYJMP_BUF yyexception_buffer;
  yyGLRStackItem* yyitems;
  yyGLRStackItem* yynextFree;
  size_t yyspaceLeft;
  yyGLRState* yysplitPoint;
  yyGLRState* yylastDeleted;
  yyGLRStateSet yytops;
};

static void yyexpandGLRStack (yyGLRStack* yystack);

static void yyFail (yyGLRStack* yystack, const char* yymsg)
  __attribute__ ((__noreturn__));
static void
yyFail (yyGLRStack* yystack, const char* yymsg)
{
  if (yymsg != NULL)
    yyerror (yymsg);
  YYLONGJMP (yystack->yyexception_buffer, 1);
}

static void yyMemoryExhausted (yyGLRStack* yystack)
  __attribute__ ((__noreturn__));
static void
yyMemoryExhausted (yyGLRStack* yystack)
{
  YYLONGJMP (yystack->yyexception_buffer, 2);
}

#if YYDEBUG || YYERROR_VERBOSE
/** A printable representation of TOKEN.  */
static inline const char*
yytokenName (yySymbol yytoken)
{
  if (yytoken == YYEMPTY)
    return "";

  return yytname[yytoken];
}
#endif

/** Fill in YYVSP[YYLOW1 .. YYLOW0-1] from the chain of states starting
 *  at YYVSP[YYLOW0].yystate.yypred.  Leaves YYVSP[YYLOW1].yystate.yypred
 *  containing the pointer to the next state in the chain. Assumes
 *  YYLOW1 < YYLOW0.  */
static void yyfillin (yyGLRStackItem *, int, int) __attribute__ ((__unused__));
static void
yyfillin (yyGLRStackItem *yyvsp, int yylow0, int yylow1)
{
  yyGLRState* s;
  int i;
  s = yyvsp[yylow0].yystate.yypred;
  for (i = yylow0-1; i >= yylow1; i -= 1)
    {
      YYASSERT (s->yyresolved);
      yyvsp[i].yystate.yyresolved = yytrue;
      yyvsp[i].yystate.yysemantics.yysval = s->yysemantics.yysval;
      yyvsp[i].yystate.yyloc = s->yyloc;
      s = yyvsp[i].yystate.yypred = s->yypred;
    }
}

/* Do nothing if YYNORMAL or if *YYLOW <= YYLOW1.  Otherwise, fill in
   YYVSP[YYLOW1 .. *YYLOW-1] as in yyfillin and set *YYLOW = YYLOW1.
   For convenience, always return YYLOW1.  */
static inline int yyfill (yyGLRStackItem *, int *, int, yybool)
     __attribute__ ((__unused__));
static inline int
yyfill (yyGLRStackItem *yyvsp, int *yylow, int yylow1, yybool yynormal)
{
  if (!yynormal && yylow1 < *yylow)
    {
      yyfillin (yyvsp, *yylow, yylow1);
      *yylow = yylow1;
    }
  return yylow1;
}

/** Perform user action for rule number YYN, with RHS length YYRHSLEN,
 *  and top stack item YYVSP.  YYLVALP points to place to put semantic
 *  value ($$), and yylocp points to place for location information
 *  (@$). Returns yyok for normal return, yyaccept for YYACCEPT,
 *  yyerr for YYERROR, yyabort for YYABORT. */
static YYRESULTTAG
yyuserAction (yyRuleNum yyn, int yyrhslen, yyGLRStackItem* yyvsp,
	      YYSTYPE* yyvalp,
	      YYLTYPE* YYOPTIONAL_LOC (yylocp),
	      yyGLRStack* yystack
              )
{
  yybool yynormal __attribute__ ((__unused__)) =
    (yystack->yysplitPoint == NULL);
  int yylow;

# undef yyerrok
# define yyerrok (yystack->yyerrState = 0)
# undef YYACCEPT
# define YYACCEPT return yyaccept
# undef YYABORT
# define YYABORT return yyabort
# undef YYERROR
# define YYERROR return yyerrok, yyerr
# undef YYRECOVERING
# define YYRECOVERING (yystack->yyerrState != 0)
# undef yyclearin
# define yyclearin (yychar = *(yystack->yytokenp) = YYEMPTY)
# undef YYFILL
# define YYFILL(N) yyfill (yyvsp, &yylow, N, yynormal)
# undef YYBACKUP
# define YYBACKUP(Token, Value)						     \
  return yyerror (YY_("syntax error: cannot back up")),     \
	 yyerrok, yyerr

  yylow = 1;
  if (yyrhslen == 0)
    *yyvalp = yyval_default;
  else
    *yyvalp = yyvsp[YYFILL (1-yyrhslen)].yystate.yysemantics.yysval;
  YYLLOC_DEFAULT (*yylocp, yyvsp - yyrhslen, yyrhslen);
  yystack->yyerror_range[1].yystate.yyloc = *yylocp;

  switch (yyn)
    {
        case 3:
#line 127 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {identVerilog.resize(0);;}
    break;

  case 5:
#line 128 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {identVerilog.resize(0);;}
    break;

  case 36:
#line 209 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 52:
#line 236 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {
                                   // yydebug=1; //sets parser in debug mode
                                    if(!parseCode) { 
							              
											 lastModule=VerilogDocGen::makeNewEntry("",Entry::CLASS_SEC,VerilogDocGen::MODULE);
                                            currentVerilog=lastModule;
                                             currentVerilog->protection=Public;
					                         parseModule();
							                 CurrState=VerilogDocGen::STATE_MODULE;
				                             
										    }
                                            else {
											      parseModule();
                                         		  }
                               currVerilogType=0;						       
							   vbufreset();
							 ;}
    break;

  case 53:
#line 255 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {
            if(!parseCode){ 
			        int ll=getVerilogLine();
	                currentVerilog->endBodyLine=ll;
			       } 	 
              vbufreset(); 
		   ;}
    break;

  case 54:
#line 261 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currentVerilog=0;vbufreset();;}
    break;

  case 57:
#line 271 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=VerilogDocGen::PORT;;}
    break;

  case 58:
#line 271 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 60:
#line 275 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 61:
#line 275 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 62:
#line 276 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 63:
#line 276 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 64:
#line 277 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 65:
#line 277 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 66:
#line 283 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=VerilogDocGen::PORT;;}
    break;

  case 67:
#line 283 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 68:
#line 284 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 69:
#line 288 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 70:
#line 292 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 71:
#line 293 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 83:
#line 315 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;vbufreset();;}
    break;

  case 84:
#line 316 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;vbufreset();;}
    break;

  case 85:
#line 317 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;vbufreset();;}
    break;

  case 86:
#line 318 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 89:
#line 327 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 90:
#line 328 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 93:
#line 331 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 95:
#line 336 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 96:
#line 337 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 97:
#line 338 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 98:
#line 339 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 99:
#line 340 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 100:
#line 341 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 101:
#line 342 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 110:
#line 353 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 111:
#line 354 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 112:
#line 355 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 113:
#line 359 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { if(parseCode) currVerilogType=VerilogDocGen::DEFPARAM;;}
    break;

  case 114:
#line 359 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); if(parseCode) currVerilogType=0; ;}
    break;

  case 115:
#line 360 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); if(parseCode) currVerilogType=0;;}
    break;

  case 116:
#line 368 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 117:
#line 368 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 118:
#line 369 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 119:
#line 369 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 120:
#line 370 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 121:
#line 370 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 122:
#line 371 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 123:
#line 371 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 124:
#line 372 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 125:
#line 372 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 127:
#line 376 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 128:
#line 376 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 129:
#line 377 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 130:
#line 377 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 131:
#line 378 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 132:
#line 378 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 133:
#line 379 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 134:
#line 379 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 135:
#line 380 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 136:
#line 380 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 137:
#line 381 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 138:
#line 384 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 139:
#line 385 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 141:
#line 393 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INOUT; ;}
    break;

  case 142:
#line 393 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 143:
#line 394 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INOUT; ;}
    break;

  case 144:
#line 394 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 145:
#line 395 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 146:
#line 396 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 147:
#line 399 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT; ;}
    break;

  case 148:
#line 399 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 149:
#line 400 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT; ;}
    break;

  case 150:
#line 400 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 151:
#line 401 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 152:
#line 402 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 153:
#line 407 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT; ;}
    break;

  case 154:
#line 407 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 155:
#line 408 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT; ;}
    break;

  case 156:
#line 408 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 159:
#line 411 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 160:
#line 412 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 161:
#line 413 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 172:
#line 441 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 173:
#line 442 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 176:
#line 449 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 178:
#line 454 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 179:
#line 455 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 180:
#line 456 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 181:
#line 457 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 182:
#line 458 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 183:
#line 459 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 184:
#line 460 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 185:
#line 461 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 186:
#line 462 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 187:
#line 463 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 188:
#line 464 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 193:
#line 477 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currVerilogType=0;;}
    break;

  case 194:
#line 478 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 195:
#line 480 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::TIME; ;}
    break;

  case 196:
#line 480 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currVerilogType=0;;}
    break;

  case 197:
#line 481 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 198:
#line 484 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 199:
#line 485 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 200:
#line 486 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 201:
#line 489 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::TIME; ;}
    break;

  case 202:
#line 489 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currVerilogType=0;;}
    break;

  case 203:
#line 490 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 212:
#line 519 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 220:
#line 541 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 221:
#line 542 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 237:
#line 581 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {
                                                                   							parseReg(currentVerilog);}
																							vbufreset();;}
    break;

  case 238:
#line 584 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) parseReg(currentVerilog);vbufreset();;}
    break;

  case 239:
#line 592 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 240:
#line 594 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {
                          			 if(currVerilogType==VerilogDocGen::PARAMETER && !parseCode)
									 parseParam(currentVerilog);
									 vbufreset();
	                   ;}
    break;

  case 244:
#line 623 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog)
						                                {
														  currentFunctionVerilog->endBodyLine=getVerilogPrevLine();
														} vbufreset(); ;}
    break;

  case 245:
#line 631 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog){currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset(); ;}
    break;

  case 246:
#line 632 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 247:
#line 636 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {  if(!parseCode){
                             //    printf("\n  funcname [%s] --\n",getVerilogString());
                                 currentFunctionVerilog=VerilogDocGen::makeNewEntry("",Entry::FUNCTION_SEC,VerilogDocGen::FUNCTION);
								 currentFunctionVerilog->fileName=getVerilogParsingFile();
								 parseFunction(currentFunctionVerilog);
								 CurrState=VerilogDocGen::STATE_FUNCTION;
								 }
								 vbufreset();
							   ;}
    break;

  case 261:
#line 672 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;;}
    break;

  case 264:
#line 686 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog) { currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset();;}
    break;

  case 266:
#line 690 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog) { currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset();;}
    break;

  case 267:
#line 692 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog) { currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset();;}
    break;

  case 268:
#line 693 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 269:
#line 696 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {  if(!parseCode){
                             //    printf("\n  funcname [%s] --\n",getVerilogString());
                                 currentFunctionVerilog=VerilogDocGen::makeNewEntry("",Entry::FUNCTION_SEC,VerilogDocGen::TASK);
								 currentFunctionVerilog->fileName=getVerilogParsingFile();
								 parseFunction(currentFunctionVerilog);
								 CurrState=VerilogDocGen::STATE_FUNCTION;
								 }
								 vbufreset();
							   ;}
    break;

  case 279:
#line 732 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {
                             if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                     ;}
    break;

  case 280:
#line 737 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                      ;}
    break;

  case 281:
#line 741 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                       ;}
    break;

  case 282:
#line 746 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {
                             if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                   ;}
    break;

  case 283:
#line 751 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {
                             if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                    ;}
    break;

  case 290:
#line 769 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode )currVerilogType=VerilogDocGen::INOUT;;}
    break;

  case 291:
#line 770 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode)currVerilogType=VerilogDocGen::OUTPUT;;}
    break;

  case 292:
#line 771 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode)currVerilogType=VerilogDocGen::INPUT;;}
    break;

  case 293:
#line 772 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode){parsePortDir(currentVerilog,3);vbufreset();};}
    break;

  case 296:
#line 780 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 297:
#line 781 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 298:
#line 782 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 299:
#line 783 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 300:
#line 784 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 301:
#line 785 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 302:
#line 786 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 303:
#line 787 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 328:
#line 834 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 341:
#line 876 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { 
                    						;}
    break;

  case 342:
#line 877 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 344:
#line 878 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 352:
#line 892 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 355:
#line 899 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { ;}
    break;

  case 357:
#line 904 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 358:
#line 905 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 359:
#line 909 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); currVerilogType=0;;}
    break;

  case 360:
#line 910 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); currVerilogType=0;;}
    break;

  case 361:
#line 913 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { 
                            const char *name=(((yyGLRStackItem const *)yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.cstr);
                            QCString first(name);
							QCString sec(getVerilogString());
						     QCString ll=getLastLetter();
							
							 parseModuleInst(first,sec);
							     if(parseCode){
							  currVerilogType=VerilogDocGen::COMPONENT;
							  vbufreset();
							  }
							  ;}
    break;

  case 370:
#line 955 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {CurrState=VerilogDocGen::STATE_GENERATE;;}
    break;

  case 371:
#line 955 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {CurrState=0;;}
    break;

  case 375:
#line 964 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 378:
#line 969 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 379:
#line 970 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 380:
#line 971 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 381:
#line 972 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 382:
#line 973 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 391:
#line 993 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 396:
#line 1001 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 397:
#line 1002 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 398:
#line 1011 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currentVerilog=0;;}
    break;

  case 400:
#line 1017 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode) { 
							               //  printf("\n  name_of_mod [%s] [%d]--\n",getVerilogString(),getVerilogLine());
                                            lastModule=VerilogDocGen::makeNewEntry("",Entry::CLASS_SEC,VerilogDocGen::MODULE);
                                             currentVerilog=lastModule;
                                             currentVerilog->protection=Private;
					                        //  currentVerilog->stat=TRUE;
					                         parseModule();
							                 CurrState=VerilogDocGen::STATE_MODULE;

										    }
                                            else {
											      parseModule();
                                              //    currVerilogType=VerilogDocGen::MODULE;
												  }
						        vbufreset();
							 ;}
    break;

  case 401:
#line 1039 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 402:
#line 1040 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 413:
#line 1061 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 414:
#line 1062 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 415:
#line 1063 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 416:
#line 1064 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 417:
#line 1067 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 418:
#line 1068 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 419:
#line 1070 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) parseReg(currentVerilog);vbufreset();;}
    break;

  case 420:
#line 1071 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) parseReg(currentVerilog);vbufreset();;}
    break;

  case 422:
#line 1081 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 423:
#line 1082 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 424:
#line 1083 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 429:
#line 1096 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 430:
#line 1097 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 431:
#line 1100 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr);writeDigit(); ;}
    break;

  case 443:
#line 1125 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr);writeDigit(); ;}
    break;

  case 452:
#line 1145 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {assert(0);;}
    break;

  case 463:
#line 1170 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 464:
#line 1171 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();  ;}
    break;

  case 465:
#line 1174 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {
                               currVerilogType=VerilogDocGen::ALWAYS;
                     		   ;}
    break;

  case 466:
#line 1176 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {
                                            if(!parseCode && currentFunctionVerilog)
											 {
											  currentFunctionVerilog->endBodyLine=getVerilogEndLine();
											  if( currentFunctionVerilog->endBodyLine<currentFunctionVerilog->startLine || c_lloc.first_line>currentFunctionVerilog->endBodyLine ) // awlays without end
											   currentFunctionVerilog->endBodyLine=c_lloc.first_line;
											  currVerilogType=0;
											  } vbufreset();;}
    break;

  case 467:
#line 1184 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();currVerilogType=0;;}
    break;

  case 471:
#line 1191 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 475:
#line 1197 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 497:
#line 1249 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currVerilogType==VerilogDocGen::ALWAYS)parseAlways(true);;}
    break;

  case 516:
#line 1277 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 531:
#line 1304 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 534:
#line 1309 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 535:
#line 1309 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 537:
#line 1315 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 538:
#line 1316 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 539:
#line 1317 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 540:
#line 1318 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 556:
#line 1357 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 558:
#line 1359 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 560:
#line 1361 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 582:
#line 1413 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 583:
#line 1414 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 584:
#line 1418 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 585:
#line 1419 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 586:
#line 1423 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 587:
#line 1424 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 588:
#line 1425 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 589:
#line 1426 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 590:
#line 1427 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 779:
#line 1836 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr);writeDigit(); ;}
    break;

  case 780:
#line 1837 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {if(parseCode) {writePrevVerilogWords(identVerilog);writeVerilogFont("vhdllogic",identVerilog.data());identVerilog.resize(0);};}
    break;

  case 791:
#line 1866 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {
										 ;}
    break;

  case 792:
#line 1870 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    { parseString(); ;}
    break;

  case 793:
#line 1873 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {
                    	if(parseCode) 
						      identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr); 
							 ;}
    break;

  case 794:
#line 1877 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;


      default: break;
    }

  return yyok;
# undef yyerrok
# undef YYABORT
# undef YYACCEPT
# undef YYERROR
# undef YYBACKUP
# undef yyclearin
# undef YYRECOVERING
/* Line 872 of glr.c.  */
#line 5307 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.cpp"
}


static void
yyuserMerge (int yyn, YYSTYPE* yy0, YYSTYPE* yy1)
{
  /* `Use' the arguments.  */
  (void) yy0;
  (void) yy1;

  switch (yyn)
    {
      
      default: break;
    }
}

			      /* Bison grammar-table manipulation.  */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
        break;
    }
}

/** Number of symbols composing the right hand side of rule #RULE.  */
static inline int
yyrhsLength (yyRuleNum yyrule)
{
  return yyr2[yyrule];
}

static void
yydestroyGLRState (char const *yymsg, yyGLRState *yys)
{
  if (yys->yyresolved)
    yydestruct (yymsg, yystos[yys->yylrState],
		&yys->yysemantics.yysval, &yys->yyloc);
  else
    {
#if YYDEBUG
      if (yydebug)
	{
	  YYFPRINTF (stderr, "%s unresolved ", yymsg);
	  yysymprint (stderr, yystos[yys->yylrState],
		      &yys->yysemantics.yysval, &yys->yyloc);
	  YYFPRINTF (stderr, "\n");
	}
#endif

      if (yys->yysemantics.yyfirstVal)
        {
          yySemanticOption *yyoption = yys->yysemantics.yyfirstVal;
          yyGLRState *yyrh;
          int yyn;
          for (yyrh = yyoption->yystate, yyn = yyrhsLength (yyoption->yyrule);
               yyn > 0;
               yyrh = yyrh->yypred, yyn -= 1)
            yydestroyGLRState (yymsg, yyrh);
        }
    }
}

/** Left-hand-side symbol for rule #RULE. */
static inline yySymbol
yylhsNonterm (yyRuleNum yyrule)
{
  return yyr1[yyrule];
}

#define yyis_pact_ninf(yystate) \
  ((yystate) == YYPACT_NINF)

/** True iff LR state STATE has only a default reduction (regardless
 *  of token). */
static inline yybool
yyisDefaultedState (yyStateNum yystate)
{
  return yyis_pact_ninf (yypact[yystate]);
}

/** The default reduction for STATE, assuming it has one. */
static inline yyRuleNum
yydefaultAction (yyStateNum yystate)
{
  return yydefact[yystate];
}

#define yyis_table_ninf(yytable_value) \
  0

/** Set *YYACTION to the action to take in YYSTATE on seeing YYTOKEN.
 *  Result R means
 *    R < 0:  Reduce on rule -R.
 *    R = 0:  Error.
 *    R > 0:  Shift to state R.
 *  Set *CONFLICTS to a pointer into yyconfl to 0-terminated list of
 *  conflicting reductions.
 */
static inline void
yygetLRActions (yyStateNum yystate, int yytoken,
	        int* yyaction, const short int** yyconflicts)
{
  int yyindex = yypact[yystate] + yytoken;
  if (yyindex < 0 || YYLAST < yyindex || yycheck[yyindex] != yytoken)
    {
      *yyaction = -yydefact[yystate];
      *yyconflicts = yyconfl;
    }
  else if (! yyis_table_ninf (yytable[yyindex]))
    {
      *yyaction = yytable[yyindex];
      *yyconflicts = yyconfl + yyconflp[yyindex];
    }
  else
    {
      *yyaction = 0;
      *yyconflicts = yyconfl + yyconflp[yyindex];
    }
}

static inline yyStateNum
yyLRgotoState (yyStateNum yystate, yySymbol yylhs)
{
  int yyr;
  yyr = yypgoto[yylhs - YYNTOKENS] + yystate;
  if (0 <= yyr && yyr <= YYLAST && yycheck[yyr] == yystate)
    return yytable[yyr];
  else
    return yydefgoto[yylhs - YYNTOKENS];
}

static inline yybool
yyisShiftAction (int yyaction)
{
  return 0 < yyaction;
}

static inline yybool
yyisErrorAction (int yyaction)
{
  return yyaction == 0;
}

				/* GLRStates */

static void
yyaddDeferredAction (yyGLRStack* yystack, yyGLRState* yystate,
		     yyGLRState* rhs, yyRuleNum yyrule)
{
  yySemanticOption* yynewItem;
  yynewItem = &yystack->yynextFree->yyoption;
  yystack->yyspaceLeft -= 1;
  yystack->yynextFree += 1;
  yynewItem->yyisState = yyfalse;
  yynewItem->yystate = rhs;
  yynewItem->yyrule = yyrule;
  yynewItem->yynext = yystate->yysemantics.yyfirstVal;
  yystate->yysemantics.yyfirstVal = yynewItem;
  if (yystack->yyspaceLeft < YYHEADROOM)
    yyexpandGLRStack (yystack);
}

				/* GLRStacks */

/** Initialize SET to a singleton set containing an empty stack. */
static yybool
yyinitStateSet (yyGLRStateSet* yyset)
{
  yyset->yysize = 1;
  yyset->yycapacity = 16;
  yyset->yystates = (yyGLRState**) YYMALLOC (16 * sizeof yyset->yystates[0]);
  if (! yyset->yystates)
    return yyfalse;
  yyset->yystates[0] = NULL;
  return yytrue;
}

static void yyfreeStateSet (yyGLRStateSet* yyset)
{
  YYFREE (yyset->yystates);
}

/** Initialize STACK to a single empty stack, with total maximum
 *  capacity for all stacks of SIZE. */
static yybool
yyinitGLRStack (yyGLRStack* yystack, size_t yysize)
{
  yystack->yyerrState = 0;
  yynerrs = 0;
  yystack->yyspaceLeft = yysize;
  yystack->yyitems =
    (yyGLRStackItem*) YYMALLOC (yysize * sizeof yystack->yynextFree[0]);
  if (!yystack->yyitems)
    return yyfalse;
  yystack->yynextFree = yystack->yyitems;
  yystack->yysplitPoint = NULL;
  yystack->yylastDeleted = NULL;
  return yyinitStateSet (&yystack->yytops);
}

#define YYRELOC(YYFROMITEMS,YYTOITEMS,YYX,YYTYPE) \
  &((YYTOITEMS) - ((YYFROMITEMS) - (yyGLRStackItem*) (YYX)))->YYTYPE

/** If STACK is expandable, extend it.  WARNING: Pointers into the
    stack from outside should be considered invalid after this call.
    We always expand when there are 1 or fewer items left AFTER an
    allocation, so that we can avoid having external pointers exist
    across an allocation. */
static void
yyexpandGLRStack (yyGLRStack* yystack)
{
#if YYSTACKEXPANDABLE
  yyGLRStackItem* yynewItems;
  yyGLRStackItem* yyp0, *yyp1;
  size_t yysize, yynewSize;
  size_t yyn;
  yysize = yystack->yynextFree - yystack->yyitems;
  if (YYMAXDEPTH <= yysize)
    yyMemoryExhausted (yystack);
  yynewSize = 2*yysize;
  if (YYMAXDEPTH < yynewSize)
    yynewSize = YYMAXDEPTH;
  yynewItems = (yyGLRStackItem*) YYMALLOC (yynewSize * sizeof yynewItems[0]);
  if (! yynewItems)
    yyMemoryExhausted (yystack);
  for (yyp0 = yystack->yyitems, yyp1 = yynewItems, yyn = yysize;
       0 < yyn;
       yyn -= 1, yyp0 += 1, yyp1 += 1)
    {
      *yyp1 = *yyp0;
      if (*(yybool *) yyp0)
	{
	  yyGLRState* yys0 = &yyp0->yystate;
	  yyGLRState* yys1 = &yyp1->yystate;
	  if (yys0->yypred != NULL)
	    yys1->yypred =
	      YYRELOC (yyp0, yyp1, yys0->yypred, yystate);
	  if (! yys0->yyresolved && yys0->yysemantics.yyfirstVal != NULL)
	    yys1->yysemantics.yyfirstVal =
	      YYRELOC(yyp0, yyp1, yys0->yysemantics.yyfirstVal, yyoption);
	}
      else
	{
	  yySemanticOption* yyv0 = &yyp0->yyoption;
	  yySemanticOption* yyv1 = &yyp1->yyoption;
	  if (yyv0->yystate != NULL)
	    yyv1->yystate = YYRELOC (yyp0, yyp1, yyv0->yystate, yystate);
	  if (yyv0->yynext != NULL)
	    yyv1->yynext = YYRELOC (yyp0, yyp1, yyv0->yynext, yyoption);
	}
    }
  if (yystack->yysplitPoint != NULL)
    yystack->yysplitPoint = YYRELOC (yystack->yyitems, yynewItems,
				 yystack->yysplitPoint, yystate);

  for (yyn = 0; yyn < yystack->yytops.yysize; yyn += 1)
    if (yystack->yytops.yystates[yyn] != NULL)
      yystack->yytops.yystates[yyn] =
	YYRELOC (yystack->yyitems, yynewItems,
		 yystack->yytops.yystates[yyn], yystate);
  YYFREE (yystack->yyitems);
  yystack->yyitems = yynewItems;
  yystack->yynextFree = yynewItems + yysize;
  yystack->yyspaceLeft = yynewSize - yysize;

#else
  yyMemoryExhausted (yystack);
#endif
}

static void
yyfreeGLRStack (yyGLRStack* yystack)
{
  YYFREE (yystack->yyitems);
  yyfreeStateSet (&yystack->yytops);
}

/** Assuming that S is a GLRState somewhere on STACK, update the
 *  splitpoint of STACK, if needed, so that it is at least as deep as
 *  S. */
static inline void
yyupdateSplit (yyGLRStack* yystack, yyGLRState* yys)
{
  if (yystack->yysplitPoint != NULL && yystack->yysplitPoint > yys)
    yystack->yysplitPoint = yys;
}

/** Invalidate stack #K in STACK. */
static inline void
yymarkStackDeleted (yyGLRStack* yystack, size_t yyk)
{
  if (yystack->yytops.yystates[yyk] != NULL)
    yystack->yylastDeleted = yystack->yytops.yystates[yyk];
  yystack->yytops.yystates[yyk] = NULL;
}

/** Undelete the last stack that was marked as deleted.  Can only be
    done once after a deletion, and only when all other stacks have
    been deleted. */
static void
yyundeleteLastStack (yyGLRStack* yystack)
{
  if (yystack->yylastDeleted == NULL || yystack->yytops.yysize != 0)
    return;
  yystack->yytops.yystates[0] = yystack->yylastDeleted;
  yystack->yytops.yysize = 1;
  YYDPRINTF ((stderr, "Restoring last deleted stack as stack #0.\n"));
  yystack->yylastDeleted = NULL;
}

static inline void
yyremoveDeletes (yyGLRStack* yystack)
{
  size_t yyi, yyj;
  yyi = yyj = 0;
  while (yyj < yystack->yytops.yysize)
    {
      if (yystack->yytops.yystates[yyi] == NULL)
	{
	  if (yyi == yyj)
	    {
	      YYDPRINTF ((stderr, "Removing dead stacks.\n"));
	    }
	  yystack->yytops.yysize -= 1;
	}
      else
	{
	  yystack->yytops.yystates[yyj] = yystack->yytops.yystates[yyi];
	  if (yyj != yyi)
	    {
	      YYDPRINTF ((stderr, "Rename stack %lu -> %lu.\n",
			  (unsigned long int) yyi, (unsigned long int) yyj));
	    }
	  yyj += 1;
	}
      yyi += 1;
    }
}

/** Shift to a new state on stack #K of STACK, corresponding to LR state
 * LRSTATE, at input position POSN, with (resolved) semantic value SVAL. */
static inline void
yyglrShift (yyGLRStack* yystack, size_t yyk, yyStateNum yylrState,
	    size_t yyposn,
	    YYSTYPE yysval, YYLTYPE* yylocp)
{
  yyGLRStackItem* yynewItem;

  yynewItem = yystack->yynextFree;
  yystack->yynextFree += 1;
  yystack->yyspaceLeft -= 1;
  yynewItem->yystate.yyisState = yytrue;
  yynewItem->yystate.yylrState = yylrState;
  yynewItem->yystate.yyposn = yyposn;
  yynewItem->yystate.yyresolved = yytrue;
  yynewItem->yystate.yypred = yystack->yytops.yystates[yyk];
  yystack->yytops.yystates[yyk] = &yynewItem->yystate;
  yynewItem->yystate.yysemantics.yysval = yysval;
  yynewItem->yystate.yyloc = *yylocp;
  if (yystack->yyspaceLeft < YYHEADROOM)
    yyexpandGLRStack (yystack);
}

/** Shift stack #K of YYSTACK, to a new state corresponding to LR
 *  state YYLRSTATE, at input position YYPOSN, with the (unresolved)
 *  semantic value of YYRHS under the action for YYRULE. */
static inline void
yyglrShiftDefer (yyGLRStack* yystack, size_t yyk, yyStateNum yylrState,
		 size_t yyposn, yyGLRState* rhs, yyRuleNum yyrule)
{
  yyGLRStackItem* yynewItem;

  yynewItem = yystack->yynextFree;
  yynewItem->yystate.yyisState = yytrue;
  yynewItem->yystate.yylrState = yylrState;
  yynewItem->yystate.yyposn = yyposn;
  yynewItem->yystate.yyresolved = yyfalse;
  yynewItem->yystate.yypred = yystack->yytops.yystates[yyk];
  yynewItem->yystate.yysemantics.yyfirstVal = NULL;
  yystack->yytops.yystates[yyk] = &yynewItem->yystate;
  yystack->yynextFree += 1;
  yystack->yyspaceLeft -= 1;
  yyaddDeferredAction (yystack, &yynewItem->yystate, rhs, yyrule);
}

/** Pop the symbols consumed by reduction #RULE from the top of stack
 *  #K of STACK, and perform the appropriate semantic action on their
 *  semantic values.  Assumes that all ambiguities in semantic values
 *  have been previously resolved. Set *VALP to the resulting value,
 *  and *LOCP to the computed location (if any).  Return value is as
 *  for userAction. */
static inline YYRESULTTAG
yydoAction (yyGLRStack* yystack, size_t yyk, yyRuleNum yyrule,
	    YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  int yynrhs = yyrhsLength (yyrule);

  if (yystack->yysplitPoint == NULL)
    {
      /* Standard special case: single stack. */
      yyGLRStackItem* rhs = (yyGLRStackItem*) yystack->yytops.yystates[yyk];
      YYASSERT (yyk == 0);
      yystack->yynextFree -= yynrhs;
      yystack->yyspaceLeft += yynrhs;
      yystack->yytops.yystates[0] = & yystack->yynextFree[-1].yystate;
      return yyuserAction (yyrule, yynrhs, rhs,
			   yyvalp, yylocp, yystack);
    }
  else
    {
      int yyi;
      yyGLRState* yys;
      yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
      yys = yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred
	= yystack->yytops.yystates[yyk];
      for (yyi = 0; yyi < yynrhs; yyi += 1)
	{
	  yys = yys->yypred;
	  YYASSERT (yys);
	}
      yyupdateSplit (yystack, yys);
      yystack->yytops.yystates[yyk] = yys;
      return yyuserAction (yyrule, yynrhs, yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
			   yyvalp, yylocp, yystack);
    }
}

#if !YYDEBUG
# define YY_REDUCE_PRINT(K, Rule)
#else
# define YY_REDUCE_PRINT(K, Rule)	\
do {					\
  if (yydebug)				\
    yy_reduce_print (K, Rule);		\
} while (0)

/*----------------------------------------------------------.
| Report that the RULE is going to be reduced on stack #K.  |
`----------------------------------------------------------*/

static inline void
yy_reduce_print (size_t yyk, yyRuleNum yyrule)
{
  int yyi;
  YYFPRINTF (stderr, "Reducing stack %lu by rule %d (line %lu), ",
	     (unsigned long int) yyk, yyrule - 1,
	     (unsigned long int) yyrline[yyrule]);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytokenName (yyrhs[yyi]));
  YYFPRINTF (stderr, "-> %s\n", yytokenName (yyr1[yyrule]));
}
#endif

/** Pop items off stack #K of STACK according to grammar rule RULE,
 *  and push back on the resulting nonterminal symbol.  Perform the
 *  semantic action associated with RULE and store its value with the
 *  newly pushed state, if FORCEEVAL or if STACK is currently
 *  unambiguous.  Otherwise, store the deferred semantic action with
 *  the new state.  If the new state would have an identical input
 *  position, LR state, and predecessor to an existing state on the stack,
 *  it is identified with that existing state, eliminating stack #K from
 *  the STACK. In this case, the (necessarily deferred) semantic value is
 *  added to the options for the existing state's semantic value.
 */
static inline YYRESULTTAG
yyglrReduce (yyGLRStack* yystack, size_t yyk, yyRuleNum yyrule,
             yybool yyforceEval)
{
  size_t yyposn = yystack->yytops.yystates[yyk]->yyposn;

  if (yyforceEval || yystack->yysplitPoint == NULL)
    {
      YYSTYPE yysval;
      YYLTYPE yyloc;

      YY_REDUCE_PRINT (yyk, yyrule);
      YYCHK (yydoAction (yystack, yyk, yyrule, &yysval, &yyloc));
      yyglrShift (yystack, yyk,
		  yyLRgotoState (yystack->yytops.yystates[yyk]->yylrState,
				 yylhsNonterm (yyrule)),
		  yyposn, yysval, &yyloc);
    }
  else
    {
      size_t yyi;
      int yyn;
      yyGLRState* yys, *yys0 = yystack->yytops.yystates[yyk];
      yyStateNum yynewLRState;

      for (yys = yystack->yytops.yystates[yyk], yyn = yyrhsLength (yyrule);
	   0 < yyn; yyn -= 1)
	{
	  yys = yys->yypred;
	  YYASSERT (yys);
	}
      yyupdateSplit (yystack, yys);
      yynewLRState = yyLRgotoState (yys->yylrState, yylhsNonterm (yyrule));
      YYDPRINTF ((stderr,
		  "Reduced stack %lu by rule #%d; action deferred. Now in state %d.\n",
		  (unsigned long int) yyk, yyrule - 1, yynewLRState));
      for (yyi = 0; yyi < yystack->yytops.yysize; yyi += 1)
	if (yyi != yyk && yystack->yytops.yystates[yyi] != NULL)
	  {
	    yyGLRState* yyp, *yysplit = yystack->yysplitPoint;
	    yyp = yystack->yytops.yystates[yyi];
	    while (yyp != yys && yyp != yysplit && yyp->yyposn >= yyposn)
	      {
		if (yyp->yylrState == yynewLRState && yyp->yypred == yys)
		  {
		    yyaddDeferredAction (yystack, yyp, yys0, yyrule);
		    yymarkStackDeleted (yystack, yyk);
		    YYDPRINTF ((stderr, "Merging stack %lu into stack %lu.\n",
				(unsigned long int) yyk,
				(unsigned long int) yyi));
		    return yyok;
		  }
		yyp = yyp->yypred;
	      }
	  }
      yystack->yytops.yystates[yyk] = yys;
      yyglrShiftDefer (yystack, yyk, yynewLRState, yyposn, yys0, yyrule);
    }
  return yyok;
}

static size_t
yysplitStack (yyGLRStack* yystack, size_t yyk)
{
  if (yystack->yysplitPoint == NULL)
    {
      YYASSERT (yyk == 0);
      yystack->yysplitPoint = yystack->yytops.yystates[yyk];
    }
  if (yystack->yytops.yysize >= yystack->yytops.yycapacity)
    {
      yyGLRState** yynewStates;
      if (! ((yystack->yytops.yycapacity
	      <= (YYSIZEMAX / (2 * sizeof yynewStates[0])))
	     && (yynewStates =
		 (yyGLRState**) YYREALLOC (yystack->yytops.yystates,
					   ((yystack->yytops.yycapacity *= 2)
					    * sizeof yynewStates[0])))))
	yyMemoryExhausted (yystack);
      yystack->yytops.yystates = yynewStates;
    }
  yystack->yytops.yystates[yystack->yytops.yysize]
    = yystack->yytops.yystates[yyk];
  yystack->yytops.yysize += 1;
  return yystack->yytops.yysize-1;
}

/** True iff Y0 and Y1 represent identical options at the top level.
 *  That is, they represent the same rule applied to RHS symbols
 *  that produce the same terminal symbols. */
static yybool
yyidenticalOptions (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  if (yyy0->yyrule == yyy1->yyrule)
    {
      yyGLRState *yys0, *yys1;
      int yyn;
      for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
	   yyn = yyrhsLength (yyy0->yyrule);
	   yyn > 0;
	   yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
	if (yys0->yyposn != yys1->yyposn)
	  return yyfalse;
      return yytrue;
    }
  else
    return yyfalse;
}

/** Assuming identicalOptions (Y0,Y1), destructively merge the
 *  alternative semantic values for the RHS-symbols of Y1 and Y0. */
static void
yymergeOptionSets (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  yyGLRState *yys0, *yys1;
  int yyn;
  for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
       yyn = yyrhsLength (yyy0->yyrule);
       yyn > 0;
       yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
    {
      if (yys0 == yys1)
	break;
      else if (yys0->yyresolved)
	{
	  yys1->yyresolved = yytrue;
	  yys1->yysemantics.yysval = yys0->yysemantics.yysval;
	}
      else if (yys1->yyresolved)
	{
	  yys0->yyresolved = yytrue;
	  yys0->yysemantics.yysval = yys1->yysemantics.yysval;
	}
      else
	{
	  yySemanticOption** yyz0p;
	  yySemanticOption* yyz1;
	  yyz0p = &yys0->yysemantics.yyfirstVal;
	  yyz1 = yys1->yysemantics.yyfirstVal;
	  while (yytrue)
	    {
	      if (yyz1 == *yyz0p || yyz1 == NULL)
		break;
	      else if (*yyz0p == NULL)
		{
		  *yyz0p = yyz1;
		  break;
		}
	      else if (*yyz0p < yyz1)
		{
		  yySemanticOption* yyz = *yyz0p;
		  *yyz0p = yyz1;
		  yyz1 = yyz1->yynext;
		  (*yyz0p)->yynext = yyz;
		}
	      yyz0p = &(*yyz0p)->yynext;
	    }
	  yys1->yysemantics.yyfirstVal = yys0->yysemantics.yyfirstVal;
	}
    }
}

/** Y0 and Y1 represent two possible actions to take in a given
 *  parsing state; return 0 if no combination is possible,
 *  1 if user-mergeable, 2 if Y0 is preferred, 3 if Y1 is preferred. */
static int
yypreference (yySemanticOption* y0, yySemanticOption* y1)
{
  yyRuleNum r0 = y0->yyrule, r1 = y1->yyrule;
  int p0 = yydprec[r0], p1 = yydprec[r1];

  if (p0 == p1)
    {
      if (yymerger[r0] == 0 || yymerger[r0] != yymerger[r1])
	return 0;
      else
	return 1;
    }
  if (p0 == 0 || p1 == 0)
    return 0;
  if (p0 < p1)
    return 3;
  if (p1 < p0)
    return 2;
  return 0;
}

static YYRESULTTAG yyresolveValue (yySemanticOption* yyoptionList,
				   yyGLRStack* yystack, YYSTYPE* yyvalp,
				   YYLTYPE* yylocp);

static YYRESULTTAG
yyresolveStates (yyGLRState* yys, int yyn, yyGLRStack* yystack)
{
  YYRESULTTAG yyflag;
  if (0 < yyn)
    {
      YYASSERT (yys->yypred);
      yyflag = yyresolveStates (yys->yypred, yyn-1, yystack);
      if (yyflag != yyok)
	return yyflag;
      if (! yys->yyresolved)
	{
	  yyflag = yyresolveValue (yys->yysemantics.yyfirstVal, yystack,
				   &yys->yysemantics.yysval, &yys->yyloc
				  );
	  if (yyflag != yyok)
	    return yyflag;
	  yys->yyresolved = yytrue;
	}
    }
  return yyok;
}

static YYRESULTTAG
yyresolveAction (yySemanticOption* yyopt, yyGLRStack* yystack,
	         YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
  int yynrhs;

  yynrhs = yyrhsLength (yyopt->yyrule);
  YYCHK (yyresolveStates (yyopt->yystate, yynrhs, yystack));
  yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred = yyopt->yystate;
  return yyuserAction (yyopt->yyrule, yynrhs,
		       yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
		       yyvalp, yylocp, yystack);
}

#if YYDEBUG
static void
yyreportTree (yySemanticOption* yyx, int yyindent)
{
  int yynrhs = yyrhsLength (yyx->yyrule);
  int yyi;
  yyGLRState* yys;
  yyGLRState* yystates[YYMAXRHS];
  yyGLRState yyleftmost_state;

  for (yyi = yynrhs, yys = yyx->yystate; 0 < yyi; yyi -= 1, yys = yys->yypred)
    yystates[yyi] = yys;
  if (yys == NULL)
    {
      yyleftmost_state.yyposn = 0;
      yystates[0] = &yyleftmost_state;
    }
  else
    yystates[0] = yys;

  if (yyx->yystate->yyposn < yys->yyposn + 1)
    YYFPRINTF (stderr, "%*s%s -> <Rule %d, empty>\n",
	       yyindent, "", yytokenName (yylhsNonterm (yyx->yyrule)),
	       yyx->yyrule);
  else
    YYFPRINTF (stderr, "%*s%s -> <Rule %d, tokens %lu .. %lu>\n",
	       yyindent, "", yytokenName (yylhsNonterm (yyx->yyrule)),
	       yyx->yyrule, (unsigned long int) (yys->yyposn + 1),
	       (unsigned long int) yyx->yystate->yyposn);
  for (yyi = 1; yyi <= yynrhs; yyi += 1)
    {
      if (yystates[yyi]->yyresolved)
	{
	  if (yystates[yyi-1]->yyposn+1 > yystates[yyi]->yyposn)
	    YYFPRINTF (stderr, "%*s%s <empty>\n", yyindent+2, "",
		       yytokenName (yyrhs[yyprhs[yyx->yyrule]+yyi-1]));
	  else
	    YYFPRINTF (stderr, "%*s%s <tokens %lu .. %lu>\n", yyindent+2, "",
		       yytokenName (yyrhs[yyprhs[yyx->yyrule]+yyi-1]),
		       (unsigned long int) (yystates[yyi - 1]->yyposn + 1),
		       (unsigned long int) yystates[yyi]->yyposn);
	}
      else
	yyreportTree (yystates[yyi]->yysemantics.yyfirstVal, yyindent+2);
    }
}
#endif

static void yyreportAmbiguity (yySemanticOption* yyx0, yySemanticOption* yyx1,
			       yyGLRStack* yystack)
  __attribute__ ((__noreturn__));
static void
yyreportAmbiguity (yySemanticOption* yyx0, yySemanticOption* yyx1,
		   yyGLRStack* yystack)
{
  /* `Unused' warnings.  */
  (void) yyx0;
  (void) yyx1;

#if YYDEBUG
  YYFPRINTF (stderr, "Ambiguity detected.\n");
  YYFPRINTF (stderr, "Option 1,\n");
  yyreportTree (yyx0, 2);
  YYFPRINTF (stderr, "\nOption 2,\n");
  yyreportTree (yyx1, 2);
  YYFPRINTF (stderr, "\n");
#endif
  yyFail (yystack, YY_("syntax is ambiguous"));
}


/** Resolve the ambiguity represented by OPTIONLIST, perform the indicated
 *  actions, and return the result. */
static YYRESULTTAG
yyresolveValue (yySemanticOption* yyoptionList, yyGLRStack* yystack,
		YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  yySemanticOption* yybest;
  yySemanticOption** yypp;
  yybool yymerge;

  yybest = yyoptionList;
  yymerge = yyfalse;
  for (yypp = &yyoptionList->yynext; *yypp != NULL; )
    {
      yySemanticOption* yyp = *yypp;

      if (yyidenticalOptions (yybest, yyp))
	{
	  yymergeOptionSets (yybest, yyp);
	  *yypp = yyp->yynext;
	}
      else
	{
	  switch (yypreference (yybest, yyp))
	    {
	    case 0:
	      yyreportAmbiguity (yybest, yyp, yystack);
	      break;
	    case 1:
	      yymerge = yytrue;
	      break;
	    case 2:
	      break;
	    case 3:
	      yybest = yyp;
	      yymerge = yyfalse;
	      break;
	    default:
	      /* This cannot happen so it is not worth a YYASSERT (yyfalse),
	         but some compilers complain if the default case is
		 omitted.  */
	      break;
	    }
	  yypp = &yyp->yynext;
	}
    }

  if (yymerge)
    {
      yySemanticOption* yyp;
      int yyprec = yydprec[yybest->yyrule];
      YYCHK (yyresolveAction (yybest, yystack, yyvalp, yylocp));
      for (yyp = yybest->yynext; yyp != NULL; yyp = yyp->yynext)
	{
	  if (yyprec == yydprec[yyp->yyrule])
	    {
	      YYSTYPE yyval1;
	      YYLTYPE yydummy;
	      YYCHK (yyresolveAction (yyp, yystack, &yyval1, &yydummy));
	      yyuserMerge (yymerger[yyp->yyrule], yyvalp, &yyval1);
	    }
	}
      return yyok;
    }
  else
    return yyresolveAction (yybest, yystack, yyvalp, yylocp);
}

static YYRESULTTAG
yyresolveStack (yyGLRStack* yystack)
{
  if (yystack->yysplitPoint != NULL)
    {
      yyGLRState* yys;
      int yyn;

      for (yyn = 0, yys = yystack->yytops.yystates[0];
	   yys != yystack->yysplitPoint;
	   yys = yys->yypred, yyn += 1)
	continue;
      YYCHK (yyresolveStates (yystack->yytops.yystates[0], yyn, yystack
			     ));
    }
  return yyok;
}

static void
yycompressStack (yyGLRStack* yystack)
{
  yyGLRState* yyp, *yyq, *yyr;

  if (yystack->yytops.yysize != 1 || yystack->yysplitPoint == NULL)
    return;

  for (yyp = yystack->yytops.yystates[0], yyq = yyp->yypred, yyr = NULL;
       yyp != yystack->yysplitPoint;
       yyr = yyp, yyp = yyq, yyq = yyp->yypred)
    yyp->yypred = yyr;

  yystack->yyspaceLeft += yystack->yynextFree - yystack->yyitems;
  yystack->yynextFree = ((yyGLRStackItem*) yystack->yysplitPoint) + 1;
  yystack->yyspaceLeft -= yystack->yynextFree - yystack->yyitems;
  yystack->yysplitPoint = NULL;
  yystack->yylastDeleted = NULL;

  while (yyr != NULL)
    {
      yystack->yynextFree->yystate = *yyr;
      yyr = yyr->yypred;
      yystack->yynextFree->yystate.yypred = & yystack->yynextFree[-1].yystate;
      yystack->yytops.yystates[0] = &yystack->yynextFree->yystate;
      yystack->yynextFree += 1;
      yystack->yyspaceLeft -= 1;
    }
}

static YYRESULTTAG
yyprocessOneStack (yyGLRStack* yystack, size_t yyk,
	           size_t yyposn, YYSTYPE* yylvalp, YYLTYPE* yyllocp
		  )
{
  int yyaction;
  const short int* yyconflicts;
  yyRuleNum yyrule;
  yySymbol* const yytokenp = yystack->yytokenp;

  while (yystack->yytops.yystates[yyk] != NULL)
    {
      yyStateNum yystate = yystack->yytops.yystates[yyk]->yylrState;
      YYDPRINTF ((stderr, "Stack %lu Entering state %d\n",
		  (unsigned long int) yyk, yystate));

      YYASSERT (yystate != YYFINAL);

      if (yyisDefaultedState (yystate))
	{
	  yyrule = yydefaultAction (yystate);
	  if (yyrule == 0)
	    {
	      YYDPRINTF ((stderr, "Stack %lu dies.\n",
			  (unsigned long int) yyk));
	      yymarkStackDeleted (yystack, yyk);
	      return yyok;
	    }
	  YYCHK (yyglrReduce (yystack, yyk, yyrule, yyfalse));
	}
      else
	{
	  if (*yytokenp == YYEMPTY)
	    {
	      YYDPRINTF ((stderr, "Reading a token: "));
	      yychar = YYLEX;
	      *yytokenp = YYTRANSLATE (yychar);
	      YY_SYMBOL_PRINT ("Next token is", *yytokenp, yylvalp, yyllocp);
	    }
	  yygetLRActions (yystate, *yytokenp, &yyaction, &yyconflicts);

	  while (*yyconflicts != 0)
	    {
	      size_t yynewStack = yysplitStack (yystack, yyk);
	      YYDPRINTF ((stderr, "Splitting off stack %lu from %lu.\n",
			  (unsigned long int) yynewStack,
			  (unsigned long int) yyk));
	      YYCHK (yyglrReduce (yystack, yynewStack,
				  *yyconflicts, yyfalse));
	      YYCHK (yyprocessOneStack (yystack, yynewStack, yyposn,
					yylvalp, yyllocp));
	      yyconflicts += 1;
	    }

	  if (yyisShiftAction (yyaction))
	    {
	      YYDPRINTF ((stderr, "On stack %lu, ", (unsigned long int) yyk));
	      YY_SYMBOL_PRINT ("shifting", *yytokenp, yylvalp, yyllocp);
	      yyglrShift (yystack, yyk, yyaction, yyposn+1,
			  *yylvalp, yyllocp);
	      YYDPRINTF ((stderr, "Stack %lu now in state #%d\n",
			  (unsigned long int) yyk,
			  yystack->yytops.yystates[yyk]->yylrState));
	      break;
	    }
	  else if (yyisErrorAction (yyaction))
	    {
	      YYDPRINTF ((stderr, "Stack %lu dies.\n",
			  (unsigned long int) yyk));
	      yymarkStackDeleted (yystack, yyk);
	      break;
	    }
	  else
	    YYCHK (yyglrReduce (yystack, yyk, -yyaction, yyfalse));
	}
    }
  return yyok;
}

static void
yyreportSyntaxError (yyGLRStack* yystack,
		     YYSTYPE* yylvalp, YYLTYPE* yyllocp)
{
  /* `Unused' warnings. */
  (void) yylvalp;
  (void) yyllocp;

  if (yystack->yyerrState == 0)
    {
#if YYERROR_VERBOSE
      yySymbol* const yytokenp = yystack->yytokenp;
      int yyn;
      yyn = yypact[yystack->yytops.yystates[0]->yylrState];
      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  size_t yysize0 = yytnamerr (NULL, yytokenName (*yytokenp));
	  size_t yysize = yysize0;
	  size_t yysize1;
	  yybool yysize_overflow = yyfalse;
	  char* yymsg = NULL;
	  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
	  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
	  int yyx;
	  char *yyfmt;
	  char const *yyf;
	  static char const yyunexpected[] = "syntax error, unexpected %s";
	  static char const yyexpecting[] = ", expecting %s";
	  static char const yyor[] = " or %s";
	  char yyformat[sizeof yyunexpected
			+ sizeof yyexpecting - 1
			+ ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
			   * (sizeof yyor - 1))];
	  char const *yyprefix = yyexpecting;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 1;

	  yyarg[0] = yytokenName (*yytokenp);
	  yyfmt = yystpcpy (yyformat, yyunexpected);

	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
		  {
		    yycount = 1;
		    yysize = yysize0;
		    yyformat[sizeof yyunexpected - 1] = '\0';
		    break;
		  }
		yyarg[yycount++] = yytokenName (yyx);
		yysize1 = yysize + yytnamerr (NULL, yytokenName (yyx));
		yysize_overflow |= yysize1 < yysize;
		yysize = yysize1;
		yyfmt = yystpcpy (yyfmt, yyprefix);
		yyprefix = yyor;
	      }

	  yyf = YY_(yyformat);
	  yysize1 = yysize + strlen (yyf);
	  yysize_overflow |= yysize1 < yysize;
	  yysize = yysize1;

	  if (!yysize_overflow)
	    yymsg = (char *) YYMALLOC (yysize);

	  if (yymsg)
	    {
	      char *yyp = yymsg;
	      int yyi = 0;
	      while ((*yyp = *yyf))
		{
		  if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		    {
		      yyp += yytnamerr (yyp, yyarg[yyi++]);
		      yyf += 2;
		    }
		  else
		    {
		      yyp++;
		      yyf++;
		    }
		}
	      yyerror (yymsg);
	      YYFREE (yymsg);
	    }
	  else
	    {
	      yyerror (YY_("syntax error"));
	      yyMemoryExhausted (yystack);
	    }
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror (YY_("syntax error"));
      yynerrs += 1;
    }
}

/* Recover from a syntax error on YYSTACK, assuming that YYTOKENP,
   YYLVALP, and YYLLOCP point to the syntactic category, semantic
   value, and location of the look-ahead.  */
static void
yyrecoverSyntaxError (yyGLRStack* yystack,
		      YYSTYPE* yylvalp,
		      YYLTYPE* YYOPTIONAL_LOC (yyllocp)
		      )
{
  yySymbol* const yytokenp = yystack->yytokenp;
  size_t yyk;
  int yyj;

  if (yystack->yyerrState == 3)
    /* We just shifted the error token and (perhaps) took some
       reductions.  Skip tokens until we can proceed.  */
    while (yytrue)
      {
	if (*yytokenp == YYEOF)
	  yyFail (yystack, NULL);
	if (*yytokenp != YYEMPTY)
	  {
	    /* We throw away the lookahead, but the error range
	       of the shifted error token must take it into account. */
	    yyGLRState *yys = yystack->yytops.yystates[0];
	    yyGLRStackItem yyerror_range[3];
	    yyerror_range[1].yystate.yyloc = yys->yyloc;
	    yyerror_range[2].yystate.yyloc = *yyllocp;
	    YYLLOC_DEFAULT (yys->yyloc, yyerror_range, 2);
	    yydestruct ("Error: discarding",
			*yytokenp, yylvalp, yyllocp);
	  }
	YYDPRINTF ((stderr, "Reading a token: "));
	yychar = YYLEX;
	*yytokenp = YYTRANSLATE (yychar);
	YY_SYMBOL_PRINT ("Next token is", *yytokenp, yylvalp, yyllocp);
	yyj = yypact[yystack->yytops.yystates[0]->yylrState];
	if (yyis_pact_ninf (yyj))
	  return;
	yyj += *yytokenp;
	if (yyj < 0 || YYLAST < yyj || yycheck[yyj] != *yytokenp)
	  {
	    if (yydefact[yystack->yytops.yystates[0]->yylrState] != 0)
	      return;
	  }
	else if (yytable[yyj] != 0 && ! yyis_table_ninf (yytable[yyj]))
	  return;
      }

  /* Reduce to one stack.  */
  for (yyk = 0; yyk < yystack->yytops.yysize; yyk += 1)
    if (yystack->yytops.yystates[yyk] != NULL)
      break;
  if (yyk >= yystack->yytops.yysize)
    yyFail (yystack, NULL);
  for (yyk += 1; yyk < yystack->yytops.yysize; yyk += 1)
    yymarkStackDeleted (yystack, yyk);
  yyremoveDeletes (yystack);
  yycompressStack (yystack);

  /* Now pop stack until we find a state that shifts the error token. */
  yystack->yyerrState = 3;
  while (yystack->yytops.yystates[0] != NULL)
    {
      yyGLRState *yys = yystack->yytops.yystates[0];
      yyj = yypact[yys->yylrState];
      if (! yyis_pact_ninf (yyj))
	{
	  yyj += YYTERROR;
	  if (0 <= yyj && yyj <= YYLAST && yycheck[yyj] == YYTERROR
	      && yyisShiftAction (yytable[yyj]))
	    {
	      /* Shift the error token having adjusted its location.  */
	      YYLTYPE yyerrloc;
	      yystack->yyerror_range[2].yystate.yyloc = *yyllocp;
	      YYLLOC_DEFAULT (yyerrloc, yystack->yyerror_range, 2);
	      YY_SYMBOL_PRINT ("Shifting", yystos[yytable[yyj]],
			       yylvalp, &yyerrloc);
	      yyglrShift (yystack, 0, yytable[yyj],
			  yys->yyposn, *yylvalp, &yyerrloc);
	      yys = yystack->yytops.yystates[0];
	      break;
	    }
	}
      yystack->yyerror_range[1].yystate.yyloc = yys->yyloc;
      yydestroyGLRState ("Error: popping", yys);
      yystack->yytops.yystates[0] = yys->yypred;
      yystack->yynextFree -= 1;
      yystack->yyspaceLeft += 1;
    }
  if (yystack->yytops.yystates[0] == NULL)
    yyFail (yystack, NULL);
}

#define YYCHK1(YYE)							     \
  do {									     \
    switch (YYE) {							     \
    case yyok:								     \
      break;								     \
    case yyabort:							     \
      goto yyabortlab;							     \
    case yyaccept:							     \
      goto yyacceptlab;							     \
    case yyerr:								     \
      goto yyuser_error;						     \
    default:								     \
      goto yybuglab;							     \
    }									     \
  } while (0)


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
  int yyresult;
  yySymbol yytoken;
  yyGLRStack yystack;
  size_t yyposn;


  YYSTYPE* const yylvalp = &yylval;
  YYLTYPE* const yyllocp = &yylloc;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yytoken = YYEMPTY;
  yylval = yyval_default;

#if YYLTYPE_IS_TRIVIAL
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 0;
#endif


  if (! yyinitGLRStack (&yystack, YYINITDEPTH))
    goto yyexhaustedlab;
  switch (YYSETJMP (yystack.yyexception_buffer))
    {
    case 0: break;
    case 1: goto yyabortlab;
    case 2: goto yyexhaustedlab;
    default: goto yybuglab;
    }
  yystack.yytokenp = &yytoken;
  yyglrShift (&yystack, 0, 0, 0, yylval, &yylloc);
  yyposn = 0;

  while (yytrue)
    {
      /* For efficiency, we have two loops, the first of which is
	 specialized to deterministic operation (single stack, no
	 potential ambiguity).  */
      /* Standard mode */
      while (yytrue)
	{
	  yyRuleNum yyrule;
	  int yyaction;
	  const short int* yyconflicts;

	  yyStateNum yystate = yystack.yytops.yystates[0]->yylrState;
          YYDPRINTF ((stderr, "Entering state %d\n", yystate));
	  if (yystate == YYFINAL)
	    goto yyacceptlab;
	  if (yyisDefaultedState (yystate))
	    {
	      yyrule = yydefaultAction (yystate);
	      if (yyrule == 0)
		{
		  yystack.yyerror_range[1].yystate.yyloc = *yyllocp;
		  yyreportSyntaxError (&yystack, yylvalp, yyllocp);
		  goto yyuser_error;
		}
	      YYCHK1 (yyglrReduce (&yystack, 0, yyrule, yytrue));
	    }
	  else
	    {
	      if (yytoken == YYEMPTY)
		{
		  YYDPRINTF ((stderr, "Reading a token: "));
		  yychar = YYLEX;
		  yytoken = YYTRANSLATE (yychar);
                  YY_SYMBOL_PRINT ("Next token is", yytoken, yylvalp, yyllocp);
		}
	      yygetLRActions (yystate, yytoken, &yyaction, &yyconflicts);
	      if (*yyconflicts != 0)
		break;
	      if (yyisShiftAction (yyaction))
		{
		  YY_SYMBOL_PRINT ("Shifting", yytoken, yylvalp, yyllocp);
		  if (yytoken != YYEOF)
		    yytoken = YYEMPTY;
		  yyposn += 1;
		  yyglrShift (&yystack, 0, yyaction, yyposn, yylval, yyllocp);
		  if (0 < yystack.yyerrState)
		    yystack.yyerrState -= 1;
		}
	      else if (yyisErrorAction (yyaction))
		{
		  yystack.yyerror_range[1].yystate.yyloc = *yyllocp;
		  yyreportSyntaxError (&yystack, yylvalp, yyllocp);
		  goto yyuser_error;
		}
	      else
		YYCHK1 (yyglrReduce (&yystack, 0, -yyaction, yytrue));
	    }
	}

      while (yytrue)
	{
	  size_t yys;
	  size_t yyn = yystack.yytops.yysize;
	  for (yys = 0; yys < yyn; yys += 1)
	    YYCHK1 (yyprocessOneStack (&yystack, yys, yyposn,
				       yylvalp, yyllocp));
	  yytoken = YYEMPTY;
	  yyposn += 1;
	  yyremoveDeletes (&yystack);
	  if (yystack.yytops.yysize == 0)
	    {
	      yyundeleteLastStack (&yystack);
	      if (yystack.yytops.yysize == 0)
		yyFail (&yystack, YY_("syntax error"));
	      YYCHK1 (yyresolveStack (&yystack));
	      YYDPRINTF ((stderr, "Returning to deterministic operation.\n"));
	      yystack.yyerror_range[1].yystate.yyloc = *yyllocp;
	      yyreportSyntaxError (&yystack, yylvalp, yyllocp);
	      goto yyuser_error;
	    }
	  else if (yystack.yytops.yysize == 1)
	    {
	      YYCHK1 (yyresolveStack (&yystack));
	      YYDPRINTF ((stderr, "Returning to deterministic operation.\n"));
	      yycompressStack (&yystack);
	      break;
	    }
	}
      continue;
    yyuser_error:
      yyrecoverSyntaxError (&yystack, yylvalp, yyllocp);
      yyposn = yystack.yytops.yystates[0]->yyposn;
    }

 yyacceptlab:
  yyresult = 0;
  goto yyreturn;

 yybuglab:
  YYASSERT (yyfalse);
  /* Fall through.  */

 yyabortlab:
  yyresult = 1;
  goto yyreturn;

 yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */

 yyreturn:
  if (yytoken != YYEOF && yytoken != YYEMPTY)
    yydestruct ("Cleanup: discarding lookahead",
                yytoken, yylvalp, yyllocp);

  /* If the stack is well-formed, pop the stack until it is empty,
     destroying its entries as we go.  But free the stack regardless
     of whether it is well-formed.  */
  if (yystack.yyitems)
    {
      yyGLRState** yystates = yystack.yytops.yystates;
      if (yystates)
	while (yystates[0])
	  {
	    yyGLRState *yys = yystates[0];
	  yystack.yyerror_range[1].yystate.yyloc = yys->yyloc;
	    yydestroyGLRState ("Cleanup: popping", yys);
	    yystates[0] = yys->yypred;
	    yystack.yynextFree -= 1;
	    yystack.yyspaceLeft += 1;
	  }
      yyfreeGLRStack (&yystack);
    }

  return yyresult;
}

/* DEBUGGING ONLY */
#ifdef YYDEBUG
static void yypstack (yyGLRStack* yystack, size_t yyk)
  __attribute__ ((__unused__));
static void yypdumpstack (yyGLRStack* yystack) __attribute__ ((__unused__));

static void
yy_yypstack (yyGLRState* yys)
{
  if (yys->yypred)
    {
      yy_yypstack (yys->yypred);
      fprintf (stderr, " -> ");
    }
  fprintf (stderr, "%d@%lu", yys->yylrState, (unsigned long int) yys->yyposn);
}

static void
yypstates (yyGLRState* yyst)
{
  if (yyst == NULL)
    fprintf (stderr, "<null>");
  else
    yy_yypstack (yyst);
  fprintf (stderr, "\n");
}

static void
yypstack (yyGLRStack* yystack, size_t yyk)
{
  yypstates (yystack->yytops.yystates[yyk]);
}

#define YYINDEX(YYX)							     \
    ((YYX) == NULL ? -1 : (yyGLRStackItem*) (YYX) - yystack->yyitems)


static void
yypdumpstack (yyGLRStack* yystack)
{
  yyGLRStackItem* yyp;
  size_t yyi;
  for (yyp = yystack->yyitems; yyp < yystack->yynextFree; yyp += 1)
    {
      fprintf (stderr, "%3lu. ", (unsigned long int) (yyp - yystack->yyitems));
      if (*(yybool *) yyp)
	{
	  fprintf (stderr, "Res: %d, LR State: %d, posn: %lu, pred: %ld",
		   yyp->yystate.yyresolved, yyp->yystate.yylrState,
		   (unsigned long int) yyp->yystate.yyposn,
		   (long int) YYINDEX (yyp->yystate.yypred));
	  if (! yyp->yystate.yyresolved)
	    fprintf (stderr, ", firstVal: %ld",
		     (long int) YYINDEX (yyp->yystate.yysemantics.yyfirstVal));
	}
      else
	{
	  fprintf (stderr, "Option. rule: %d, state: %ld, next: %ld",
		   yyp->yyoption.yyrule,
		   (long int) YYINDEX (yyp->yyoption.yystate),
		   (long int) YYINDEX (yyp->yyoption.yynext));
	}
      fprintf (stderr, "\n");
    }
  fprintf (stderr, "Tops:");
  for (yyi = 0; yyi < yystack->yytops.yysize; yyi += 1)
    fprintf (stderr, "%lu: %ld; ", (unsigned long int) yyi,
	     (long int) YYINDEX (yystack->yytops.yystates[yyi]));
  fprintf (stderr, "\n");
}
#endif


#line 1884 "c:\\tmp\\newrepos\\src\\\\..\\src\\verilogparser.y"

//------ ------------------------------------------------------------------------------------------------

 Entry* getCurrVerilogEntry(){return current;}
 Entry* getCurrVerilog(){return currentVerilog; }
 QCString getCurrVerilogParsingClass(){return currVerilogClass; }

 void initVerilogParser(Entry* ee,bool pc){
  currVerilogInst.resize(0);
  currVerilogClass.resize(0);
  prevDocEntryVerilog.reset();
  currentVerilog=0;
  currentFunctionVerilog=0;
  parseCode=pc;
if(pc) return;
  current_rootVerilog=ee;
  lastModule=0;
  current=new Entry;
  VerilogDocGen::initEntry(current);
  current_rootVerilog->name=QCString("XXX"); // dummy name for root
}

 Entry* VerilogDocGen::makeNewEntry(char* name,int sec,int spec,int line,bool add){
 
  bool bb=false; 
  Entry *e=current;
 
 //QCString kkk(name);
 //if(!kkk.isEmpty())fprintf(stderr,"\n name: %s 0x%p",kkk.data(),current);

if(parseCode) // should not happen!
 assert(0);

if(add){ // features like 'include xxx or 'define xxx must not be inserted here
 if(lastModule)
    addSubEntry(lastModule,e); 
  else
    addSubEntry(current_rootVerilog,e); 
}
   if(line){
  	  e->bodyLine=line;
      e->startLine=line;
  }else
   {
     e->bodyLine=getVerilogPrevLine();
     e->startLine=getVerilogPrevLine();
   }
   
  e->section=sec;
  e->spec=spec;
  e->name=name;

  current=new Entry;
  VerilogDocGen::initEntry(current);
  
  return e;
 }

void addSubEntry(Entry* root, Entry* e) {
 if(e==NULL || root==NULL) return;
  root->addSubEntry(e);
 } 




//-------------------------------------------------------------------------

// extracts module/primitive name

void parseModule(){
 
 QCString mod(getVerilogString());
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,' ');
 VhdlDocGen::deleteAllChars(mod,';');
 VhdlDocGen::deleteAllChars(mod,'(');
 
 QRegExp reg("[^_a-zA-Z0-9$]");

 int ll=mod.find(reg);

 if(ll>-1){
  char c=mod.at(ll);
  QCString val=mod.remove(ll,1);

 }

//if(mod.len>80)

 if(parseCode) {
 //generateVerilogClassOrGlobalLink(mod.data());
 currVerilogClass=mod;
 return;
 }
  currentVerilog->name=mod;
 }//parseModuleName


// extracts module instances [ module_name name,module_name #(...) name]

void parseModuleInst(QCString& first, QCString& sec) {
 
if(currVerilogType==VerilogDocGen::DEFPARAM) return;

 VhdlDocGen::deleteAllChars(sec,'(');
 VhdlDocGen::deleteAllChars(sec,'\n');
 VhdlDocGen::deleteAllChars(sec,')');
 VhdlDocGen::deleteAllChars(sec,' ');
 VhdlDocGen::deleteAllChars(sec,',');
 VhdlDocGen::deleteAllChars(sec,';');
 QCString temp=sec;
//while(sec.stripPrefix(" "));

if(sec!=first && (sec.contains("#")==0))
{ 
 //QStringList ql=QStringList::split(first.data(),sec,false);
int oo=sec.findRev(first.data());
if(oo>0) 
 sec=sec.left(oo);
}
else
 sec=getLastLetter();

if(temp.contains("#"))
{ 
 int ii=temp.find("#");
 sec=temp.left(ii);
while(sec.stripPrefix(" "));
}

 if(parseCode){
     VhdlDocGen::deleteAllChars(sec,'\t');
   currVerilogInst=sec;
   return;
  }
 else {
  Entry* pTemp=VerilogDocGen::makeNewEntry(first.data(),Entry::VARIABLE_SEC,VerilogDocGen::COMPONENT,c_lloc.first_line);
  pTemp->type=sec;
 
 if(sec==first)return;
if(currentVerilog)
 if(!findExtendsComponent(currentVerilog->extends,sec)){	
  	BaseInfo *bb=new BaseInfo(sec,Private,Normal);
    currentVerilog->extends->append(bb);						
   }
  }
}


void parseListOfPorts() {
 
  QCString type;

 QCString mod(getVerilogString());
 
 VhdlDocGen::deleteAllChars(mod,' ');
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,';');
 VhdlDocGen::deleteAllChars(mod,')');
 VhdlDocGen::deleteAllChars(mod,'(');
  QStringList ql=QStringList::split(",",mod,false);
  QCString name=(QCString)ql[0];
if(!parseCode) {
  for(uint j=0;j<ql.count();j++) {
  QCString name=(QCString)ql[j];
   int i=name.find('[');
  if(i > 0){
    type=mod.right(mod.length()-i);
    name=mod.left(i);
  }
  
 name.prepend(VhdlDocGen::getRecordNumber().data());
 Entry* pTemp=VerilogDocGen::makeNewEntry(name.data(),Entry::VARIABLE_SEC,VerilogDocGen::PORT,c_lloc.first_line);
  pTemp->type=type; 
   }
  return;
 }	

 }//parseListOfPorts



void parseReg(Entry* e){

// "reg"|"integer\real\event"|wire"|"tri"|"tri1"|"supply0"|"wand"|"triand"|"tri0"|"supply1"|"wor"|"trior"|"trireg"

static QCString prevType;
static QCString sigType;
static QRegExp regg("[ \\[]");
static QRegExp qregg("[ \\[]");
QCString regType;
QCString qcs;

int p,l;
     

 if((CurrState==VerilogDocGen::STATE_FUNCTION || CurrState==VerilogDocGen::STATE_TASK )) return;

QCString mod(getVerilogString());

int port_type=0;

VhdlDocGen::deleteAllChars(mod,'(');
VhdlDocGen::deleteAllChars(mod,')');
VhdlDocGen::deleteAllChars(mod,';');
VhdlDocGen::deleteAllChars(mod,'\n');
VhdlDocGen::deleteAllChars(mod,',');

if(mod.contains("="))
{
 int i=mod.find("=");
 //qcs=mod.right(mod.length()-i-1);
 VhdlDocGen::deleteAllChars(qcs,' ');
 mod=mod.left(i);
}
  
 mod=mod.simplifyWhiteSpace(); 
  
//while(mod.stripPrefix(" "));
  p=qregg.match(mod,0,&l);

 if(p>0){
  sigType=mod.left(p);
  prevType.resize(0);
  mod.stripPrefix(sigType.data());
}

 
 while(mod.stripPrefix(" "));
 

VhdlDocGen::deleteAllChars(mod,' ');

  int i=mod.find(']');
  int h=mod.find('[');

  if(h==0){
  	prevType+=mod.left(i+1);
  	mod=mod.right(mod.length()-i-1);
  h=mod.find('[');
  }

  if(h > 0){
   if(port_type!=2){ 
	regType=mod.right(mod.length()-h);
    mod=mod.left(h);
   }
   else {
    int ii=mod.find('[');
	if(ii>0){
  	prevType=mod.mid(ii,mod.length());
   	mod=mod.left(ii);
   }
  }
 }

  QStringList ql=QStringList::split(",",mod,false);
  for(uint j=0;j<ql.count();j++) {
  QCString name=(QCString)ql[j];
  name.prepend(VhdlDocGen::getRecordNumber().data());
 
  Entry* pTemp=VerilogDocGen::makeNewEntry(name.data(),Entry::VARIABLE_SEC,getVerilogPrevLine());
  pTemp->type=prevType;
  pTemp->args=regType;
  pTemp->args+=sigType;
 pTemp->args+=qcs;
  pTemp->spec=VerilogDocGen::SIGNAL;//currVerilogType;
  
  regType=prevType;
  if(getVerilogToken()==SEM_TOK)
   { prevType="";sigType="";}
  
  }
} // parsReg


// extracts function/task prototype 

void parseFunction(Entry* curF)
{
  QCString mod(getVerilogString());
  QCString type; 
 
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,';');
  while(mod.stripPrefix(" "));
 
  int i=mod.findRev(']');
  if(i > 0){
    type=mod.left(i+1);
   	mod=mod.right(mod.length()-i-1);
  }
  else {
  QStringList ql=QStringList::split(" ",mod,false);
  if(ql.count()>1) {
    type=(QCString)ql[0];
	mod=(QCString)ql[1];
  }
  }
 
 VhdlDocGen::deleteAllChars(mod,' ');
 VhdlDocGen::deleteAllChars(type,' ');

  curF->name+=mod;
  if(type.stripPrefix("automatic"))
   curF->type+="automatic "+type; 
   else
  curF->type+=type;
}
							   

// extract (local)parameter declaration 

void parseParam(Entry* e)
{
   QCString prevType,qcs;
  QRegExp regg("[ \t]");

  if((CurrState==VerilogDocGen::STATE_FUNCTION || CurrState==VerilogDocGen::STATE_TASK )) return;
  
  QCString mod(getVerilogString());
  VhdlDocGen::deleteAllChars(mod,';');
  VhdlDocGen::deleteAllChars(mod,'\n');
  VhdlDocGen::deleteAllChars(mod,',');

if(mod.contains("="))
{
 int i=mod.find("=");
 qcs=mod.right(mod.length()-i-1);
 while(qcs.stripPrefix(" "));
 mod=mod.left(i);
}

 while(mod.stripPrefix(" "));

 int j=mod.find(regg,0);
			 if(j>0){
			 bool bb=false;
			 QCString sem=mod.mid(0,j);
			 if(sem=="integer"){ prevType=sem;bb=true;}
			 else if(sem=="real"){prevType=sem;bb=true;}
			 else if(sem=="realtime"){prevType=sem;bb=true;}
			 else if(sem=="time"){prevType=sem;bb=true;}
			 else if(sem=="signed"){prevType=sem;bb=true;}
			 else if(sem=="wire"){prevType=sem;bb=true;}
			 if(bb)
			 mod.stripPrefix(sem.data());
			 }

 
 while(mod.stripPrefix(" "));
  
  int i=mod.find(']');
  if(i > 0){
    prevType+=" ";
	prevType+=mod.left(i+1);
   	mod=mod.right(mod.length()-i-1);
  }
 

  VhdlDocGen::deleteAllChars(mod,' ');


// each local member must get its unique number, because in Verilog
// two local variables can have the same identifier.
// ( input Q, reg Q)
  mod.prepend(VhdlDocGen::getRecordNumber().data());
 
  Entry* pTemp=VerilogDocGen::makeNewEntry(mod.data(),Entry::VARIABLE_SEC,VerilogDocGen::PARAMETER,getVerilogPrevLine());
  //pTemp->fileName+=getVerilogParsingFile();
  pTemp->type=prevType;
  pTemp->args=qcs;
  
  
}

// extract  input/output ports

void parsePortDir(Entry* e,int port)
{

static QCString prevType;
static QCString type; 

QCString mod(getVerilogString());
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,')');
 VhdlDocGen::deleteAllChars(mod,'(');
 VhdlDocGen::deleteAllChars(mod,';');
 VhdlDocGen::deleteAllChars(mod,',');

 while(mod.stripPrefix(" "));


if(mod.stripPrefix("input"))
 prevType="";
else if(mod.stripPrefix("output"))
  prevType=""; 
else if(mod.stripPrefix("inout"))
  prevType="";
else {
             QRegExp regg("[ \\[]");
  			 int j=mod.find(regg,0);
			 if(j>0){
			 type=mod.mid(0,j);
			 mod.stripPrefix(type.data());
			 }
	 } 


while(mod.stripPrefix(" "));
 
QRegExp regg("[ \t]");
 int j=mod.find(regg,0);
			 if(j>0){
			 bool bb=false;
			 QCString sem=mod.mid(0,j);
			 if(sem=="integer"){ prevType=sem;bb=true;}
			 else if(sem=="real"){prevType=sem;bb=true;}
			 else if(sem=="realtime"){prevType=sem;bb=true;}
			 else if(sem=="time"){prevType=sem;bb=true;}
			 else if(sem=="signed"){prevType=sem;bb=true;}
			 else if(sem=="wire"){prevType=sem;bb=true;}
			 if(bb)
			 mod.stripPrefix(sem.data());
			 }

while(mod.stripPrefix(" "));
  
  int i=mod.findRev(']');
  if(i > 0){
    prevType+=" ";
	prevType+=mod.left(i+1);
   	mod=mod.right(mod.length()-i-1);
  }
  else{ 
  int j=mod.find(regg,0);
   if(j>0){
    QCString sem=mod.mid(0,j);
	if(sem=="reg"){		
     mod=mod.right(mod.length()-j-1);
     prevType+=" reg";
     }
    }
   }
  
  VhdlDocGen::deleteAllChars(mod,' ');
  mod.prepend(VhdlDocGen::getRecordNumber().data());
  if(CurrState==VerilogDocGen::STATE_MODULE){  
  Entry* pTemp=VerilogDocGen::makeNewEntry(mod.data(),Entry::VARIABLE_SEC,0,c_lloc.first_line);
  pTemp->type=prevType;
  pTemp->args=type;
   assert(currVerilogType!=0);
  pTemp->spec=currVerilogType;
//   VerilogDocGen::addSubEntry(currentVerilog,pTemp);
  }
  else
  { 
   if(CurrState==VerilogDocGen::STATE_FUNCTION){
      Argument *arg=new Argument;
      
      switch(currVerilogType) {
      
      case VerilogDocGen::INPUT: arg->type="Input";break;
      case VerilogDocGen::INOUT:arg->type="Inout";break;         
      case VerilogDocGen::OUTPUT:arg->type="Output";break;         
      default:break;
      }                           
        arg->defval=prevType;                         
        arg->name=mod;//(QCString)ql[j];	
	  currentFunctionVerilog->argList->append(arg);
	  VerilogDocGen::adjustMemberName(mod); 
	  currentFunctionVerilog->args+=mod;//(QCString)ql[j]+",";
  } 
 }
 

  if(getVerilogToken()==SEM_TOK)//end of line
  {prevType="";type="";}
}

void parseAlways(bool bBody)
{

if(currVerilogType!=VerilogDocGen::ALWAYS) return ;

QRegExp regg1("[ \t]or[ \t]");

QCString mod(getVerilogString());
QCString type; 
QStringList ql;
bool sem=false;

 VhdlDocGen::deleteAllChars(mod,'@');
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,'(');
 VhdlDocGen::deleteAllChars(mod,')');
 VhdlDocGen::deleteAllChars(mod,';'); 

if(mod.contains(","))
  ql=QStringList::split(",",mod,false);
 else
  ql=QStringList::split(regg1,mod,false);
 

 if(!parseCode) {
 currentFunctionVerilog=VerilogDocGen::makeNewEntry(VhdlDocGen::getProcessNumber().data(),Entry::FUNCTION_SEC,VerilogDocGen::ALWAYS);
  currentFunctionVerilog->stat=TRUE;
  currentFunctionVerilog->fileName=getVerilogParsingFile();
  if(!bBody)
  for(uint j=0;j<ql.count();j++) {
  QCString ll=(QCString)ql[j];
  if(ll=="or" || ll=="and") continue; 
  if(sem)
	  currentFunctionVerilog->args+=',';
	  Argument *arg=new Argument;
      arg->name=ll;	
	  currentFunctionVerilog->argList->append(arg);
      currentFunctionVerilog->args+=ll; 
      sem = true;
 }
 return;
}


}//parseAlways



 // sets the current parsing module (only for parsing inline_sources)             
 void VerilogDocGen::setCurrVerilogClass(QCString& cl){ currVerilogClass = cl;}
   
 //-------------------------------------------------------------------------------------------  
           
 int MyParserConv::parse(MyParserConv* conv){
  myconv=conv;
  assert(myconv);
  return c_parse();
 } 
        
int c_lex(void){
 return myconv->doLex(); 
}


void c_error(const char * err){
   if(err && !parseCode){
   fprintf(stderr,"\n\nerror occurred at line [%d]... : in file [%s]\n\n",c_lloc.first_line,getVerilogParsingFile());
  vbufreset();
//  exit(0);
  }
   } 
    
int getVerilogToken(){return c_char;}
 //------------------------------------------------------------------------------------------------  

// writes a digit to the source

void writeDigit()
 {
   if(parseCode) {
     writePrevVerilogWords(identVerilog);
	 writeVerilogFont("vhdllogic",identVerilog.data());
	 identVerilog.resize(0);
	 printVerilogBuffer(true);
	 }
 }// writeDigit

// prints and links the parsed identifiers  

void parseString(){				
					if(parseCode ) { 
					 //   printVerilogStringList();
						 identVerilog=identVerilog.stripWhiteSpace();
				   	  writePrevVerilogWords(identVerilog);
						 bool b=false;
					 
					 if(currVerilogType==VerilogDocGen::DEFPARAM){
				       QCString s(getVerilogString());
                       if(s.contains(".")==0)
                           b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::COMPONENT);
				       else if(s.contains("="))
                           b=generateVerilogMemLink(currVerilogClass,identVerilog,-1);
                       else
				         b=generateVerilogMemLink(currVerilogInst,identVerilog,-1);	       
				     }
					 else if(currVerilogType==VerilogDocGen::COMPONENT){
					    QCString tt(getVerilogString());
					    if(tt.contains('('))
					     b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::PORT);
				        else if(!b)   
				         b=generateVerilogMemLink(currVerilogInst,identVerilog,VerilogDocGen::PORT);
				        if(!b)   
				         b=generateVerilogMemLink(currVerilogClass,identVerilog,-1);    
					   }
				    /*
				      else if(currVerilogType==VerilogDocGen::NETTYPE){
                       QCString tt(getVerilogString());
                      if(tt.contains("["))
                         b=generateVerilogMemLink(currVerilogClass,identVerilog,-1);
                       else{
                      	 codifyVerilogString(identVerilog.data(),"vhdlcharacter");
				         b=true;
				          }
                      	 }
				      */
				      else if(currVerilogType==VerilogDocGen::PORT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::PORT);
				     else if(currVerilogType==VerilogDocGen::PARAMETER)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::PARAMETER);
				     else if(currVerilogType==VerilogDocGen::SIGNAL)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::SIGNAL);
				     else if(currVerilogType==VerilogDocGen::INPUT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::INPUT);				       
         		     else if(currVerilogType==VerilogDocGen::OUTPUT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::OUTPUT);
				     else if(currVerilogType==VerilogDocGen::INOUT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::INOUT);
				   
				     else if(currVerilogType==VerilogDocGen::ALWAYS)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::ALWAYS);
						
				     if(!b){
					   b =  generateVerilogMemLink(currVerilogClass,identVerilog,-1); 
					   if(!b && getClass(identVerilog.data()))
                       b=generateVerilogClassOrGlobalLink(identVerilog.data());
					  if(!b){
					   int  col=VerilogDocGen::findKeyWord(identVerilog.data());
					   if(col==1)
					    codifyVerilogString(identVerilog.data(),"vhdldigit");
					   else if(col==2)
					     codifyVerilogString(identVerilog.data(),"comment"); 
					    else
					   codifyVerilogString(identVerilog.data(),"vhdlcharacter");
					   }   
					 }
					   printVerilogBuffer(true);
					  }
				   identVerilog.resize(0);
				 
}// parseString

// inits the parser

 //---------------------------------------------------------------------------------------------------  



// do not include the same class twice 

bool findExtendsComponent(QList<BaseInfo> *extend,QCString& compName)
{
 for(uint j=0;j<extend->count();j++){
  BaseInfo *bb=extend->at(j);
  if(bb->name==compName)
   return true;
 }
 return false;
}// findExtendsComponent


