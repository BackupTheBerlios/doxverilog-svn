/******************************************************************************
* Copyright (c) M.Kreis,2009 
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Library General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*
* You may use and distribute this software under the terms of the
* GNU General Public License, version 2 or later
*****************************************************************************/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "verilogdocgen.h"
#include "verilogscanner.h"
#include "membergroup.h"
#include "vhdldocgen.h"
#include "doxygen.h"
#include "searchindex.h"
#include "commentscan.h"

// sets the member spec variable for global variables
// needed for writing file declarations
static void setType(MemberList* ml);

static void writeFunctionProto(OutputList& ol,const ArgumentList* al,const MemberDef* mdef);



Entry* VerilogDocGen::getEntryAtLine(const Entry* ce,int line)
{
  EntryListIterator eli(*ce->children());
  Entry *found=0;
  Entry *rt;
  for (;(rt=eli.current());++eli)
  {
    if (rt->bodyLine==line)
    {
      found=rt;
    } // if
    if (!found) 
    {
      found=getEntryAtLine(rt,line);
    }
  }
  return found;
}// getEntryAtLine


void VerilogDocGen::adjustMemberName(QCString& nn) {
  QRegExp regg("[_a-zA-Z]");  int j=nn.find(regg,0);
  if (j>0)   nn=nn.mid(j,nn.length());
 }//adjustRecordMember


QCString VerilogDocGen::convertTypeToString(int type,bool sing)
{
  uint ttype=(uint)type;
  switch(type){
  case(VerilogDocGen::MODULE) :
   if(sing)return "Module";
  return "Modules"; 
  case( VerilogDocGen::FUNCTION): 
  if(sing)return "Function";
  return "Functions";
 case( VerilogDocGen::TASK): 
  if(sing)return "Task";
  return "Tasks";
  case(VerilogDocGen::PRIMITIVE):
  if(sing)return "Primitive";
  return "Primitives";
  case(VerilogDocGen::PARAMETER):  
  if(sing) return "Parameter";
  return "Parameters";
  case(VerilogDocGen::COMPONENT): 
  if(sing) return "Module Instance";
  return "Module Instances";
  case( VerilogDocGen::PORT):
  if(sing) return "Port";
  return "Ports";
  case( VerilogDocGen::ALWAYS): 
  if(sing) return "Always Construct";
  else
  return "Always Constructs";
  case( VerilogDocGen::INPUT): 
  if(sing)return "Input";
  return "Inputs";
  case( VerilogDocGen::OUTPUT): 
  if(sing) return "Output";
  return "Outputs";
  case( VerilogDocGen::INOUT): 
  if(sing) return "Inout";
  return "Inouts";
   case(VerilogDocGen::FEATURE): 
   if(sing) return "Define";
  else
  return "Defines"; 
  case( VerilogDocGen::TIME): 
  return "Time"; 
  case( VerilogDocGen::INCLUDE): 
  if(sing) return "Include";
  return "Includes"; 
  case( VerilogDocGen::SIGNAL): 
  if(sing) 
    return "Signal";
  return "Signals";  
 
  default: return "";
  }
  return "";
 
} // convertType


 void setType(MemberList *ml){
  if (ml==0) return ;
  MemberDef *mdd=0;
  MemberListIterator mmli(*ml);
  for ( ; (mdd=mmli.current()); ++mmli )
  {
     QCString type(mdd->typeString());
     if(type=="feature")
       mdd->setMemberSpecifiers(VerilogDocGen::FEATURE);
     if(type=="include") 
          mdd->setMemberSpecifiers(VerilogDocGen::INCLUDE);
       
   }
  } 
                    
 void VerilogDocGen::writeVerilogDeclarations(MemberList* ml,OutputList &ol,
               ClassDef *cd,NamespaceDef *nd,FileDef *fd,GroupDef *gd,
               const char *title,const char *subtitle,bool showEnumValues,int type) {


  MemberDef *mdd=NULL;
 // if(ml==NULL) return;
  MemberListIterator mmli(*ml);
  setType(ml);
 
if (!VhdlDocGen::membersHaveSpecificType(ml,type)) return;
  
  if (title) 
  {
    ol.startMemberHeader();
    ol.parseText(title);
    ol.endMemberHeader();
	ol.docify(" ");
  }
  if (subtitle && subtitle[0]!=0) 
  {
    //printf("subtitle=`%s'\n",subtitle);
    ol.startMemberSubtitle();
    ol.parseDoc("[generated]",-1,0,0,subtitle,FALSE,FALSE);
    ol.endMemberSubtitle();
  } 
  
  VerilogDocGen::writePlainVerilogDeclarations(mdd,ml,ol,cd,nd,fd,gd,type);
 
  if (ml->getMemberGroupList())
  {
    MemberGroupListIterator mgli(*ml->getMemberGroupList());
    MemberGroup *mg;
    while ((mg=mgli.current()))
    {
     // assert(0);
       if (VhdlDocGen::membersHaveSpecificType(mg->members(),type))
    
     {
      //printf("mg->header=%s\n",mg->header().data());
      bool hasHeader=mg->header()!="[NOHEADER]";
      ol.startMemberGroupHeader(hasHeader);
      if (hasHeader)
      {
        ol.parseText(mg->header());
      }
      ol.endMemberGroupHeader();
      if (!mg->documentation().isEmpty())
      {
        //printf("Member group has docs!\n");
        ol.startMemberGroupDocs();
        ol.parseDoc("[generated]",-1,0,0,mg->documentation()+"\n",FALSE,FALSE);
        ol.endMemberGroupDocs();
      }
      ol.startMemberGroup();
      //printf("--- mg->writePlainDeclarations ---\n");
      //mg->writePlainDeclarations(ol,cd,nd,fd,gd);
          VerilogDocGen::writePlainVerilogDeclarations(0,mg->members(),ol,cd,nd,fd,gd,type);
   
      ol.endMemberGroup(hasHeader);
     }
      ++mgli;
    }
  }
 
 }// writeVerilogDeclarations



void VerilogDocGen::writePlainVerilogDeclarations(MemberDef* mdef,MemberList* mlist,OutputList &ol,
               ClassDef *cd,NamespaceDef *nd,FileDef *fd,GroupDef *gd,int specifier){

  
  ol.pushGeneratorState();

  bool first=TRUE;
  MemberDef *md;
  MemberListIterator mli(*mlist);
  for ( ; (md=mli.current()); ++mli )
  { 
	int mems=md->getMemberSpecifiers();
	 
    if (md->isBriefSectionVisible() && (mems==specifier))
    {
             if (first) ol.startMemberList(),first=FALSE;
			VerilogDocGen::writeVerilogDeclarations(md,ol,cd,nd,fd,gd,false);
    }//if
  }//for
  if (!first) ol.endMemberList(); 
  
}//plainDeclaration

void VerilogDocGen::writeVerilogDeclarations(MemberList* ml,OutputList& ol,GroupDef* gd,ClassDef* cd,FileDef* fd){

	  VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::PORT,FALSE),0,FALSE,VerilogDocGen::PORT); 
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::MODULE,FALSE),0,FALSE,VerilogDocGen::MODULE);
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::FEATURE,FALSE),0,FALSE,VerilogDocGen::FEATURE);
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::INCLUDE,FALSE),0,FALSE,VerilogDocGen::INCLUDE);
	  VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::FUNCTION,FALSE),0,FALSE,VerilogDocGen::FUNCTION);
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::ALWAYS,FALSE),0,FALSE,VerilogDocGen::ALWAYS);
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::TASK,FALSE),0,FALSE,VerilogDocGen::TASK);
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::INPUT,FALSE),0,FALSE,VerilogDocGen::INPUT);
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::INOUT,FALSE),0,FALSE,VerilogDocGen::INOUT);
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::OUTPUT,FALSE),0,FALSE,VerilogDocGen::OUTPUT);
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::PARAMETER,FALSE),0,FALSE,VerilogDocGen::PARAMETER);
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::COMPONENT,FALSE),0,FALSE,VerilogDocGen::COMPONENT);
      VerilogDocGen::writeVerilogDeclarations(ml,ol,cd,0,fd,gd,VerilogDocGen::convertTypeToString(VerilogDocGen::SIGNAL,FALSE),0,FALSE,VerilogDocGen::SIGNAL);
 
 	 }



void VerilogDocGen::writeVerilogDeclarations(MemberDef* mdef,OutputList &ol,
                   ClassDef *cd,NamespaceDef *nd,FileDef *fd,GroupDef *gd,
                   bool inGroup) {
 
  static bool bComp=false;
  LockingPtr<MemberDef> lock(mdef,mdef);
 
  Definition *d=0;
  ASSERT (cd!=0 || nd!=0 || fd!=0 || gd!=0); // member should belong to something
 if (cd) d=cd; else if (nd) d=nd; else if (fd) d=fd; else d=gd;
//if (cd) d=cd;
  // write tag file information of this member
 int memType=mdef->getMemberSpecifiers();

  if (!Config_getString("GENERATE_TAGFILE").isEmpty())
  {
    Doxygen::tagFile << "    <member kind=\"";
    Doxygen::tagFile << VerilogDocGen::convertTypeToString(memType);
     
    Doxygen::tagFile << "\">" << endl;
    Doxygen::tagFile << "      <type>" << convertToXML(mdef->typeString()) << "</type>" << endl;
    Doxygen::tagFile << "      <name>" << convertToXML(mdef->name()) << "</name>" << endl;
    Doxygen::tagFile << "      <anchorfile>" << convertToXML(mdef->getOutputFileBase()+Doxygen::htmlFileExtension) << "</anchorfile>" << endl;
    Doxygen::tagFile << "      <anchor>" << convertToXML(mdef->anchor()) << "</anchor>" << endl;
  
	if(memType==VerilogDocGen::FUNCTION)
		Doxygen::tagFile << "      <arglist>" << convertToXML(VhdlDocGen::convertArgumentListToString(mdef->argumentList().pointer(),true)) << "</arglist>" << endl;
    else if(memType==VerilogDocGen::ALWAYS)
		Doxygen::tagFile << "      <arglist>" << convertToXML(VhdlDocGen::convertArgumentListToString(mdef->argumentList().pointer(),false)) << "</arglist>" << endl;
	else{
	Doxygen::tagFile << "      <arglist>" << convertToXML(mdef->argsString()) << "</arglist>" << endl;
   Doxygen::tagFile << "      <arglist>" << convertToXML(mdef->typeString()) << "</arglist>" << endl; 
    }
	mdef->writeDocAnchorsToTagFile();
    Doxygen::tagFile << "    </member>" << endl;
 
  }
  
  // write search index info
  if (Config_getBool("SEARCHENGINE"))
  {
    Doxygen::searchIndex->setCurrentDoc(mdef->qualifiedName(),mdef->getOutputFileBase(),mdef->anchor());
    Doxygen::searchIndex->addWord(mdef->localName(),TRUE);
    Doxygen::searchIndex->addWord(mdef->qualifiedName(),FALSE);
  }

  QCString cname  = d->name();
  QCString cfname = mdef->getOutputFileBase();

 // HtmlHelp *htmlHelp=0;
//  bool hasHtmlHelp = Config_getBool("GENERATE_HTML") && Config_getBool("GENERATE_HTMLHELP");
//  if (hasHtmlHelp) htmlHelp = HtmlHelp::getInstance();

  // search for the last anonymous scope in the member type
  ClassDef *annoClassDef=mdef->getClassDefOfAnonymousType();

  // start a new member declaration
  bool isAnonymous = annoClassDef; // || m_impl->annMemb || m_impl->annEnumType;
  ///printf("startMemberItem for %s\n",name().data());
  ol.startMemberItem( isAnonymous ); //? 1 : m_impl->tArgList ? 3 : 0);


  // If there is no detailed description we need to write the anchor here.
  bool detailsVisible = mdef->isDetailedSectionLinkable();
  if (!detailsVisible) // && !m_impl->annMemb)
  {
     QCString doxyName=mdef->name().copy();
    if (!cname.isEmpty()) doxyName.prepend(cname+"::");
    QCString doxyArgs=mdef->argsString();
    ol.startDoxyAnchor(cfname,cname,mdef->anchor(),doxyName,doxyArgs);

    ol.pushGeneratorState();
    ol.disable(OutputGenerator::Man);
    ol.disable(OutputGenerator::Latex);
    ol.docify("\n");
    ol.popGeneratorState();
    
  }
// *** write type
     /*Verilog CHANGE */
   QCString ltype(mdef->typeString()); 
   QCString largs(mdef->argsString());
   VhdlDocGen::adjustRecordMember(mdef); 
   int mm=mdef->getMemberSpecifiers();

   ClassDef *kl=NULL;
   FileDef *fdd=NULL;
   LockingPtr<ArgumentList> alp = mdef->argumentList();
   QCString nn;
   if(gd)gd=NULL;
   switch(mm)
   {
   case VerilogDocGen::INCLUDE: 
     bool ambig;
     largs=mdef->name();
     fdd=findFileDef(Doxygen::inputNameDict,largs.data(),ambig);
     if(fdd){
      QCString fbb=fdd->getFileBase();
      fbb=fdd->getReference();
     fbb= fdd->getOutputFileBase();
     fbb=fdd->getSourceFileBase();
     fbb=fdd->convertNameToFile(largs.data(),true);
     fbb=fdd->getPath();
     fbb+=fdd->getOutputFileBase()+".html";
   
       ol.writeObjectLink(fdd->getReference(),
                     fdd->getOutputFileBase(),
		     0,
		     fdd->name());
	}
	else
	 VhdlDocGen::formatString(largs,ol,mdef);	
	
        break;
	case VerilogDocGen::FEATURE: 
       	ol.startBold();
        VhdlDocGen::writeLink(mdef,ol);
	    ol.insertMemberAlign();
		VhdlDocGen::formatString(largs,ol,mdef);
        ol.endBold();
		break;

	case VerilogDocGen::MODULE: 
       	ol.startBold();
        VhdlDocGen::formatString(ltype,ol,mdef);
        ol.endBold();
		ol.insertMemberAlign();
	   //writeLink(mdef,ol);
    case VerilogDocGen::PORT:
  //  case VerilogDocGen::TIME:
//	case VerilogDocGen::INTEGER:      
		  VhdlDocGen::writeLink(mdef,ol);
		 ol.insertMemberAlign();
		  if(largs.length()>0)
		    VhdlDocGen::formatString(largs,ol,mdef);
          if(ltype.length()>0)
		    VhdlDocGen::formatString(ltype,ol,mdef);	  
		  break;
    case VerilogDocGen::ALWAYS:
	     VhdlDocGen::writeLink(mdef,ol);  
	     ol.insertMemberAlign();
		 VhdlDocGen::writeProcessProto(ol,alp.pointer(),mdef);
		break;
   case VerilogDocGen::FUNCTION:
    case VerilogDocGen::TASK:      
         VhdlDocGen::writeLink(mdef,ol);  
	   	 ol.insertMemberAlign();
		 if(ltype.length()>0)
		    VhdlDocGen::formatString(ltype,ol,mdef);
	 	   writeFunctionProto(ol,alp.pointer(),mdef);
		 break;
   case VerilogDocGen::SIGNAL:
          if(largs.length()>0)
		    VhdlDocGen::formatString(largs,ol,mdef);
     
       	    ol.insertMemberAlign();
        
            VhdlDocGen::writeLink(mdef,ol);  
            ol.docify(" ");
	     if(ltype.length())
		    VhdlDocGen::formatString(ltype,ol,mdef);       
        break;
   case VerilogDocGen::INPUT:
   case VerilogDocGen::OUTPUT:
   case VerilogDocGen::INOUT:
   case VerilogDocGen::PARAMETER:   	    
         VhdlDocGen::writeLink(mdef,ol);  
	   	 ol.insertMemberAlign();
		 if(ltype.length()>0){
		    VhdlDocGen::formatString(ltype,ol,mdef);
	   	   ol.writeString("  ");
	    }
	  //ol.insertMemberAlign();
	  if(largs.length()>0)
		    VhdlDocGen::formatString(largs,ol,mdef);	 
	 	 break;
     case VerilogDocGen::COMPONENT:
		 //VhdlDocGen::writeLink(mdef,ol);
        if(true)
		{
		nn=mdef->name().lower();
		kl=getClass(ltype);
	  //if(kl==NULL){
	    ol.startBold();
	    QCString inst=ltype+"::"+mdef->name();
          ol.writeObjectLink(mdef->getReference(),
                     mdef->getOutputFileBase(),
		     mdef->anchor(),
		     inst.data());
        ol.docify("  ");
        ol.endBold();
       //}
       	ol.insertMemberAlign();
	
		if(kl) {
			nn=kl->getOutputFileBase();
		
		ol.pushGeneratorState();
        ol.disableAllBut(OutputGenerator::Html);
         ol.docify("   ");
        QCString name=VerilogDocGen::getClassTitle(kl);
	     name=VhdlDocGen::getIndexWord(name.data(),1);
	    // ol.insertMemberAlign();
	 
	     ol.startBold();
		ol.docify(name.data());
		ol.endBold();
		ol.startEmphasis();
		   ol.docify(" ");
      
	    ol.writeObjectLink(kl->getReference(),kl->getOutputFileBase(),0,ltype);
	    ol.endEmphasis();
        ol.popGeneratorState();
		}
        } 
		break;
  default: break;
   }

   bool htmlOn = ol.isEnabled(OutputGenerator::Html);
  if (htmlOn && Config_getBool("HTML_ALIGN_MEMBERS") && !ltype.isEmpty())
  {
    ol.disable(OutputGenerator::Html);
  }
  if (!ltype.isEmpty()) ol.docify(" ");
  
  if (htmlOn) 
  {
    ol.enable(OutputGenerator::Html);
  }

  if (!detailsVisible)// && !m_impl->annMemb)
  {
    ol.endDoxyAnchor(cfname,mdef->anchor());
  }

  //printf("endMember %s annoClassDef=%p annEnumType=%p\n",
  //    name().data(),annoClassDef,annEnumType);
  ol.endMemberItem();
   if (!mdef->briefDescription().isEmpty() &&   Config_getBool("BRIEF_MEMBER_DESC") /* && !annMemb */)
  {
    ol.startMemberDescription();
    ol.parseDoc(mdef->briefFile(),mdef->briefLine(),mdef->getOuterScope()?mdef->getOuterScope():d,mdef,mdef->briefDescription(),TRUE,FALSE);
    if (detailsVisible) 
    {
      ol.pushGeneratorState();
      ol.disableAllBut(OutputGenerator::Html);
      //ol.endEmphasis();
      ol.docify(" ");
      if (mdef->getGroupDef()!=0 && gd==0) // forward link to the group
      {
        ol.startTextLink(mdef->getOutputFileBase(),mdef->anchor());
      }
      else // local link
      {
        ol.startTextLink(0,mdef->anchor());
      }
      ol.endTextLink();
      //ol.startEmphasis();
      ol.popGeneratorState();
    }
    //ol.newParagraph();

    ol.endMemberDescription();
     if(VhdlDocGen::isComponent(mdef))
      ol.lineBreak();
  }
   mdef->warnIfUndocumented();

  }// end writeVerilogDeclaration


// returns the name of module/primitive

QCString VerilogDocGen::getClassTitle(const ClassDef* cdef){
if(cdef->protection()==Public)
  return cdef->className()+" Module";
return cdef->className()+" Primitive";
}// getClassTitle


//-----------------< Code Parsing >------------------------------------------------


MemberDef* VerilogDocGen::findMember(QCString& className, QCString& memName,int type)
{
	ClassDef* cd;
	MemberDef *mdef=NULL;
	bool feat=false;

	cd=getClass(className.data());
    if(!cd) return NULL;

	 mdef=VerilogDocGen::findMemberDef(cd,memName,MemberList::variableMembers,type,feat);
     if(mdef) return mdef;
  	
  // if(memName.contains('`')){
     memName.stripPrefix("`");
     mdef=VerilogDocGen::findMemberDef(cd,memName,MemberList:: pubMethods,type,feat);
    if(mdef) return mdef;
  
     QCString file=VerilogDocGen::getFileNameFromString(cd->getDefFileName().data());
     mdef = findGlobalMember(file,memName);
	return mdef;

}//findMember


 MemberDef* VerilogDocGen::findMemberDef(ClassDef* cd,QCString& key,MemberList::ListType type,int spec,bool def)
 {
	 static QRegExp regg("[_a-zA-Z]");
	 MemberDef *md=NULL;
 
     MemberList *ml=	cd->getMemberList(type);
     if(ml==NULL) return NULL;
	 
	   MemberListIterator fmni(*ml);
      
	    for (fmni.toFirst();(md=fmni.current());++fmni)
        {
          QCString nn(md->name());
		  int j=nn.find(regg,0);
          if (j>0)
          {
           nn=nn.mid(j,nn.length());
          }
		  if(spec!=-1){ 
		  if((stricmp(key.data(),nn.data())==0) && (md->getMemberSpecifiers()==spec)) 
			  return md;
			  }
          else {
                 if(stricmp(key.data(),nn.data())==0) 
			     return md;
		       }
        } 

 return NULL;

}//findMemberDef


MemberDef* VerilogDocGen::findDefinition(ClassDef *cd, QCString& memName){
 MemberDef *md;
 MemberList *ml=	cd->getMemberList(MemberList::variableMembers);
  if(ml==NULL) return NULL;
    MemberListIterator fmni(*ml);
     
	    for (fmni.toFirst();(md=fmni.current());++fmni)
        {
            if(md->getMemberSpecifiers()==VerilogDocGen::INCLUDE){
          
		
			ClassDef* cdef=getClass(md->name());
			 if(cdef){	 
			    MemberDef* mdd=VerilogDocGen::findMemberDef(cdef,memName,MemberList::variableMembers,-1,false);
               MemberList *ml=	cdef->getMemberList(MemberList::variableMembers);
			   assert(ml);
			   if(mdd) return mdd;
			  MemberListIterator fmni(*ml);
      

			  //assert(false);
			 }
		  }
		}//for
 return NULL;
}//findDefinition

/*
MemberName* VerilogDocGen::findMemberNameSDict(QCString& mName,const QCString& className) 
{
MemberName *mn=0;
MemberDef *md;
  MemberNameSDict::Iterator mnli(*Doxygen::memberNameSDict);
  // for each member name
  for (mnli.toFirst();(mn=mnli.current());++mnli)
  {
    QCString temp(mn->memberName());
    VhdlDocGen::adjustMemberName(temp);
    if(stricmp(mName.data(),temp.data())==0){
      MemberNameIterator mni(*mn);
      for (mni.toFirst();(md=mni.current());++mni)
      {
        ClassDef *cd=md->getClassDef();
        if(cd){
         QCString nn=cd->displayName();
         if(stricmp(nn.data(),className.data())==0)
          return mn;
        }
      }
    }//if 
  }
  
  return 0;
  }//findMemberNameSdict
*/

void VerilogDocGen::initEntry(Entry *e)
{
  e->fileName +=getVerilogParsingFile();
  initGroupInfo(e);
}


 /*!
 * writes a function/Task prototype to the output
 */

void writeFunctionProto(OutputList& ol,const ArgumentList* al,const MemberDef* mdef)
{
  if (al==0) return;
  ArgumentListIterator ali(*al);
  Argument *arg;
  bool sem=FALSE;
  int len=al->count();
  ol.startBold();
  ol.docify(" ( ");    
  ol.endBold();
  if (len>2)
  {
    ol.lineBreak();
  }
  for (;(arg=ali.current());++ali)
  {
    ol.startBold();
    if (sem && len < 3)
    {
      ol.docify(" , ");
    }
   

    QCString nn=arg->name;
    VerilogDocGen::adjustMemberName(nn);
    nn+=" ";
    VhdlDocGen::startFonts(nn,"vhdlchar",ol);
    QCString qargs=arg->type;
    QCString att=arg->defval;
    if (!att.isEmpty()) 
    { 
      int str=VerilogDocGen::findKeyWord(att.data());
      att+=" ";
      if (str==0)
	VhdlDocGen::formatString(att,ol,mdef);
      else
	VhdlDocGen::startFonts(att,"vhdlchar",ol);         
    }  
ol.docify(" : ");
    //VhdlDocGen::startFonts("in ","stringliteral",ol);
    int str=VerilogDocGen::findKeyWord(qargs.data());
    ol.startEmphasis();
    if (str==0)
      VhdlDocGen::formatString(qargs,ol,mdef);
    else
      VhdlDocGen::startFonts(qargs,"vhdlkeyword",ol);         
     ol.endEmphasis();
     sem=TRUE;    
    ol.endBold();
    if (len > 2)    
    {
      ol.lineBreak();
    }
  }
  ol.startBold();    
  ol.docify(" )");    
  const char *exp=mdef->excpString();
  if(exp)
  {
    ol.insertMemberAlign();
    ol.docify("[ ");
    ol.docify(exp);
    ol.docify(" ]");
  }
  ol.endBold();  
}
 
  QCString VerilogDocGen::getFileNameFromString(const char* fileName){
  
  QCString qfile(fileName);
    QStringList ql=QStringList::split('/',qfile);
    return (QCString)ql.last();
  
  }