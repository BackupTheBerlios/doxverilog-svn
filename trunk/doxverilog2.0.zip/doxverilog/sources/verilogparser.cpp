/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for GLR parsing with Bison,
   Copyright (C) 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* This is the parser code for GLR (Generalized LR) parser. */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "glr.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 1

/* Substitute the variable and function names.  */
#define yyparse c_parse
#define yylex   c_lex
#define yyerror c_error
#define yylval  c_lval
#define yychar  c_char
#define yydebug c_debug
#define yynerrs c_nerrs
#define yylloc c_lloc

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NET_TOK = 258,
     STR0_TOK = 259,
     STR1_TOK = 260,
     GATE_TOK = 261,
     STRING_TOK = 262,
     DIGIT_TOK = 263,
     UNDERSCORE_TOK = 264,
     SEM_TOK = 265,
     DOT_TOK = 266,
     LETTER_TOK = 267,
     PLUS_TOK = 268,
     MINUS_TOK = 269,
     COLON_TOK = 270,
     LBRACE_TOK = 271,
     RBRACE_TOK = 272,
     LBRACKET_TOK = 273,
     RBRACKET_TOK = 274,
     AND_TOK = 275,
     OR_TOK = 276,
     EQU_TOK = 277,
     GT_TOK = 278,
     LT_TOK = 279,
     NOT_TOK = 280,
     MULT_TOK = 281,
     PERCENTAL_TOK = 282,
     ENV_TOK = 283,
     PARA_TOK = 284,
     CHAR_TOK = 285,
     AT_TOK = 286,
     DOLLAR_TOK = 287,
     BASE_TOK = 288,
     SN_TOK = 289,
     EXCLAMATION_TOK = 290,
     RRAM_TOK = 291,
     LRAM_TOK = 292,
     PARAMETER_TOK = 293,
     OUTPUT_TOK = 294,
     INOUT_TOK = 295,
     SMALL_TOK = 296,
     MEDIUM_TOK = 297,
     LARGE_TOK = 298,
     VEC_TOK = 299,
     SCALAR_TOK = 300,
     REG_TOK = 301,
     TIME_TOK = 302,
     REAL_TOK = 303,
     EVENT_TOK = 304,
     ASSIGN_TOK = 305,
     DEFPARAM_TOK = 306,
     MODUL_TOK = 307,
     ENDMODUL_TOK = 308,
     MACRO_MODUL_TOK = 309,
     ENDPRIMITIVE_TOK = 310,
     PRIMITIVE_TOK = 311,
     INITIAL_TOK = 312,
     TABLE_TOK = 313,
     ENDTABLE_TOK = 314,
     ALWAYS_TOK = 315,
     TASK_TOK = 316,
     ENDTASK_TOK = 317,
     FUNC_TOK = 318,
     ENDFUNC_TOK = 319,
     IF_TOK = 320,
     CASE_TOK = 321,
     CASEX_TOK = 322,
     CASEZ_TOK = 323,
     FOREVER_TOK = 324,
     REPEAT_TOK = 325,
     FOR_TOK = 326,
     JOIN_TOK = 327,
     WAIT_TOK = 328,
     FORCE_TOK = 329,
     RELEASE_TOK = 330,
     DEASSIGN_TOK = 331,
     DISABLE_TOK = 332,
     WHILE_TOK = 333,
     ELSE_TOK = 334,
     ENDCASE_TOK = 335,
     BEGIN_TOK = 336,
     DEFAULT_TOK = 337,
     FORK_TOK = 338,
     END_TOK = 339,
     SPECIFY_TOK = 340,
     ENDSPECIFY_TOK = 341,
     SPECPARAM_TOK = 342,
     DSETUP_TOK = 343,
     DHOLD_TOK = 344,
     DWIDTH_TOK = 345,
     DPERIOD_TOK = 346,
     DSKEW_TOK = 347,
     DRECOVERY_TOK = 348,
     DSETUPHOLD_TOK = 349,
     POSEDGE_TOK = 350,
     NEGEDGE_TOK = 351,
     EDGE_TOK = 352,
     COMMA_TOK = 353,
     QUESTION_TOK = 354,
     AUTO_TOK = 355,
     INPUT_TOK = 356,
     SIGNED_TOK = 357,
     LOCALPARAM_TOK = 358,
     INTEGER_TOK = 359,
     NOCHANGE_TOK = 360,
     GENERATE_TOK = 361,
     ENDGENERATE_TOK = 362,
     GENVAR_TOK = 363,
     LIBRARY_TOK = 364,
     CONFIG_TOK = 365,
     ENDCONFIG_TOK = 366,
     INCLUDE_TOK = 367,
     PULSEON_DETECT_TOK = 368,
     PULSEONE_EVENT_TOK = 369,
     USE_TOK = 370,
     LIBLIST_TOK = 371,
     INSTANCE_TOK = 372,
     CELL_TOK = 373,
     SHOWCANCEL_TOK = 374,
     NOSHOWCANCEL_TOK = 375,
     REMOVAL_TOK = 376,
     FULLSKEW_TOK = 377,
     TIMESKEW_TOK = 378,
     RECREM_TOK = 379,
     IFNONE_TOK = 380,
     REALTIME_TOK = 381,
     DESIGN_TOK = 382,
     ATL_TOK = 383,
     ATR_TOK = 384,
     OOR_TOK = 385,
     AAND_TOK = 386,
     SNNOT_TOK = 387,
     NOTSN_TOK = 388,
     AAAND_TOK = 389
   };
#endif
/* Tokens.  */
#define NET_TOK 258
#define STR0_TOK 259
#define STR1_TOK 260
#define GATE_TOK 261
#define STRING_TOK 262
#define DIGIT_TOK 263
#define UNDERSCORE_TOK 264
#define SEM_TOK 265
#define DOT_TOK 266
#define LETTER_TOK 267
#define PLUS_TOK 268
#define MINUS_TOK 269
#define COLON_TOK 270
#define LBRACE_TOK 271
#define RBRACE_TOK 272
#define LBRACKET_TOK 273
#define RBRACKET_TOK 274
#define AND_TOK 275
#define OR_TOK 276
#define EQU_TOK 277
#define GT_TOK 278
#define LT_TOK 279
#define NOT_TOK 280
#define MULT_TOK 281
#define PERCENTAL_TOK 282
#define ENV_TOK 283
#define PARA_TOK 284
#define CHAR_TOK 285
#define AT_TOK 286
#define DOLLAR_TOK 287
#define BASE_TOK 288
#define SN_TOK 289
#define EXCLAMATION_TOK 290
#define RRAM_TOK 291
#define LRAM_TOK 292
#define PARAMETER_TOK 293
#define OUTPUT_TOK 294
#define INOUT_TOK 295
#define SMALL_TOK 296
#define MEDIUM_TOK 297
#define LARGE_TOK 298
#define VEC_TOK 299
#define SCALAR_TOK 300
#define REG_TOK 301
#define TIME_TOK 302
#define REAL_TOK 303
#define EVENT_TOK 304
#define ASSIGN_TOK 305
#define DEFPARAM_TOK 306
#define MODUL_TOK 307
#define ENDMODUL_TOK 308
#define MACRO_MODUL_TOK 309
#define ENDPRIMITIVE_TOK 310
#define PRIMITIVE_TOK 311
#define INITIAL_TOK 312
#define TABLE_TOK 313
#define ENDTABLE_TOK 314
#define ALWAYS_TOK 315
#define TASK_TOK 316
#define ENDTASK_TOK 317
#define FUNC_TOK 318
#define ENDFUNC_TOK 319
#define IF_TOK 320
#define CASE_TOK 321
#define CASEX_TOK 322
#define CASEZ_TOK 323
#define FOREVER_TOK 324
#define REPEAT_TOK 325
#define FOR_TOK 326
#define JOIN_TOK 327
#define WAIT_TOK 328
#define FORCE_TOK 329
#define RELEASE_TOK 330
#define DEASSIGN_TOK 331
#define DISABLE_TOK 332
#define WHILE_TOK 333
#define ELSE_TOK 334
#define ENDCASE_TOK 335
#define BEGIN_TOK 336
#define DEFAULT_TOK 337
#define FORK_TOK 338
#define END_TOK 339
#define SPECIFY_TOK 340
#define ENDSPECIFY_TOK 341
#define SPECPARAM_TOK 342
#define DSETUP_TOK 343
#define DHOLD_TOK 344
#define DWIDTH_TOK 345
#define DPERIOD_TOK 346
#define DSKEW_TOK 347
#define DRECOVERY_TOK 348
#define DSETUPHOLD_TOK 349
#define POSEDGE_TOK 350
#define NEGEDGE_TOK 351
#define EDGE_TOK 352
#define COMMA_TOK 353
#define QUESTION_TOK 354
#define AUTO_TOK 355
#define INPUT_TOK 356
#define SIGNED_TOK 357
#define LOCALPARAM_TOK 358
#define INTEGER_TOK 359
#define NOCHANGE_TOK 360
#define GENERATE_TOK 361
#define ENDGENERATE_TOK 362
#define GENVAR_TOK 363
#define LIBRARY_TOK 364
#define CONFIG_TOK 365
#define ENDCONFIG_TOK 366
#define INCLUDE_TOK 367
#define PULSEON_DETECT_TOK 368
#define PULSEONE_EVENT_TOK 369
#define USE_TOK 370
#define LIBLIST_TOK 371
#define INSTANCE_TOK 372
#define CELL_TOK 373
#define SHOWCANCEL_TOK 374
#define NOSHOWCANCEL_TOK 375
#define REMOVAL_TOK 376
#define FULLSKEW_TOK 377
#define TIMESKEW_TOK 378
#define RECREM_TOK 379
#define IFNONE_TOK 380
#define REALTIME_TOK 381
#define DESIGN_TOK 382
#define ATL_TOK 383
#define ATR_TOK 384
#define OOR_TOK 385
#define AAND_TOK 386
#define SNNOT_TOK 387
#define NOTSN_TOK 388
#define AAAND_TOK 389




/* Copy the first part of user declarations.  */
#line 33 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "verilogdocgen.h"
#include "membergroup.h"
//#include "verilogparser.hpp"
#include "vhdldocgen.h"
#include "doxygen.h"
#include "searchindex.h"
#include "verilogscanner.h"
#include "commentscan.h"

#define YYMAXDEPTH 15000

static MyParserConv* myconv=0;

static int CurrState;
static int          currVerilogType;
static Entry*       current=0;
static Entry*		current_rootVerilog  ;
static Entry*		currentVerilog=0  ;
static Entry*       currentFunctionVerilog=0;
static Entry*       lastModule=0;

static Entry        prevDocEntryVerilog;

static bool         parseCode=FALSE; 

static QCString     currVerilogClass;
static QCString     identVerilog; // last written word
static QCString     currVerilogInst;

int c_lex (void);
void c_error (char const *);


// functions for  verilog parser ---------------------

static void parseString();
static void writeDigit();
static void initVerilogParser();
static void parseModule();
static void parseFunction(Entry* e);
static void parseReg(Entry* e);
static void parsePortDir(Entry* e,int type);
static void parseParam(Entry* e);
static void parseListOfPorts();
static void parseAlways(bool b=false);
static void parseModuleInst(QCString& first,QCString& sec);

bool findExtendsComponent(QList<BaseInfo> *extend,QCString& compName);
void addSubEntry(Entry* root, Entry* e);


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 89 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
typedef union YYSTYPE {
	int itype;	/* for count */
	char ctype;	/* for char */
	char cstr[1024];
	} YYSTYPE;
/* Line 186 of glr.c.  */
#line 410 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.cpp"
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{

  int first_line;
  int first_column;
  int last_line;
  int last_column;

} YYLTYPE;
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

/* Default (constant) value used for initialization for null
   right-hand sides.  Unlike the standard yacc.c template,
   here we set the default value of $$ to a zeroed-out value.
   Since the default value is undefined, this behavior is
   technically correct. */
static YYSTYPE yyval_default;

/* Copy the second part of user declarations.  */


/* Line 217 of glr.c.  */
#line 440 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.cpp"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

#ifndef YYFREE
# define YYFREE free
#endif
#ifndef YYMALLOC
# define YYMALLOC malloc
#endif
#ifndef YYREALLOC
# define YYREALLOC realloc
#endif

#define YYSIZEMAX ((size_t) -1)

#ifdef __cplusplus
   typedef bool yybool;
#else
   typedef unsigned char yybool;
#endif
#define yytrue 1
#define yyfalse 0

#ifndef YYSETJMP
# include <setjmp.h>
# define YYJMP_BUF jmp_buf
# define YYSETJMP(env) setjmp (env)
# define YYLONGJMP(env, val) longjmp (env, val)
#endif

/*-----------------.
| GCC extensions.  |
`-----------------*/

#ifndef __attribute__
/* This feature is available in gcc versions 2.5 and later.  */
# if (!defined (__GNUC__) || __GNUC__ < 2 \
      || (__GNUC__ == 2 && __GNUC_MINOR__ < 5) || __STRICT_ANSI__)
#  define __attribute__(Spec) /* empty */
# endif
#endif

#define YYOPTIONAL_LOC(Name) Name

#ifndef YYASSERT
# define YYASSERT(condition) ((void) ((condition) || (abort (), 0)))
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  14
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   4990

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  135
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  318
/* YYNRULES -- Number of rules. */
#define YYNRULES  793
/* YYNRULES -- Number of states. */
#define YYNSTATES  1739
/* YYMAXRHS -- Maximum number of symbols on right-hand side of rule. */
#define YYMAXRHS 25
/* YYMAXLEFT -- Maximum number of symbols to the left of a handle
   accessed by $0, $-1, etc., in any rule. */
#define YYMAXLEFT 0

/* YYTRANSLATE(X) -- Bison symbol number corresponding to X.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   389

#define YYTRANSLATE(YYX)						\
  ((YYX <= 0) ? YYEOF :							\
   (unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short int yyprhs[] =
{
       0,     0,     3,     5,     6,     9,    12,    14,    16,    18,
      20,    22,    25,    27,    29,    35,    39,    46,    52,    56,
      60,    62,    65,    69,    73,    77,    81,    85,    87,    90,
      93,    96,    98,   101,   105,   106,   109,   111,   113,   115,
     121,   126,   133,   140,   147,   154,   161,   169,   177,   185,
     187,   189,   191,   194,   195,   198,   200,   203,   204,   210,
     214,   215,   219,   220,   226,   227,   232,   233,   238,   242,
     246,   248,   252,   254,   259,   265,   267,   271,   275,   277,
     279,   281,   286,   291,   294,   297,   300,   303,   305,   308,
     312,   315,   318,   321,   324,   327,   330,   333,   336,   339,
     342,   345,   348,   351,   353,   355,   357,   359,   361,   363,
     365,   367,   369,   371,   372,   377,   381,   382,   388,   389,
     395,   396,   401,   402,   408,   409,   416,   420,   421,   426,
     427,   433,   434,   441,   442,   448,   449,   455,   459,   464,
     468,   472,   473,   479,   480,   487,   493,   500,   501,   507,
     508,   515,   521,   528,   529,   534,   535,   539,   540,   543,
     548,   552,   558,   563,   565,   567,   569,   571,   573,   575,
     578,   581,   584,   586,   590,   594,   598,   602,   606,   610,
     617,   624,   632,   640,   649,   657,   665,   673,   682,   690,
     694,   695,   697,   699,   701,   705,   709,   710,   715,   719,
     725,   730,   734,   735,   740,   744,   746,   749,   755,   761,
     765,   769,   773,   777,   782,   785,   787,   791,   793,   795,
     797,   799,   801,   805,   808,   813,   815,   819,   821,   825,
     827,   829,   833,   835,   839,   842,   844,   846,   850,   852,
     856,   860,   864,   868,   874,   880,   890,   903,   907,   909,
     910,   912,   914,   916,   918,   920,   921,   923,   924,   926,
     928,   931,   933,   936,   939,   943,   951,   958,   969,   979,
     983,   985,   988,   990,   993,   995,   997,  1000,  1002,  1006,
    1008,  1014,  1018,  1023,  1030,  1038,  1039,  1041,  1042,  1044,
    1045,  1047,  1051,  1055,  1059,  1063,  1065,  1069,  1074,  1080,
    1084,  1088,  1095,  1103,  1109,  1113,  1115,  1117,  1119,  1121,
    1124,  1127,  1130,  1133,  1136,  1139,  1142,  1145,  1150,  1156,
    1160,  1162,  1166,  1168,  1171,  1176,  1180,  1185,  1191,  1195,
    1199,  1201,  1205,  1207,  1211,  1218,  1224,  1229,  1233,  1236,
    1238,  1240,  1242,  1243,  1244,  1251,  1252,  1257,  1259,  1263,
    1268,  1274,  1276,  1278,  1280,  1284,  1286,  1288,  1292,  1298,
    1303,  1308,  1312,  1315,  1317,  1319,  1321,  1325,  1328,  1330,
    1334,  1337,  1338,  1343,  1347,  1349,  1352,  1354,  1356,  1358,
    1360,  1362,  1364,  1366,  1372,  1380,  1387,  1389,  1393,  1397,
    1401,  1404,  1418,  1422,  1428,  1432,  1436,  1442,  1453,  1464,
    1466,  1468,  1472,  1476,  1478,  1482,  1486,  1488,  1491,  1494,
    1497,  1500,  1503,  1507,  1512,  1519,  1523,  1527,  1531,  1535,
    1539,  1541,  1545,  1549,  1554,  1556,  1559,  1564,  1571,  1577,
    1581,  1583,  1585,  1587,  1590,  1593,  1597,  1602,  1607,  1609,
    1611,  1613,  1615,  1617,  1619,  1621,  1623,  1629,  1634,  1638,
    1640,  1644,  1651,  1657,  1659,  1665,  1670,  1674,  1679,  1681,
    1685,  1689,  1692,  1696,  1697,  1701,  1705,  1710,  1714,  1718,
    1721,  1727,  1732,  1737,  1740,  1743,  1746,  1749,  1752,  1756,
    1758,  1761,  1765,  1772,  1778,  1783,  1786,  1788,  1791,  1795,
    1799,  1806,  1812,  1815,  1820,  1824,  1825,  1830,  1837,  1843,
    1846,  1851,  1855,  1857,  1860,  1864,  1867,  1870,  1873,  1876,
    1879,  1883,  1886,  1890,  1893,  1896,  1899,  1902,  1904,  1906,
    1910,  1913,  1916,  1919,  1922,  1925,  1928,  1930,  1933,  1936,
    1941,  1943,  1945,  1946,  1953,  1957,  1960,  1965,  1968,  1973,
    1977,  1982,  1984,  1987,  1990,  1992,  1996,  2000,  2003,  2009,
    2015,  2023,  2031,  2037,  2045,  2052,  2059,  2066,  2070,  2077,
    2081,  2083,  2086,  2090,  2094,  2097,  2100,  2106,  2112,  2122,
    2125,  2131,  2137,  2147,  2153,  2159,  2162,  2164,  2168,  2171,
    2173,  2177,  2180,  2184,  2186,  2189,  2191,  2193,  2195,  2197,
    2199,  2203,  2207,  2211,  2215,  2219,  2223,  2226,  2229,  2232,
    2236,  2243,  2249,  2256,  2258,  2262,  2264,  2268,  2272,  2274,
    2279,  2284,  2286,  2290,  2292,  2298,  2306,  2320,  2346,  2348,
    2352,  2356,  2363,  2369,  2380,  2390,  2396,  2404,  2406,  2408,
    2410,  2416,  2422,  2425,  2427,  2429,  2431,  2433,  2435,  2437,
    2439,  2441,  2443,  2445,  2447,  2449,  2451,  2463,  2473,  2485,
    2495,  2509,  2521,  2533,  2543,  2548,  2560,  2570,  2574,  2588,
    2600,  2612,  2622,  2634,  2644,  2656,  2666,  2678,  2692,  2704,
    2712,  2720,  2730,  2732,  2736,  2738,  2740,  2742,  2744,  2749,
    2752,  2756,  2758,  2760,  2762,  2764,  2766,  2771,  2774,  2777,
    2780,  2783,  2785,  2789,  2791,  2793,  2797,  2804,  2808,  2810,
    2814,  2819,  2824,  2828,  2830,  2832,  2836,  2841,  2845,  2850,
    2852,  2856,  2861,  2866,  2868,  2872,  2875,  2880,  2886,  2888,
    2891,  2895,  2897,  2899,  2901,  2903,  2906,  2910,  2912,  2916,
    2921,  2927,  2929,  2935,  2937,  2939,  2941,  2943,  2945,  2947,
    2949,  2952,  2954,  2956,  2959,  2961,  2963,  2965,  2967,  2970,
    2974,  2977,  2981,  2983,  2985,  2987,  2989,  2992,  2995,  2998,
    3001,  3003,  3005,  3007,  3009,  3011,  3013,  3015,  3017,  3020,
    3024,  3028,  3033,  3036,  3038,  3040,  3042,  3044,  3046,  3048,
    3051,  3055,  3059,  3060,  3064,  3068,  3070,  3074,  3078,  3080,
    3082,  3086,  3088,  3090
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short int yyrhs[] =
{
     136,     0,    -1,   137,    -1,    -1,   138,   154,    -1,   137,
     154,    -1,   178,    -1,   140,    -1,   141,    -1,   143,    -1,
     144,    -1,   109,    10,    -1,   450,    -1,     7,    -1,   112,
      23,   142,    24,    10,    -1,   112,     1,    10,    -1,   110,
     450,    10,   145,   146,   111,    -1,   110,   450,    10,   145,
     111,    -1,   127,   148,    10,    -1,   127,     1,    10,    -1,
     147,    -1,   146,   147,    -1,    82,   151,    10,    -1,   149,
     151,    10,    -1,   149,   152,    10,    -1,   150,   151,    10,
      -1,   150,   152,    10,    -1,   450,    -1,   148,   450,    -1,
     117,   450,    -1,   118,   450,    -1,   116,    -1,   116,   148,
      -1,   115,   450,   153,    -1,    -1,    15,   110,    -1,   155,
      -1,   308,    -1,   139,    -1,   447,   158,    10,   161,   159,
      -1,   447,   158,    10,   159,    -1,   447,   158,   162,    10,
     161,   159,    -1,   447,   158,   168,    10,   161,   159,    -1,
     447,   158,   170,    10,   161,   159,    -1,   447,   158,   170,
      10,     1,   159,    -1,   447,   158,   168,    10,     1,   159,
      -1,   447,   158,    16,    17,    10,   161,   159,    -1,   447,
     158,   162,   168,    10,   161,   159,    -1,   447,   158,   162,
     170,    10,   161,   159,    -1,   451,    -1,    52,    -1,    54,
      -1,   157,   156,    -1,    -1,   160,    53,    -1,   177,    -1,
     161,   177,    -1,    -1,    29,    16,   163,   164,    17,    -1,
      29,     1,    17,    -1,    -1,    38,   165,   239,    -1,    -1,
     164,    98,    38,   166,   239,    -1,    -1,   164,    98,   167,
     239,    -1,    -1,    16,   169,   171,    17,    -1,    16,     1,
      17,    -1,    16,   256,    17,    -1,   172,    -1,   171,    98,
     172,    -1,   173,    -1,    11,   173,    16,    17,    -1,    11,
     173,    16,   173,    17,    -1,   175,    -1,    37,   174,    36,
      -1,   174,    98,   175,    -1,   175,    -1,   451,    -1,     8,
      -1,   451,    18,   435,    19,    -1,   451,    18,   431,    19,
      -1,   447,   195,    -1,   447,   198,    -1,   447,   201,    -1,
       1,    10,    -1,   178,    -1,   176,    10,    -1,   176,     1,
      10,    -1,   447,   296,    -1,   447,   182,    -1,   447,   188,
      -1,   447,   375,    -1,   447,   194,    -1,   447,   179,    -1,
     447,   180,    -1,   447,   334,    -1,   447,   270,    -1,   447,
     330,    -1,   447,   277,    -1,   447,   337,    -1,   447,   338,
      -1,   211,    -1,   217,    -1,   210,    -1,   214,    -1,   218,
      -1,   215,    -1,   208,    -1,   209,    -1,   251,    -1,   243,
      -1,    -1,    51,   181,   233,    10,    -1,    51,     1,    10,
      -1,    -1,   103,   242,   183,   233,    10,    -1,    -1,   103,
     265,   184,   233,    10,    -1,    -1,   103,   185,   233,    10,
      -1,    -1,   103,   443,   186,   233,    10,    -1,    -1,   103,
     443,   242,   187,   233,    10,    -1,   103,     1,    10,    -1,
      -1,    38,   189,   233,    10,    -1,    -1,    38,   265,   190,
     233,    10,    -1,    -1,    38,   443,   242,   191,   233,    10,
      -1,    -1,    38,   242,   192,   233,    10,    -1,    -1,    38,
     443,   193,   233,    10,    -1,    38,     1,    10,    -1,    87,
     242,   236,    10,    -1,    87,   236,    10,    -1,    87,     1,
      10,    -1,    -1,    40,   247,   260,   196,   451,    -1,    -1,
      40,   207,   247,   260,   197,   451,    -1,   195,    98,   247,
     260,   451,    -1,   195,    98,   207,   247,   260,   451,    -1,
      -1,   101,   247,   260,   199,   451,    -1,    -1,   101,   207,
     247,   260,   200,   451,    -1,   198,    98,   247,   260,   451,
      -1,   198,    98,   207,   247,   260,   451,    -1,    -1,    39,
     206,   202,   451,    -1,    -1,    39,   203,   451,    -1,    -1,
      39,   204,    -1,   201,    98,    39,   336,    -1,   201,    98,
     451,    -1,   201,    98,    39,   206,   451,    -1,   201,    98,
      39,   451,    -1,    47,    -1,   104,    -1,   207,    -1,   242,
      -1,   443,    -1,    46,    -1,   206,   102,    -1,   206,   242,
      -1,   206,   205,    -1,     3,    -1,    49,   227,    10,    -1,
      49,     1,    10,    -1,   108,   230,    10,    -1,   108,     1,
      10,    -1,   104,   237,    10,    -1,   104,     1,    10,    -1,
       3,   212,   247,   260,   232,    10,    -1,     3,   212,   247,
     260,   231,    10,    -1,     3,   212,   247,   260,   223,   231,
      10,    -1,     3,   212,   247,   260,   223,   232,    10,    -1,
       3,   221,   212,   247,   260,   223,   231,    10,    -1,     3,
     221,   212,   247,   260,   231,    10,    -1,     3,   221,   212,
     247,   260,   232,    10,    -1,     3,   222,   212,   247,   260,
     232,    10,    -1,     3,   222,   212,   247,   260,   223,   232,
      10,    -1,     3,   222,   212,   247,   260,   231,    10,    -1,
       3,     1,    10,    -1,    -1,   213,    -1,    44,    -1,    45,
      -1,    48,   237,    10,    -1,    48,     1,    10,    -1,    -1,
     126,   216,   237,    10,    -1,   126,     1,    10,    -1,    46,
     247,   242,   237,    10,    -1,    46,   247,   237,    10,    -1,
      46,     1,    10,    -1,    -1,    47,   219,   237,    10,    -1,
      47,     1,    10,    -1,   241,    -1,   220,   241,    -1,    16,
       4,    98,     5,    17,    -1,    16,     5,    98,     4,    17,
      -1,    16,     1,    17,    -1,    16,    41,    17,    -1,    16,
      42,    17,    -1,    16,    43,    17,    -1,    29,    16,   224,
      17,    -1,    29,   226,    -1,   226,    -1,   224,    98,   226,
      -1,   223,    -1,   436,    -1,   228,    -1,   229,    -1,   451,
      -1,   228,    98,   451,    -1,   451,   220,    -1,   229,    98,
     451,   220,    -1,   451,    -1,   230,    98,   451,    -1,   238,
      -1,   231,    98,   238,    -1,   227,    -1,   239,    -1,   233,
      98,   239,    -1,   451,    -1,   451,    22,   435,    -1,   451,
     220,    -1,   234,    -1,   240,    -1,   236,    98,   240,    -1,
     235,    -1,   237,    98,   235,    -1,   451,    22,   435,    -1,
     450,    22,   435,    -1,   451,    22,   436,    -1,    18,   430,
      15,   430,    19,    -1,    18,   438,    15,   437,    19,    -1,
      63,   246,   247,   245,   244,    10,   248,   354,    64,    -1,
      63,   246,   247,   245,   244,    16,   250,    17,    10,   253,
     354,    64,    -1,    63,     1,    64,    -1,   451,    -1,    -1,
     242,    -1,   104,    -1,    48,    -1,    47,    -1,   126,    -1,
      -1,   100,    -1,    -1,   102,    -1,   249,    -1,   248,   249,
      -1,   266,    -1,   263,    10,    -1,   447,   264,    -1,   250,
      98,   264,    -1,    61,   246,   252,    10,   254,   351,    62,
      -1,    61,   246,   252,    10,   351,    62,    -1,    61,   246,
     252,    16,   256,    17,    10,   253,   351,    62,    -1,    61,
     246,   252,    16,   256,    17,    10,   351,    62,    -1,    61,
       1,    62,    -1,   451,    -1,   253,   266,    -1,   266,    -1,
     254,   255,    -1,   255,    -1,   266,    -1,   257,    10,    -1,
     257,    -1,   256,    98,   257,    -1,   258,    -1,   262,   247,
     259,   260,   451,    -1,   262,   265,   451,    -1,   258,    98,
     265,   451,    -1,   258,    98,   247,   259,   260,   451,    -1,
     258,    98,   262,   247,   259,   260,   451,    -1,    -1,    46,
      -1,    -1,   242,    -1,    -1,     3,    -1,   447,    40,   261,
      -1,   447,    39,   261,    -1,   447,   101,   261,    -1,   262,
      98,   451,    -1,   264,    -1,   263,    98,   264,    -1,   101,
     247,   260,   451,    -1,   101,    46,   247,   260,   451,    -1,
     101,   265,   451,    -1,   264,    98,   451,    -1,   264,    98,
     101,   247,   260,   451,    -1,   264,    98,   101,    46,   247,
     260,   451,    -1,   264,    98,   101,   265,   451,    -1,   101,
       1,    10,    -1,    47,    -1,    48,    -1,   126,    -1,   104,
      -1,   447,   267,    -1,   447,   208,    -1,   447,   210,    -1,
     447,   182,    -1,   447,   188,    -1,   447,   214,    -1,   447,
     215,    -1,   447,   218,    -1,    46,   242,   268,    10,    -1,
      46,   443,   242,   268,    10,    -1,    46,   268,    10,    -1,
     269,    -1,   268,    98,   269,    -1,   451,    -1,   451,   220,
      -1,     6,   223,   272,    10,    -1,     6,   272,    10,    -1,
       6,   221,   272,    10,    -1,     6,   221,   223,   272,    10,
      -1,     6,   271,    10,    -1,     6,     1,    10,    -1,   274,
      -1,   271,    98,   274,    -1,   273,    -1,   272,    98,   273,
      -1,   275,    16,   276,    98,   432,    17,    -1,    16,   276,
      98,   432,    17,    -1,   275,    16,   276,    17,    -1,    16,
     276,    17,    -1,   451,   242,    -1,   451,    -1,   442,    -1,
     278,    -1,    -1,    -1,   451,   279,   283,   282,   280,    10,
      -1,    -1,   451,   282,   281,    10,    -1,   289,    -1,   282,
      98,   289,    -1,    29,    16,   284,    17,    -1,    29,    16,
       1,    17,    10,    -1,   285,    -1,   287,    -1,   286,    -1,
     285,    98,   286,    -1,   435,    -1,   288,    -1,   287,    98,
     288,    -1,    11,   451,    16,   435,    17,    -1,    11,   451,
      16,    17,    -1,   290,    16,   291,    17,    -1,   290,    16,
      17,    -1,   451,   260,    -1,   292,    -1,   294,    -1,   293,
      -1,   292,    98,   293,    -1,   447,   435,    -1,   295,    -1,
     294,    98,   295,    -1,   447,   288,    -1,    -1,   106,   297,
     298,   107,    -1,   106,     1,   107,    -1,   300,    -1,   298,
     300,    -1,   300,    -1,    10,    -1,   301,    -1,   302,    -1,
     305,    -1,   307,    -1,   178,    -1,    65,    16,   435,    17,
     299,    -1,    65,    16,   435,    17,   299,    79,   299,    -1,
      66,    16,   435,    17,   303,    80,    -1,   304,    -1,   303,
      98,   304,    -1,   432,    15,   299,    -1,    82,    15,   299,
      -1,    82,   299,    -1,    71,    16,   306,    10,   435,    10,
     306,    17,    81,    15,   451,   298,    84,    -1,   451,    22,
     435,    -1,    81,    15,   451,   298,    84,    -1,    81,   298,
      84,    -1,    81,     1,    84,    -1,    81,    15,   451,     1,
      84,    -1,   447,    56,   309,    16,   310,    17,    10,   313,
     318,    55,    -1,   447,    56,   309,    16,   311,    17,    10,
     313,   318,    55,    -1,   451,    -1,   451,    -1,   310,    98,
     451,    -1,   315,    98,   312,    -1,   316,    -1,   312,    98,
     316,    -1,   312,    98,   451,    -1,   314,    -1,   313,   314,
      -1,   315,    10,    -1,   316,    10,    -1,   317,    10,    -1,
     314,    10,    -1,   447,    39,   451,    -1,   447,    39,    46,
     451,    -1,   447,    39,    46,   451,    22,   435,    -1,   315,
      98,   451,    -1,   447,   101,   451,    -1,   316,    98,   451,
      -1,   447,    46,   451,    -1,   317,    98,   451,    -1,   319,
      -1,    58,   320,    59,    -1,    58,     1,    59,    -1,   322,
      58,   320,    59,    -1,   321,    -1,   320,   321,    -1,   324,
      15,   328,    10,    -1,   324,    15,   326,    15,   327,    10,
      -1,    57,   451,    22,   323,    10,    -1,    57,     1,    10,
      -1,     8,    -1,   325,    -1,   329,    -1,   324,   325,    -1,
     324,   329,    -1,    16,   329,    17,    -1,    16,   329,   329,
      17,    -1,   325,    16,   329,    17,    -1,   329,    -1,   328,
      -1,    14,    -1,   329,    -1,     8,    -1,    99,    -1,    26,
      -1,    12,    -1,   451,   221,   225,   331,    10,    -1,   451,
     221,   331,    10,    -1,   451,   331,    10,    -1,   332,    -1,
     331,    98,   332,    -1,   333,    16,   276,    98,   432,    17,
      -1,    16,   276,    98,   432,    17,    -1,   290,    -1,    50,
     221,   223,   335,    10,    -1,    50,   223,   335,    10,    -1,
      50,   335,    10,    -1,    50,   221,   335,    10,    -1,   336,
      -1,   335,    98,   336,    -1,   442,    22,   435,    -1,    57,
     352,    -1,    57,     1,    84,    -1,    -1,    60,   339,   352,
      -1,   338,     1,    84,    -1,   442,    22,   357,   435,    -1,
     442,    22,   435,    -1,   442,    22,   357,    -1,   340,     1,
      -1,   442,    23,    22,   357,   435,    -1,   442,    23,    22,
     435,    -1,   442,    23,    22,   357,    -1,   341,     1,    -1,
      50,   347,    -1,    76,   442,    -1,    74,   336,    -1,    75,
     442,    -1,   442,    22,   435,    -1,   354,    -1,   447,    10,
      -1,    81,   351,    84,    -1,    81,    15,   451,   253,   351,
      84,    -1,    81,    15,   451,   346,    84,    -1,    81,   253,
     351,    84,    -1,    81,    84,    -1,   354,    -1,   346,   354,
      -1,   442,    22,   435,    -1,    83,   351,    72,    -1,    83,
      15,   451,   253,   351,    72,    -1,    83,    15,   451,   351,
      72,    -1,    83,    72,    -1,    83,    15,     1,    72,    -1,
      83,     1,    72,    -1,    -1,    81,   350,   351,    84,    -1,
      81,    15,   451,   253,   351,    84,    -1,    81,    15,   451,
     351,    84,    -1,    81,    84,    -1,    81,    15,   451,    84,
      -1,    81,     1,    84,    -1,   352,    -1,   351,   352,    -1,
     447,   340,    10,    -1,   447,   368,    -1,   447,   366,    -1,
     447,   359,    -1,   447,   361,    -1,   447,   372,    -1,   447,
     341,    10,    -1,   447,   348,    -1,   447,   342,    10,    -1,
     447,   364,    -1,   447,   349,    -1,   447,   373,    -1,   447,
     365,    -1,   352,    -1,    10,    -1,   447,   343,    10,    -1,
     447,   355,    -1,   447,   367,    -1,   447,   371,    -1,   447,
     345,    -1,   447,   359,    -1,   447,   373,    -1,   368,    -1,
      29,     8,    -1,    29,    12,    -1,    29,    16,   436,    17,
      -1,   356,    -1,   360,    -1,    -1,    70,    16,   435,   358,
      17,   360,    -1,    77,   451,    10,    -1,    31,   451,    -1,
      31,    16,   363,    17,    -1,    31,    26,    -1,    31,    16,
      26,    17,    -1,    31,   128,    17,    -1,    14,    24,   451,
      10,    -1,   435,    -1,    95,   435,    -1,    96,   435,    -1,
     362,    -1,   363,    98,   362,    -1,   363,     6,   362,    -1,
     357,   353,    -1,    73,    16,   435,    17,   353,    -1,    65,
      16,   435,    17,   353,    -1,    65,    16,   435,    17,   353,
      79,   353,    -1,    65,    16,   435,    17,     1,    79,   353,
      -1,    65,    16,   435,    17,   344,    -1,    65,    16,   435,
      17,   344,    79,   344,    -1,    66,    16,   435,    17,   369,
      80,    -1,    66,    16,   435,    17,     1,    80,    -1,    68,
      16,   435,    17,   369,    80,    -1,    68,     1,    80,    -1,
      67,    16,   435,    17,   369,    80,    -1,    67,     1,    80,
      -1,   370,    -1,   369,   370,    -1,   432,    15,   353,    -1,
      82,    15,   353,    -1,    82,   353,    -1,    69,   354,    -1,
      70,    16,   435,    17,   354,    -1,    78,    16,   435,    17,
     354,    -1,    71,    16,   347,    10,   435,    10,   347,    17,
     354,    -1,    69,   352,    -1,    70,    16,   435,    17,   352,
      -1,    78,    16,   435,    17,   352,    -1,    71,    16,   347,
      10,   435,    10,   347,    17,   352,    -1,   450,    16,   374,
      17,    10,    -1,   450,    16,     1,    17,    10,    -1,   450,
      10,    -1,   435,    -1,   374,    98,   435,    -1,   374,    98,
      -1,    98,    -1,    85,   376,    86,    -1,    85,    86,    -1,
      85,     1,    86,    -1,   377,    -1,   376,   377,    -1,   194,
      -1,   380,    -1,   398,    -1,   378,    -1,   379,    -1,   113,
     384,    10,    -1,   114,   384,    10,    -1,   114,     1,    10,
      -1,   119,   384,    10,    -1,   120,   384,    10,    -1,   120,
       1,    10,    -1,   381,    10,    -1,   390,    10,    -1,   396,
      10,    -1,   382,    22,   387,    -1,    16,   386,    22,    24,
     386,    17,    -1,    16,   383,   385,   384,    17,    -1,    16,
     383,    26,    24,   384,    17,    -1,   386,    -1,   383,    98,
     386,    -1,   383,    -1,   397,    22,    24,    -1,   397,    26,
      24,    -1,   451,    -1,   451,    18,   431,    19,    -1,   451,
      18,   435,    19,    -1,   388,    -1,    16,   388,    17,    -1,
     389,    -1,    16,   389,    98,   389,    17,    -1,    16,   389,
      98,   389,    98,   389,    17,    -1,    16,   389,    98,   389,
      98,   389,    98,   389,    98,   389,    98,   389,    17,    -1,
      16,   389,    98,   389,    98,   389,    98,   389,    98,   389,
      98,   389,    98,   389,    98,   389,    98,   389,    98,   389,
      98,   389,    98,   389,    17,    -1,   436,    -1,   391,    22,
     387,    -1,   392,    22,   387,    -1,    16,   395,   386,    22,
      24,   393,    -1,    16,   386,    22,    24,   393,    -1,    16,
     395,   383,    26,    24,   384,   444,    15,   394,    17,    -1,
      16,   383,    26,    24,   384,   444,    15,   394,    17,    -1,
     386,   444,    15,   394,    17,    -1,    16,   386,   444,    15,
     394,    17,    17,    -1,   435,    -1,    95,    -1,    96,    -1,
      65,    16,   435,    17,   381,    -1,    65,    16,   435,    17,
     390,    -1,   125,   381,    -1,   444,    -1,   402,    -1,   403,
      -1,   404,    -1,   405,    -1,   406,    -1,   407,    -1,   410,
      -1,   409,    -1,   408,    -1,   401,    -1,   399,    -1,   400,
      -1,   122,    16,   414,    98,   415,    98,   413,    98,   411,
      17,    10,    -1,   122,    16,   414,    98,   415,    98,   413,
      17,    10,    -1,   123,    16,   414,    98,   415,    98,   413,
      98,   411,    17,    10,    -1,   123,    16,   414,    98,   415,
      98,   413,    17,    10,    -1,   124,    16,   416,    98,   416,
      98,   413,    98,   413,    98,   411,    17,    10,    -1,   124,
      16,   416,    98,   416,    98,   413,    98,   413,    17,    10,
      -1,    88,    16,   414,    98,   415,    98,   413,    98,   411,
      17,    10,    -1,    88,    16,   414,    98,   415,    98,   413,
      17,    10,    -1,    88,    16,     1,    17,    -1,    89,    16,
     414,    98,   415,    98,   413,    98,   411,    17,    10,    -1,
      89,    16,   414,    98,   415,    98,   413,    17,    10,    -1,
      89,     1,    10,    -1,    94,    16,   416,    98,   416,    98,
     413,    98,   413,    98,   411,    17,    10,    -1,    94,    16,
     416,    98,   416,    98,   413,    98,   413,    17,    10,    -1,
      93,    16,   414,    98,   415,    98,   413,    98,   411,    17,
      10,    -1,    93,    16,   414,    98,   415,    98,   413,    17,
      10,    -1,   121,    16,   414,    98,   415,    98,   413,    98,
     411,    17,    10,    -1,   121,    16,   414,    98,   415,    98,
     413,    17,    10,    -1,    92,    16,   414,    98,   415,    98,
     413,    98,   411,    17,    10,    -1,    92,    16,   414,    98,
     415,    98,   413,    17,    10,    -1,   105,    16,   416,    98,
     416,    98,   436,    98,   436,    17,    10,    -1,   105,    16,
     416,    98,   416,    98,   436,    98,   436,    98,   411,    17,
      10,    -1,    90,    16,   417,    98,   413,    98,   435,    98,
     411,    17,    10,    -1,    90,    16,   417,    98,   413,    17,
      10,    -1,    91,    16,   417,    98,   413,    17,    10,    -1,
      91,    16,   417,    98,   413,    98,   411,    17,    10,    -1,
     412,    -1,   411,    98,   412,    -1,   435,    -1,   435,    -1,
     416,    -1,   416,    -1,   418,   422,   134,   423,    -1,   418,
     422,    -1,   422,   134,   423,    -1,   422,    -1,   416,    -1,
      95,    -1,    96,    -1,   419,    -1,    97,    18,   421,    19,
      -1,     1,    19,    -1,     8,     8,    -1,     8,    12,    -1,
      12,     8,    -1,   420,    -1,   421,    98,   420,    -1,   386,
      -1,   436,    -1,    37,   432,    36,    -1,    37,   435,    37,
     432,    36,    36,    -1,    37,   426,    36,    -1,   427,    -1,
     426,    98,   427,    -1,   451,    18,   431,    19,    -1,   451,
      18,   435,    19,    -1,   451,   429,   431,    -1,   425,    -1,
     451,    -1,    16,   432,    17,    -1,   446,    16,   432,    17,
      -1,    18,   435,    19,    -1,   429,    18,   435,    19,    -1,
     435,    -1,   435,    15,   437,    -1,   435,    13,    15,   439,
      -1,   435,    14,    15,   439,    -1,   435,    -1,   432,    98,
     435,    -1,   450,   429,    -1,   450,    18,   431,    19,    -1,
     450,   429,    18,   431,    19,    -1,   450,    -1,   450,   428,
      -1,    16,   436,    17,    -1,   424,    -1,   445,    -1,   433,
      -1,     7,    -1,   440,   433,    -1,   440,   446,   433,    -1,
     434,    -1,   435,   441,   434,    -1,   435,   441,   446,   434,
      -1,   435,    99,   435,    15,   434,    -1,   435,    -1,   435,
      15,   435,    15,   436,    -1,   435,    -1,   435,    -1,   435,
      -1,    35,    -1,    20,    -1,    25,    -1,    34,    -1,    34,
      20,    -1,   132,    -1,    21,    -1,    34,    21,    -1,   444,
      -1,   133,    -1,    27,    -1,   444,    -1,    22,    22,    -1,
      22,    22,    22,    -1,    35,    22,    -1,    35,    22,    22,
      -1,   131,    -1,   130,    -1,    24,    -1,    23,    -1,    23,
      23,    -1,    23,    22,    -1,    24,    22,    -1,    24,    24,
      -1,    26,    -1,    28,    -1,    25,    -1,    20,    -1,    21,
      -1,    34,    -1,   132,    -1,   133,    -1,    26,    26,    -1,
      23,    23,    23,    -1,    24,    24,    24,    -1,   451,    18,
     431,    19,    -1,   451,   429,    -1,   425,    -1,   450,    -1,
     102,    -1,    14,    -1,    13,    -1,     8,    -1,   444,     8,
      -1,   128,   448,   129,    -1,   128,     1,   129,    -1,    -1,
     128,   448,   129,    -1,   128,     1,   129,    -1,   449,    -1,
     448,    98,   449,    -1,   451,    22,   435,    -1,   451,    -1,
     451,    -1,   450,    11,   451,    -1,   452,    -1,    12,    -1,
      32,   452,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short int yyrline[] =
{
       0,   125,   125,   127,   127,   128,   129,   137,   139,   140,
     141,   144,   147,   148,   151,   152,   158,   159,   163,   164,
     169,   170,   174,   175,   176,   177,   178,   182,   183,   187,
     190,   194,   195,   198,   201,   202,   209,   210,   211,   215,
     216,   217,   219,   220,   221,   222,   223,   224,   225,   230,
     233,   234,   236,   255,   255,   263,   264,   271,   271,   272,
     275,   275,   276,   276,   277,   277,   283,   283,   284,   288,
     292,   293,   296,   297,   298,   301,   302,   305,   306,   309,
     310,   311,   312,   315,   316,   317,   318,   325,   326,   327,
     328,   329,   330,   331,   332,   336,   337,   338,   339,   340,
     341,   342,   343,   346,   347,   348,   349,   350,   351,   352,
     353,   354,   355,   359,   359,   360,   368,   368,   369,   369,
     370,   370,   371,   371,   372,   372,   373,   376,   376,   377,
     377,   378,   378,   379,   379,   380,   380,   381,   384,   385,
     386,   393,   393,   394,   394,   395,   396,   399,   399,   400,
     400,   401,   402,   407,   407,   408,   408,   410,   410,   412,
     413,   414,   415,   423,   424,   428,   429,   430,   431,   432,
     433,   434,   439,   443,   444,   447,   448,   451,   452,   456,
     457,   458,   459,   460,   461,   462,   463,   464,   465,   466,
     470,   471,   475,   476,   479,   480,   482,   482,   483,   486,
     487,   488,   491,   491,   492,   495,   496,   503,   504,   505,
     510,   511,   512,   521,   522,   525,   526,   529,   532,   539,
     540,   543,   544,   548,   549,   553,   554,   557,   558,   561,
     564,   565,   570,   571,   572,   575,   579,   580,   583,   586,
     594,   596,   603,   611,   614,   622,   630,   634,   638,   651,
     652,   653,   654,   655,   656,   660,   661,   664,   665,   668,
     669,   673,   674,   678,   679,   687,   689,   691,   693,   695,
     698,   710,   711,   714,   715,   719,   720,   724,   725,   730,
     734,   739,   743,   748,   753,   761,   762,   764,   765,   767,
     768,   771,   772,   773,   774,   778,   779,   782,   783,   784,
     785,   786,   787,   788,   789,   793,   794,   795,   796,   803,
     804,   805,   806,   807,   808,   809,   810,   813,   814,   815,
     819,   820,   823,   824,   831,   832,   833,   834,   835,   836,
     839,   840,   843,   844,   849,   850,   855,   856,   859,   860,
     868,   875,   878,   879,   878,   880,   880,   883,   884,   887,
     888,   890,   891,   894,   895,   898,   901,   902,   906,   907,
     911,   912,   915,   931,   932,   935,   936,   939,   943,   944,
     947,   957,   957,   958,   961,   962,   966,   967,   971,   972,
     973,   974,   975,   978,   979,   982,   985,   986,   989,   990,
     991,   995,   998,  1001,  1002,  1003,  1004,  1012,  1014,  1019,
    1041,  1042,  1044,  1047,  1048,  1049,  1052,  1053,  1056,  1057,
    1058,  1060,  1063,  1064,  1065,  1066,  1069,  1070,  1072,  1073,
    1079,  1083,  1084,  1085,  1088,  1089,  1092,  1093,  1098,  1099,
    1102,  1106,  1107,  1108,  1109,  1112,  1113,  1114,  1118,  1120,
    1121,  1124,  1127,  1128,  1129,  1130,  1138,  1139,  1140,  1143,
    1144,  1147,  1148,  1151,  1159,  1160,  1161,  1162,  1165,  1166,
    1169,  1172,  1173,  1176,  1176,  1186,  1190,  1191,  1192,  1193,
    1196,  1197,  1198,  1199,  1206,  1207,  1208,  1209,  1212,  1216,
    1217,  1225,  1226,  1227,  1228,  1229,  1234,  1235,  1238,  1241,
    1242,  1243,  1244,  1245,  1246,  1251,  1250,  1253,  1254,  1255,
    1256,  1257,  1260,  1261,  1269,  1270,  1271,  1272,  1273,  1274,
    1275,  1276,  1277,  1278,  1279,  1280,  1281,  1284,  1285,  1289,
    1290,  1291,  1292,  1293,  1294,  1295,  1298,  1304,  1305,  1306,
    1309,  1310,  1311,  1311,  1314,  1317,  1318,  1319,  1320,  1321,
    1324,  1327,  1328,  1329,  1332,  1333,  1334,  1337,  1339,  1345,
    1346,  1347,  1351,  1352,  1359,  1360,  1361,  1362,  1363,  1364,
    1368,  1369,  1373,  1374,  1375,  1382,  1383,  1384,  1385,  1389,
    1390,  1391,  1392,  1400,  1401,  1402,  1405,  1406,  1407,  1408,
    1415,  1416,  1417,  1421,  1422,  1426,  1427,  1428,  1429,  1430,
    1434,  1435,  1436,  1440,  1441,  1442,  1449,  1450,  1451,  1455,
    1460,  1461,  1462,  1465,  1466,  1469,  1472,  1473,  1483,  1484,
    1485,  1489,  1490,  1494,  1495,  1496,  1497,  1498,  1506,  1509,
    1510,  1514,  1515,  1519,  1521,  1527,  1528,  1532,  1534,  1535,
    1539,  1540,  1541,  1545,  1554,  1555,  1556,  1557,  1558,  1559,
    1560,  1561,  1562,  1563,  1564,  1565,  1569,  1570,  1573,  1574,
    1578,  1579,  1583,  1584,  1585,  1588,  1589,  1590,  1594,  1595,
    1598,  1599,  1601,  1602,  1606,  1607,  1610,  1611,  1614,  1615,
    1619,  1620,  1623,  1624,  1627,  1635,  1637,  1640,  1643,  1644,
    1645,  1646,  1649,  1653,  1654,  1655,  1658,  1659,  1662,  1663,
    1664,  1667,  1668,  1671,  1675,  1683,  1684,  1689,  1691,  1692,
    1695,  1696,  1697,  1698,  1699,  1708,  1709,  1717,  1718,  1723,
    1727,  1728,  1729,  1732,  1733,  1741,  1742,  1743,  1744,  1745,
    1746,  1747,  1749,  1753,  1754,  1755,  1756,  1759,  1760,  1761,
    1762,  1765,  1766,  1769,  1771,  1773,  1780,  1781,  1782,  1783,
    1784,  1785,  1786,  1787,  1788,  1789,  1793,  1794,  1796,  1797,
    1798,  1799,  1800,  1801,  1802,  1803,  1804,  1805,  1806,  1807,
    1808,  1809,  1810,  1811,  1812,  1813,  1814,  1815,  1816,  1817,
    1818,  1826,  1827,  1828,  1829,  1835,  1838,  1839,  1843,  1844,
    1855,  1856,  1859,  1860,  1861,  1864,  1865,  1868,  1869,  1872,
    1873,  1877,  1880,  1884
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "NET_TOK", "STR0_TOK", "STR1_TOK",
  "GATE_TOK", "STRING_TOK", "DIGIT_TOK", "UNDERSCORE_TOK", "SEM_TOK",
  "DOT_TOK", "LETTER_TOK", "PLUS_TOK", "MINUS_TOK", "COLON_TOK",
  "LBRACE_TOK", "RBRACE_TOK", "LBRACKET_TOK", "RBRACKET_TOK", "AND_TOK",
  "OR_TOK", "EQU_TOK", "GT_TOK", "LT_TOK", "NOT_TOK", "MULT_TOK",
  "PERCENTAL_TOK", "ENV_TOK", "PARA_TOK", "CHAR_TOK", "AT_TOK",
  "DOLLAR_TOK", "BASE_TOK", "SN_TOK", "EXCLAMATION_TOK", "RRAM_TOK",
  "LRAM_TOK", "PARAMETER_TOK", "OUTPUT_TOK", "INOUT_TOK", "SMALL_TOK",
  "MEDIUM_TOK", "LARGE_TOK", "VEC_TOK", "SCALAR_TOK", "REG_TOK",
  "TIME_TOK", "REAL_TOK", "EVENT_TOK", "ASSIGN_TOK", "DEFPARAM_TOK",
  "MODUL_TOK", "ENDMODUL_TOK", "MACRO_MODUL_TOK", "ENDPRIMITIVE_TOK",
  "PRIMITIVE_TOK", "INITIAL_TOK", "TABLE_TOK", "ENDTABLE_TOK",
  "ALWAYS_TOK", "TASK_TOK", "ENDTASK_TOK", "FUNC_TOK", "ENDFUNC_TOK",
  "IF_TOK", "CASE_TOK", "CASEX_TOK", "CASEZ_TOK", "FOREVER_TOK",
  "REPEAT_TOK", "FOR_TOK", "JOIN_TOK", "WAIT_TOK", "FORCE_TOK",
  "RELEASE_TOK", "DEASSIGN_TOK", "DISABLE_TOK", "WHILE_TOK", "ELSE_TOK",
  "ENDCASE_TOK", "BEGIN_TOK", "DEFAULT_TOK", "FORK_TOK", "END_TOK",
  "SPECIFY_TOK", "ENDSPECIFY_TOK", "SPECPARAM_TOK", "DSETUP_TOK",
  "DHOLD_TOK", "DWIDTH_TOK", "DPERIOD_TOK", "DSKEW_TOK", "DRECOVERY_TOK",
  "DSETUPHOLD_TOK", "POSEDGE_TOK", "NEGEDGE_TOK", "EDGE_TOK", "COMMA_TOK",
  "QUESTION_TOK", "AUTO_TOK", "INPUT_TOK", "SIGNED_TOK", "LOCALPARAM_TOK",
  "INTEGER_TOK", "NOCHANGE_TOK", "GENERATE_TOK", "ENDGENERATE_TOK",
  "GENVAR_TOK", "LIBRARY_TOK", "CONFIG_TOK", "ENDCONFIG_TOK",
  "INCLUDE_TOK", "PULSEON_DETECT_TOK", "PULSEONE_EVENT_TOK", "USE_TOK",
  "LIBLIST_TOK", "INSTANCE_TOK", "CELL_TOK", "SHOWCANCEL_TOK",
  "NOSHOWCANCEL_TOK", "REMOVAL_TOK", "FULLSKEW_TOK", "TIMESKEW_TOK",
  "RECREM_TOK", "IFNONE_TOK", "REALTIME_TOK", "DESIGN_TOK", "ATL_TOK",
  "ATR_TOK", "OOR_TOK", "AAND_TOK", "SNNOT_TOK", "NOTSN_TOK", "AAAND_TOK",
  "$accept", "file", "lines", "@1", "library_text", "library_descriptions",
  "library_declaration", "file_path_spec", "include_statement",
  "config_declaration", "design_statement", "config_rule_statement_list",
  "config_rule_statement", "aidentifier_list", "inst_clause",
  "cell_clause", "liblist_clause", "use_clause", "config", "description",
  "module_declaration", "name_of_module", "module_type", "module_keyword",
  "end_mod", "@2", "module_option", "module_parameter_port_list", "@3",
  "parameter_declaration_list", "@4", "@5", "@6", "list_of_ports", "@7",
  "list_of_port_declarations", "port_list", "port", "port_expression",
  "port_reference_list", "port_reference", "port_declaration",
  "module_item", "module_or_generate_item",
  "module_or_generate_item_declaration", "parameter_override", "@8",
  "local_parameter_declaration", "@9", "@10", "@11", "@12", "@13",
  "parameter_declaration", "@14", "@15", "@16", "@17", "@18",
  "specparam_declaration", "inout_declaration", "@19", "@20",
  "input_declaration", "@21", "@22", "output_declaration", "@23", "@24",
  "@25", "output_var_type", "s_type", "net_type", "event_declaration",
  "genvar_declaration", "integer_declaration", "net_declaration",
  "xscalared", "scalared", "real_declaration", "realtime_declaration",
  "@26", "reg_declaration", "time_declaration", "@27", "dimension_list",
  "drive_strength", "charge_strength", "delay3", "delay_value_list",
  "delay2", "delay_value", "list_of_event_identifiers",
  "list_of_event_lists", "dim_list", "list_of_genvar_identifiers",
  "list_of_net_decl_assignments", "list_of_net_identifiers",
  "list_of_param_assignments", "real_type", "variable_type",
  "list_of_specparam_assignments", "list_of_variable_identifiers",
  "net_decl_assignment", "param_assignment", "specparam_assignment",
  "dimension", "range", "function_declaration", "name_of_function",
  "range_or_type", "automatic", "xsigned",
  "function_item_declaration_list", "function_item_declaration",
  "function_port_list", "task_declaration", "name_of_task",
  "block_item_declaration_list", "task_item_declaration_list",
  "task_item_declaration", "task_port_list", "task_port_item",
  "tf_port_declaration", "xreg", "xrange", "xnettype", "tf_port_dir",
  "tf_input_declaration_list", "tf_input_declaration", "task_port_type",
  "block_item_declaration", "block_reg_declaration",
  "list_of_block_variable_identifiers", "block_variable_type",
  "gate_instantiation", "pull_gate_instance_list",
  "cmos_switch_instance_list", "cmos_switch_instance",
  "pull_gate_instance", "name_of_gate_instance", "output_terminal",
  "module_instantiation", "module_identifier", "@28", "@29", "@30",
  "module_instance_list", "parameter_value_assignment",
  "list_of_parameter_assignments", "ordered_parameter_assignment_list",
  "ordered_parameter_assignment", "named_parameter_assignment_list",
  "named_parameter_assignment", "module_instance", "identifier11",
  "list_of_port_connections", "ordered_port_connection_list",
  "ordered_port_connection", "named_port_connection_list",
  "named_port_connection", "generated_instantiation", "@31",
  "generate_item_list", "generate_item_or_null", "generate_item",
  "generate_conditional_statement", "generate_case_statement",
  "genvar_module_case_item_list", "genvar_case_item",
  "generate_loop_statement", "genvar_assignment", "generate_block",
  "udp_declaration", "name_of_udp", "udp_port_list",
  "udp_declaration_port_list", "udp_input_declaration_list",
  "udp_port_declaration_list", "udp_port_declaration",
  "udp_output_declaration", "udp_input_declaration", "udp_reg_declaration",
  "udp_body", "combinational_body", "combinational_entry_list",
  "combinational_entry", "udp_initial_statement", "init_val",
  "edge_input_list", "edge_indicator", "current_state", "next_state",
  "output_symbol", "level_symbol", "udp_instantiation",
  "udp_instance_list", "udp_instance", "name_of_instance",
  "continuous_assign", "list_of_net_assignments", "net_assignment",
  "initial_construct", "always_construct", "@32", "blocking_assignment",
  "nonblocking_assignment", "procedural_continuous_assignments",
  "function_blocking_assignment", "function_statement_or_null",
  "function_seq_block", "function_statement_list", "variable_assignment",
  "par_block", "seq_block", "@33", "statement_list", "statement",
  "statement_or_null", "function_statement", "function_case_statement",
  "delay_control", "delay_or_event_control", "@34", "disable_statement",
  "event_control", "event_trigger", "event_expression",
  "event_expression_list", "procedural_timing_control_statement",
  "wait_statement", "conditional_statement",
  "function_conditional_statement", "case_statement", "case_item_list",
  "case_item", "function_loop_statement", "loop_statement",
  "system_task_enable", "expression_list_null", "specify_block",
  "specify_item_list", "specify_item", "pulsestyle_declaration",
  "showcancelled_declaration", "path_declaration",
  "simple_path_declaration", "parallel_path_description",
  "list_of_path_inputs", "list_of_path_outputs", "connection",
  "specify_input_terminal_descriptor", "path_delay_value",
  "list_of_path_delay_expressions", "path_delay_expression",
  "edge_sensitive_path_declaration",
  "parallel_edge_sensitive_path_description",
  "full_edge_sensitive_path_description", "example",
  "data_source_expression", "edge_identifier",
  "state_dependent_path_declaration", "polarity_operator",
  "system_timing_check", "fullskew_timing_check",
  "timingskew_timing_check", "recrem_timing_check", "setup_timing_check",
  "hold_timing_check", "setuphold_timing_check", "recovery_timing_check",
  "removal_timing_check", "skew_timing_check", "nochange_timing_check",
  "width_timing_check", "period_timing_check", "notify_register_list",
  "notify_register", "timing_check_limit", "data_event", "reference_event",
  "timing_check_event", "controlled_timing_check_event",
  "timing_check_event_control", "edge_control_specifier",
  "edge_descriptor", "edge_descriptor_list", "specify_terminal_descriptor",
  "timing_check_condition", "concatenation", "net_concatenation",
  "net_concatenation_value_list", "net_concatenation_value",
  "function_call", "expression_bracket_list",
  "dimension_constant_expression", "range_expression", "expression_list",
  "primary", "unprim", "expression", "mintypemax_expression",
  "lsb_constant_expression", "msb_constant_expression",
  "width_constant_expression", "unary_operator", "binary_operator",
  "net_lvalue", "signed", "pol_op", "number", "attribute_instance11",
  "attribute_instance", "attr_spec_list", "attr_spec", "simple_identifier",
  "identifier", "ident", 0
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned short int yyr1[] =
{
       0,   135,   136,   138,   137,   137,   137,   139,   140,   140,
     140,   141,   142,   142,   143,   143,   144,   144,   145,   145,
     146,   146,   147,   147,   147,   147,   147,   148,   148,   149,
     150,   151,   151,   152,   153,   153,   154,   154,   154,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   156,
     157,   157,   158,   160,   159,   161,   161,   163,   162,   162,
     165,   164,   166,   164,   167,   164,   169,   168,   168,   170,
     171,   171,   172,   172,   172,   173,   173,   174,   174,   175,
     175,   175,   175,   176,   176,   176,   176,   177,   177,   177,
     177,   177,   177,   177,   177,   178,   178,   178,   178,   178,
     178,   178,   178,   179,   179,   179,   179,   179,   179,   179,
     179,   179,   179,   181,   180,   180,   183,   182,   184,   182,
     185,   182,   186,   182,   187,   182,   182,   189,   188,   190,
     188,   191,   188,   192,   188,   193,   188,   188,   194,   194,
     194,   196,   195,   197,   195,   195,   195,   199,   198,   200,
     198,   198,   198,   202,   201,   203,   201,   204,   201,   201,
     201,   201,   201,   205,   205,   206,   206,   206,   206,   206,
     206,   206,   207,   208,   208,   209,   209,   210,   210,   211,
     211,   211,   211,   211,   211,   211,   211,   211,   211,   211,
     212,   212,   213,   213,   214,   214,   216,   215,   215,   217,
     217,   217,   219,   218,   218,   220,   220,   221,   221,   221,
     222,   222,   222,   223,   223,   224,   224,   225,   226,   227,
     227,   228,   228,   229,   229,   230,   230,   231,   231,   232,
     233,   233,   234,   234,   234,   235,   236,   236,   237,   237,
     238,   239,   240,   241,   242,   243,   243,   243,   244,   245,
     245,   245,   245,   245,   245,   246,   246,   247,   247,   248,
     248,   249,   249,   250,   250,   251,   251,   251,   251,   251,
     252,   253,   253,   254,   254,   255,   255,   256,   256,   257,
     258,   258,   258,   258,   258,   259,   259,   260,   260,   261,
     261,   262,   262,   262,   262,   263,   263,   264,   264,   264,
     264,   264,   264,   264,   264,   265,   265,   265,   265,   266,
     266,   266,   266,   266,   266,   266,   266,   267,   267,   267,
     268,   268,   269,   269,   270,   270,   270,   270,   270,   270,
     271,   271,   272,   272,   273,   273,   274,   274,   275,   275,
     276,   277,   279,   280,   278,   281,   278,   282,   282,   283,
     283,   284,   284,   285,   285,   286,   287,   287,   288,   288,
     289,   289,   290,   291,   291,   292,   292,   293,   294,   294,
     295,   297,   296,   296,   298,   298,   299,   299,   300,   300,
     300,   300,   300,   301,   301,   302,   303,   303,   304,   304,
     304,   305,   306,   307,   307,   307,   307,   308,   308,   309,
     310,   310,   311,   312,   312,   312,   313,   313,   314,   314,
     314,   314,   315,   315,   315,   315,   316,   316,   317,   317,
     318,   319,   319,   319,   320,   320,   321,   321,   322,   322,
     323,   324,   324,   324,   324,   325,   325,   325,   326,   327,
     327,   328,   329,   329,   329,   329,   330,   330,   330,   331,
     331,   332,   332,   333,   334,   334,   334,   334,   335,   335,
     336,   337,   337,   339,   338,   338,   340,   340,   340,   340,
     341,   341,   341,   341,   342,   342,   342,   342,   343,   344,
     344,   345,   345,   345,   345,   345,   346,   346,   347,   348,
     348,   348,   348,   348,   348,   350,   349,   349,   349,   349,
     349,   349,   351,   351,   352,   352,   352,   352,   352,   352,
     352,   352,   352,   352,   352,   352,   352,   353,   353,   354,
     354,   354,   354,   354,   354,   354,   355,   356,   356,   356,
     357,   357,   358,   357,   359,   360,   360,   360,   360,   360,
     361,   362,   362,   362,   363,   363,   363,   364,   365,   366,
     366,   366,   367,   367,   368,   368,   368,   368,   368,   368,
     369,   369,   370,   370,   370,   371,   371,   371,   371,   372,
     372,   372,   372,   373,   373,   373,   374,   374,   374,   374,
     375,   375,   375,   376,   376,   377,   377,   377,   377,   377,
     378,   378,   378,   379,   379,   379,   380,   380,   380,   381,
     382,   382,   382,   383,   383,   384,   385,   385,   386,   386,
     386,   387,   387,   388,   388,   388,   388,   388,   389,   390,
     390,   391,   391,   392,   392,   393,   393,   394,   395,   395,
     396,   396,   396,   397,   398,   398,   398,   398,   398,   398,
     398,   398,   398,   398,   398,   398,   399,   399,   400,   400,
     401,   401,   402,   402,   402,   403,   403,   403,   404,   404,
     405,   405,   406,   406,   407,   407,   408,   408,   409,   409,
     410,   410,   411,   411,   412,   413,   414,   415,   416,   416,
     416,   416,   417,   418,   418,   418,   419,   419,   420,   420,
     420,   421,   421,   422,   423,   424,   424,   425,   426,   426,
     427,   427,   427,   427,   427,   428,   428,   429,   429,   430,
     431,   431,   431,   432,   432,   433,   433,   433,   433,   433,
     433,   433,   433,   434,   434,   434,   434,   435,   435,   435,
     435,   436,   436,   437,   438,   439,   440,   440,   440,   440,
     440,   440,   440,   440,   440,   440,   441,   441,   441,   441,
     441,   441,   441,   441,   441,   441,   441,   441,   441,   441,
     441,   441,   441,   441,   441,   441,   441,   441,   441,   441,
     441,   442,   442,   442,   442,   443,   444,   444,   445,   445,
     446,   446,   447,   447,   447,   448,   448,   449,   449,   450,
     450,   451,   452,   452
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     0,     2,     2,     1,     1,     1,     1,
       1,     2,     1,     1,     5,     3,     6,     5,     3,     3,
       1,     2,     3,     3,     3,     3,     3,     1,     2,     2,
       2,     1,     2,     3,     0,     2,     1,     1,     1,     5,
       4,     6,     6,     6,     6,     6,     7,     7,     7,     1,
       1,     1,     2,     0,     2,     1,     2,     0,     5,     3,
       0,     3,     0,     5,     0,     4,     0,     4,     3,     3,
       1,     3,     1,     4,     5,     1,     3,     3,     1,     1,
       1,     4,     4,     2,     2,     2,     2,     1,     2,     3,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     0,     4,     3,     0,     5,     0,     5,
       0,     4,     0,     5,     0,     6,     3,     0,     4,     0,
       5,     0,     6,     0,     5,     0,     5,     3,     4,     3,
       3,     0,     5,     0,     6,     5,     6,     0,     5,     0,
       6,     5,     6,     0,     4,     0,     3,     0,     2,     4,
       3,     5,     4,     1,     1,     1,     1,     1,     1,     2,
       2,     2,     1,     3,     3,     3,     3,     3,     3,     6,
       6,     7,     7,     8,     7,     7,     7,     8,     7,     3,
       0,     1,     1,     1,     3,     3,     0,     4,     3,     5,
       4,     3,     0,     4,     3,     1,     2,     5,     5,     3,
       3,     3,     3,     4,     2,     1,     3,     1,     1,     1,
       1,     1,     3,     2,     4,     1,     3,     1,     3,     1,
       1,     3,     1,     3,     2,     1,     1,     3,     1,     3,
       3,     3,     3,     5,     5,     9,    12,     3,     1,     0,
       1,     1,     1,     1,     1,     0,     1,     0,     1,     1,
       2,     1,     2,     2,     3,     7,     6,    10,     9,     3,
       1,     2,     1,     2,     1,     1,     2,     1,     3,     1,
       5,     3,     4,     6,     7,     0,     1,     0,     1,     0,
       1,     3,     3,     3,     3,     1,     3,     4,     5,     3,
       3,     6,     7,     5,     3,     1,     1,     1,     1,     2,
       2,     2,     2,     2,     2,     2,     2,     4,     5,     3,
       1,     3,     1,     2,     4,     3,     4,     5,     3,     3,
       1,     3,     1,     3,     6,     5,     4,     3,     2,     1,
       1,     1,     0,     0,     6,     0,     4,     1,     3,     4,
       5,     1,     1,     1,     3,     1,     1,     3,     5,     4,
       4,     3,     2,     1,     1,     1,     3,     2,     1,     3,
       2,     0,     4,     3,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     5,     7,     6,     1,     3,     3,     3,
       2,    13,     3,     5,     3,     3,     5,    10,    10,     1,
       1,     3,     3,     1,     3,     3,     1,     2,     2,     2,
       2,     2,     3,     4,     6,     3,     3,     3,     3,     3,
       1,     3,     3,     4,     1,     2,     4,     6,     5,     3,
       1,     1,     1,     2,     2,     3,     4,     4,     1,     1,
       1,     1,     1,     1,     1,     1,     5,     4,     3,     1,
       3,     6,     5,     1,     5,     4,     3,     4,     1,     3,
       3,     2,     3,     0,     3,     3,     4,     3,     3,     2,
       5,     4,     4,     2,     2,     2,     2,     2,     3,     1,
       2,     3,     6,     5,     4,     2,     1,     2,     3,     3,
       6,     5,     2,     4,     3,     0,     4,     6,     5,     2,
       4,     3,     1,     2,     3,     2,     2,     2,     2,     2,
       3,     2,     3,     2,     2,     2,     2,     1,     1,     3,
       2,     2,     2,     2,     2,     2,     1,     2,     2,     4,
       1,     1,     0,     6,     3,     2,     4,     2,     4,     3,
       4,     1,     2,     2,     1,     3,     3,     2,     5,     5,
       7,     7,     5,     7,     6,     6,     6,     3,     6,     3,
       1,     2,     3,     3,     2,     2,     5,     5,     9,     2,
       5,     5,     9,     5,     5,     2,     1,     3,     2,     1,
       3,     2,     3,     1,     2,     1,     1,     1,     1,     1,
       3,     3,     3,     3,     3,     3,     2,     2,     2,     3,
       6,     5,     6,     1,     3,     1,     3,     3,     1,     4,
       4,     1,     3,     1,     5,     7,    13,    25,     1,     3,
       3,     6,     5,    10,     9,     5,     7,     1,     1,     1,
       5,     5,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,    11,     9,    11,     9,
      13,    11,    11,     9,     4,    11,     9,     3,    13,    11,
      11,     9,    11,     9,    11,     9,    11,    13,    11,     7,
       7,     9,     1,     3,     1,     1,     1,     1,     4,     2,
       3,     1,     1,     1,     1,     1,     4,     2,     2,     2,
       2,     1,     3,     1,     1,     3,     6,     3,     1,     3,
       4,     4,     3,     1,     1,     3,     4,     3,     4,     1,
       3,     4,     4,     1,     3,     2,     4,     5,     1,     2,
       3,     1,     1,     1,     1,     2,     3,     1,     3,     4,
       5,     1,     5,     1,     1,     1,     1,     1,     1,     1,
       2,     1,     1,     2,     1,     1,     1,     1,     2,     3,
       2,     3,     1,     1,     1,     1,     2,     2,     2,     2,
       1,     1,     1,     1,     1,     1,     1,     1,     2,     3,
       3,     4,     2,     1,     1,     1,     1,     1,     1,     2,
       3,     3,     0,     3,     3,     1,     3,     3,     1,     1,
       3,     1,     1,     2
};

/* YYDPREC[RULE-NUM] -- Dynamic precedence of rule #RULE-NUM (0 if none). */
static const unsigned char yydprec[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0
};

/* YYMERGER[RULE-NUM] -- Index of merging function for rule #RULE-NUM. */
static const unsigned char yymerger[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0
};

/* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
   doesn't specify something else to do.  Zero means the default is an
   error.  */
static const unsigned short int yydefact[] =
{
     782,     0,     0,   782,   782,     6,     0,     0,   792,     0,
       0,   785,   788,   791,     1,     0,     0,     0,    38,     7,
       8,     9,    10,     5,    36,    37,     0,     4,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   463,     0,     0,
       0,     0,     0,    95,    96,   109,   110,   105,   103,   106,
     108,   104,   107,   112,   111,    98,   100,   341,    99,    97,
     101,     0,   342,   784,   793,     0,   783,     0,    11,     0,
     789,     0,     0,    50,    51,     0,     0,     0,     0,     0,
     192,   193,   257,   191,   190,   190,     0,     0,     0,     0,
       0,     0,     0,   332,   330,     0,   339,     0,   258,     0,
       0,     0,     0,   235,   238,     0,   232,     0,     0,   219,
     220,   221,     0,     0,     0,     0,     0,   458,   773,     0,
     774,   789,     0,     0,     0,   461,     0,   782,     0,   256,
       0,     0,   257,     0,     0,     0,     0,   225,     0,     0,
       0,     0,     0,     0,   345,   347,     0,     0,   449,     0,
     287,   786,   724,   778,   777,   776,     0,   737,   742,   738,
     739,   736,     0,   741,   745,   721,   723,   727,   787,     0,
     744,   722,   718,     0,     0,    15,    13,     0,    12,     0,
     399,    52,    49,     0,     0,     0,     0,     0,     0,   189,
       0,     0,     0,     0,     0,     0,   287,   257,   257,   329,
       0,   340,     0,   214,   731,   218,     0,     0,     0,     0,
       0,   328,     0,   325,     0,     0,     0,   338,   201,     0,
       0,   204,     0,   195,   194,     0,     0,     0,   234,   205,
     174,   173,     0,     0,   223,   703,     0,   698,   704,     0,
       0,     0,   456,     0,     0,     0,   772,   115,     0,   230,
       0,   462,     0,     0,     0,     0,     0,     0,     0,     0,
     782,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   511,   514,   530,   782,   507,   531,
     508,   513,   516,   506,   505,   509,   515,     0,   774,   464,
     269,     0,   270,   247,   249,   178,   177,   176,   175,     0,
     198,     0,   465,     0,     0,   217,     0,   453,     0,     0,
       0,     0,     0,   782,   448,     0,     0,   288,   362,     0,
     740,   743,     0,   713,   763,   764,     0,   755,   754,   762,
     760,   746,   761,   765,     0,     0,   753,   752,   766,   767,
       0,   747,     0,   725,     0,     0,   779,     0,     0,   719,
     715,     0,     0,     0,   790,     0,   782,     0,    40,     0,
       0,     0,    55,    87,     0,     0,     0,     0,     0,   277,
     279,   257,     0,     0,    57,     0,     0,     0,     0,     0,
       0,   209,     0,     0,   210,   211,   212,     0,   287,   287,
     337,     0,     0,   215,   218,     0,     0,     0,   326,     0,
     324,     0,   331,     0,   333,     0,   734,     0,   200,     0,
     203,   239,     0,   709,   233,   206,   222,     0,   697,     0,
       0,     0,     0,   457,   455,   459,   460,     0,     0,     0,
     114,     0,     0,     0,   527,   528,     0,     0,   537,     0,
     535,   474,     0,     0,     0,     0,     0,     0,     0,   569,
       0,     0,     0,   476,   477,   475,     0,     0,     0,     0,
     499,   782,     0,     0,   492,   782,   502,   469,   504,   473,
     510,   512,   518,   517,   547,     0,     0,   575,     0,   782,
     782,   253,   252,   251,   254,   250,     0,   226,   197,     0,
       0,   447,     0,   343,     0,   348,   346,   361,     0,   363,
     365,   364,   368,     0,   450,     0,   720,   695,     0,     0,
     748,   757,   756,   758,   759,   768,   750,     0,   728,     0,
       0,     0,   726,     0,   713,     0,     0,     0,     0,     0,
      27,     0,    17,     0,     0,     0,    20,     0,     0,    14,
       0,     0,     0,     0,   400,    86,    54,    39,    56,     0,
      88,     0,   157,   257,     0,     0,   257,     0,     0,    91,
      92,    94,    83,    84,    85,    90,    93,    68,     0,    80,
       0,     0,     0,    70,    72,    75,    79,    69,   782,   257,
     305,   306,     0,   308,   307,   285,     0,   289,   289,   289,
      59,     0,     0,     0,     0,    53,     0,    53,     0,     0,
       0,     0,   229,     0,     0,   227,   221,     0,     0,     0,
     213,     0,     0,   327,     0,     0,     0,   336,     0,     0,
     199,     0,   224,   699,     0,     0,   702,     0,   454,   771,
     777,   776,     0,   707,     0,   231,   241,     0,     0,     0,
       0,     0,   544,     0,   541,   539,     0,     0,     0,   559,
       0,   557,     0,     0,     0,     0,   534,     0,   501,   782,
     782,   494,     0,   782,   489,   503,     0,   468,   467,     0,
       0,   579,     0,   576,   782,   274,     0,   275,   782,     0,
       0,     0,   248,     0,   446,     0,     0,     0,   351,   353,
     352,   356,   355,     0,   360,   782,   782,   370,   367,     0,
     714,     0,   749,   769,   770,   751,     0,   729,   781,   780,
     705,   716,     0,     0,     0,    19,    18,    28,    31,     0,
      29,    30,    16,    21,     0,     0,     0,     0,     0,     0,
       0,     0,   782,     0,    89,     0,   775,     0,   133,   129,
     135,   172,   168,     0,   158,   153,   165,   166,   167,   257,
     287,     0,     0,     0,   581,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   585,     0,   583,   588,   589,   586,     0,     0,
       0,     0,     0,     0,   587,   644,   645,   643,   634,   635,
     636,   637,   638,   639,   642,   641,   640,     0,     0,   236,
       0,     0,   257,   287,     0,     0,   116,   118,   122,     0,
     782,   257,   257,     0,     0,     0,     0,    78,    67,     0,
       0,   278,   285,   257,     0,   294,   286,   287,   281,   290,
     292,   291,   293,    60,     0,    41,     0,     0,    45,    42,
      44,    43,   207,   208,     0,     0,   180,     0,   179,     0,
       0,     0,     0,     0,     0,     0,   335,   216,     0,     0,
       0,   733,     0,     0,   700,   707,     0,     0,   710,   708,
     540,   529,   538,   542,   543,     0,   536,     0,   488,     0,
       0,     0,     0,   782,     0,     0,   782,   782,   500,   782,
     272,   782,     0,   496,   493,   782,   782,     0,   466,   472,
     471,     0,     0,   578,   273,   782,   276,   266,     0,   312,
     313,   310,   311,   314,   315,   316,   309,     0,   782,   782,
     452,     0,     0,   349,     0,     0,   344,   366,     0,   369,
       0,     0,     0,   730,   717,   706,    32,    22,    34,    23,
      24,    25,    26,   782,   401,   782,   402,   403,     0,   415,
       0,   412,   137,     0,     0,     0,     0,   131,   156,   163,
     169,   164,     0,   171,   170,   287,   141,   582,   628,   629,
       0,   603,     0,   608,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   605,     0,   603,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   632,   580,   584,
     596,     0,   597,     0,     0,   598,   140,   139,     0,     0,
       0,   287,   147,   126,     0,     0,     0,     0,   124,   373,
       0,     0,     0,     0,   382,   782,   374,   378,   379,   380,
     381,   257,   287,   257,   287,     0,   160,    46,     0,    76,
       0,    71,     0,     0,   287,   285,   282,     0,     0,    58,
      64,    47,    48,   181,   182,   228,     0,   240,     0,   184,
     185,     0,   188,   186,   732,   334,   244,   243,   735,   711,
     712,   546,   545,     0,   549,     0,   782,     0,   560,     0,
       0,     0,   570,     0,     0,   548,   571,   271,   782,   498,
     782,   491,   532,   470,   574,   573,   577,   265,     0,     0,
     320,     0,   322,   782,     0,   782,   259,     0,   295,   261,
       0,     0,     0,   350,     0,   354,   357,   451,   696,     0,
      33,   782,   406,     0,     0,     0,     0,   782,   782,     0,
       0,   413,   128,     0,     0,     0,     0,   154,   143,     0,
       0,     0,     0,     0,   633,     0,     0,   603,     0,     0,
       0,   683,   684,     0,   693,     0,   676,     0,   685,   681,
     657,     0,     0,   682,     0,     0,     0,     0,     0,     0,
     590,   592,   591,   593,   595,   594,     0,     0,     0,     0,
       0,   603,     0,   599,   611,   613,   618,   619,   620,   237,
     138,   242,   149,     0,   121,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   782,   372,   375,   287,     0,   287,
       0,     0,   159,   162,    73,     0,    77,    82,    81,     0,
     287,   280,    61,    62,     0,   183,   187,   782,   782,   555,
     782,   564,   554,   561,   782,   558,   556,   533,     0,   497,
     490,     0,   319,     0,     0,   323,   782,   782,     0,   257,
     287,     0,   260,     0,     0,   262,     0,     0,     0,     0,
     263,   359,     0,    35,     0,     0,   407,     0,   420,     0,
     411,   408,     0,   409,   410,     0,     0,     0,   404,   405,
     417,   416,     0,   134,   130,   136,     0,     0,   142,     0,
     604,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     654,   687,     0,     0,   679,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   613,   618,     0,   148,   117,   119,   123,     0,     0,
       0,     0,     0,   395,     0,   394,     0,   145,     0,   151,
     161,    74,   283,     0,     0,    65,   551,   550,   563,   562,
       0,   317,   321,     0,   782,   268,   304,   287,     0,   299,
     245,     0,   782,     0,     0,     0,   782,     0,   523,   520,
     524,   521,   526,   522,   525,     0,   296,   257,   300,   782,
     264,   358,     0,     0,     0,   442,   445,     0,   444,   443,
       0,   424,     0,   431,   432,   397,     0,   419,   418,   398,
     414,   132,   144,     0,   601,   606,   607,     0,     0,   622,
       0,     0,   609,   610,   630,   631,     0,     0,   691,     0,
       0,   677,     0,   680,   694,     0,     0,   675,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     612,     0,   150,   125,   782,     0,     0,     0,     0,   782,
     146,   152,   284,    63,   782,   318,   267,     0,   297,     0,
     565,     0,     0,     0,     0,     0,   485,   782,   782,   519,
       0,   257,   287,     0,   782,   429,     0,   422,     0,   421,
     425,     0,   433,   434,     0,     0,   602,     0,     0,   600,
       0,     0,     0,   621,   688,   689,   690,   686,     0,     0,
     678,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   377,   383,   376,
     782,     0,   386,     0,     0,   392,   396,   393,   572,   298,
       0,     0,     0,     0,   782,   782,   481,   478,   287,     0,
     303,     0,   430,     0,   435,     0,     0,     0,   438,     0,
     423,     0,     0,     0,     0,   692,     0,     0,   669,     0,
     670,     0,   672,   674,     0,     0,     0,     0,     0,     0,
       0,     0,   614,     0,   782,   782,   390,   385,     0,   782,
       0,   782,   782,     0,   782,   782,   782,   486,   484,     0,
     301,   246,   428,   436,     0,   426,   437,     0,   627,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   384,   389,   387,   388,     0,   552,   479,
       0,   566,     0,   567,   782,   483,   487,   302,   440,     0,
     439,   441,   624,     0,   625,     0,   653,     0,   656,     0,
       0,   671,   673,   665,     0,   661,     0,     0,     0,   663,
       0,   647,     0,   649,     0,     0,   615,     0,     0,   782,
     480,     0,   482,   427,     0,   623,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   553,     0,   626,   652,   655,   668,   664,   660,
     659,     0,   666,     0,   662,   646,   648,   651,     0,     0,
       0,   782,     0,     0,     0,     0,   782,   568,   658,   667,
     650,     0,   782,     0,   391,   616,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   617
};

/* YYPDEFGOTO[NTERM-NUM]. */
static const short int yydefgoto[] =
{
      -1,     2,     3,     4,    18,    19,    20,   177,    21,    22,
     353,   535,   536,   529,   537,   538,   719,   726,  1120,    23,
      24,   181,    76,    77,   358,   359,   360,   186,   591,   834,
    1048,  1344,  1224,   187,   367,   188,   572,   573,   574,   816,
     575,   361,   362,   363,    43,    44,   123,   909,  1015,  1016,
     805,  1017,  1198,   910,   737,   955,  1136,   954,   956,   772,
     562,  1139,  1287,   563,  1193,  1323,   564,   962,   743,   744,
     963,   745,   746,   911,    46,   912,    48,    82,    83,   913,
     914,   139,    51,   915,   101,   234,    84,    85,    90,   392,
     306,   203,   602,   109,   110,   136,   603,   604,   248,   103,
     104,   798,   105,   605,   249,   799,   229,   317,    53,   681,
     486,   130,    99,  1105,  1106,  1111,    54,   291,   889,   674,
     675,   368,   369,   370,   827,   318,   830,   371,  1107,  1108,
     586,   890,   916,  1099,  1100,    55,    91,    92,    93,    94,
     209,   303,    56,    57,   143,   693,   312,   144,   310,   687,
     688,   689,   690,   697,   145,   307,   498,   499,   500,   501,
     502,   565,   810,  1025,  1518,  1519,  1027,  1028,  1521,  1522,
    1029,  1331,  1030,    25,   179,   540,   541,   946,  1121,  1122,
    1123,  1124,  1125,  1267,  1268,  1390,  1391,  1269,  1543,  1392,
    1393,  1546,  1639,  1547,  1394,    58,   147,   148,   149,    59,
     116,   117,    60,    61,   127,   271,   272,   273,  1367,  1628,
    1368,  1586,   441,   274,   275,   461,   465,   466,   474,  1629,
    1369,   276,   277,   884,   278,   279,   280,   642,   643,   281,
     282,   283,  1371,   284,  1077,  1078,  1373,   285,   286,   672,
     566,   773,   774,   775,   776,   777,   778,   779,   984,   985,
    1142,  1154,  1183,  1184,  1185,   780,   781,   782,  1409,  1597,
     972,   783,  1143,   784,   785,   786,   787,   788,   789,   790,
     791,   792,   793,   794,   795,   796,  1561,  1562,  1426,  1155,
    1420,  1156,  1164,  1157,  1158,  1418,  1419,  1159,  1423,   165,
     118,   236,   237,   349,   246,   412,   427,  1079,   166,   167,
     204,  1186,   862,   407,  1069,   169,   340,   201,   748,   170,
     171,   345,   126,    10,    11,   172,    70,    13
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -1301
static const short int yypact[] =
{
    1040,  1134,   113,    77,  1509, -1301,  2085,    62, -1301,   462,
     354, -1301,   120, -1301, -1301,   164,   462,   149, -1301, -1301,
   -1301, -1301, -1301, -1301, -1301, -1301,  1084, -1301,   790,  1348,
     148,  1233,  1243,  1318,  1468,  1331,  3053, -1301,   501,   603,
    1355,  1356,  1377, -1301, -1301, -1301, -1301, -1301, -1301, -1301,
   -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301,
   -1301,  1877,  1247, -1301, -1301,   462, -1301,  3562, -1301,   295,
   -1301,   379,   492, -1301, -1301,   462,   462,  1143,   415,  1207,
   -1301, -1301,   408, -1301,   572,   572,   573,  1321,  3594,  1577,
    1329,   138,   171, -1301, -1301,   560,   315,   592, -1301,  1489,
     631,   462,   699, -1301, -1301,   178,   696,   711,   778,   713,
     726,   783,  1460,  1456,  1477,  1456,   254, -1301, -1301,   842,
     906,   957,  1004,   462,   909, -1301,  3637,   907,   987, -1301,
     462,   988,   408,  1065,   293,  1068,   298, -1301,  1078,   462,
    1031,  1321,  1639,  1112,  1056, -1301,  1146,   301, -1301,  1167,
     315, -1301, -1301, -1301, -1301, -1301,  3562, -1301, -1301, -1301,
     883, -1301,  3562, -1301, -1301, -1301, -1301, -1301,  4678,   349,
    1178, -1301,   146,  1079,   462, -1301, -1301,  1216,   906,  1212,
   -1301, -1301, -1301,  1692,   100,   653,  1177,  1241,  1248, -1301,
    1226,  1179,  1188,  1253,  1301,  1319,   315,   408,   408, -1301,
     150, -1301,  3562, -1301,  3949, -1301,  1456,  1329,   306,  1287,
     333, -1301,  1524, -1301,  1329,  1456,  3562, -1301, -1301,   343,
     462, -1301,   364, -1301, -1301,   462,  3562,  3562,   783, -1301,
   -1301, -1301,   462,   462,   783, -1301,   429, -1301,  1363,  1456,
     377,   397, -1301,  1456,  3562,  3562,  1395, -1301,   425, -1301,
    1095, -1301,  1315,  1206,   444,  1456,  1405,  1415,   777,   982,
     907,  1418,  1432,  1440,  1456,  1456,  1456,   462,  1444,  2791,
    2870,   585,  1008,  1416, -1301, -1301, -1301,    74, -1301, -1301,
   -1301, -1301, -1301, -1301, -1301, -1301, -1301,   935,  1277, -1301,
   -1301,  1246, -1301, -1301,   323, -1301, -1301, -1301, -1301,   462,
   -1301,   482, -1301,  1371,  1456, -1301,  1545, -1301,   483,  1455,
     462,   462,  1467,    69, -1301,  1545,  1456, -1301, -1301,  1437,
   -1301, -1301,   649,  3993, -1301, -1301,  1465,   999,  1374, -1301,
    1476, -1301, -1301, -1301,  1486,  3562, -1301, -1301, -1301, -1301,
    3134, -1301,  1383, -1301,  1178,  1770, -1301,  3562,  3562, -1301,
    1464,  1495,  1398,  1083, -1301,  1525,    94,  1529, -1301,  1466,
    1692,  1223, -1301, -1301,  3685,  1526,  1535,  1541,   165, -1301,
    1469,  1035,   910,  1547, -1301,  2420,   167,  1548,  1552,  2577,
    2710, -1301,  1565,  1568, -1301, -1301, -1301,  1055,   315,   315,
   -1301,  3562,   209, -1301,  1437,  3562,  1485,   491, -1301,  1456,
   -1301,  1456, -1301,  1560, -1301,   270,  4678,  1607, -1301,   509,
   -1301, -1301,  1623,  4678,  4678, -1301, -1301,   783, -1301,  1456,
    3562,  3428,   525, -1301, -1301, -1301,  4678,  1561,  1503,  3562,
   -1301,   462,  3562,   462, -1301, -1301,  3562,  1755, -1301,  1598,
   -1301, -1301,  1627,  3562,  3562,  1572,  3562,  1580,  3562, -1301,
    3562,  1456,  3562, -1301, -1301, -1301,  1647,  3562,  1578,   462,
   -1301,   907,  1589,  1410, -1301,    43, -1301, -1301, -1301, -1301,
   -1301, -1301, -1301, -1301, -1301,  1534,  1641, -1301,   730,   907,
     907, -1301, -1301, -1301, -1301, -1301,   462, -1301, -1301,  3562,
     527, -1301,  1260,  1056,  1146, -1301, -1301, -1301,  1653,  1575,
   -1301,  1579, -1301,   550, -1301,  1584, -1301, -1301,  3562,  3562,
    1661, -1301,  1662, -1301,  1663, -1301,  1666,  4011, -1301,  3562,
    1562,   590, -1301,   380,  4678,  1671,  3562,  3562,  1682,  1081,
     906,  1583, -1301,   462,   462,  1172, -1301,  1275,  1275, -1301,
     452,  1677,  1602,  1657, -1301, -1301, -1301, -1301, -1301,  1693,
   -1301,   346,   588,   111,  1958,  1166,   111,   757,  1593, -1301,
   -1301, -1301,  1604,  1608,  1609, -1301, -1301, -1301,  2420, -1301,
    1421,  1323,   454, -1301, -1301, -1301,  1687, -1301,   907,   833,
   -1301, -1301,   462, -1301, -1301,  1674,   462,  1705,  1705,  1705,
   -1301,  1679,  1692,  2420,  2420,  1529,  1692,  1529,  1692,  1706,
    1711,   462, -1301,   528,  1699, -1301,   809,  1055,  1055,   524,
   -1301,  3562,  4029, -1301,  1635,  1717,  1456, -1301,  3562,  3562,
   -1301,  3562,   783, -1301,  1718,  3809, -1301,  4073, -1301, -1301,
    1721,  1729,  3562, -1301,  4154, -1301,  4678,  1736,  1730,  1731,
    3562,  3562, -1301,   116,  4678, -1301,  3562,  4173,  4196, -1301,
    4212, -1301,  4235,  4254,  1740,  4296, -1301,  4335, -1301,   238,
     241, -1301,  1684,   907, -1301, -1301,  1735,  3562,  4678,  1534,
    1737, -1301,   662,  4678,   907, -1301,  1748, -1301,   231,  4749,
     684,  1336, -1301,   694, -1301,  1742,   462,  1743,  1667, -1301,
    1668, -1301,  4678,  1751, -1301,   907,   907, -1301,  4678,  3562,
    4678,   780, -1301, -1301, -1301, -1301,  3562, -1301, -1301, -1301,
   -1301, -1301,  1745,  3827,   728, -1301, -1301,   906,   462,  1760,
     906,   906, -1301, -1301,   462,  1762,  1764,  1775,  1778,  1781,
     462,  1784,    94,  1145, -1301,  1787, -1301,   462, -1301, -1301,
     315, -1301, -1301,   462, -1301,   414, -1301, -1301, -1301,   408,
     315,  1713,   391,  1785, -1301,  1788,  1169,  1789,  1790,  1792,
    1793,  1794,  1795,   462,  1413,   462,  1427,  1796,  1797,  1798,
    1800,  1801, -1301,  4651, -1301, -1301, -1301, -1301,  1811,  1802,
    1812,  1803,  1804,  1813, -1301, -1301, -1301, -1301, -1301, -1301,
   -1301, -1301, -1301, -1301, -1301, -1301, -1301,  1818,   532, -1301,
     462,  1807,   408,   315,  1820,   462, -1301, -1301,   315,  1696,
    1077,   111,   111,  1170,  1692,  1815,   813, -1301, -1301,  1541,
    3562, -1301,  1674,   949,   462, -1301, -1301,   315, -1301, -1301,
   -1301, -1301, -1301, -1301,   769, -1301,  1692,  1692, -1301, -1301,
   -1301, -1301, -1301, -1301,   557,  1822, -1301,   462, -1301,  3562,
     462,   567,  1823,   462,   578,  1824, -1301, -1301,  3562,  1819,
     779,  4678,  1816,  1830, -1301,   855,  3562,  3562, -1301, -1301,
   -1301, -1301, -1301,  4678,  4678,  2368, -1301,  2368,  4678,  2968,
    1478,  3460,  3460,   907,  1821,  3562,    74,   907, -1301,   907,
   -1301,   335,  4817, -1301, -1301,   907,    64,  3562,  4678,  3562,
    4678,  1829,  1831,  3562, -1301,   280, -1301, -1301,   659, -1301,
   -1301, -1301, -1301, -1301, -1301, -1301, -1301,  1842,    23,   907,
   -1301,  1843,  1838, -1301,  3562,  1808, -1301, -1301,  3562, -1301,
    1808,   786,  1826, -1301, -1301, -1301,   462, -1301,  1099, -1301,
   -1301, -1301, -1301,   907, -1301,   907,  1757,  1758,  1763, -1301,
     462, -1301, -1301,   589,   462,   462,   462, -1301, -1301, -1301,
   -1301, -1301,   462, -1301, -1301,   315, -1301, -1301, -1301, -1301,
     304,  1841,   462,  1847,  3562,   542,  1858,   703,   703,   703,
     703,   703,   703,   703,  1771,  1860, -1301,  1861,  1862,  1864,
    1865,  1869,   703,   703,   703,   703,   462, -1301, -1301, -1301,
   -1301,  3625, -1301,  3625,  3625, -1301, -1301, -1301,   462,   601,
    3562,   315, -1301, -1301,   608,   462,   462,   462, -1301, -1301,
    1866,  1868,  1870,  2484, -1301,   995, -1301, -1301, -1301, -1301,
   -1301,   408,   315,   408,   315,   488, -1301, -1301,  1438, -1301,
    1323, -1301,  1871,  3862,   315,  1674, -1301,   462,   462, -1301,
    1853, -1301, -1301, -1301, -1301, -1301,  1859,  4678,   614, -1301,
   -1301,  1875, -1301, -1301, -1301, -1301, -1301, -1301,  4678, -1301,
   -1301, -1301, -1301,  1814,  1817,  1827,   106,  2897, -1301,    63,
    3319,  3351, -1301,  1863,  1286, -1301, -1301, -1301,   340, -1301,
      72, -1301,  4678,  4678, -1301, -1301,  4678, -1301,   462,   630,
   -1301,   315,   783,   907,   596,    23, -1301,   638,  1799, -1301,
     938,   798,  1791, -1301,  3492, -1301, -1301, -1301, -1301,  1810,
   -1301,   997,  1885,   650,   651,   679,   994,   997,    94,   462,
     462,  1876, -1301,   682,   683,   687,   462, -1301, -1301,   462,
    1880,   462,   462,  1204, -1301,  1882,   184,  1879,  3562,  4376,
    1310, -1301, -1301,  1881, -1301,  1834, -1301,   462, -1301,  1774,
   -1301,  1891,  1837, -1301,  1846,  1848,  1849,  1851,  1852,  1854,
   -1301, -1301, -1301, -1301, -1301, -1301,  1855,  1856,  1857,  1867,
     862,  1889,  3664, -1301, -1301, -1301, -1301, -1301, -1301, -1301,
   -1301, -1301, -1301,   462, -1301,   692,   715,   746,   462,  3562,
    3562,   462,  1835,   462,  1108, -1301, -1301,   315,   462,   315,
     462,   821, -1301,   504, -1301,  1896, -1301, -1301, -1301,   462,
     315, -1301, -1301, -1301,   462, -1301, -1301,    74,    74, -1301,
      74, -1301, -1301, -1301,    74, -1301, -1301, -1301,  1456, -1301,
   -1301,   747, -1301,   462,   462,   783,   907,   339,  1904,   408,
     315,   462, -1301,  1872,  4864, -1301,  1791,   203,  1908,  1791,
    1799, -1301,  4418, -1301,  1451,   520,  1885,  1884, -1301,  1883,
   -1301, -1301,   462, -1301, -1301,   462,   462,  1890,  1758, -1301,
   -1301, -1301,  3562, -1301, -1301, -1301,   749,   462, -1301,   462,
   -1301,  1905,  1897,  1927,  1600,  1936,  1942,  1948,  3879,  1952,
   -1301, -1301,  1357,   703,  1836,  3562,   703,  3562,  3562,   703,
     703,   703,   703,   703,   703,   703,   703,  1945,  1949,  3562,
    1955,  1878,  1437,   462, -1301, -1301, -1301, -1301,   756,  4456,
    4498,  1967,  1957, -1301,  3155, -1301,   462, -1301,   462, -1301,
   -1301, -1301, -1301,   462,   462, -1301, -1301, -1301, -1301, -1301,
    1965, -1301, -1301,   760,   411, -1301, -1301,   315,   462, -1301,
   -1301,  1972,   907,  1974,  1975,  1976,    89,  1986, -1301, -1301,
   -1301, -1301, -1301, -1301, -1301,  1977,  1799,   107, -1301,   907,
    1799, -1301,  1987,  1978,  1939, -1301, -1301,   547, -1301, -1301,
     771, -1301,   119,  1985, -1301, -1301,   708, -1301, -1301, -1301,
    4678, -1301, -1301,   667, -1301, -1301, -1301,   462,  1288, -1301,
     462,  1600, -1301, -1301, -1301, -1301,  1400,  1994, -1301,   179,
    1910, -1301,  3562, -1301, -1301,  1911,   804,  4678,   812,  1912,
    1913,  1914,  1915,  1916,  1917,  1918,  1919,   462,   462,  1878,
   -1301,  3562, -1301, -1301,   317,  3531,  3562,  3562,  1934,  1154,
   -1301, -1301, -1301, -1301,   907, -1301, -1301,   462, -1301,  3562,
   -1301,  2212,  3562,  1456,  3562,   462, -1301,   907,   690, -1301,
    3562,   408,   315,   462,   907, -1301,  2011, -1301,   641, -1301,
   -1301,   547,  1985, -1301,   547,   874, -1301,  2005,  1482, -1301,
    2009,  1482,  1482, -1301, -1301, -1301, -1301, -1301,  1357,  3562,
   -1301,  3562,  2016,  3562,  2017,  3562,  3562,  3562,  3562,  3562,
    3562,  3562,  3562,  3562,  2012,  2013,   815, -1301,  1953, -1301,
     319,   230, -1301,    92,  3739,  4678, -1301, -1301, -1301, -1301,
    4539,  4578,  2018,  4619,   907,   803, -1301,  4678,   315,   462,
   -1301,  1969, -1301,  2021, -1301,  2020,  2019,  2028,  2029,  2023,
   -1301,  3562,  2026,  3562,  2027, -1301,   826,   840, -1301,  4660,
   -1301,   876, -1301,  4678,   884,   892,  1959,  1961,   899,   903,
     904,  1962, -1301,  3562,   317,   317, -1301, -1301,  3531,   317,
     462,   907,   907,  3562,   907,   907,   860, -1301, -1301,   462,
   -1301, -1301, -1301, -1301,   900, -1301, -1301,  2038,  4678,  3562,
    2039,  3562,  2051,  3562,  2052,  3562,  3562,  2054,  3562,  2055,
    3562,  2057,  3562,  3562,  3562,  2059,  3562,  2060,  3562,  2064,
    3562,  3562,   905, -1301, -1301, -1301, -1301,  2068,  2007, -1301,
    1305, -1301,  3792, -1301,   940, -1301, -1301, -1301, -1301,  2077,
   -1301, -1301, -1301,  2072, -1301,  2073, -1301,   912, -1301,   919,
     922, -1301, -1301, -1301,   929, -1301,   930,   939,   945, -1301,
     946, -1301,   948, -1301,   950,   955, -1301,  3562,  2014,   907,
   -1301,  1456, -1301, -1301,  2075, -1301,  2083,  2084,  2086,  2088,
    2089,  2090,  3562,  2091,  3562,  2092,  2095,  2096,  2097,  3562,
    2015,  2099, -1301,  2093, -1301, -1301, -1301, -1301, -1301, -1301,
   -1301,   960, -1301,   964, -1301, -1301, -1301, -1301,   983,  3562,
     462,   907,  2105,  2108,  2110,  2025,  1077, -1301, -1301, -1301,
   -1301,  3562,  1176,   991, -1301, -1301,  3562,  2030,  3562,  2032,
    3562,  2040,  3562,  2041,  3562,  2045,  3562,  2104, -1301
};

/* YYPGOTO[NTERM-NUM].  */
static const short int yypgoto[] =
{
   -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301,
   -1301, -1301,  1590,  1409, -1301, -1301,  1053,  1611, -1301,  2143,
   -1301, -1301, -1301, -1301,  -306, -1301,  -270, -1301, -1301, -1301,
   -1301, -1301, -1301,  1964, -1301,  1979, -1301,  1332,  -540, -1301,
    -544, -1301,  -325,    13, -1301, -1301, -1301,  1805, -1301, -1301,
   -1301, -1301, -1301,  1806, -1301, -1301, -1301, -1301, -1301,  1828,
   -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301,
   -1301,  1118,  -497,    41, -1301,    45, -1301,  1516, -1301,    46,
      49, -1301, -1301,    51, -1301,   -97,   817, -1301,     5, -1301,
   -1301,  -169,  2122, -1301, -1301, -1301,  -541,  -532,  -716, -1301,
    1933,  1360,    24,  1314,  -412,  1155,  -216,   -67, -1301, -1301,
   -1301,  2123,   -39, -1301,  1059, -1301, -1301, -1301,  -649, -1301,
    1492,  1702,  -409, -1301,  -761,  -194,  1025,  1588, -1301,  -984,
    -535,  -478, -1301, -1025,   941, -1301, -1301,    87,  1971,  1960,
      33,   -63, -1301, -1301, -1301, -1301, -1301,  1873, -1301, -1301,
   -1301,  1249, -1301,  -472,  1886,   -14, -1301, -1301,  1491, -1301,
    1494, -1301, -1301, -1008,  -419,  -774, -1301, -1301, -1301,   609,
   -1301,   611, -1301, -1301, -1301, -1301, -1301, -1301,  1250,   227,
    1840,  -695, -1301,  1067, -1301,   802, -1300, -1301, -1301, -1301,
     807, -1301, -1301,   612, -1222, -1301,   -59,  1887, -1301, -1301,
     -15,  -226, -1301, -1301, -1301, -1301, -1301, -1301, -1301,   536,
   -1301, -1301,  -444, -1301, -1301, -1301,  -451,   -31,  -791, -1079,
   -1301, -1301,  -403, -1301, -1209,  1124, -1301,   566, -1301, -1301,
   -1301, -1301, -1301, -1204,   745,   543, -1301, -1301, -1201, -1301,
   -1301, -1301,  1436, -1301, -1301, -1301,  -748, -1301,  -694,  -724,
   -1301,  -684,   643,  1028, -1064,   913, -1301, -1301,   805,  -454,
   -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301, -1301,
   -1301, -1301, -1301, -1301, -1301, -1301,  -494,   605, -1162,   733,
     366,    91,  1235, -1301, -1301,   719, -1301,  1061,   797, -1301,
     -79, -1301,  1832, -1301,   309,  1599,  -323,  -154,   -84,  -294,
    1809,   -82,  1594, -1301,  1354, -1301, -1301,   -23,  -486,  1698,
   -1301,  -109,     0,  1892,  2160,    15,   865,  2218
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -790
static const short int yytable[] =
{
       6,   677,   387,    26,    26,   125,   205,   654,   322,   228,
     660,   119,   415,     5,   895,  1204,   739,   425,   415,   635,
     691,   953,   807,   997,   200,   525,  1253,   817,   678,   217,
     815,    69,   220,   393,   235,   548,  1026,   947,   453,   115,
     988,   989,   991,   196,   824,  1370,   518,    45,   146,   120,
    1372,    47,    49,  1374,   547,    50,   749,    52,   970,   802,
     844,  1044,    95,   351,   134,   740,   851,   854,   971,   845,
     676,   808,   667,  1241,   319,   852,   855,    -2,  1234,   986,
     986,   986,   986,   308,   472,   343,   497,   178,  1074,  1014,
    1480,   119,   119,   294,   207,  1085,   289,   624,   626,   240,
     241,   365,   120,   287,  1465,   592,     8,  1579,   -66,   596,
     598,   -66,   -66,    14,   741,   664,   472,   366,  1321,   239,
     394,  1230,   875,   219,  1104,   222,     9,  1385,  1260,   120,
     120,  1386,   -66,   876,  1481,  1387,  1091,   -66,   250,  -782,
    -782,   288,    67,   396,  1240,  1388,  1428,   305,   211,    97,
      71,     1,   405,  1471,   580,   581,   120,   174,   388,   389,
    -257,   508,   347,   301,   348,  1478,  -257,   390,   365,   821,
    1483,     1,    72,  1466,    68,   -66,   208,   210,   -66,   -66,
    -257,   213,   577,   364,   372,  1480,    15,    16,   224,    17,
     508,    63,     1,   523,   607,   608,   677,     1,  1497,   -66,
       1,  -782,     1,   712,   -66,     1,  -782,  -782,   891,    98,
    1295,   583,   896,    98,   877,     8,   119,     1,  1389,  1353,
     119,   120,     1,   905,   422,   707,   610,   485,     1,   449,
     120,   519,   442,   584,     1,     9,   212,   609,  1133,  1134,
    1135,   119,   454,   455,   409,   403,   473,   490,   391,  1026,
      98,  1206,  1370,   505,   120,  1439,  1545,  1372,   120,  1548,
    1374,   522,  1549,   578,   242,   676,   899,   548,  -782,   214,
     120,   548,  1376,   548,   342,  1380,   225,  1498,  1146,   120,
     120,   120,  1141,  1460,  1220,  1231,   835,   617,  1147,   838,
     839,   840,   841,   907,   397,     1,   494,   494,   814,  1195,
    1196,  1197,  1180,   296,  1377,   173,   174,   611,   298,  1058,
    1577,   314,  1181,   503,  1031,  1033,   398,   154,   155,   120,
     622,  1061,   888,   836,   837,   893,  1449,  1517,  1578,  1517,
    1140,   120,   585,   216,  1575,   683,   614,  1556,   615,  1557,
     235,   216,  1097,   400,  1564,  1565,  1566,   735,  1568,  1569,
    1570,  1571,   243,   408,   638,   701,   543,   153,  -127,     1,
     364,     8,   154,   155,   216,   156,     1,   530,   618,     1,
     481,   482,  1641,   714,   410,   364,   372,  1516,  -127,   364,
     364,     9,  1020,  1021,  1020,  1021,   162,   423,  1022,   175,
    1022,   225,   601,   580,   581,  1541,   299,   710,  1023,   315,
    1023,  1355,  1141,     8,   214,    45,   415,   424,     1,    47,
      49,  1087,   933,    50,   120,    52,   120,  1087,  1291,  1089,
    1286,  1370,  1101,     9,  1239,   189,  1372,   483,   442,  1374,
    1206,   214,   216,  1278,   665,   430,  1346,  1347,  1088,  1348,
    1109,   225,   857,  1349,  1090,     1,   250,     1,   736,   484,
     583,  1657,    65,  1116,  1246,  1587,     8,  1290,   986,  1665,
     437,   959,   225,     1,   860,   418,   120,     1,     1,   729,
     438,   818,   584,  1456,     8,   243,     9,   342,   508,   679,
     372,   350,  1328,    66,   738,   747,   968,   969,   800,   548,
     806,   741,   488,   491,     9,   243,  1216,  1042,  1215,   176,
       8,   613,   128,  1631,     8,  1633,   216,  1636,  1037,  1622,
      98,   548,   548,  -255,   750,  -789,   960,   803,   961,   620,
       9,  1384,   245,   431,     9,   113,  -789,   419,  1385,   205,
    1051,  1052,  1386,  -255,   742,   628,  1387,   684,   846,     1,
     822,   856,  1007,  1150,   717,   931,  1388,   421,   720,   721,
     730,  1414,   819,   859,     8,  1385,   966,   152,   153,  1386,
    1026,   686,     8,   154,   155,  1403,   156,  1053,   364,  1251,
     157,   158,   439,  1388,     9,   159,   215,  1059,   372,   372,
     225,   315,     9,   199,   160,   161,   467,   162,  1062,   214,
     736,   741,   364,   364,   364,   468,   364,  1248,   364,  1132,
    -155,   129,   218,  1690,   131,   986,   216,   225,  -257,  1012,
    1408,  1190,   850,   853,  -257,  -255,    80,    81,  1194,  1389,
    -155,  -255,   508,   243,  1225,   315,   847,  1109,  -257,   665,
    1008,   120,  1717,  1047,   742,  -255,  1222,  1151,  1152,  1153,
    1242,   221,  1249,   580,   581,  1715,  1389,   665,  1255,  1385,
    -255,  -255,  1247,  1386,   373,   847,   287,  1723,  1544,   892,
    1271,  1273,  1727,   892,  1729,   847,  1731,  1388,  1733,   374,
    1735,     8,  1737,   957,   679,  1206,   847,   216,   964,   902,
     154,   155,   163,   164,  1486,   507,  1491,   431,    65,  1274,
     736,     9,  1283,  1284,   288,   928,   930,  1285,    98,  1008,
     583,   917,  1325,   129,  1161,  -255,   431,  -255,  1722,   223,
     965,   920,   847,  1514,   226,     8,  1385,  1467,   227,   709,
    1386,   230,   584,  1488,  1387,  1326,   986,  1492,  1243,  -255,
    1474,   670,   948,   530,  1388,     9,  1256,   152,   153,   938,
    1389,  1018,     8,   154,   155,   935,   156,   508,  1272,  1129,
     157,   158,   250,   986,  1515,   159,  1327,  1351,   804,  1401,
     903,   736,     9,  1011,   160,   161,  1443,   162,  1087,  -120,
    1455,  1138,  1032,  1034,  1536,   216,  1064,  1275,   445,  1385,
     431,   431,   578,  1386,  1045,   431,  1049,  1387,   231,  -120,
     431,    78,   508,   446,  1350,  1354,  1065,  1388,  1151,  1152,
    1153,   226,  -190,  1117,   580,   581,    79,  1389,  -190,  1212,
       6,   232,  1345,   431,   364,  1258,   932,  1192,     1,  -190,
     250,  1502,  -190,  1024,   233,  1297,   508,   226,   671,  1504,
    1479,   849,  1572,     8,    80,    81,   364,   364,  1208,   216,
    1210,  1098,  1473,  1602,   431,  1243,    89,   431,   473,  1039,
    1219,   114,  1082,     9,   431,   473,  1086,  1604,  1243,   736,
     665,   583,   163,   164,   244,   665,    12,  1050,   959,   287,
    1389,    62,  -782,  -782,   665,   154,   155,   508,   508,   142,
     580,   581,  1385,   584,   508,  1585,  1386,  1588,  1317,   892,
    1387,  -701,  -190,  1607,    96,   892,  1259,   106,   111,   121,
    1388,  1609,  1503,   320,   321,   106,   137,   288,  1385,  1611,
    1505,  1040,  1386,  1573,  1638,  1468,  1615,   174,  1110,  1112,
    1617,  1619,  1666,   960,  1603,   961,  1388,   150,  1191,  1676,
      12,     1,  1453,  1550,  -782,    98,  1677,   583,  1605,  1678,
     180,   182,  1026,  1126,  1635,  1126,  1679,  1680,  1206,   587,
     588,   717,   121,  -701,    96,    96,  1681,   475,   476,   584,
    1141,     1,  1683,  1685,   106,  1686,   106,  1687,   747,   250,
     250,   250,  1688,  1389,  1608,   245,   551,  1712,   238,   121,
     121,  1713,  1610,   447,   908,    31,    32,    33,     1,  1087,
    1612,   121,  1207,   251,  1209,   292,  1087,  1616,   448,  1389,
    1714,  1618,  1620,  1667,   106,  1245,   121,   150,  1725,   469,
    1608,   589,   119,  1336,   247,  1338,  1535,  1608,   470,  1532,
    1608,   511,   512,     6,  1672,     6,  1343,  1608,  1608,   415,
     250,   250,   250,   733,  1244,     1,  1024,  1682,  1024,   354,
    1276,   557,    40,  1684,  1608,   473,  1608,   582,  1608,   290,
     120,    98,   293,  1689,  1264,  1265,  1358,   665,  1608,   665,
    1020,  1021,  1608,   250,    42,  1250,  1022,     8,     1,  1163,
    1163,   121,    96,  1168,  1169,   295,  1023,    96,   297,    96,
     121,  1608,   580,   581,    88,   106,  1179,     9,   300,  1726,
     106,   716,    -3,     8,    -3,  1130,    -3,   416,   417,  1600,
    1322,  1576,  1205,   892,   121,  1254,   174,  1087,   121,  1647,
     174,  1649,  1650,     9,  1119,   302,  1654,   432,  1656,   440,
     121,  1126,  1660,     1,  1662,     1,  1664,  1126,   948,   121,
     121,   121,   456,   582,  1634,     7,    73,    98,    74,   583,
      75,   309,  1020,  1021,   964,  1643,     8,  1645,  1022,    -3,
      -3,   250,    -3,   183,   311,  1623,  1624,     8,  1023,   184,
    1626,   584,   313,  1457,   487,   531,     9,   797,     1,   121,
     976,   150,   185,  1020,  1021,   150,   150,     9,     8,  1022,
     150,   121,     8,   316,   216,   977,   346,   375,  1701,  1023,
    1703,   950,  1335,   376,   532,  1708,   473,   473,     9,   473,
     533,   534,     9,   473,     6,     1,   352,    12,   190,  1035,
    1357,   191,   192,   250,   434,   442,   665,  1024,   435,  1020,
    1021,   544,   436,  1424,   549,  1022,  1292,  1693,   356,    62,
    1293,  1375,   576,   550,   100,  1023,     1,  1322,  1527,   250,
     355,  1020,  1021,   381,   102,  -202,   892,  1022,   193,   194,
     195,   379,   606,   120,   531,     8,   479,  1023,   380,     8,
    1724,   685,   480,   141,   121,  -202,   121,   152,   153,   288,
     384,   686,     8,   154,   155,     9,   156,   382,  1539,     9,
     157,   158,     1,   722,   238,   159,   383,   477,   174,   533,
     534,  1523,     9,   478,   160,   161,  1238,   162,   637,   154,
     155,   154,   155,   399,     1,  1489,   324,   325,   326,   327,
     328,   329,   330,   331,   332,  1670,   121,     8,   385,   107,
     333,   334,   190,   665,   659,   191,   192,  1300,   663,  1301,
       8,   569,   122,     8,     6,     8,   386,     9,  1472,   433,
    1424,     8,   113,  -113,  1589,   206,   918,  1024,  1266,    86,
       9,   682,   919,     9,  1266,     9,   133,   135,   113,   250,
       8,     9,  1461,  -113,    87,  1416,   892,     8,     8,  1417,
    1361,   257,   258,   259,  1362,  1363,  1364,    88,   138,  1110,
       9,   420,   267,  1365,   520,   335,  1366,     9,     9,  -196,
     724,   718,   163,   164,  1421,     8,   513,  1421,   514,   528,
    1421,  1421,  1431,  1432,  1421,  1421,  1421,  1436,  1494,  -196,
       8,   662,  1495,   429,   987,     9,   336,   337,   338,   339,
     801,   443,     8,  1528,  1523,     8,   471,  1567,   990,   569,
       9,   444,  1538,     8,   450,   576,   576,   665,  1375,     8,
     442,  1071,     9,  1072,     6,     9,   569,   825,   451,     6,
       8,   828,  1382,     9,   506,  1214,   452,  1024,   571,     9,
     457,   190,  1024,     8,   191,   192,   606,   892,     8,   489,
       9,   492,   606,   606,  1254,   571,   288,   496,   120,  1075,
       8,   121,   526,     9,   112,   152,   153,   510,     9,     8,
       8,   154,   155,   113,   156,   154,   155,    88,   157,   158,
       9,     8,   515,   159,   665,   113,    88,   216,   516,     9,
       9,   527,   160,   161,   113,   162,   630,   631,   632,   546,
       6,     9,   633,   324,   325,   326,   327,   328,   329,   330,
     331,   332,  1658,  1024,  1254,   539,     8,   333,   334,   545,
     401,   152,   153,   567,   121,   568,     8,   154,   155,   569,
     156,   922,   570,     8,   157,   158,     9,     8,   593,   159,
    1076,   304,   594,   253,   590,   254,     9,   579,   160,   161,
     599,   162,   600,     9,     6,     6,   616,     9,   571,     6,
     629,  1630,  1461,   391,  1461,   892,  1461,  1024,  1024,     8,
     725,   727,  1024,   206,   809,   944,  -371,   949,   951,  -371,
     197,   198,   335,   665,   666,  -371,    88,  1375,   958,     9,
     163,   164,     8,   831,   832,   645,  1407,   973,    15,    16,
    1233,    17,   619,  1233,  1233,  -371,  1080,  1081,   973,   973,
     973,   973,     9,   336,   337,   338,   339,     1,   621,  -371,
    -371,  -371,  -371,  -371,  -371,   288,  1187,  1188,   442,   646,
    -371,     8,   649,  -371,  -371,   304,  -371,   656,  -371,  -371,
     651,   661,   658,   669,  -371,   801,   163,   164,    88,  1630,
     694,     9,  1425,   695,  -371,  1429,  1430,   696,  1036,  1433,
    1434,  1435,   699,   702,   576,   703,   120,   704,   705,  1046,
     711,   708,   715,   357,   731,  -782,   733,  -371,  -782,   718,
     732,  -371,   811,   734,  -782,   820,   812,   813,   829,   848,
    1162,  1461,  1056,  1166,  1167,  1056,     6,   833,   111,  -371,
     826,  -371,     6,   842,  -782,  1176,  1177,  1178,   843,  1024,
    -782,  -782,  -782,   618,   390,  1024,   866,   864,  -782,  -782,
    -782,  -782,  -782,  -782,   867,   -53,   870,   871,   872,  -782,
     885,   897,  -782,  -782,   901,  -782,   894,   121,   906,   921,
     923,   926,   152,   153,   934,   924,   925,     8,   154,   155,
     937,   156,   939,  1102,   940,   157,   158,  -782,   153,  -782,
     159,   639,     8,   154,   155,   941,   156,     9,   942,   160,
     161,   943,   162,  -782,   945,  -782,  -782,   952,  -782,   967,
    -782,   974,     9,  1019,   975,   978,   979,   162,   980,   981,
     982,   983,   992,   993,   994,  1131,   995,   996,  -782,   686,
       1,  1000,  1002,  1005,  1001,  1003,  1004,  1137,  1006,  1010,
    1013,  1038,  1054,  1060,  1063,  1066,   617,   973,  1083,  1094,
     973,  1095,   973,   973,   973,   973,   973,   973,   973,  1067,
     640,   641,  1103,  1113,  1114,  1128,  1129,   973,   973,   973,
     973,   973,  1118,  1145,  1130,  1148,   341,   344,  1160,  1141,
    1170,  1171,  1172,   801,  1173,  1174,   168,  -102,   140,  1175,
    -102,   849,  1199,  -102,  1200,  1226,  1201,   163,   164,  -102,
    1217,  1223,  1104,  1227,   254,  1270,  1228,  1257,  1282,  1302,
    1213,  1296,   341,   576,  1289,   576,  1294,  1229,  1305,  -102,
    1301,  1318,  1221,  1341,  1356,  -102,  -102,  -102,  1379,  1333,
    1263,  1405,  1404,  -102,  -102,  -102,  -102,  -102,  -102,  -102,
    -102,  -102,  1303,  -102,  -102,  1306,  1360,  -102,  -102,  1395,
    -102,  1396,  -102,  -102,  1307,  1399,  1308,  1309,  -102,  1310,
    1311,  1406,  1312,  1313,  1314,  1315,  -102,  -102,  -102,   751,
    1410,  -102,  -102,  1102,  -102,  1316,  1411,  1412,   752,  1437,
    1422,   323,  1440,  1438,   752,  -102,  1441,  1446,  -102,  1447,
    -102,  -102,  1454,  -102,  -102,  -102,  -102,  -102,  1459,  -102,
    1462,  1463,  1464,  1279,  1280,  1281,  1469,  1475,  1477,  1470,
    1476,  1484,  1496,  -102,  1288,  -102,   973,   973,  1499,  1501,
    1506,  1507,  1508,  1509,  1510,  1511,  1512,  1513,  1526,  1542,
    1551,   341,   973,   753,  1553,   406,  1558,  1560,  1583,  1486,
    1489,  1592,  1574,  1591,  1594,   413,   414,  1593,  1595,  -441,
    1596,  1599,  1601,   344,   754,   555,   755,   756,   757,   758,
     759,   760,   761,   426,   428,  1642,  1644,  1613,  1324,  1614,
    1621,  1646,  1648,   762,  1651,  1653,  1332,  1655,  1334,  1659,
    1661,   763,   764,  1337,  1663,  1339,  1340,   765,   766,   767,
     768,   769,   770,   771,  1342,  1668,  1669,  1673,    28,  1674,
    1675,    29,  1694,  1695,  1696,  1691,  1697,     8,  1698,  1699,
    1700,  1702,  1704,   121,   341,  1705,  1706,  1707,  1102,  1102,
    1711,   341,   341,  1709,  1710,  1718,  1359,     9,  1719,   121,
    1720,  1738,  1378,  1721,   341,   723,   341,   936,  1728,  1383,
    1730,    30,    31,    32,    33,    34,    35,   949,  1732,  1734,
    1397,  1398,    36,  1736,   517,    37,    38,    27,    39,   728,
     377,  1041,  1402,  1211,   973,   108,   524,   428,   411,   973,
    1009,  1055,   132,  1189,  1252,   378,   904,   823,   973,   559,
     560,   973,   402,  1115,   973,   973,   973,   973,   973,   973,
     973,   973,   680,   493,  1352,   404,   927,  1625,  1442,    40,
     929,  1627,   561,    41,  1277,  1127,   542,   495,  1485,  1482,
     524,  1450,   504,  1451,   612,  1692,  1640,  1237,  1452,   999,
    1320,    42,  1415,  1652,  1165,   341,  1493,  1555,  1304,  1500,
     863,  1070,   341,  1458,     8,   151,   868,    64,     0,   625,
     627,     0,     0,     0,   521,     0,     0,     0,   634,     0,
       0,   636,     0,     0,     9,     0,   644,     0,     0,   113,
       0,   623,   647,   648,     0,   650,     0,   652,     0,   653,
       0,   655,     0,     0,     0,     0,   657,     0,     0,     0,
       0,     0,   973,     0,     0,   973,   973,  1361,   257,   258,
     259,  1362,  1363,  1364,   668,     0,     0,   673,     0,   267,
    1365,     0,     0,  1366,     0,     0,     0,     0,   524,     0,
       0,   692,   973,   973,     0,     0,     0,     0,     0,     0,
     341,     0,   698,     0,     0,     0,     0,   700,   524,     0,
       0,     0,  1529,   341,     0,   341,   121,     0,   121,     0,
    1534,     0,   341,     0,   341,   713,   524,     0,  1540,     0,
       0,     0,   341,     0,     0,   341,   341,     0,   341,     0,
     341,   341,     0,   341,     0,   341,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   341,     0,     0,     0,
       0,   341,     0,     0,     0,   152,   153,     0,     0,     0,
       8,   154,   155,     0,   156,     0,     0,     0,   157,   158,
     341,     0,     0,   159,     0,     0,   341,     0,   341,     0,
       9,     0,   160,   161,  1590,   162,     0,     0,     0,     0,
       0,   341,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   357,     0,  -782,     0,     0,  -782,   524,   861,     0,
     413,     0,  -782,     0,     0,     0,     0,     0,     0,     0,
       0,   861,     0,     0,     0,  1332,     0,     0,     0,   873,
     874,     0,  -782,     0,  1637,   878,     0,     0,  -782,  -782,
    -782,     0,     0,   640,   641,     0,  -782,  -782,  -782,  -782,
    -782,  -782,     0,     0,     0,     0,   898,  -782,   900,     0,
    -782,  -782,     0,  -782,     0,  1202,     0,  -782,     0,     0,
    -782,     0,     0,     0,     0,   121,  -782,     0,     0,  1203,
     163,   164,     0,     0,     0,  -782,     0,  -782,   524,     0,
       0,     0,     0,     0,     0,     0,  -782,     0,     0,     0,
       0,  -782,     0,  -782,  -782,     0,  -782,     0,  -782,     0,
    -782,  -782,  -782,  -782,  -782,  -782,   121,     0,     0,     0,
       0,  -782,     0,     0,  -782,  -782,  -782,  -782,     1,  1020,
    1021,     0,     0,     0,     0,  1022,     0,     0,     0,   341,
       0,     0,     0,     0,     0,  1023,     0,     0,     0,     0,
       0,   341,   341,     0,     0,  1716,   341,     0,   595,     0,
    -782,     0,     0,  -782,     0,     0,     0,     0,  -782,  -782,
       0,     0,  -782,     0,     0,     0,   341,     0,   341,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,  -782,
    -782,     0,     1,     0,     0,  -782,  -782,  -782,     0,     0,
       0,     0,     0,  -782,  -782,  -782,  -782,  -782,  -782,  1043,
       0,     0,     0,     0,  -782,     0,     0,  -782,  -782,     0,
    -782,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1057,     0,
       0,     0,  -782,     0,  -782,     0,     0,     0,  1144,     0,
       0,     0,     0,     0,     0,  1068,  1068,     0,  -782,     0,
    -782,  -782,     0,  -782,   644,  -782,   644,     0,     0,   524,
     524,   524,     0,     0,  1084,     0,     0,     0,     0,     0,
       0,     0,     0,  -782,     0,     1,  1092,     0,  1093,     0,
       0,   597,  1096,  -782,     0,     0,  -782,     0,     0,     0,
       0,     0,  -782,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   692,     0,     0,     0,   698,     0,     0,
       0,   341,  -782,     0,     0,     0,     0,     0,  -782,  -782,
    -782,     0,     0,     0,     0,   341,  -782,  -782,  -782,  -782,
    -782,  -782,     0,     0,     0,     0,   341,  -782,     0,     0,
    -782,  -782,     0,  -782,     0,     0,     0,     0,     0,     0,
       0,     0,   341,  1149,     0,     0,     0,     0,     0,     0,
     341,   341,   458,     0,   341,  -782,     0,  -782,     0,     0,
       0,     0,     0,  -495,     0,  -495,   459,     0,     0,     0,
       0,  -782,     0,  -782,  -782,     0,  -782,     0,  -782,     0,
    -495,     0,  -495,  -495,     0,     0,     0,     0,  -495,     0,
       0,     0,     0,     0,     0,     0,  -782,     0,     1,     0,
       0,  -495,     0,     0,     0,     0,     0,   341,     0,     0,
       0,     0,     0,     0,     0,     0,  -495,  -495,  -495,  -495,
    -495,  -495,  -495,     0,  -495,  -495,  -495,  -495,  -495,  -495,
       0,   462,  -495,     0,  -495,   460,     0,     0,  1144,     0,
       0,     0,  -782,     0,  -782,   463,   524,     0,     0,   524,
     524,     0,     0,     0,     0,     0,     0,     0,     0,  -782,
       0,  -782,  -782,     0,   152,   153,     0,  -782,     0,     8,
     154,   155,     0,   156,     0,     0,     0,   157,   158,  -495,
    -782,     0,   159,  1262,     0,     0,     0,     0,     0,     9,
       0,   160,   161,     0,   162,  -782,  -782,  -782,  -782,  -782,
    -782,  -782,   464,  -782,  -782,  -782,  -782,  -782,  -782,     0,
       0,  -782,     0,  -782,     0,     0,     0,  1298,     0,     0,
     341,     0,     0,     0,     0,     0,     0,     0,     0,  1073,
       0,     0,     0,     0,     0,     0,     0,  1232,   472,  1076,
    -782,     0,  -782,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   341,  -782,     1,  -782,
    -782,     0,     0,     0,     0,  -782,     0,     0,  1329,  1330,
       0,     0,     0,     0,     0,     0,     0,     0,  -782,     0,
       0,     0,     0,     0,     0,     0,     0,   341,   341,   163,
     164,     0,     0,  -782,  -782,  -782,  -782,  -782,  -782,  -782,
       0,  -782,  -782,  -782,  -782,  -782,  -782,     0,     0,  -782,
       0,  -782,     0,     0,   124,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  -782,     0,  -782,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  -782,     0,  -782,  -782,     0,     0,     0,     0,
    -782,  1400,     0,     0,     0,     0,     1,     0,   341,     0,
       0,  1487,     0,  -782,     0,     0,  1490,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1427,  1427,  -782,  -782,
    -782,  -782,  -782,  -782,  -782,   341,  -782,  -782,  -782,  -782,
    -782,  -782,     0,     0,  -782,     0,  -782,     0,     0,     0,
       0,   152,   153,     0,     0,     0,     8,   154,   155,     0,
     156,     0,     0,     0,   157,   158,  1448,     0,  -782,   159,
       0,  -782,     0,     0,     0,     0,     9,  -782,   160,   161,
       0,   162,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     1,     0,     0,     0,     0,  1552,  -782,     0,  1554,
    1490,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  -782,  -782,  -782,  -782,  -782,  -782,     0,     0,     0,
       0,     0,  -782,     0,     0,  -782,  -782,     0,  -782,     0,
    1020,  1021,   341,   341,     0,     0,  1022,     0,   341,   341,
       0,   341,     0,     0,     0,   341,  1023,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   524,  1524,  1525,   341,     0,  -782,
       0,   341,   342,  -782,     0,     0,   163,   164,  1530,     0,
       0,  1531,     0,  1533,     0,     0,     0,     0,     0,  1537,
       0,  -782,     0,     1,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   341,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1427,     0,
    1427,     0,  1559,     0,  1563,  1427,  1427,  1427,     0,  1427,
    1427,  1427,  1427,     0,     0,     0,   152,   153,     0,     0,
     341,     8,   154,   155,     0,   156,     0,     0,     0,   157,
     158,     0,     0,     0,   159,     0,     0,     0,     0,     0,
       0,     9,     0,   160,   161,     0,   162,     0,   152,   153,
    1598,     0,  1598,     8,   154,   155,     0,   156,     0,     0,
       0,   157,   158,     0,     0,     0,   159,     0,     0,     0,
       0,     0,     0,     9,     0,   160,   161,   524,   162,     0,
       0,     0,  1632,     0,     0,     0,     0,     0,     0,  1235,
       0,  1076,     0,     0,     0,     0,     0,     0,  1598,     0,
    1598,     0,  1563,     0,  1563,  1563,     0,  1563,     0,  1563,
       0,  1563,  1427,     0,     0,  1563,     0,  1563,     0,  1563,
    1427,  1236,     0,  1076,     0,   152,   153,     0,     0,     0,
       8,   154,   155,     0,   156,     0,   429,     0,   157,   158,
       0,   163,   164,   159,     0,     0,     0,     0,     0,     0,
       9,     0,   160,   161,     0,   162,     0,   152,   153,     0,
       0,     0,     8,   154,   155,     0,   156,     0,     0,     0,
     157,   158,     0,   163,   164,   159,     0,     0,     0,     0,
       0,  1563,     9,  1563,   160,   161,     0,   162,  1563,   152,
     153,     0,     0,     0,     8,   154,   155,     0,   156,  1261,
       0,     0,   157,   158,     0,     0,     0,   159,     0,     0,
       0,     0,     0,     0,     9,     0,   160,   161,     0,   162,
       0,     0,     0,     0,     0,     0,     0,     0,   152,   153,
       0,     0,  1076,     8,   154,   155,     0,   156,     0,     0,
       0,   157,   158,     0,     0,     0,   159,     0,     0,     0,
     163,   164,     0,     9,     0,   160,   161,     0,   162,   152,
     153,     0,     0,     0,     8,   154,   155,     0,   156,     0,
       0,     0,   157,   158,     0,     0,     0,   159,     0,     0,
       0,     0,   163,   164,     9,     0,   160,   161,     0,   162,
       0,   152,   153,     0,     0,     0,     8,   154,   155,     0,
     202,     0,     0,  1520,   157,   158,     0,     0,     0,   159,
       0,     0,     0,     0,   163,   164,     9,     0,   160,   161,
       0,   162,   152,   153,     0,     0,     0,     8,   154,   155,
       0,  1182,     0,     0,     0,   157,   158,     0,     0,     8,
     159,   252,     0,     0,     0,     0,     0,     9,     0,   160,
     161,     0,   162,   163,   164,     0,   253,     0,   254,     9,
       0,   152,   153,     0,   113,     0,     8,   154,   155,     0,
    1319,     0,     0,     0,   157,   158,     0,   255,    28,   159,
       0,    29,     0,     0,   163,   164,     9,     8,   160,   161,
       0,   162,   256,   257,   258,   259,   260,   261,   262,     0,
     263,   264,   265,   266,   267,   268,     0,     9,   269,     0,
     270,     0,     0,   551,   552,   553,   163,   164,     0,     0,
       0,    30,    31,    32,    33,    34,    35,     0,     0,     0,
       0,     0,    36,     0,     0,    37,    38,     0,    39,  1580,
       0,     0,   154,   155,     0,     0,     0,   163,   164,   324,
     325,   326,   327,   328,   329,   330,   331,   332,     0,     0,
     554,     0,   555,   333,   334,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   556,     0,   557,    40,
       0,   558,     0,    41,     0,     0,   163,   164,     0,     0,
       0,     0,  1671,     0,     0,   154,   155,     0,     0,     0,
       0,    42,   324,   325,   326,   327,   328,   329,   330,   331,
     332,     0,   630,   631,   632,     0,   333,   334,   865,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   335,     0,
     630,   631,   632,   333,   334,     0,   869,   324,   325,   326,
     327,   328,   329,   330,   331,   332,     0,     0,     0,     0,
       0,   333,   334,     0,     0,     0,     0,     0,     0,   336,
     337,   338,   339,     0,     0,   630,   631,   632,     0,     0,
       0,  1218,   324,   325,   326,   327,   328,   329,   330,   331,
     332,   335,   630,   631,   632,     0,   333,   334,  1413,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   335,     0,
       0,     0,     0,   333,   334,     0,     0,     0,     0,     0,
       0,     0,   336,   337,   338,   339,   335,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   336,
     337,   338,   339,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   336,   337,   338,
     339,   335,   154,   155,   395,     0,     0,     0,     0,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   335,     0,
       0,     0,     0,   333,   334,     0,     0,     0,     0,     0,
       0,     0,   336,   337,   338,   339,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   154,   155,     0,   336,
     337,   338,   339,   324,   325,   326,   327,   328,   329,   330,
     331,   332,     0,     0,   154,   155,   706,   333,   334,     0,
     509,   324,   325,   326,   327,   328,   329,   330,   331,   332,
       0,     0,   154,   155,   858,   333,   334,     0,   335,   324,
     325,   326,   327,   328,   329,   330,   331,   332,     0,     0,
       0,     0,     0,   333,   334,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   336,
     337,   338,   339,     0,     0,     0,   630,   631,   632,     0,
       0,     0,   335,   324,   325,   326,   327,   328,   329,   330,
     331,   332,     0,     0,     0,     0,     0,   333,   334,     0,
     335,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   336,   337,   338,   339,     0,   335,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   336,   337,   338,   339,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   336,
     337,   338,   339,     0,     0,     0,     0,   154,   155,     0,
       0,     0,   335,   869,   324,   325,   326,   327,   328,   329,
     330,   331,   332,     0,     0,     0,   154,   155,   333,   334,
     879,     0,     0,   324,   325,   326,   327,   328,   329,   330,
     331,   332,     0,   336,   337,   338,   339,   333,   334,   154,
     155,     0,     0,   880,     0,     0,   324,   325,   326,   327,
     328,   329,   330,   331,   332,   154,   155,     0,     0,   881,
     333,   334,   324,   325,   326,   327,   328,   329,   330,   331,
     332,     0,     0,     0,     0,     0,   333,   334,   154,   155,
       0,     0,   882,   335,     0,   324,   325,   326,   327,   328,
     329,   330,   331,   332,     0,     0,     0,   154,   155,   333,
     334,   883,   335,     0,   324,   325,   326,   327,   328,   329,
     330,   331,   332,     0,   336,   337,   338,   339,   333,   334,
       0,     0,     0,     0,     0,   335,     0,     0,     0,     0,
       0,     0,     0,   336,   337,   338,   339,     0,     0,   154,
     155,   335,     0,   886,     0,     0,   324,   325,   326,   327,
     328,   329,   330,   331,   332,     0,   336,   337,   338,   339,
     333,   334,     0,     0,   335,     0,     0,     0,     0,     0,
       0,     0,   336,   337,   338,   339,     0,     0,   154,   155,
       0,     0,   887,   335,     0,   324,   325,   326,   327,   328,
     329,   330,   331,   332,     0,   336,   337,   338,   339,   333,
     334,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   336,   337,   338,   339,     0,   154,
     155,     0,     0,  1299,     0,   335,   324,   325,   326,   327,
     328,   329,   330,   331,   332,     0,     0,     0,     0,     0,
     333,   334,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   336,   337,   338,   339,
       0,   154,   155,     0,   335,  1381,     0,     0,   324,   325,
     326,   327,   328,   329,   330,   331,   332,     0,     0,     0,
       0,     0,   333,   334,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   336,   337,   338,   339,   154,
     155,     0,     0,  1444,     0,   335,   324,   325,   326,   327,
     328,   329,   330,   331,   332,     0,     0,     0,     0,     0,
     333,   334,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   336,   337,   338,   339,
       0,   154,   155,     0,     0,  1445,     0,   335,   324,   325,
     326,   327,   328,   329,   330,   331,   332,     0,     0,     0,
       0,     0,   333,   334,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   336,   337,
     338,   339,   154,   155,     0,   335,  1581,     0,     0,   324,
     325,   326,   327,   328,   329,   330,   331,   332,     0,     0,
       0,     0,     0,   333,   334,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   336,   337,   338,   339,
       0,   154,   155,     0,     0,  1582,     0,   335,   324,   325,
     326,   327,   328,   329,   330,   331,   332,     0,     0,     0,
       0,     0,   333,   334,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   336,   337,
     338,   339,   154,   155,     0,     0,  1584,     0,   335,   324,
     325,   326,   327,   328,   329,   330,   331,   332,     0,     0,
       0,     0,     0,   333,   334,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   752,     0,   336,
     337,   338,   339,   154,   155,     0,     0,   335,     0,     0,
     324,   325,   326,   327,   328,   329,   330,   331,   332,     0,
       0,   154,   155,     0,   333,   334,     0,     0,   324,   325,
     326,   327,   328,   329,   330,   331,   332,     0,   336,   337,
     338,   339,   333,   334,     0,     0,   753,     0,   335,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   998,   555,   755,
     756,   757,   758,   759,   760,   761,     0,     0,     0,   336,
     337,   338,   339,     0,     0,     0,   762,     0,  1606,   335,
       0,     8,     0,   252,   763,   764,     0,     0,     0,     0,
     765,   766,   767,   768,   769,   770,   771,   335,   253,     0,
     254,     9,     0,     0,     0,     0,   113,   551,   587,   588,
     336,   337,   338,   339,     0,   908,    31,    32,    33,   255,
       0,     0,     0,     0,     0,     0,     0,     0,   336,   337,
     338,   339,     0,     0,   256,   257,   258,   259,   260,   261,
     262,     0,   263,   264,   265,   266,   267,   268,     0,     8,
     269,   252,   270,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   253,     0,   254,     9,
     589,     0,   557,    40,   113,   551,     0,     0,     0,     0,
       0,     0,     0,   908,    31,    32,    33,   255,     0,     0,
       0,     0,     0,     0,     0,    42,     8,     0,     0,     0,
       0,     0,   256,   257,   258,   259,   260,   261,   262,     0,
     263,   264,   265,   266,   267,   268,     9,     0,   269,     0,
     270,   113,   551,     0,     0,     0,     0,     0,     0,     0,
     908,    31,    32,    33,     0,     0,     0,     0,     0,     0,
     557,    40,     0,     0,     0,     0,     0,     0,     0,  1361,
     257,   258,   259,  1362,  1363,  1364,     0,     0,     0,     0,
       0,   267,  1365,    42,     0,  1366,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   557,    40,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      42
};

/* YYCONFLP[YYPACT[STATE-NUM]] -- Pointer into YYCONFL of start of
   list of conflicting reductions corresponding to action entry for
   state STATE-NUM in yytable.  0 means no conflicts.  The list in
   yyconfl is terminated by a rule number of 0.  */
static const unsigned char yyconflp[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0
};

/* YYCONFL[I] -- lists of conflicting rule numbers, each terminated by
   0, pointed into by YYCONFLP.  */
static const short int yyconfl[] =
{
       0
};

static const short int yycheck[] =
{
       0,   479,   196,     3,     4,    36,    88,   451,   162,   106,
     461,    34,   228,     0,   663,  1023,   551,   243,   234,   431,
     492,   737,   557,   771,    87,   348,  1105,   571,   479,    96,
     570,    16,    99,   202,   113,   360,   810,   732,   264,    34,
     764,   765,   766,    82,   579,  1254,   340,     6,    62,    34,
    1254,     6,     6,  1254,   360,     6,   553,     6,   752,   556,
     601,   822,    29,   172,    40,   551,   607,   608,   752,   601,
     479,   557,   475,  1098,   156,   607,   608,     0,    15,   763,
     764,   765,   766,   142,    10,   169,    17,    72,   879,   805,
    1390,   114,   115,   132,    89,   886,   127,   420,   421,   114,
     115,     1,    87,   126,    15,   375,    12,    15,     8,   379,
     380,    11,    12,     0,     3,    72,    10,    17,  1182,   114,
     202,    15,     6,    99,   101,   101,    32,     8,  1112,   114,
     115,    12,    32,    17,    15,    16,    72,    37,   123,    39,
      40,   126,    22,   206,    72,    26,  1308,   142,    10,     1,
       1,   128,   215,    46,    47,    48,   141,    11,   197,   198,
      12,    98,    16,   139,    18,  1387,    18,    17,     1,   578,
    1392,   128,    23,    84,    10,     8,    89,    90,    11,    12,
      32,    10,    17,   183,   184,  1485,   109,   110,    10,   112,
      98,   129,   128,   347,   388,   389,   674,   128,    19,    32,
     128,   101,   128,   526,    37,   128,    39,    40,   659,   102,
      26,   104,   663,   102,    98,    12,   239,   128,    99,  1244,
     243,   206,   128,   674,   239,   519,    17,   294,   128,   260,
     215,   340,   255,   126,   128,    32,    98,   391,   954,   955,
     956,   264,   265,   266,   220,   212,   277,   306,    98,  1023,
     102,  1025,  1461,   316,   239,  1319,  1478,  1461,   243,  1481,
    1461,   345,  1484,    98,    10,   674,   669,   592,   101,    98,
     255,   596,  1256,   598,   128,  1259,    98,    98,   972,   264,
     265,   266,    98,  1362,  1045,  1076,   592,    17,   972,   595,
     596,   597,   598,    62,   207,   128,   310,   311,   568,  1015,
    1016,  1017,   996,    10,   101,    10,    11,    98,    10,   850,
      80,    10,   996,   313,   811,   812,    10,    13,    14,   304,
     417,   853,    84,   593,   594,    84,  1334,    10,    98,    10,
      26,   316,   371,    18,    15,   489,   399,  1499,   401,  1501,
     419,    18,    62,    10,  1506,  1507,  1508,     1,  1510,  1511,
    1512,  1513,    98,    10,   436,   509,   356,     8,    12,   128,
     360,    12,    13,    14,    18,    16,   128,   352,    98,   128,
      47,    48,  1594,   527,    10,   375,   376,  1441,    32,   379,
     380,    32,    65,    66,    65,    66,    37,    10,    71,    10,
      71,    98,   387,    47,    48,  1474,    98,    17,    81,    98,
      81,    62,    98,    12,    98,   364,   622,    10,   128,   364,
     364,   889,   706,   364,   399,   364,   401,   895,  1142,    84,
    1136,  1630,   908,    32,    84,    10,  1630,   104,   451,  1630,
    1204,    98,    18,  1128,   465,    10,  1227,  1228,   889,  1230,
     918,    98,   611,  1234,   895,   128,   431,   128,   102,   126,
     104,  1613,    98,   925,  1103,  1534,    12,  1141,  1142,  1621,
      16,    47,    98,   128,   618,    36,   451,   128,   128,    17,
      26,    17,   126,    62,    12,    98,    32,   128,    98,   479,
     480,   172,  1198,   129,   551,   552,    95,    96,   555,   814,
     557,     3,    10,    10,    32,    98,  1040,   820,  1038,     7,
      12,    10,     1,  1582,    12,  1584,    18,  1586,   814,  1573,
     102,   836,   837,    12,   553,    11,   102,   556,   104,    10,
      32,     1,    18,    98,    32,    37,    22,    98,     8,   611,
     836,   837,    12,    32,    46,    10,    16,    10,    10,   128,
     579,    17,    10,     1,   529,   699,    26,   238,   533,   534,
      98,  1299,    98,   616,    12,     8,   750,     7,     8,    12,
    1334,    11,    12,    13,    14,  1289,    16,    10,   568,  1104,
      20,    21,   128,    26,    32,    25,    16,    10,   578,   579,
      98,    98,    32,    10,    34,    35,     1,    37,    10,    98,
     102,     3,   592,   593,   594,    10,   596,     1,   598,    10,
      12,   100,    10,  1667,     1,  1289,    18,    98,    12,   803,
    1294,    10,   607,   608,    18,    12,    44,    45,    10,    99,
      32,    18,    98,    98,    10,    98,    98,  1105,    32,   660,
      98,   616,  1711,   827,    46,    32,  1048,    95,    96,    97,
      10,    10,    46,    47,    48,  1709,    99,   678,    10,     8,
      47,    48,  1103,    12,     1,    98,   679,  1721,    17,   659,
      10,    10,  1726,   663,  1728,    98,  1730,    26,  1732,    16,
    1734,    12,  1736,   740,   674,  1449,    98,    18,   745,    17,
      13,    14,   132,   133,    17,    36,  1410,    98,    98,    10,
     102,    32,    10,    10,   679,   695,   696,    10,   102,    98,
     104,    17,    10,   100,     1,   102,    98,   104,  1716,    10,
     749,    17,    98,  1437,    18,    12,     8,  1366,    22,   129,
      12,    10,   126,  1407,    16,    10,  1410,  1411,    98,   126,
    1379,     1,   732,   718,    26,    32,    98,     7,     8,   724,
      99,   808,    12,    13,    14,    17,    16,    98,    98,    98,
      20,    21,   737,  1437,  1438,    25,    10,    10,     1,    10,
      98,   102,    32,   802,    34,    35,    10,    37,  1246,    12,
      10,   965,   811,   812,    84,    18,   858,    98,     1,     8,
      98,    98,    98,    12,   823,    98,    17,    16,    10,    32,
      98,     1,    98,    16,  1238,  1246,    17,    26,    95,    96,
      97,    18,    12,    17,    47,    48,    16,    99,    18,  1035,
     810,    98,  1224,    98,   814,    17,    36,  1011,   128,    29,
     805,    17,    32,   810,    98,  1148,    98,    18,    98,    17,
      59,    22,    17,    12,    44,    45,   836,   837,  1032,    18,
    1034,   908,  1377,    17,    98,    98,    29,    98,   879,    36,
    1044,    34,   883,    32,    98,   886,   887,    17,    98,   102,
     891,   104,   132,   133,    22,   896,     1,    98,    47,   892,
      99,     6,    39,    40,   905,    13,    14,    98,    98,    62,
      47,    48,     8,   126,    98,  1534,    12,    84,    26,   889,
      16,    36,   102,    17,    29,   895,    98,    32,    33,    34,
      26,    17,    98,    20,    21,    40,    41,   892,     8,    17,
      98,    98,    12,    98,    14,  1366,    17,    11,   918,   919,
      17,    17,    17,   102,    98,   104,    26,    62,  1010,    17,
      65,   128,  1344,    59,   101,   102,    17,   104,    98,    17,
      75,    76,  1716,   943,    84,   945,    17,    17,  1722,    39,
      40,   936,    87,    98,    89,    90,    17,    22,    23,   126,
      98,   128,    17,    17,    99,    17,   101,    17,  1035,   954,
     955,   956,    17,    99,    98,    18,    38,    17,   113,   114,
     115,    17,    98,     1,    46,    47,    48,    49,   128,  1467,
      98,   126,  1031,    84,  1033,   130,  1474,    98,    16,    99,
      17,    98,    98,    98,   139,  1102,   141,   142,    17,     1,
      98,   101,  1035,  1207,    10,  1209,  1467,    98,    10,  1463,
      98,    22,    23,  1023,    84,  1025,  1220,    98,    98,  1245,
    1015,  1016,  1017,    39,  1101,   128,  1023,    98,  1025,   174,
      46,   103,   104,    98,    98,  1076,    98,    98,    98,    62,
    1035,   102,    64,    98,    57,    58,  1250,  1088,    98,  1090,
      65,    66,    98,  1048,   126,  1104,    71,    12,   128,   978,
     979,   206,   207,   982,   983,    10,    81,   212,    10,   214,
     215,    98,    47,    48,    29,   220,   995,    32,    10,    98,
     225,    10,    52,    12,    54,   101,    56,   232,   233,  1553,
    1182,  1520,   107,  1103,   239,  1105,    11,  1585,   243,  1603,
      11,  1605,  1606,    32,    15,    84,  1610,    22,  1612,   254,
     255,  1121,  1616,   128,  1618,   128,  1620,  1127,  1128,   264,
     265,   266,   267,    98,  1585,     1,    52,   102,    54,   104,
      56,    29,    65,    66,  1211,  1599,    12,  1601,    71,   109,
     110,  1136,   112,    10,    98,  1574,  1575,    12,    81,    16,
    1579,   126,    16,  1357,   299,    82,    32,     1,   128,   304,
       1,   306,    29,    65,    66,   310,   311,    32,    12,    71,
     315,   316,    12,    16,    18,    16,     8,    10,  1682,    81,
    1684,    46,    84,    16,   111,  1689,  1227,  1228,    32,  1230,
     117,   118,    32,  1234,  1204,   128,   127,   342,     1,    39,
    1249,     4,     5,  1198,     8,  1238,  1247,  1204,    12,    65,
      66,   356,    16,  1305,     1,    71,    22,  1671,    16,   364,
      26,  1254,   367,    10,     1,    81,   128,  1319,    84,  1224,
      24,    65,    66,    17,     1,    12,  1246,    71,    41,    42,
      43,    10,   387,  1238,    82,    12,    10,    81,    10,    12,
      84,     1,    16,    16,   399,    32,   401,     7,     8,  1254,
      17,    11,    12,    13,    14,    32,    16,    98,  1472,    32,
      20,    21,   128,   111,   419,    25,    98,    10,    11,   117,
     118,  1445,    32,    16,    34,    35,    10,    37,   433,    13,
      14,    13,    14,    16,   128,    17,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    10,   451,    12,    17,     1,
      34,    35,     1,  1354,   459,     4,     5,    17,   463,    19,
      12,     8,     1,    12,  1334,    12,    17,    32,  1377,    24,
    1422,    12,    37,    12,  1538,    16,    10,  1334,  1121,     1,
      32,   486,    16,    32,  1127,    32,     1,     1,    37,  1344,
      12,    32,  1362,    32,    16,     8,  1366,    12,    12,    12,
      65,    66,    67,    68,    69,    70,    71,    29,     1,  1379,
      32,    18,    77,    78,     1,    99,    81,    32,    32,    12,
     115,   116,   132,   133,  1303,    12,    22,  1306,    24,     1,
    1309,  1310,  1311,  1312,  1313,  1314,  1315,  1316,     8,    32,
      12,     1,    12,    18,     1,    32,   130,   131,   132,   133,
     555,    16,    12,  1454,  1578,    12,    10,  1509,     1,     8,
      32,    16,  1471,    12,    16,   570,   571,  1468,  1461,    12,
    1463,   875,    32,   877,  1444,    32,     8,   582,    16,  1449,
      12,   586,     1,    32,    17,    17,    16,  1444,    37,    32,
      16,     1,  1449,    12,     4,     5,   601,  1467,    12,    98,
      32,    16,   607,   608,  1474,    37,  1461,    10,  1463,     1,
      12,   616,    18,    32,    16,     7,     8,    22,    32,    12,
      12,    13,    14,    37,    16,    13,    14,    29,    20,    21,
      32,    12,    26,    25,  1535,    37,    29,    18,    22,    32,
      32,    16,    34,    35,    37,    37,    13,    14,    15,    53,
    1520,    32,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,  1614,  1520,  1534,    10,    12,    34,    35,    10,
      16,     7,     8,    17,   679,    10,    12,    13,    14,     8,
      16,   686,    11,    12,    20,    21,    32,    12,    10,    25,
      82,    16,    10,    29,    17,    31,    32,    98,    34,    35,
       5,    37,     4,    32,  1574,  1575,    16,    32,    37,  1579,
      19,  1581,  1582,    98,  1584,  1585,  1586,  1574,  1575,    12,
     537,   538,  1579,    16,     1,   730,     3,   732,   733,     6,
      84,    85,    99,  1634,    70,    12,    29,  1630,   743,    32,
     132,   133,    12,   588,   589,    17,    16,   752,   109,   110,
    1077,   112,    15,  1080,  1081,    32,   881,   882,   763,   764,
     765,   766,    32,   130,   131,   132,   133,   128,    15,    46,
      47,    48,    49,    50,    51,  1630,  1003,  1004,  1671,    22,
      57,    12,    80,    60,    61,    16,    63,    10,    65,    66,
      80,    72,    84,    22,    71,   800,   132,   133,    29,  1669,
      17,    32,  1306,    98,    81,  1309,  1310,    98,   813,  1313,
    1314,  1315,    98,    22,   819,    23,  1671,    24,    22,   824,
      19,   129,    10,     1,    17,     3,    39,   104,     6,   116,
      98,   108,    98,    10,    12,    18,    98,    98,     3,    10,
     977,  1711,   847,   980,   981,   850,  1716,    38,   853,   126,
      46,   128,  1722,    17,    32,   992,   993,   994,    17,  1716,
      38,    39,    40,    98,    17,  1722,    15,    19,    46,    47,
      48,    49,    50,    51,    15,    53,    10,    17,    17,    57,
      10,    16,    60,    61,    17,    63,    72,   892,    10,    17,
      17,    10,     7,     8,    19,    98,    98,    12,    13,    14,
      10,    16,    10,   908,    10,    20,    21,    85,     8,    87,
      25,    26,    12,    13,    14,    10,    16,    32,    10,    34,
      35,    10,    37,   101,    10,   103,   104,    10,   106,    86,
     108,    16,    32,   107,    16,    16,    16,    37,    16,    16,
      16,    16,    16,    16,    16,   950,    16,    16,   126,    11,
     128,    10,    10,    10,    22,    22,    22,   962,    10,    22,
      10,    16,    10,    10,    10,    19,    17,   972,    17,    10,
     975,    10,   977,   978,   979,   980,   981,   982,   983,    19,
      95,    96,    10,    10,    16,    98,    98,   992,   993,   994,
     995,   996,    36,    22,   101,    18,   168,   169,    10,    98,
      10,    10,    10,  1008,    10,    10,    67,     0,     1,    10,
       3,    22,    16,     6,    16,    10,    16,   132,   133,    12,
      19,    38,   101,    79,    31,    10,    79,    98,    22,    18,
    1035,    22,   204,  1038,    24,  1040,    24,    80,   134,    32,
      19,    22,  1047,    17,    10,    38,    39,    40,    10,    84,
     110,    24,    17,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    98,    56,    57,    98,    64,    60,    61,    55,
      63,    58,    65,    66,    98,    55,    98,    98,    71,    98,
      98,    24,    98,    98,    98,    98,    79,    80,    81,     1,
      24,    84,    85,  1098,    87,    98,    24,    19,    16,    24,
     134,   162,    17,    24,    16,    98,    98,    10,   101,    22,
     103,   104,    17,   106,   107,   108,   109,   110,    16,   112,
      16,    16,    16,  1128,  1129,  1130,    10,    10,    59,    22,
      22,    16,     8,   126,  1139,   128,  1141,  1142,    98,    98,
      98,    98,    98,    98,    98,    98,    98,    98,    84,     8,
      15,   323,  1157,    65,    15,   216,    10,    10,    10,    17,
      17,    10,    79,    64,    15,   226,   227,    17,    10,    10,
      17,    15,    15,   345,    86,    87,    88,    89,    90,    91,
      92,    93,    94,   244,   245,    17,    17,    98,  1193,    98,
      98,    10,    10,   105,    10,    10,  1201,    10,  1203,    10,
      10,   113,   114,  1208,    10,  1210,  1211,   119,   120,   121,
     122,   123,   124,   125,  1219,    17,    79,    10,     3,    17,
      17,     6,    17,    10,    10,    81,    10,    12,    10,    10,
      10,    10,    10,  1238,   406,    10,    10,    10,  1243,  1244,
      17,   413,   414,    98,    15,    10,  1251,    32,    10,  1254,
      10,    17,  1257,    98,   426,   535,   428,   718,    98,  1264,
      98,    46,    47,    48,    49,    50,    51,  1272,    98,    98,
    1275,  1276,    57,    98,   335,    60,    61,     4,    63,   538,
     186,   819,  1287,  1035,  1289,    33,   347,   348,   225,  1294,
     800,   847,    39,  1008,  1105,   186,   674,   579,  1303,   364,
     364,  1306,   212,   924,  1309,  1310,  1311,  1312,  1313,  1314,
    1315,  1316,   480,   310,  1243,   214,   695,  1578,  1323,   104,
     696,  1580,   364,   108,  1127,   945,   356,   311,  1396,  1392,
     391,  1336,   315,  1338,   395,  1669,  1594,  1083,  1343,   773,
    1182,   126,  1299,  1608,   979,   517,  1411,  1498,  1157,  1422,
     621,   867,   524,  1358,    12,    65,   632,     9,    -1,   420,
     421,    -1,    -1,    -1,   342,    -1,    -1,    -1,   429,    -1,
      -1,   432,    -1,    -1,    32,    -1,   437,    -1,    -1,    37,
      -1,   419,   443,   444,    -1,   446,    -1,   448,    -1,   450,
      -1,   452,    -1,    -1,    -1,    -1,   457,    -1,    -1,    -1,
      -1,    -1,  1407,    -1,    -1,  1410,  1411,    65,    66,    67,
      68,    69,    70,    71,   475,    -1,    -1,   478,    -1,    77,
      78,    -1,    -1,    81,    -1,    -1,    -1,    -1,   489,    -1,
      -1,   492,  1437,  1438,    -1,    -1,    -1,    -1,    -1,    -1,
     612,    -1,   503,    -1,    -1,    -1,    -1,   508,   509,    -1,
      -1,    -1,  1457,   625,    -1,   627,  1461,    -1,  1463,    -1,
    1465,    -1,   634,    -1,   636,   526,   527,    -1,  1473,    -1,
      -1,    -1,   644,    -1,    -1,   647,   648,    -1,   650,    -1,
     652,   653,    -1,   655,    -1,   657,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   668,    -1,    -1,    -1,
      -1,   673,    -1,    -1,    -1,     7,     8,    -1,    -1,    -1,
      12,    13,    14,    -1,    16,    -1,    -1,    -1,    20,    21,
     692,    -1,    -1,    25,    -1,    -1,   698,    -1,   700,    -1,
      32,    -1,    34,    35,  1539,    37,    -1,    -1,    -1,    -1,
      -1,   713,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,     1,    -1,     3,    -1,    -1,     6,   618,   619,    -1,
     621,    -1,    12,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   632,    -1,    -1,    -1,  1580,    -1,    -1,    -1,   640,
     641,    -1,    32,    -1,  1589,   646,    -1,    -1,    38,    39,
      40,    -1,    -1,    95,    96,    -1,    46,    47,    48,    49,
      50,    51,    -1,    -1,    -1,    -1,   667,    57,   669,    -1,
      60,    61,    -1,    63,    -1,     1,    -1,     3,    -1,    -1,
       6,    -1,    -1,    -1,    -1,  1630,    12,    -1,    -1,    15,
     132,   133,    -1,    -1,    -1,    85,    -1,    87,   699,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    32,    -1,    -1,    -1,
      -1,   101,    -1,   103,   104,    -1,   106,    -1,   108,    -1,
      46,    47,    48,    49,    50,    51,  1671,    -1,    -1,    -1,
      -1,    57,    -1,    -1,    60,    61,   126,    63,   128,    65,
      66,    -1,    -1,    -1,    -1,    71,    -1,    -1,    -1,   861,
      -1,    -1,    -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,
      -1,   873,   874,    -1,    -1,  1710,   878,    -1,     1,    -1,
       3,    -1,    -1,     6,    -1,    -1,    -1,    -1,   104,    12,
      -1,    -1,   108,    -1,    -1,    -1,   898,    -1,   900,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    32,
     126,    -1,   128,    -1,    -1,    38,    39,    40,    -1,    -1,
      -1,    -1,    -1,    46,    47,    48,    49,    50,    51,   820,
      -1,    -1,    -1,    -1,    57,    -1,    -1,    60,    61,    -1,
      63,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   849,    -1,
      -1,    -1,    85,    -1,    87,    -1,    -1,    -1,   970,    -1,
      -1,    -1,    -1,    -1,    -1,   866,   867,    -1,   101,    -1,
     103,   104,    -1,   106,   875,   108,   877,    -1,    -1,   880,
     881,   882,    -1,    -1,   885,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   126,    -1,   128,   897,    -1,   899,    -1,
      -1,     1,   903,     3,    -1,    -1,     6,    -1,    -1,    -1,
      -1,    -1,    12,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   924,    -1,    -1,    -1,   928,    -1,    -1,
      -1,  1043,    32,    -1,    -1,    -1,    -1,    -1,    38,    39,
      40,    -1,    -1,    -1,    -1,  1057,    46,    47,    48,    49,
      50,    51,    -1,    -1,    -1,    -1,  1068,    57,    -1,    -1,
      60,    61,    -1,    63,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1084,   974,    -1,    -1,    -1,    -1,    -1,    -1,
    1092,  1093,     1,    -1,  1096,    85,    -1,    87,    -1,    -1,
      -1,    -1,    -1,    12,    -1,    14,    15,    -1,    -1,    -1,
      -1,   101,    -1,   103,   104,    -1,   106,    -1,   108,    -1,
      29,    -1,    31,    32,    -1,    -1,    -1,    -1,    37,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   126,    -1,   128,    -1,
      -1,    50,    -1,    -1,    -1,    -1,    -1,  1149,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,
      69,    70,    71,    -1,    73,    74,    75,    76,    77,    78,
      -1,     1,    81,    -1,    83,    84,    -1,    -1,  1180,    -1,
      -1,    -1,    12,    -1,    14,    15,  1077,    -1,    -1,  1080,
    1081,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,
      -1,    31,    32,    -1,     7,     8,    -1,    37,    -1,    12,
      13,    14,    -1,    16,    -1,    -1,    -1,    20,    21,   128,
      50,    -1,    25,  1114,    -1,    -1,    -1,    -1,    -1,    32,
      -1,    34,    35,    -1,    37,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    -1,
      -1,    81,    -1,    83,    -1,    -1,    -1,  1148,    -1,    -1,
    1262,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    80,    10,    82,
      12,    -1,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1298,    29,   128,    31,
      32,    -1,    -1,    -1,    -1,    37,    -1,    -1,  1199,  1200,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    50,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1329,  1330,   132,
     133,    -1,    -1,    65,    66,    67,    68,    69,    70,    71,
      -1,    73,    74,    75,    76,    77,    78,    -1,    -1,    81,
      -1,    83,    -1,    -1,     1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    12,    -1,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    -1,    31,    32,    -1,    -1,    -1,    -1,
      37,  1282,    -1,    -1,    -1,    -1,   128,    -1,  1400,    -1,
      -1,  1403,    -1,    50,    -1,    -1,  1408,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1307,  1308,    65,    66,
      67,    68,    69,    70,    71,  1427,    73,    74,    75,    76,
      77,    78,    -1,    -1,    81,    -1,    83,    -1,    -1,    -1,
      -1,     7,     8,    -1,    -1,    -1,    12,    13,    14,    -1,
      16,    -1,    -1,    -1,    20,    21,     1,    -1,     3,    25,
      -1,     6,    -1,    -1,    -1,    -1,    32,    12,    34,    35,
      -1,    37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   128,    -1,    -1,    -1,    -1,  1488,    32,    -1,  1491,
    1492,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    46,    47,    48,    49,    50,    51,    -1,    -1,    -1,
      -1,    -1,    57,    -1,    -1,    60,    61,    -1,    63,    -1,
      65,    66,  1524,  1525,    -1,    -1,    71,    -1,  1530,  1531,
      -1,  1533,    -1,    -1,    -1,  1537,    81,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1445,  1446,  1447,  1559,    -1,   104,
      -1,  1563,   128,   108,    -1,    -1,   132,   133,  1459,    -1,
      -1,  1462,    -1,  1464,    -1,    -1,    -1,    -1,    -1,  1470,
      -1,   126,    -1,   128,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1598,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1499,    -1,
    1501,    -1,  1503,    -1,  1505,  1506,  1507,  1508,    -1,  1510,
    1511,  1512,  1513,    -1,    -1,    -1,     7,     8,    -1,    -1,
    1632,    12,    13,    14,    -1,    16,    -1,    -1,    -1,    20,
      21,    -1,    -1,    -1,    25,    -1,    -1,    -1,    -1,    -1,
      -1,    32,    -1,    34,    35,    -1,    37,    -1,     7,     8,
    1551,    -1,  1553,    12,    13,    14,    -1,    16,    -1,    -1,
      -1,    20,    21,    -1,    -1,    -1,    25,    -1,    -1,    -1,
      -1,    -1,    -1,    32,    -1,    34,    35,  1578,    37,    -1,
      -1,    -1,  1583,    -1,    -1,    -1,    -1,    -1,    -1,    80,
      -1,    82,    -1,    -1,    -1,    -1,    -1,    -1,  1599,    -1,
    1601,    -1,  1603,    -1,  1605,  1606,    -1,  1608,    -1,  1610,
      -1,  1612,  1613,    -1,    -1,  1616,    -1,  1618,    -1,  1620,
    1621,    80,    -1,    82,    -1,     7,     8,    -1,    -1,    -1,
      12,    13,    14,    -1,    16,    -1,    18,    -1,    20,    21,
      -1,   132,   133,    25,    -1,    -1,    -1,    -1,    -1,    -1,
      32,    -1,    34,    35,    -1,    37,    -1,     7,     8,    -1,
      -1,    -1,    12,    13,    14,    -1,    16,    -1,    -1,    -1,
      20,    21,    -1,   132,   133,    25,    -1,    -1,    -1,    -1,
      -1,  1682,    32,  1684,    34,    35,    -1,    37,  1689,     7,
       8,    -1,    -1,    -1,    12,    13,    14,    -1,    16,    17,
      -1,    -1,    20,    21,    -1,    -1,    -1,    25,    -1,    -1,
      -1,    -1,    -1,    -1,    32,    -1,    34,    35,    -1,    37,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     7,     8,
      -1,    -1,    82,    12,    13,    14,    -1,    16,    -1,    -1,
      -1,    20,    21,    -1,    -1,    -1,    25,    -1,    -1,    -1,
     132,   133,    -1,    32,    -1,    34,    35,    -1,    37,     7,
       8,    -1,    -1,    -1,    12,    13,    14,    -1,    16,    -1,
      -1,    -1,    20,    21,    -1,    -1,    -1,    25,    -1,    -1,
      -1,    -1,   132,   133,    32,    -1,    34,    35,    -1,    37,
      -1,     7,     8,    -1,    -1,    -1,    12,    13,    14,    -1,
      16,    -1,    -1,    82,    20,    21,    -1,    -1,    -1,    25,
      -1,    -1,    -1,    -1,   132,   133,    32,    -1,    34,    35,
      -1,    37,     7,     8,    -1,    -1,    -1,    12,    13,    14,
      -1,    16,    -1,    -1,    -1,    20,    21,    -1,    -1,    12,
      25,    14,    -1,    -1,    -1,    -1,    -1,    32,    -1,    34,
      35,    -1,    37,   132,   133,    -1,    29,    -1,    31,    32,
      -1,     7,     8,    -1,    37,    -1,    12,    13,    14,    -1,
      16,    -1,    -1,    -1,    20,    21,    -1,    50,     3,    25,
      -1,     6,    -1,    -1,   132,   133,    32,    12,    34,    35,
      -1,    37,    65,    66,    67,    68,    69,    70,    71,    -1,
      73,    74,    75,    76,    77,    78,    -1,    32,    81,    -1,
      83,    -1,    -1,    38,    39,    40,   132,   133,    -1,    -1,
      -1,    46,    47,    48,    49,    50,    51,    -1,    -1,    -1,
      -1,    -1,    57,    -1,    -1,    60,    61,    -1,    63,    10,
      -1,    -1,    13,    14,    -1,    -1,    -1,   132,   133,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    -1,
      85,    -1,    87,    34,    35,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   101,    -1,   103,   104,
      -1,   106,    -1,   108,    -1,    -1,   132,   133,    -1,    -1,
      -1,    -1,    10,    -1,    -1,    13,    14,    -1,    -1,    -1,
      -1,   126,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    -1,    13,    14,    15,    -1,    34,    35,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    99,    -1,
      13,    14,    15,    34,    35,    -1,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,
      -1,    34,    35,    -1,    -1,    -1,    -1,    -1,    -1,   130,
     131,   132,   133,    -1,    -1,    13,    14,    15,    -1,    -1,
      -1,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    99,    13,    14,    15,    -1,    34,    35,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    99,    -1,
      -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   130,   131,   132,   133,    99,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,
     131,   132,   133,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,   131,   132,
     133,    99,    13,    14,    15,    -1,    -1,    -1,    -1,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    99,    -1,
      -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   130,   131,   132,   133,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    13,    14,    -1,   130,
     131,   132,   133,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    -1,    -1,    13,    14,    15,    34,    35,    -1,
      37,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    -1,    13,    14,    15,    34,    35,    -1,    99,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    -1,
      -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,
     131,   132,   133,    -1,    -1,    -1,    13,    14,    15,    -1,
      -1,    -1,    99,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    -1,    -1,    -1,    -1,    -1,    34,    35,    -1,
      99,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   130,   131,   132,   133,    -1,    99,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   130,   131,   132,   133,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,
     131,   132,   133,    -1,    -1,    -1,    -1,    13,    14,    -1,
      -1,    -1,    99,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    -1,    -1,    -1,    13,    14,    34,    35,
      17,    -1,    -1,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    -1,   130,   131,   132,   133,    34,    35,    13,
      14,    -1,    -1,    17,    -1,    -1,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    13,    14,    -1,    -1,    17,
      34,    35,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    -1,    -1,    -1,    -1,    -1,    34,    35,    13,    14,
      -1,    -1,    17,    99,    -1,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    -1,    -1,    -1,    13,    14,    34,
      35,    17,    99,    -1,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    -1,   130,   131,   132,   133,    34,    35,
      -1,    -1,    -1,    -1,    -1,    99,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   130,   131,   132,   133,    -1,    -1,    13,
      14,    99,    -1,    17,    -1,    -1,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,   130,   131,   132,   133,
      34,    35,    -1,    -1,    99,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   130,   131,   132,   133,    -1,    -1,    13,    14,
      -1,    -1,    17,    99,    -1,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    -1,   130,   131,   132,   133,    34,
      35,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   130,   131,   132,   133,    -1,    13,
      14,    -1,    -1,    17,    -1,    99,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,
      34,    35,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   130,   131,   132,   133,
      -1,    13,    14,    -1,    99,    17,    -1,    -1,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,    -1,    -1,
      -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   130,   131,   132,   133,    13,
      14,    -1,    -1,    17,    -1,    99,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,
      34,    35,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   130,   131,   132,   133,
      -1,    13,    14,    -1,    -1,    17,    -1,    99,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,    -1,    -1,
      -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,   131,
     132,   133,    13,    14,    -1,    99,    17,    -1,    -1,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    -1,
      -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   130,   131,   132,   133,
      -1,    13,    14,    -1,    -1,    17,    -1,    99,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,    -1,    -1,
      -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,   131,
     132,   133,    13,    14,    -1,    -1,    17,    -1,    99,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,    -1,
      -1,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    16,    -1,   130,
     131,   132,   133,    13,    14,    -1,    -1,    99,    -1,    -1,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      -1,    13,    14,    -1,    34,    35,    -1,    -1,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,   130,   131,
     132,   133,    34,    35,    -1,    -1,    65,    -1,    99,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,    88,
      89,    90,    91,    92,    93,    94,    -1,    -1,    -1,   130,
     131,   132,   133,    -1,    -1,    -1,   105,    -1,    98,    99,
      -1,    12,    -1,    14,   113,   114,    -1,    -1,    -1,    -1,
     119,   120,   121,   122,   123,   124,   125,    99,    29,    -1,
      31,    32,    -1,    -1,    -1,    -1,    37,    38,    39,    40,
     130,   131,   132,   133,    -1,    46,    47,    48,    49,    50,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   130,   131,
     132,   133,    -1,    -1,    65,    66,    67,    68,    69,    70,
      71,    -1,    73,    74,    75,    76,    77,    78,    -1,    12,
      81,    14,    83,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    29,    -1,    31,    32,
     101,    -1,   103,   104,    37,    38,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    46,    47,    48,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   126,    12,    -1,    -1,    -1,
      -1,    -1,    65,    66,    67,    68,    69,    70,    71,    -1,
      73,    74,    75,    76,    77,    78,    32,    -1,    81,    -1,
      83,    37,    38,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      46,    47,    48,    49,    -1,    -1,    -1,    -1,    -1,    -1,
     103,   104,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    -1,    -1,    -1,    -1,
      -1,    77,    78,   126,    -1,    81,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   103,   104,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     126
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned short int yystos[] =
{
       0,   128,   136,   137,   138,   178,   447,     1,    12,    32,
     448,   449,   451,   452,     0,   109,   110,   112,   139,   140,
     141,   143,   144,   154,   155,   308,   447,   154,     3,     6,
      46,    47,    48,    49,    50,    51,    57,    60,    61,    63,
     104,   108,   126,   179,   180,   208,   209,   210,   211,   214,
     215,   217,   218,   243,   251,   270,   277,   278,   330,   334,
     337,   338,   451,   129,   452,    98,   129,    22,    10,   450,
     451,     1,    23,    52,    54,    56,   157,   158,     1,    16,
      44,    45,   212,   213,   221,   222,     1,    16,    29,   221,
     223,   271,   272,   273,   274,   275,   451,     1,   102,   247,
       1,   219,     1,   234,   235,   237,   451,     1,   227,   228,
     229,   451,    16,    37,   221,   223,   335,   336,   425,   442,
     450,   451,     1,   181,     1,   352,   447,   339,     1,   100,
     246,     1,   246,     1,   237,     1,   230,   451,     1,   216,
       1,    16,   221,   279,   282,   289,   290,   331,   332,   333,
     451,   449,     7,     8,    13,    14,    16,    20,    21,    25,
      34,    35,    37,   132,   133,   424,   433,   434,   435,   440,
     444,   445,   450,    10,    11,    10,     7,   142,   450,   309,
     451,   156,   451,    10,    16,    29,   162,   168,   170,    10,
       1,     4,     5,    41,    42,    43,   247,   212,   212,    10,
     276,   442,    16,   226,   435,   436,    16,   223,   272,   275,
     272,    10,    98,    10,    98,    16,    18,   242,    10,   237,
     242,    10,   237,    10,    10,    98,    18,    22,   220,   241,
      10,    10,    98,    98,   220,   425,   426,   427,   451,   223,
     335,   335,    10,    98,    22,    18,   429,    10,   233,   239,
     450,    84,    14,    29,    31,    50,    65,    66,    67,    68,
      69,    70,    71,    73,    74,    75,    76,    77,    78,    81,
      83,   340,   341,   342,   348,   349,   356,   357,   359,   360,
     361,   364,   365,   366,   368,   372,   373,   442,   450,   352,
      62,   252,   451,    64,   247,    10,    10,    10,    10,    98,
      10,   237,    84,   276,    16,   223,   225,   290,   331,    29,
     283,    98,   281,    16,    10,    98,    16,   242,   260,   436,
      20,    21,   432,   435,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    34,    35,    99,   130,   131,   132,   133,
     441,   444,   128,   433,   444,   446,     8,    16,    18,   428,
     429,   446,   127,   145,   451,    24,    16,     1,   159,   160,
     161,   176,   177,   178,   447,     1,    17,   169,   256,   257,
     258,   262,   447,     1,    16,    10,    16,   168,   170,    10,
      10,    17,    98,    98,    17,    17,    17,   260,   247,   247,
      17,    98,   224,   226,   436,    15,   276,   272,    10,    16,
      10,    16,   274,   275,   273,   276,   435,   438,    10,   237,
      10,   235,   430,   435,   435,   241,   451,   451,    36,    98,
      18,   429,   335,    10,    10,   336,   435,   431,   435,    18,
      10,    98,    22,    24,     8,    12,    16,    16,    26,   128,
     451,   347,   442,    16,    16,     1,    16,     1,    16,   352,
      16,    16,    16,   336,   442,   442,   451,    16,     1,    15,
      84,   350,     1,    15,    72,   351,   352,     1,    10,     1,
      10,    10,    10,   352,   353,    22,    23,    10,    16,    10,
      16,    47,    48,   104,   126,   242,   245,   451,    10,    98,
     331,    10,    16,   282,   290,   289,    10,    17,   291,   292,
     293,   294,   295,   447,   332,   276,    17,    36,    98,    37,
      22,    22,    23,    22,    24,    26,    22,   435,   434,   446,
       1,   448,   433,   432,   435,   431,    18,    16,     1,   148,
     450,    82,   111,   117,   118,   146,   147,   149,   150,    10,
     310,   311,   315,   447,   451,    10,    53,   159,   177,     1,
      10,    38,    39,    40,    85,    87,   101,   103,   106,   182,
     188,   194,   195,   198,   201,   296,   375,    17,    10,     8,
      11,    37,   171,   172,   173,   175,   451,    17,    98,    98,
      47,    48,    98,   104,   126,   247,   265,    39,    40,   101,
      17,   163,   161,    10,    10,     1,   161,     1,   161,     5,
       4,   223,   227,   231,   232,   238,   451,   260,   260,   432,
      17,    98,   435,    10,   276,   276,    16,    17,    98,    15,
      10,    15,   220,   427,   431,   435,   431,   435,    10,    19,
      13,    14,    15,    19,   435,   239,   435,   451,   436,    26,
      95,    96,   362,   363,   435,    17,    22,   435,   435,    80,
     435,    80,   435,   435,   347,   435,    10,   435,    84,   451,
     351,    72,     1,   451,    72,   352,    70,   357,   435,    22,
       1,    98,   374,   435,   254,   255,   257,   266,   351,   447,
     256,   244,   451,   432,    10,     1,    11,   284,   285,   286,
     287,   288,   435,   280,    17,    98,    98,   288,   435,    98,
     435,   432,    22,    23,    24,    22,    15,   434,   129,   129,
      17,    19,   431,   435,   432,    10,    10,   450,   116,   151,
     450,   450,   111,   147,   115,   151,   152,   151,   152,    17,
      98,    17,    98,    39,    10,     1,   102,   189,   242,   265,
     443,     3,    46,   203,   204,   206,   207,   242,   443,   207,
     247,     1,    16,    65,    86,    88,    89,    90,    91,    92,
      93,    94,   105,   113,   114,   119,   120,   121,   122,   123,
     124,   125,   194,   376,   377,   378,   379,   380,   381,   382,
     390,   391,   392,   396,   398,   399,   400,   401,   402,   403,
     404,   405,   406,   407,   408,   409,   410,     1,   236,   240,
     242,   451,   207,   247,     1,   185,   242,   265,   443,     1,
     297,    98,    98,    98,   161,   173,   174,   175,    17,    98,
      18,   257,   247,   262,   265,   451,    46,   259,   451,     3,
     261,   261,   261,    38,   164,   159,   161,   161,   159,   159,
     159,   159,    17,    17,   231,   232,    10,    98,    10,    22,
     223,   231,   232,   223,   231,   232,    17,   226,    15,   276,
     432,   435,   437,   430,    19,    19,    15,    15,   437,    19,
      10,    17,    17,   435,   435,     6,    17,    98,   435,    17,
      17,    17,    17,    17,   358,    10,    17,    17,    84,   253,
     266,   351,   447,    84,    72,   253,   351,    16,   435,   357,
     435,    17,    17,    98,   255,   351,    10,    62,    46,   182,
     188,   208,   210,   214,   215,   218,   267,    17,    10,    16,
      17,    17,   451,    17,    98,    98,    10,   293,   447,   295,
     447,   432,    36,   434,    19,    17,   148,    10,   450,    10,
      10,    10,    10,    10,   451,    10,   312,   316,   447,   451,
      46,   451,    10,   233,   192,   190,   193,   242,   451,    47,
     102,   104,   202,   205,   242,   247,   260,    86,    95,    96,
     383,   386,   395,   451,    16,    16,     1,    16,    16,    16,
      16,    16,    16,    16,   383,   384,   386,     1,   384,   384,
       1,   384,    16,    16,    16,    16,    16,   381,    86,   377,
      10,    22,    10,    22,    22,    10,    10,    10,    98,   236,
      22,   247,   260,    10,   233,   183,   184,   186,   242,   107,
      65,    66,    71,    81,   178,   298,   300,   301,   302,   305,
     307,   207,   247,   207,   247,    39,   451,   159,    16,    36,
      98,   172,   431,   435,   259,   247,   451,   260,   165,    17,
      98,   159,   159,    10,    10,   238,   451,   435,   231,    10,
      10,   232,    10,    10,   436,    17,    19,    19,   435,   439,
     439,   362,   362,     1,   353,     1,    82,   369,   370,   432,
     369,   369,   352,    17,   435,   353,   352,   266,   351,    84,
     351,    72,   435,   435,    10,    10,   435,    62,   242,   268,
     269,   443,   451,    10,   101,   248,   249,   263,   264,   266,
     447,   250,   447,    10,    16,   286,   288,    17,    36,    15,
     153,   313,   314,   315,   316,   317,   447,   313,    98,    98,
     101,   451,    10,   233,   233,   233,   191,   451,   260,   196,
      26,    98,   385,   397,   444,    22,   383,   386,    18,   435,
       1,    95,    96,    97,   386,   414,   416,   418,   419,   422,
      10,     1,   414,   416,   417,   417,   414,   414,   416,   416,
      10,    10,    10,    10,    10,    10,   414,   414,   414,   416,
     383,   386,    16,   387,   388,   389,   436,   387,   387,   240,
      10,   436,   260,   199,    10,   233,   233,   233,   187,    16,
      16,    16,     1,    15,   298,   107,   300,   247,   260,   247,
     260,   206,   336,   451,    17,   173,   175,    19,    19,   260,
     259,   451,   239,    38,   167,    10,    10,    79,    79,    80,
      15,   353,    80,   370,    15,    80,    80,   360,    10,    84,
      72,   268,    10,    98,   242,   220,   253,   351,     1,    46,
     247,   265,   249,   354,   447,    10,    98,    98,    17,    98,
     264,    17,   435,   110,    57,    58,   314,   318,   319,   322,
      10,    10,    98,    10,    10,    98,    46,   318,   316,   451,
     451,   451,    22,    10,    10,    10,   233,   197,   451,    24,
     386,   384,    22,    26,    24,    26,    22,   431,   435,    17,
      17,    19,    18,    98,   422,   134,    98,    98,    98,    98,
      98,    98,    98,    98,    98,    98,    98,    26,    22,    16,
     388,   389,   436,   200,   451,    10,    10,    10,   233,   435,
     435,   306,   451,    84,   451,    84,   260,   451,   260,   451,
     451,    17,   451,   260,   166,   239,   353,   353,   353,   353,
     347,    10,   269,   268,   351,    62,    10,   247,   260,   451,
      64,    65,    69,    70,    71,    78,    81,   343,   345,   355,
     359,   367,   368,   371,   373,   442,   264,   101,   451,    10,
     264,    17,     1,   451,     1,     8,    12,    16,    26,    99,
     320,   321,   324,   325,   329,    55,    58,   451,   451,    55,
     435,    10,   451,   384,    17,    24,    24,    16,   386,   393,
      24,    24,    19,    19,   381,   390,     8,    12,   420,   421,
     415,   416,   134,   423,   436,   415,   413,   435,   413,   415,
     415,   416,   416,   415,   415,   415,   416,    24,    24,   389,
      17,    98,   451,    10,    17,    17,    10,    22,     1,   298,
     451,   451,   451,   239,    17,    10,    62,   260,   451,    16,
     354,   447,    16,    16,    16,    15,    84,   253,   351,    10,
      22,    46,   247,   265,   253,    10,    22,    59,   329,    59,
     321,    15,   325,   329,    16,   320,    17,   444,   386,    17,
     444,   384,   386,   393,     8,    12,     8,    19,    98,    98,
     423,    98,    17,    98,    17,    98,    98,    98,    98,    98,
      98,    98,    98,    98,   384,   386,   389,    10,   299,   300,
      82,   303,   304,   432,   435,   435,    84,    84,   352,   451,
     435,   435,   347,   435,   451,   351,    84,   435,   247,   260,
     451,   354,     8,   323,    17,   329,   326,   328,   329,   329,
      59,    15,   444,    15,   444,   420,   413,   413,    10,   435,
      10,   411,   412,   435,   413,   413,   413,   436,   413,   413,
     413,   413,    17,    98,    79,    15,   299,    80,    98,    15,
      10,    17,    17,    10,    17,   253,   346,   354,    84,   260,
     451,    64,    10,    17,    15,    10,    17,   394,   435,    15,
     394,    15,    17,    98,    17,    98,    98,    17,    98,    17,
      98,    17,    98,    98,    98,    17,    98,    17,    98,    17,
      98,    98,   389,   299,   299,   304,   299,   306,   344,   354,
     447,   354,   435,   354,   351,    84,   354,   451,    14,   327,
     328,   329,    17,   394,    17,   394,    10,   411,    10,   411,
     411,    10,   412,    10,   411,    10,   411,   413,   436,    10,
     411,    10,   411,    10,   411,   413,    17,    98,    17,    79,
      10,    10,    84,    10,    17,    17,    17,    17,    17,    17,
      17,    17,    98,    17,    98,    17,    17,    17,    17,    98,
     389,    81,   344,   347,    17,    10,    10,    10,    10,    10,
      10,   411,    10,   411,    10,    10,    10,    10,   411,    98,
      15,    17,    17,    17,    17,   389,   451,   354,    10,    10,
      10,    98,   298,   389,    84,    17,    98,   389,    98,   389,
      98,   389,    98,   389,    98,   389,    98,   389,    17
};


/* Prevent warning if -Wmissing-prototypes.  */
int yyparse (void);

/* Error token number */
#define YYTERROR 1

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */


#define YYRHSLOC(Rhs, K) ((Rhs)[K].yystate.yyloc)
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (N)								\
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (0)

/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# define YY_LOCATION_PRINT(File, Loc)			\
    fprintf (File, "%d.%d-%d.%d",			\
             (Loc).first_line, (Loc).first_column,	\
             (Loc).last_line,  (Loc).last_column)
#endif


#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */
#define YYLEX yylex ()

YYSTYPE yylval;

YYLTYPE yylloc;

int yynerrs;
int yychar;

static const int YYEOF = 0;
static const int YYEMPTY = -2;

typedef enum { yyok, yyaccept, yyabort, yyerr } YYRESULTTAG;

#define YYCHK(YYE)							     \
   do { YYRESULTTAG yyflag = YYE; if (yyflag != yyok) return yyflag; }	     \
   while (0)

#if YYDEBUG

#if ! defined (YYFPRINTF)
#  define YYFPRINTF fprintf
#endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");

# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr,					\
                  Type, Value, Location);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;

#else /* !YYDEBUG */

# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)

#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYMAXDEPTH * sizeof (GLRStackItem)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

/* Minimum number of free items on the stack allowed after an
   allocation.  This is to allow allocation and initialization
   to be completed by functions that call yyexpandGLRStack before the
   stack is expanded, thus insuring that all necessary pointers get
   properly redirected to new data. */
#define YYHEADROOM 2

#ifndef YYSTACKEXPANDABLE
# if (! defined (__cplusplus) \
      || (defined (YYLTYPE_IS_TRIVIAL) && YYLTYPE_IS_TRIVIAL \
	  && defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL))
#  define YYSTACKEXPANDABLE 1
# else
#  define YYSTACKEXPANDABLE 0
# endif
#endif

#if YYERROR_VERBOSE

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static size_t
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      size_t yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return strlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

#endif /* !YYERROR_VERBOSE */

/** State numbers, as in LALR(1) machine */
typedef int yyStateNum;

/** Rule numbers, as in LALR(1) machine */
typedef int yyRuleNum;

/** Grammar symbol */
typedef short int yySymbol;

/** Item references, as in LALR(1) machine */
typedef short int yyItemNum;

typedef struct yyGLRState yyGLRState;
typedef struct yySemanticOption yySemanticOption;
typedef union yyGLRStackItem yyGLRStackItem;
typedef struct yyGLRStack yyGLRStack;
typedef struct yyGLRStateSet yyGLRStateSet;

struct yyGLRState {
  /** Type tag: always true. */
  yybool yyisState;
  /** Type tag for yysemantics. If true, yysval applies, otherwise
   *  yyfirstVal applies. */
  yybool yyresolved;
  /** Number of corresponding LALR(1) machine state. */
  yyStateNum yylrState;
  /** Preceding state in this stack */
  yyGLRState* yypred;
  /** Source position of the first token produced by my symbol */
  size_t yyposn;
  union {
    /** First in a chain of alternative reductions producing the
     *  non-terminal corresponding to this state, threaded through
     *  yynext. */
    yySemanticOption* yyfirstVal;
    /** Semantic value for this state. */
    YYSTYPE yysval;
  } yysemantics;
  /** Source location for this state. */
  YYLTYPE yyloc;
};

struct yyGLRStateSet {
  yyGLRState** yystates;
  size_t yysize, yycapacity;
};

struct yySemanticOption {
  /** Type tag: always false. */
  yybool yyisState;
  /** Rule number for this reduction */
  yyRuleNum yyrule;
  /** The last RHS state in the list of states to be reduced. */
  yyGLRState* yystate;
  /** Next sibling in chain of options. To facilitate merging,
   *  options are chained in decreasing order by address. */
  yySemanticOption* yynext;
};

/** Type of the items in the GLR stack. The yyisState field
 *  indicates which item of the union is valid. */
union yyGLRStackItem {
  yyGLRState yystate;
  yySemanticOption yyoption;
};

struct yyGLRStack {
  int yyerrState;
  /* To compute the location of the error token.  */
  yyGLRStackItem yyerror_range[3];

  yySymbol* yytokenp;
  YYJMP_BUF yyexception_buffer;
  yyGLRStackItem* yyitems;
  yyGLRStackItem* yynextFree;
  size_t yyspaceLeft;
  yyGLRState* yysplitPoint;
  yyGLRState* yylastDeleted;
  yyGLRStateSet yytops;
};

static void yyexpandGLRStack (yyGLRStack* yystack);

static void yyFail (yyGLRStack* yystack, const char* yymsg)
  __attribute__ ((__noreturn__));
static void
yyFail (yyGLRStack* yystack, const char* yymsg)
{
  if (yymsg != NULL)
    yyerror (yymsg);
  YYLONGJMP (yystack->yyexception_buffer, 1);
}

static void yyMemoryExhausted (yyGLRStack* yystack)
  __attribute__ ((__noreturn__));
static void
yyMemoryExhausted (yyGLRStack* yystack)
{
  YYLONGJMP (yystack->yyexception_buffer, 2);
}

#if YYDEBUG || YYERROR_VERBOSE
/** A printable representation of TOKEN.  */
static inline const char*
yytokenName (yySymbol yytoken)
{
  if (yytoken == YYEMPTY)
    return "";

  return yytname[yytoken];
}
#endif

/** Fill in YYVSP[YYLOW1 .. YYLOW0-1] from the chain of states starting
 *  at YYVSP[YYLOW0].yystate.yypred.  Leaves YYVSP[YYLOW1].yystate.yypred
 *  containing the pointer to the next state in the chain. Assumes
 *  YYLOW1 < YYLOW0.  */
static void yyfillin (yyGLRStackItem *, int, int) __attribute__ ((__unused__));
static void
yyfillin (yyGLRStackItem *yyvsp, int yylow0, int yylow1)
{
  yyGLRState* s;
  int i;
  s = yyvsp[yylow0].yystate.yypred;
  for (i = yylow0-1; i >= yylow1; i -= 1)
    {
      YYASSERT (s->yyresolved);
      yyvsp[i].yystate.yyresolved = yytrue;
      yyvsp[i].yystate.yysemantics.yysval = s->yysemantics.yysval;
      yyvsp[i].yystate.yyloc = s->yyloc;
      s = yyvsp[i].yystate.yypred = s->yypred;
    }
}

/* Do nothing if YYNORMAL or if *YYLOW <= YYLOW1.  Otherwise, fill in
   YYVSP[YYLOW1 .. *YYLOW-1] as in yyfillin and set *YYLOW = YYLOW1.
   For convenience, always return YYLOW1.  */
static inline int yyfill (yyGLRStackItem *, int *, int, yybool)
     __attribute__ ((__unused__));
static inline int
yyfill (yyGLRStackItem *yyvsp, int *yylow, int yylow1, yybool yynormal)
{
  if (!yynormal && yylow1 < *yylow)
    {
      yyfillin (yyvsp, *yylow, yylow1);
      *yylow = yylow1;
    }
  return yylow1;
}

/** Perform user action for rule number YYN, with RHS length YYRHSLEN,
 *  and top stack item YYVSP.  YYLVALP points to place to put semantic
 *  value ($$), and yylocp points to place for location information
 *  (@$). Returns yyok for normal return, yyaccept for YYACCEPT,
 *  yyerr for YYERROR, yyabort for YYABORT. */
static YYRESULTTAG
yyuserAction (yyRuleNum yyn, int yyrhslen, yyGLRStackItem* yyvsp,
	      YYSTYPE* yyvalp,
	      YYLTYPE* YYOPTIONAL_LOC (yylocp),
	      yyGLRStack* yystack
              )
{
  yybool yynormal __attribute__ ((__unused__)) =
    (yystack->yysplitPoint == NULL);
  int yylow;

# undef yyerrok
# define yyerrok (yystack->yyerrState = 0)
# undef YYACCEPT
# define YYACCEPT return yyaccept
# undef YYABORT
# define YYABORT return yyabort
# undef YYERROR
# define YYERROR return yyerrok, yyerr
# undef YYRECOVERING
# define YYRECOVERING (yystack->yyerrState != 0)
# undef yyclearin
# define yyclearin (yychar = *(yystack->yytokenp) = YYEMPTY)
# undef YYFILL
# define YYFILL(N) yyfill (yyvsp, &yylow, N, yynormal)
# undef YYBACKUP
# define YYBACKUP(Token, Value)						     \
  return yyerror (YY_("syntax error: cannot back up")),     \
	 yyerrok, yyerr

  yylow = 1;
  if (yyrhslen == 0)
    *yyvalp = yyval_default;
  else
    *yyvalp = yyvsp[YYFILL (1-yyrhslen)].yystate.yysemantics.yysval;
  YYLLOC_DEFAULT (*yylocp, yyvsp - yyrhslen, yyrhslen);
  yystack->yyerror_range[1].yystate.yyloc = *yylocp;

  switch (yyn)
    {
        case 3:
#line 127 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {identVerilog.resize(0);;}
    break;

  case 5:
#line 128 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {identVerilog.resize(0);;}
    break;

  case 36:
#line 209 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 52:
#line 236 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {
                                    yydebug=1; //sets parser in debug mode
                                    if(!parseCode) { 
							              
											 lastModule=VerilogDocGen::makeNewEntry("",Entry::CLASS_SEC,VerilogDocGen::MODULE);
                                            currentVerilog=lastModule;
                                             currentVerilog->protection=Public;
					                         parseModule();
							                 CurrState=VerilogDocGen::STATE_MODULE;
				                             
										    }
                                            else {
											      parseModule();
                                         		  }
                               currVerilogType=0;						       
							   vbufreset();
							 ;}
    break;

  case 53:
#line 255 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {
            if(!parseCode){ 
			        int ll=getVerilogLine();
	                currentVerilog->endBodyLine=ll;
			       } 	 
              vbufreset(); 
		   ;}
    break;

  case 54:
#line 261 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currentVerilog=0;vbufreset();;}
    break;

  case 57:
#line 271 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=VerilogDocGen::PORT;;}
    break;

  case 58:
#line 271 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 60:
#line 275 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 61:
#line 275 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 62:
#line 276 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 63:
#line 276 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 64:
#line 277 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 65:
#line 277 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 66:
#line 283 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=VerilogDocGen::PORT;;}
    break;

  case 67:
#line 283 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 68:
#line 284 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 69:
#line 288 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 70:
#line 292 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 71:
#line 293 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 83:
#line 315 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;vbufreset();;}
    break;

  case 84:
#line 316 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;vbufreset();;}
    break;

  case 85:
#line 317 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;vbufreset();;}
    break;

  case 86:
#line 318 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 89:
#line 327 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 90:
#line 328 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 93:
#line 331 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 95:
#line 336 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 96:
#line 337 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 97:
#line 338 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 98:
#line 339 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 99:
#line 340 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 100:
#line 341 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 101:
#line 342 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 110:
#line 353 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 111:
#line 354 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 112:
#line 355 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 113:
#line 359 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { if(parseCode) currVerilogType=VerilogDocGen::DEFPARAM;;}
    break;

  case 114:
#line 359 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); if(parseCode) currVerilogType=0; ;}
    break;

  case 115:
#line 360 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); if(parseCode) currVerilogType=0;;}
    break;

  case 116:
#line 368 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 117:
#line 368 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 118:
#line 369 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 119:
#line 369 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 120:
#line 370 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 121:
#line 370 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 122:
#line 371 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 123:
#line 371 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 124:
#line 372 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 125:
#line 372 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 127:
#line 376 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 128:
#line 376 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 129:
#line 377 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 130:
#line 377 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 131:
#line 378 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 132:
#line 378 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 133:
#line 379 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 134:
#line 379 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 135:
#line 380 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::PARAMETER;;}
    break;

  case 136:
#line 380 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 137:
#line 381 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;vbufreset();;}
    break;

  case 138:
#line 384 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 139:
#line 385 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 141:
#line 393 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INOUT; ;}
    break;

  case 142:
#line 393 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 143:
#line 394 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INOUT; ;}
    break;

  case 144:
#line 394 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 145:
#line 395 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 146:
#line 396 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 147:
#line 399 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT; ;}
    break;

  case 148:
#line 399 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 149:
#line 400 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT; ;}
    break;

  case 150:
#line 400 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 151:
#line 401 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 152:
#line 402 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 153:
#line 407 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT; ;}
    break;

  case 154:
#line 407 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 155:
#line 408 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT; ;}
    break;

  case 156:
#line 408 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 157:
#line 410 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT; ;}
    break;

  case 158:
#line 410 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 160:
#line 413 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 161:
#line 414 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 162:
#line 415 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 173:
#line 443 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 174:
#line 444 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 177:
#line 451 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 179:
#line 456 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 180:
#line 457 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 181:
#line 458 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 182:
#line 459 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 183:
#line 460 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 184:
#line 461 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 185:
#line 462 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 186:
#line 463 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 187:
#line 464 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 188:
#line 465 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 189:
#line 466 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 194:
#line 479 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currVerilogType=0;;}
    break;

  case 195:
#line 480 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 196:
#line 482 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::TIME; ;}
    break;

  case 197:
#line 482 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currVerilogType=0;;}
    break;

  case 198:
#line 483 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 199:
#line 486 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 200:
#line 487 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 201:
#line 488 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 202:
#line 491 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::TIME; ;}
    break;

  case 203:
#line 491 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currVerilogType=0;;}
    break;

  case 204:
#line 492 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 213:
#line 521 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 220:
#line 540 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 221:
#line 543 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 222:
#line 544 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 238:
#line 583 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {
                                                                   							parseReg(currentVerilog);}
																							vbufreset();;}
    break;

  case 239:
#line 586 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) parseReg(currentVerilog);vbufreset();;}
    break;

  case 240:
#line 594 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) {parseReg(currentVerilog);}vbufreset();;}
    break;

  case 241:
#line 596 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {
                          			 if(currVerilogType==VerilogDocGen::PARAMETER && !parseCode)
									 parseParam(currentVerilog);
									 vbufreset();
	                   ;}
    break;

  case 245:
#line 625 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog)
						                                {
														  currentFunctionVerilog->endBodyLine=getVerilogPrevLine();
														} vbufreset(); ;}
    break;

  case 246:
#line 633 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog){currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset(); ;}
    break;

  case 247:
#line 634 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 248:
#line 638 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {  if(!parseCode){
                             //    printf("\n  funcname [%s] --\n",getVerilogString());
                                 currentFunctionVerilog=VerilogDocGen::makeNewEntry("",Entry::FUNCTION_SEC,VerilogDocGen::FUNCTION);
								 currentFunctionVerilog->fileName=getVerilogParsingFile();
								 parseFunction(currentFunctionVerilog);
								 CurrState=VerilogDocGen::STATE_FUNCTION;
								 }
								 vbufreset();
							   ;}
    break;

  case 262:
#line 674 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=0;;}
    break;

  case 265:
#line 688 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog) { currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset();;}
    break;

  case 267:
#line 692 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog) { currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset();;}
    break;

  case 268:
#line 694 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currentFunctionVerilog) { currentFunctionVerilog->endBodyLine=getVerilogPrevLine();} vbufreset();;}
    break;

  case 269:
#line 695 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 270:
#line 698 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {  if(!parseCode){
                             //    printf("\n  funcname [%s] --\n",getVerilogString());
                                 currentFunctionVerilog=VerilogDocGen::makeNewEntry("",Entry::FUNCTION_SEC,VerilogDocGen::TASK);
								 currentFunctionVerilog->fileName=getVerilogParsingFile();
								 parseFunction(currentFunctionVerilog);
								 CurrState=VerilogDocGen::STATE_FUNCTION;
								 }
								 vbufreset();
							   ;}
    break;

  case 280:
#line 734 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {
                             if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                     ;}
    break;

  case 281:
#line 739 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                      ;}
    break;

  case 282:
#line 743 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                       ;}
    break;

  case 283:
#line 748 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {
                             if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                   ;}
    break;

  case 284:
#line 753 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {
                             if(!parseCode){
							   parsePortDir(currentVerilog,3);}
							   vbufreset();
                    ;}
    break;

  case 291:
#line 771 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode )currVerilogType=VerilogDocGen::INOUT;;}
    break;

  case 292:
#line 772 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode)currVerilogType=VerilogDocGen::OUTPUT;;}
    break;

  case 293:
#line 773 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode)currVerilogType=VerilogDocGen::INPUT;;}
    break;

  case 294:
#line 774 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode){parsePortDir(currentVerilog,3);vbufreset();};}
    break;

  case 297:
#line 782 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 298:
#line 783 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 299:
#line 784 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 300:
#line 785 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 301:
#line 786 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 302:
#line 787 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 303:
#line 788 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode){currVerilogType=VerilogDocGen::INPUT;parsePortDir(currentVerilog,3);}vbufreset();;}
    break;

  case 304:
#line 789 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 317:
#line 813 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 318:
#line 814 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 319:
#line 815 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 329:
#line 836 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 342:
#line 878 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { 
                    						;}
    break;

  case 343:
#line 879 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 345:
#line 880 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 353:
#line 894 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;

  case 356:
#line 901 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { ;}
    break;

  case 358:
#line 906 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 359:
#line 907 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 360:
#line 911 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); currVerilogType=0;;}
    break;

  case 361:
#line 912 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset(); currVerilogType=0;;}
    break;

  case 362:
#line 915 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { 
                            const char *name=(((yyGLRStackItem const *)yyvsp)[YYFILL (-1)].yystate.yysemantics.yysval.cstr);
                            QCString first(name);
							QCString sec(getVerilogString());
						     QCString ll=getLastLetter();
							
							 parseModuleInst(first,sec);
							     if(parseCode){
							  currVerilogType=VerilogDocGen::COMPONENT;
							  vbufreset();
							  }
							  ;}
    break;

  case 371:
#line 957 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {CurrState=VerilogDocGen::STATE_GENERATE;;}
    break;

  case 372:
#line 957 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {CurrState=0;;}
    break;

  case 378:
#line 971 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 379:
#line 972 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 380:
#line 973 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 381:
#line 974 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 382:
#line 975 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 395:
#line 1003 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 396:
#line 1004 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 397:
#line 1013 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();currentVerilog=0;;}
    break;

  case 399:
#line 1019 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { if(!parseCode) { 
							               //  printf("\n  name_of_mod [%s] [%d]--\n",getVerilogString(),getVerilogLine());
                                            lastModule=VerilogDocGen::makeNewEntry("",Entry::CLASS_SEC,VerilogDocGen::MODULE);
                                             currentVerilog=lastModule;
                                             currentVerilog->protection=Private;
					                        //  currentVerilog->stat=TRUE;
					                         parseModule();
							                 CurrState=VerilogDocGen::STATE_MODULE;

										    }
                                            else {
											      parseModule();
                                              //    currVerilogType=VerilogDocGen::MODULE;
												  }
						        vbufreset();
							 ;}
    break;

  case 400:
#line 1041 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 401:
#line 1042 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {parseListOfPorts();vbufreset();;}
    break;

  case 412:
#line 1063 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 413:
#line 1064 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 414:
#line 1065 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 415:
#line 1066 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::OUTPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 416:
#line 1069 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 417:
#line 1070 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { currVerilogType=VerilogDocGen::INPUT;if(!parseCode)parsePortDir(currentVerilog,3);vbufreset();;}
    break;

  case 418:
#line 1072 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) parseReg(currentVerilog);vbufreset();;}
    break;

  case 419:
#line 1073 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode) parseReg(currentVerilog);vbufreset();;}
    break;

  case 421:
#line 1083 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 422:
#line 1084 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 423:
#line 1085 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 428:
#line 1098 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 429:
#line 1099 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 430:
#line 1102 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr);writeDigit(); ;}
    break;

  case 442:
#line 1127 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr);writeDigit(); ;}
    break;

  case 461:
#line 1172 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 462:
#line 1173 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();  ;}
    break;

  case 463:
#line 1176 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {
                               currVerilogType=VerilogDocGen::ALWAYS;
                     		   ;}
    break;

  case 464:
#line 1178 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {
                                            if(!parseCode && currentFunctionVerilog)
											 {
											  currentFunctionVerilog->endBodyLine=getVerilogEndLine();
											  if( currentFunctionVerilog->endBodyLine<currentFunctionVerilog->startLine || c_lloc.first_line>currentFunctionVerilog->endBodyLine ) // awlays without end
											   currentFunctionVerilog->endBodyLine=c_lloc.first_line;
											  currVerilogType=0;
											  } vbufreset();;}
    break;

  case 465:
#line 1186 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();currVerilogType=0;;}
    break;

  case 469:
#line 1193 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 473:
#line 1199 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 495:
#line 1251 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(!parseCode && currVerilogType==VerilogDocGen::ALWAYS)parseAlways(true);;}
    break;

  case 514:
#line 1279 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 529:
#line 1306 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 532:
#line 1311 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 533:
#line 1311 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {currVerilogType=0;;}
    break;

  case 535:
#line 1317 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 536:
#line 1318 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 537:
#line 1319 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 538:
#line 1320 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 539:
#line 1321 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { parseAlways(); vbufreset();currVerilogType=0;;}
    break;

  case 555:
#line 1360 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 557:
#line 1362 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 559:
#line 1364 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset();;}
    break;

  case 581:
#line 1416 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 582:
#line 1417 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 583:
#line 1421 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 584:
#line 1422 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 585:
#line 1426 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 586:
#line 1427 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 587:
#line 1428 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 588:
#line 1429 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 589:
#line 1430 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 778:
#line 1843 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr);writeDigit(); ;}
    break;

  case 779:
#line 1844 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {if(parseCode) {writePrevVerilogWords(identVerilog);writeVerilogFont("vhdllogic",identVerilog.data());identVerilog.resize(0);};}
    break;

  case 780:
#line 1855 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {vbufreset();;}
    break;

  case 781:
#line 1856 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 783:
#line 1860 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 784:
#line 1861 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { vbufreset(); ;}
    break;

  case 790:
#line 1873 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {
										 ;}
    break;

  case 791:
#line 1877 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    { parseString(); ;}
    break;

  case 792:
#line 1880 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {
                    	if(parseCode) 
						      identVerilog+=(((yyGLRStackItem const *)yyvsp)[YYFILL (0)].yystate.yysemantics.yysval.cstr); 
							 ;}
    break;

  case 793:
#line 1884 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"
    {;}
    break;


      default: break;
    }

  return yyok;
# undef yyerrok
# undef YYABORT
# undef YYACCEPT
# undef YYERROR
# undef YYBACKUP
# undef yyclearin
# undef YYRECOVERING
/* Line 872 of glr.c.  */
#line 5364 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.cpp"
}


static void
yyuserMerge (int yyn, YYSTYPE* yy0, YYSTYPE* yy1)
{
  /* `Use' the arguments.  */
  (void) yy0;
  (void) yy1;

  switch (yyn)
    {
      
      default: break;
    }
}

			      /* Bison grammar-table manipulation.  */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
        break;
    }
}

/** Number of symbols composing the right hand side of rule #RULE.  */
static inline int
yyrhsLength (yyRuleNum yyrule)
{
  return yyr2[yyrule];
}

static void
yydestroyGLRState (char const *yymsg, yyGLRState *yys)
{
  if (yys->yyresolved)
    yydestruct (yymsg, yystos[yys->yylrState],
		&yys->yysemantics.yysval, &yys->yyloc);
  else
    {
#if YYDEBUG
      if (yydebug)
	{
	  YYFPRINTF (stderr, "%s unresolved ", yymsg);
	  yysymprint (stderr, yystos[yys->yylrState],
		      &yys->yysemantics.yysval, &yys->yyloc);
	  YYFPRINTF (stderr, "\n");
	}
#endif

      if (yys->yysemantics.yyfirstVal)
        {
          yySemanticOption *yyoption = yys->yysemantics.yyfirstVal;
          yyGLRState *yyrh;
          int yyn;
          for (yyrh = yyoption->yystate, yyn = yyrhsLength (yyoption->yyrule);
               yyn > 0;
               yyrh = yyrh->yypred, yyn -= 1)
            yydestroyGLRState (yymsg, yyrh);
        }
    }
}

/** Left-hand-side symbol for rule #RULE. */
static inline yySymbol
yylhsNonterm (yyRuleNum yyrule)
{
  return yyr1[yyrule];
}

#define yyis_pact_ninf(yystate) \
  ((yystate) == YYPACT_NINF)

/** True iff LR state STATE has only a default reduction (regardless
 *  of token). */
static inline yybool
yyisDefaultedState (yyStateNum yystate)
{
  return yyis_pact_ninf (yypact[yystate]);
}

/** The default reduction for STATE, assuming it has one. */
static inline yyRuleNum
yydefaultAction (yyStateNum yystate)
{
  return yydefact[yystate];
}

#define yyis_table_ninf(yytable_value) \
  0

/** Set *YYACTION to the action to take in YYSTATE on seeing YYTOKEN.
 *  Result R means
 *    R < 0:  Reduce on rule -R.
 *    R = 0:  Error.
 *    R > 0:  Shift to state R.
 *  Set *CONFLICTS to a pointer into yyconfl to 0-terminated list of
 *  conflicting reductions.
 */
static inline void
yygetLRActions (yyStateNum yystate, int yytoken,
	        int* yyaction, const short int** yyconflicts)
{
  int yyindex = yypact[yystate] + yytoken;
  if (yyindex < 0 || YYLAST < yyindex || yycheck[yyindex] != yytoken)
    {
      *yyaction = -yydefact[yystate];
      *yyconflicts = yyconfl;
    }
  else if (! yyis_table_ninf (yytable[yyindex]))
    {
      *yyaction = yytable[yyindex];
      *yyconflicts = yyconfl + yyconflp[yyindex];
    }
  else
    {
      *yyaction = 0;
      *yyconflicts = yyconfl + yyconflp[yyindex];
    }
}

static inline yyStateNum
yyLRgotoState (yyStateNum yystate, yySymbol yylhs)
{
  int yyr;
  yyr = yypgoto[yylhs - YYNTOKENS] + yystate;
  if (0 <= yyr && yyr <= YYLAST && yycheck[yyr] == yystate)
    return yytable[yyr];
  else
    return yydefgoto[yylhs - YYNTOKENS];
}

static inline yybool
yyisShiftAction (int yyaction)
{
  return 0 < yyaction;
}

static inline yybool
yyisErrorAction (int yyaction)
{
  return yyaction == 0;
}

				/* GLRStates */

static void
yyaddDeferredAction (yyGLRStack* yystack, yyGLRState* yystate,
		     yyGLRState* rhs, yyRuleNum yyrule)
{
  yySemanticOption* yynewItem;
  yynewItem = &yystack->yynextFree->yyoption;
  yystack->yyspaceLeft -= 1;
  yystack->yynextFree += 1;
  yynewItem->yyisState = yyfalse;
  yynewItem->yystate = rhs;
  yynewItem->yyrule = yyrule;
  yynewItem->yynext = yystate->yysemantics.yyfirstVal;
  yystate->yysemantics.yyfirstVal = yynewItem;
  if (yystack->yyspaceLeft < YYHEADROOM)
    yyexpandGLRStack (yystack);
}

				/* GLRStacks */

/** Initialize SET to a singleton set containing an empty stack. */
static yybool
yyinitStateSet (yyGLRStateSet* yyset)
{
  yyset->yysize = 1;
  yyset->yycapacity = 16;
  yyset->yystates = (yyGLRState**) YYMALLOC (16 * sizeof yyset->yystates[0]);
  if (! yyset->yystates)
    return yyfalse;
  yyset->yystates[0] = NULL;
  return yytrue;
}

static void yyfreeStateSet (yyGLRStateSet* yyset)
{
  YYFREE (yyset->yystates);
}

/** Initialize STACK to a single empty stack, with total maximum
 *  capacity for all stacks of SIZE. */
static yybool
yyinitGLRStack (yyGLRStack* yystack, size_t yysize)
{
  yystack->yyerrState = 0;
  yynerrs = 0;
  yystack->yyspaceLeft = yysize;
  yystack->yyitems =
    (yyGLRStackItem*) YYMALLOC (yysize * sizeof yystack->yynextFree[0]);
  if (!yystack->yyitems)
    return yyfalse;
  yystack->yynextFree = yystack->yyitems;
  yystack->yysplitPoint = NULL;
  yystack->yylastDeleted = NULL;
  return yyinitStateSet (&yystack->yytops);
}

#define YYRELOC(YYFROMITEMS,YYTOITEMS,YYX,YYTYPE) \
  &((YYTOITEMS) - ((YYFROMITEMS) - (yyGLRStackItem*) (YYX)))->YYTYPE

/** If STACK is expandable, extend it.  WARNING: Pointers into the
    stack from outside should be considered invalid after this call.
    We always expand when there are 1 or fewer items left AFTER an
    allocation, so that we can avoid having external pointers exist
    across an allocation. */
static void
yyexpandGLRStack (yyGLRStack* yystack)
{
#if YYSTACKEXPANDABLE
  yyGLRStackItem* yynewItems;
  yyGLRStackItem* yyp0, *yyp1;
  size_t yysize, yynewSize;
  size_t yyn;
  yysize = yystack->yynextFree - yystack->yyitems;
  if (YYMAXDEPTH <= yysize)
    yyMemoryExhausted (yystack);
  yynewSize = 2*yysize;
  if (YYMAXDEPTH < yynewSize)
    yynewSize = YYMAXDEPTH;
  yynewItems = (yyGLRStackItem*) YYMALLOC (yynewSize * sizeof yynewItems[0]);
  if (! yynewItems)
    yyMemoryExhausted (yystack);
  for (yyp0 = yystack->yyitems, yyp1 = yynewItems, yyn = yysize;
       0 < yyn;
       yyn -= 1, yyp0 += 1, yyp1 += 1)
    {
      *yyp1 = *yyp0;
      if (*(yybool *) yyp0)
	{
	  yyGLRState* yys0 = &yyp0->yystate;
	  yyGLRState* yys1 = &yyp1->yystate;
	  if (yys0->yypred != NULL)
	    yys1->yypred =
	      YYRELOC (yyp0, yyp1, yys0->yypred, yystate);
	  if (! yys0->yyresolved && yys0->yysemantics.yyfirstVal != NULL)
	    yys1->yysemantics.yyfirstVal =
	      YYRELOC(yyp0, yyp1, yys0->yysemantics.yyfirstVal, yyoption);
	}
      else
	{
	  yySemanticOption* yyv0 = &yyp0->yyoption;
	  yySemanticOption* yyv1 = &yyp1->yyoption;
	  if (yyv0->yystate != NULL)
	    yyv1->yystate = YYRELOC (yyp0, yyp1, yyv0->yystate, yystate);
	  if (yyv0->yynext != NULL)
	    yyv1->yynext = YYRELOC (yyp0, yyp1, yyv0->yynext, yyoption);
	}
    }
  if (yystack->yysplitPoint != NULL)
    yystack->yysplitPoint = YYRELOC (yystack->yyitems, yynewItems,
				 yystack->yysplitPoint, yystate);

  for (yyn = 0; yyn < yystack->yytops.yysize; yyn += 1)
    if (yystack->yytops.yystates[yyn] != NULL)
      yystack->yytops.yystates[yyn] =
	YYRELOC (yystack->yyitems, yynewItems,
		 yystack->yytops.yystates[yyn], yystate);
  YYFREE (yystack->yyitems);
  yystack->yyitems = yynewItems;
  yystack->yynextFree = yynewItems + yysize;
  yystack->yyspaceLeft = yynewSize - yysize;

#else
  yyMemoryExhausted (yystack);
#endif
}

static void
yyfreeGLRStack (yyGLRStack* yystack)
{
  YYFREE (yystack->yyitems);
  yyfreeStateSet (&yystack->yytops);
}

/** Assuming that S is a GLRState somewhere on STACK, update the
 *  splitpoint of STACK, if needed, so that it is at least as deep as
 *  S. */
static inline void
yyupdateSplit (yyGLRStack* yystack, yyGLRState* yys)
{
  if (yystack->yysplitPoint != NULL && yystack->yysplitPoint > yys)
    yystack->yysplitPoint = yys;
}

/** Invalidate stack #K in STACK. */
static inline void
yymarkStackDeleted (yyGLRStack* yystack, size_t yyk)
{
  if (yystack->yytops.yystates[yyk] != NULL)
    yystack->yylastDeleted = yystack->yytops.yystates[yyk];
  yystack->yytops.yystates[yyk] = NULL;
}

/** Undelete the last stack that was marked as deleted.  Can only be
    done once after a deletion, and only when all other stacks have
    been deleted. */
static void
yyundeleteLastStack (yyGLRStack* yystack)
{
  if (yystack->yylastDeleted == NULL || yystack->yytops.yysize != 0)
    return;
  yystack->yytops.yystates[0] = yystack->yylastDeleted;
  yystack->yytops.yysize = 1;
  YYDPRINTF ((stderr, "Restoring last deleted stack as stack #0.\n"));
  yystack->yylastDeleted = NULL;
}

static inline void
yyremoveDeletes (yyGLRStack* yystack)
{
  size_t yyi, yyj;
  yyi = yyj = 0;
  while (yyj < yystack->yytops.yysize)
    {
      if (yystack->yytops.yystates[yyi] == NULL)
	{
	  if (yyi == yyj)
	    {
	      YYDPRINTF ((stderr, "Removing dead stacks.\n"));
	    }
	  yystack->yytops.yysize -= 1;
	}
      else
	{
	  yystack->yytops.yystates[yyj] = yystack->yytops.yystates[yyi];
	  if (yyj != yyi)
	    {
	      YYDPRINTF ((stderr, "Rename stack %lu -> %lu.\n",
			  (unsigned long int) yyi, (unsigned long int) yyj));
	    }
	  yyj += 1;
	}
      yyi += 1;
    }
}

/** Shift to a new state on stack #K of STACK, corresponding to LR state
 * LRSTATE, at input position POSN, with (resolved) semantic value SVAL. */
static inline void
yyglrShift (yyGLRStack* yystack, size_t yyk, yyStateNum yylrState,
	    size_t yyposn,
	    YYSTYPE yysval, YYLTYPE* yylocp)
{
  yyGLRStackItem* yynewItem;

  yynewItem = yystack->yynextFree;
  yystack->yynextFree += 1;
  yystack->yyspaceLeft -= 1;
  yynewItem->yystate.yyisState = yytrue;
  yynewItem->yystate.yylrState = yylrState;
  yynewItem->yystate.yyposn = yyposn;
  yynewItem->yystate.yyresolved = yytrue;
  yynewItem->yystate.yypred = yystack->yytops.yystates[yyk];
  yystack->yytops.yystates[yyk] = &yynewItem->yystate;
  yynewItem->yystate.yysemantics.yysval = yysval;
  yynewItem->yystate.yyloc = *yylocp;
  if (yystack->yyspaceLeft < YYHEADROOM)
    yyexpandGLRStack (yystack);
}

/** Shift stack #K of YYSTACK, to a new state corresponding to LR
 *  state YYLRSTATE, at input position YYPOSN, with the (unresolved)
 *  semantic value of YYRHS under the action for YYRULE. */
static inline void
yyglrShiftDefer (yyGLRStack* yystack, size_t yyk, yyStateNum yylrState,
		 size_t yyposn, yyGLRState* rhs, yyRuleNum yyrule)
{
  yyGLRStackItem* yynewItem;

  yynewItem = yystack->yynextFree;
  yynewItem->yystate.yyisState = yytrue;
  yynewItem->yystate.yylrState = yylrState;
  yynewItem->yystate.yyposn = yyposn;
  yynewItem->yystate.yyresolved = yyfalse;
  yynewItem->yystate.yypred = yystack->yytops.yystates[yyk];
  yynewItem->yystate.yysemantics.yyfirstVal = NULL;
  yystack->yytops.yystates[yyk] = &yynewItem->yystate;
  yystack->yynextFree += 1;
  yystack->yyspaceLeft -= 1;
  yyaddDeferredAction (yystack, &yynewItem->yystate, rhs, yyrule);
}

/** Pop the symbols consumed by reduction #RULE from the top of stack
 *  #K of STACK, and perform the appropriate semantic action on their
 *  semantic values.  Assumes that all ambiguities in semantic values
 *  have been previously resolved. Set *VALP to the resulting value,
 *  and *LOCP to the computed location (if any).  Return value is as
 *  for userAction. */
static inline YYRESULTTAG
yydoAction (yyGLRStack* yystack, size_t yyk, yyRuleNum yyrule,
	    YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  int yynrhs = yyrhsLength (yyrule);

  if (yystack->yysplitPoint == NULL)
    {
      /* Standard special case: single stack. */
      yyGLRStackItem* rhs = (yyGLRStackItem*) yystack->yytops.yystates[yyk];
      YYASSERT (yyk == 0);
      yystack->yynextFree -= yynrhs;
      yystack->yyspaceLeft += yynrhs;
      yystack->yytops.yystates[0] = & yystack->yynextFree[-1].yystate;
      return yyuserAction (yyrule, yynrhs, rhs,
			   yyvalp, yylocp, yystack);
    }
  else
    {
      int yyi;
      yyGLRState* yys;
      yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
      yys = yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred
	= yystack->yytops.yystates[yyk];
      for (yyi = 0; yyi < yynrhs; yyi += 1)
	{
	  yys = yys->yypred;
	  YYASSERT (yys);
	}
      yyupdateSplit (yystack, yys);
      yystack->yytops.yystates[yyk] = yys;
      return yyuserAction (yyrule, yynrhs, yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
			   yyvalp, yylocp, yystack);
    }
}

#if !YYDEBUG
# define YY_REDUCE_PRINT(K, Rule)
#else
# define YY_REDUCE_PRINT(K, Rule)	\
do {					\
  if (yydebug)				\
    yy_reduce_print (K, Rule);		\
} while (0)

/*----------------------------------------------------------.
| Report that the RULE is going to be reduced on stack #K.  |
`----------------------------------------------------------*/

static inline void
yy_reduce_print (size_t yyk, yyRuleNum yyrule)
{
  int yyi;
  YYFPRINTF (stderr, "Reducing stack %lu by rule %d (line %lu), ",
	     (unsigned long int) yyk, yyrule - 1,
	     (unsigned long int) yyrline[yyrule]);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytokenName (yyrhs[yyi]));
  YYFPRINTF (stderr, "-> %s\n", yytokenName (yyr1[yyrule]));
}
#endif

/** Pop items off stack #K of STACK according to grammar rule RULE,
 *  and push back on the resulting nonterminal symbol.  Perform the
 *  semantic action associated with RULE and store its value with the
 *  newly pushed state, if FORCEEVAL or if STACK is currently
 *  unambiguous.  Otherwise, store the deferred semantic action with
 *  the new state.  If the new state would have an identical input
 *  position, LR state, and predecessor to an existing state on the stack,
 *  it is identified with that existing state, eliminating stack #K from
 *  the STACK. In this case, the (necessarily deferred) semantic value is
 *  added to the options for the existing state's semantic value.
 */
static inline YYRESULTTAG
yyglrReduce (yyGLRStack* yystack, size_t yyk, yyRuleNum yyrule,
             yybool yyforceEval)
{
  size_t yyposn = yystack->yytops.yystates[yyk]->yyposn;

  if (yyforceEval || yystack->yysplitPoint == NULL)
    {
      YYSTYPE yysval;
      YYLTYPE yyloc;

      YY_REDUCE_PRINT (yyk, yyrule);
      YYCHK (yydoAction (yystack, yyk, yyrule, &yysval, &yyloc));
      yyglrShift (yystack, yyk,
		  yyLRgotoState (yystack->yytops.yystates[yyk]->yylrState,
				 yylhsNonterm (yyrule)),
		  yyposn, yysval, &yyloc);
    }
  else
    {
      size_t yyi;
      int yyn;
      yyGLRState* yys, *yys0 = yystack->yytops.yystates[yyk];
      yyStateNum yynewLRState;

      for (yys = yystack->yytops.yystates[yyk], yyn = yyrhsLength (yyrule);
	   0 < yyn; yyn -= 1)
	{
	  yys = yys->yypred;
	  YYASSERT (yys);
	}
      yyupdateSplit (yystack, yys);
      yynewLRState = yyLRgotoState (yys->yylrState, yylhsNonterm (yyrule));
      YYDPRINTF ((stderr,
		  "Reduced stack %lu by rule #%d; action deferred. Now in state %d.\n",
		  (unsigned long int) yyk, yyrule - 1, yynewLRState));
      for (yyi = 0; yyi < yystack->yytops.yysize; yyi += 1)
	if (yyi != yyk && yystack->yytops.yystates[yyi] != NULL)
	  {
	    yyGLRState* yyp, *yysplit = yystack->yysplitPoint;
	    yyp = yystack->yytops.yystates[yyi];
	    while (yyp != yys && yyp != yysplit && yyp->yyposn >= yyposn)
	      {
		if (yyp->yylrState == yynewLRState && yyp->yypred == yys)
		  {
		    yyaddDeferredAction (yystack, yyp, yys0, yyrule);
		    yymarkStackDeleted (yystack, yyk);
		    YYDPRINTF ((stderr, "Merging stack %lu into stack %lu.\n",
				(unsigned long int) yyk,
				(unsigned long int) yyi));
		    return yyok;
		  }
		yyp = yyp->yypred;
	      }
	  }
      yystack->yytops.yystates[yyk] = yys;
      yyglrShiftDefer (yystack, yyk, yynewLRState, yyposn, yys0, yyrule);
    }
  return yyok;
}

static size_t
yysplitStack (yyGLRStack* yystack, size_t yyk)
{
  if (yystack->yysplitPoint == NULL)
    {
      YYASSERT (yyk == 0);
      yystack->yysplitPoint = yystack->yytops.yystates[yyk];
    }
  if (yystack->yytops.yysize >= yystack->yytops.yycapacity)
    {
      yyGLRState** yynewStates;
      if (! ((yystack->yytops.yycapacity
	      <= (YYSIZEMAX / (2 * sizeof yynewStates[0])))
	     && (yynewStates =
		 (yyGLRState**) YYREALLOC (yystack->yytops.yystates,
					   ((yystack->yytops.yycapacity *= 2)
					    * sizeof yynewStates[0])))))
	yyMemoryExhausted (yystack);
      yystack->yytops.yystates = yynewStates;
    }
  yystack->yytops.yystates[yystack->yytops.yysize]
    = yystack->yytops.yystates[yyk];
  yystack->yytops.yysize += 1;
  return yystack->yytops.yysize-1;
}

/** True iff Y0 and Y1 represent identical options at the top level.
 *  That is, they represent the same rule applied to RHS symbols
 *  that produce the same terminal symbols. */
static yybool
yyidenticalOptions (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  if (yyy0->yyrule == yyy1->yyrule)
    {
      yyGLRState *yys0, *yys1;
      int yyn;
      for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
	   yyn = yyrhsLength (yyy0->yyrule);
	   yyn > 0;
	   yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
	if (yys0->yyposn != yys1->yyposn)
	  return yyfalse;
      return yytrue;
    }
  else
    return yyfalse;
}

/** Assuming identicalOptions (Y0,Y1), destructively merge the
 *  alternative semantic values for the RHS-symbols of Y1 and Y0. */
static void
yymergeOptionSets (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  yyGLRState *yys0, *yys1;
  int yyn;
  for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
       yyn = yyrhsLength (yyy0->yyrule);
       yyn > 0;
       yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
    {
      if (yys0 == yys1)
	break;
      else if (yys0->yyresolved)
	{
	  yys1->yyresolved = yytrue;
	  yys1->yysemantics.yysval = yys0->yysemantics.yysval;
	}
      else if (yys1->yyresolved)
	{
	  yys0->yyresolved = yytrue;
	  yys0->yysemantics.yysval = yys1->yysemantics.yysval;
	}
      else
	{
	  yySemanticOption** yyz0p;
	  yySemanticOption* yyz1;
	  yyz0p = &yys0->yysemantics.yyfirstVal;
	  yyz1 = yys1->yysemantics.yyfirstVal;
	  while (yytrue)
	    {
	      if (yyz1 == *yyz0p || yyz1 == NULL)
		break;
	      else if (*yyz0p == NULL)
		{
		  *yyz0p = yyz1;
		  break;
		}
	      else if (*yyz0p < yyz1)
		{
		  yySemanticOption* yyz = *yyz0p;
		  *yyz0p = yyz1;
		  yyz1 = yyz1->yynext;
		  (*yyz0p)->yynext = yyz;
		}
	      yyz0p = &(*yyz0p)->yynext;
	    }
	  yys1->yysemantics.yyfirstVal = yys0->yysemantics.yyfirstVal;
	}
    }
}

/** Y0 and Y1 represent two possible actions to take in a given
 *  parsing state; return 0 if no combination is possible,
 *  1 if user-mergeable, 2 if Y0 is preferred, 3 if Y1 is preferred. */
static int
yypreference (yySemanticOption* y0, yySemanticOption* y1)
{
  yyRuleNum r0 = y0->yyrule, r1 = y1->yyrule;
  int p0 = yydprec[r0], p1 = yydprec[r1];

  if (p0 == p1)
    {
      if (yymerger[r0] == 0 || yymerger[r0] != yymerger[r1])
	return 0;
      else
	return 1;
    }
  if (p0 == 0 || p1 == 0)
    return 0;
  if (p0 < p1)
    return 3;
  if (p1 < p0)
    return 2;
  return 0;
}

static YYRESULTTAG yyresolveValue (yySemanticOption* yyoptionList,
				   yyGLRStack* yystack, YYSTYPE* yyvalp,
				   YYLTYPE* yylocp);

static YYRESULTTAG
yyresolveStates (yyGLRState* yys, int yyn, yyGLRStack* yystack)
{
  YYRESULTTAG yyflag;
  if (0 < yyn)
    {
      YYASSERT (yys->yypred);
      yyflag = yyresolveStates (yys->yypred, yyn-1, yystack);
      if (yyflag != yyok)
	return yyflag;
      if (! yys->yyresolved)
	{
	  yyflag = yyresolveValue (yys->yysemantics.yyfirstVal, yystack,
				   &yys->yysemantics.yysval, &yys->yyloc
				  );
	  if (yyflag != yyok)
	    return yyflag;
	  yys->yyresolved = yytrue;
	}
    }
  return yyok;
}

static YYRESULTTAG
yyresolveAction (yySemanticOption* yyopt, yyGLRStack* yystack,
	         YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
  int yynrhs;

  yynrhs = yyrhsLength (yyopt->yyrule);
  YYCHK (yyresolveStates (yyopt->yystate, yynrhs, yystack));
  yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred = yyopt->yystate;
  return yyuserAction (yyopt->yyrule, yynrhs,
		       yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
		       yyvalp, yylocp, yystack);
}

#if YYDEBUG
static void
yyreportTree (yySemanticOption* yyx, int yyindent)
{
  int yynrhs = yyrhsLength (yyx->yyrule);
  int yyi;
  yyGLRState* yys;
  yyGLRState* yystates[YYMAXRHS];
  yyGLRState yyleftmost_state;

  for (yyi = yynrhs, yys = yyx->yystate; 0 < yyi; yyi -= 1, yys = yys->yypred)
    yystates[yyi] = yys;
  if (yys == NULL)
    {
      yyleftmost_state.yyposn = 0;
      yystates[0] = &yyleftmost_state;
    }
  else
    yystates[0] = yys;

  if (yyx->yystate->yyposn < yys->yyposn + 1)
    YYFPRINTF (stderr, "%*s%s -> <Rule %d, empty>\n",
	       yyindent, "", yytokenName (yylhsNonterm (yyx->yyrule)),
	       yyx->yyrule);
  else
    YYFPRINTF (stderr, "%*s%s -> <Rule %d, tokens %lu .. %lu>\n",
	       yyindent, "", yytokenName (yylhsNonterm (yyx->yyrule)),
	       yyx->yyrule, (unsigned long int) (yys->yyposn + 1),
	       (unsigned long int) yyx->yystate->yyposn);
  for (yyi = 1; yyi <= yynrhs; yyi += 1)
    {
      if (yystates[yyi]->yyresolved)
	{
	  if (yystates[yyi-1]->yyposn+1 > yystates[yyi]->yyposn)
	    YYFPRINTF (stderr, "%*s%s <empty>\n", yyindent+2, "",
		       yytokenName (yyrhs[yyprhs[yyx->yyrule]+yyi-1]));
	  else
	    YYFPRINTF (stderr, "%*s%s <tokens %lu .. %lu>\n", yyindent+2, "",
		       yytokenName (yyrhs[yyprhs[yyx->yyrule]+yyi-1]),
		       (unsigned long int) (yystates[yyi - 1]->yyposn + 1),
		       (unsigned long int) yystates[yyi]->yyposn);
	}
      else
	yyreportTree (yystates[yyi]->yysemantics.yyfirstVal, yyindent+2);
    }
}
#endif

static void yyreportAmbiguity (yySemanticOption* yyx0, yySemanticOption* yyx1,
			       yyGLRStack* yystack)
  __attribute__ ((__noreturn__));
static void
yyreportAmbiguity (yySemanticOption* yyx0, yySemanticOption* yyx1,
		   yyGLRStack* yystack)
{
  /* `Unused' warnings.  */
  (void) yyx0;
  (void) yyx1;

#if YYDEBUG
  YYFPRINTF (stderr, "Ambiguity detected.\n");
  YYFPRINTF (stderr, "Option 1,\n");
  yyreportTree (yyx0, 2);
  YYFPRINTF (stderr, "\nOption 2,\n");
  yyreportTree (yyx1, 2);
  YYFPRINTF (stderr, "\n");
#endif
  yyFail (yystack, YY_("syntax is ambiguous"));
}


/** Resolve the ambiguity represented by OPTIONLIST, perform the indicated
 *  actions, and return the result. */
static YYRESULTTAG
yyresolveValue (yySemanticOption* yyoptionList, yyGLRStack* yystack,
		YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  yySemanticOption* yybest;
  yySemanticOption** yypp;
  yybool yymerge;

  yybest = yyoptionList;
  yymerge = yyfalse;
  for (yypp = &yyoptionList->yynext; *yypp != NULL; )
    {
      yySemanticOption* yyp = *yypp;

      if (yyidenticalOptions (yybest, yyp))
	{
	  yymergeOptionSets (yybest, yyp);
	  *yypp = yyp->yynext;
	}
      else
	{
	  switch (yypreference (yybest, yyp))
	    {
	    case 0:
	      yyreportAmbiguity (yybest, yyp, yystack);
	      break;
	    case 1:
	      yymerge = yytrue;
	      break;
	    case 2:
	      break;
	    case 3:
	      yybest = yyp;
	      yymerge = yyfalse;
	      break;
	    default:
	      /* This cannot happen so it is not worth a YYASSERT (yyfalse),
	         but some compilers complain if the default case is
		 omitted.  */
	      break;
	    }
	  yypp = &yyp->yynext;
	}
    }

  if (yymerge)
    {
      yySemanticOption* yyp;
      int yyprec = yydprec[yybest->yyrule];
      YYCHK (yyresolveAction (yybest, yystack, yyvalp, yylocp));
      for (yyp = yybest->yynext; yyp != NULL; yyp = yyp->yynext)
	{
	  if (yyprec == yydprec[yyp->yyrule])
	    {
	      YYSTYPE yyval1;
	      YYLTYPE yydummy;
	      YYCHK (yyresolveAction (yyp, yystack, &yyval1, &yydummy));
	      yyuserMerge (yymerger[yyp->yyrule], yyvalp, &yyval1);
	    }
	}
      return yyok;
    }
  else
    return yyresolveAction (yybest, yystack, yyvalp, yylocp);
}

static YYRESULTTAG
yyresolveStack (yyGLRStack* yystack)
{
  if (yystack->yysplitPoint != NULL)
    {
      yyGLRState* yys;
      int yyn;

      for (yyn = 0, yys = yystack->yytops.yystates[0];
	   yys != yystack->yysplitPoint;
	   yys = yys->yypred, yyn += 1)
	continue;
      YYCHK (yyresolveStates (yystack->yytops.yystates[0], yyn, yystack
			     ));
    }
  return yyok;
}

static void
yycompressStack (yyGLRStack* yystack)
{
  yyGLRState* yyp, *yyq, *yyr;

  if (yystack->yytops.yysize != 1 || yystack->yysplitPoint == NULL)
    return;

  for (yyp = yystack->yytops.yystates[0], yyq = yyp->yypred, yyr = NULL;
       yyp != yystack->yysplitPoint;
       yyr = yyp, yyp = yyq, yyq = yyp->yypred)
    yyp->yypred = yyr;

  yystack->yyspaceLeft += yystack->yynextFree - yystack->yyitems;
  yystack->yynextFree = ((yyGLRStackItem*) yystack->yysplitPoint) + 1;
  yystack->yyspaceLeft -= yystack->yynextFree - yystack->yyitems;
  yystack->yysplitPoint = NULL;
  yystack->yylastDeleted = NULL;

  while (yyr != NULL)
    {
      yystack->yynextFree->yystate = *yyr;
      yyr = yyr->yypred;
      yystack->yynextFree->yystate.yypred = & yystack->yynextFree[-1].yystate;
      yystack->yytops.yystates[0] = &yystack->yynextFree->yystate;
      yystack->yynextFree += 1;
      yystack->yyspaceLeft -= 1;
    }
}

static YYRESULTTAG
yyprocessOneStack (yyGLRStack* yystack, size_t yyk,
	           size_t yyposn, YYSTYPE* yylvalp, YYLTYPE* yyllocp
		  )
{
  int yyaction;
  const short int* yyconflicts;
  yyRuleNum yyrule;
  yySymbol* const yytokenp = yystack->yytokenp;

  while (yystack->yytops.yystates[yyk] != NULL)
    {
      yyStateNum yystate = yystack->yytops.yystates[yyk]->yylrState;
      YYDPRINTF ((stderr, "Stack %lu Entering state %d\n",
		  (unsigned long int) yyk, yystate));

      YYASSERT (yystate != YYFINAL);

      if (yyisDefaultedState (yystate))
	{
	  yyrule = yydefaultAction (yystate);
	  if (yyrule == 0)
	    {
	      YYDPRINTF ((stderr, "Stack %lu dies.\n",
			  (unsigned long int) yyk));
	      yymarkStackDeleted (yystack, yyk);
	      return yyok;
	    }
	  YYCHK (yyglrReduce (yystack, yyk, yyrule, yyfalse));
	}
      else
	{
	  if (*yytokenp == YYEMPTY)
	    {
	      YYDPRINTF ((stderr, "Reading a token: "));
	      yychar = YYLEX;
	      *yytokenp = YYTRANSLATE (yychar);
	      YY_SYMBOL_PRINT ("Next token is", *yytokenp, yylvalp, yyllocp);
	    }
	  yygetLRActions (yystate, *yytokenp, &yyaction, &yyconflicts);

	  while (*yyconflicts != 0)
	    {
	      size_t yynewStack = yysplitStack (yystack, yyk);
	      YYDPRINTF ((stderr, "Splitting off stack %lu from %lu.\n",
			  (unsigned long int) yynewStack,
			  (unsigned long int) yyk));
	      YYCHK (yyglrReduce (yystack, yynewStack,
				  *yyconflicts, yyfalse));
	      YYCHK (yyprocessOneStack (yystack, yynewStack, yyposn,
					yylvalp, yyllocp));
	      yyconflicts += 1;
	    }

	  if (yyisShiftAction (yyaction))
	    {
	      YYDPRINTF ((stderr, "On stack %lu, ", (unsigned long int) yyk));
	      YY_SYMBOL_PRINT ("shifting", *yytokenp, yylvalp, yyllocp);
	      yyglrShift (yystack, yyk, yyaction, yyposn+1,
			  *yylvalp, yyllocp);
	      YYDPRINTF ((stderr, "Stack %lu now in state #%d\n",
			  (unsigned long int) yyk,
			  yystack->yytops.yystates[yyk]->yylrState));
	      break;
	    }
	  else if (yyisErrorAction (yyaction))
	    {
	      YYDPRINTF ((stderr, "Stack %lu dies.\n",
			  (unsigned long int) yyk));
	      yymarkStackDeleted (yystack, yyk);
	      break;
	    }
	  else
	    YYCHK (yyglrReduce (yystack, yyk, -yyaction, yyfalse));
	}
    }
  return yyok;
}

static void
yyreportSyntaxError (yyGLRStack* yystack,
		     YYSTYPE* yylvalp, YYLTYPE* yyllocp)
{
  /* `Unused' warnings. */
  (void) yylvalp;
  (void) yyllocp;

  if (yystack->yyerrState == 0)
    {
#if YYERROR_VERBOSE
      yySymbol* const yytokenp = yystack->yytokenp;
      int yyn;
      yyn = yypact[yystack->yytops.yystates[0]->yylrState];
      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  size_t yysize0 = yytnamerr (NULL, yytokenName (*yytokenp));
	  size_t yysize = yysize0;
	  size_t yysize1;
	  yybool yysize_overflow = yyfalse;
	  char* yymsg = NULL;
	  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
	  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
	  int yyx;
	  char *yyfmt;
	  char const *yyf;
	  static char const yyunexpected[] = "syntax error, unexpected %s";
	  static char const yyexpecting[] = ", expecting %s";
	  static char const yyor[] = " or %s";
	  char yyformat[sizeof yyunexpected
			+ sizeof yyexpecting - 1
			+ ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
			   * (sizeof yyor - 1))];
	  char const *yyprefix = yyexpecting;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 1;

	  yyarg[0] = yytokenName (*yytokenp);
	  yyfmt = yystpcpy (yyformat, yyunexpected);

	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
		  {
		    yycount = 1;
		    yysize = yysize0;
		    yyformat[sizeof yyunexpected - 1] = '\0';
		    break;
		  }
		yyarg[yycount++] = yytokenName (yyx);
		yysize1 = yysize + yytnamerr (NULL, yytokenName (yyx));
		yysize_overflow |= yysize1 < yysize;
		yysize = yysize1;
		yyfmt = yystpcpy (yyfmt, yyprefix);
		yyprefix = yyor;
	      }

	  yyf = YY_(yyformat);
	  yysize1 = yysize + strlen (yyf);
	  yysize_overflow |= yysize1 < yysize;
	  yysize = yysize1;

	  if (!yysize_overflow)
	    yymsg = (char *) YYMALLOC (yysize);

	  if (yymsg)
	    {
	      char *yyp = yymsg;
	      int yyi = 0;
	      while ((*yyp = *yyf))
		{
		  if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		    {
		      yyp += yytnamerr (yyp, yyarg[yyi++]);
		      yyf += 2;
		    }
		  else
		    {
		      yyp++;
		      yyf++;
		    }
		}
	      yyerror (yymsg);
	      YYFREE (yymsg);
	    }
	  else
	    {
	      yyerror (YY_("syntax error"));
	      yyMemoryExhausted (yystack);
	    }
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror (YY_("syntax error"));
      yynerrs += 1;
    }
}

/* Recover from a syntax error on YYSTACK, assuming that YYTOKENP,
   YYLVALP, and YYLLOCP point to the syntactic category, semantic
   value, and location of the look-ahead.  */
static void
yyrecoverSyntaxError (yyGLRStack* yystack,
		      YYSTYPE* yylvalp,
		      YYLTYPE* YYOPTIONAL_LOC (yyllocp)
		      )
{
  yySymbol* const yytokenp = yystack->yytokenp;
  size_t yyk;
  int yyj;

  if (yystack->yyerrState == 3)
    /* We just shifted the error token and (perhaps) took some
       reductions.  Skip tokens until we can proceed.  */
    while (yytrue)
      {
	if (*yytokenp == YYEOF)
	  yyFail (yystack, NULL);
	if (*yytokenp != YYEMPTY)
	  {
	    /* We throw away the lookahead, but the error range
	       of the shifted error token must take it into account. */
	    yyGLRState *yys = yystack->yytops.yystates[0];
	    yyGLRStackItem yyerror_range[3];
	    yyerror_range[1].yystate.yyloc = yys->yyloc;
	    yyerror_range[2].yystate.yyloc = *yyllocp;
	    YYLLOC_DEFAULT (yys->yyloc, yyerror_range, 2);
	    yydestruct ("Error: discarding",
			*yytokenp, yylvalp, yyllocp);
	  }
	YYDPRINTF ((stderr, "Reading a token: "));
	yychar = YYLEX;
	*yytokenp = YYTRANSLATE (yychar);
	YY_SYMBOL_PRINT ("Next token is", *yytokenp, yylvalp, yyllocp);
	yyj = yypact[yystack->yytops.yystates[0]->yylrState];
	if (yyis_pact_ninf (yyj))
	  return;
	yyj += *yytokenp;
	if (yyj < 0 || YYLAST < yyj || yycheck[yyj] != *yytokenp)
	  {
	    if (yydefact[yystack->yytops.yystates[0]->yylrState] != 0)
	      return;
	  }
	else if (yytable[yyj] != 0 && ! yyis_table_ninf (yytable[yyj]))
	  return;
      }

  /* Reduce to one stack.  */
  for (yyk = 0; yyk < yystack->yytops.yysize; yyk += 1)
    if (yystack->yytops.yystates[yyk] != NULL)
      break;
  if (yyk >= yystack->yytops.yysize)
    yyFail (yystack, NULL);
  for (yyk += 1; yyk < yystack->yytops.yysize; yyk += 1)
    yymarkStackDeleted (yystack, yyk);
  yyremoveDeletes (yystack);
  yycompressStack (yystack);

  /* Now pop stack until we find a state that shifts the error token. */
  yystack->yyerrState = 3;
  while (yystack->yytops.yystates[0] != NULL)
    {
      yyGLRState *yys = yystack->yytops.yystates[0];
      yyj = yypact[yys->yylrState];
      if (! yyis_pact_ninf (yyj))
	{
	  yyj += YYTERROR;
	  if (0 <= yyj && yyj <= YYLAST && yycheck[yyj] == YYTERROR
	      && yyisShiftAction (yytable[yyj]))
	    {
	      /* Shift the error token having adjusted its location.  */
	      YYLTYPE yyerrloc;
	      yystack->yyerror_range[2].yystate.yyloc = *yyllocp;
	      YYLLOC_DEFAULT (yyerrloc, yystack->yyerror_range, 2);
	      YY_SYMBOL_PRINT ("Shifting", yystos[yytable[yyj]],
			       yylvalp, &yyerrloc);
	      yyglrShift (yystack, 0, yytable[yyj],
			  yys->yyposn, *yylvalp, &yyerrloc);
	      yys = yystack->yytops.yystates[0];
	      break;
	    }
	}
      yystack->yyerror_range[1].yystate.yyloc = yys->yyloc;
      yydestroyGLRState ("Error: popping", yys);
      yystack->yytops.yystates[0] = yys->yypred;
      yystack->yynextFree -= 1;
      yystack->yyspaceLeft += 1;
    }
  if (yystack->yytops.yystates[0] == NULL)
    yyFail (yystack, NULL);
}

#define YYCHK1(YYE)							     \
  do {									     \
    switch (YYE) {							     \
    case yyok:								     \
      break;								     \
    case yyabort:							     \
      goto yyabortlab;							     \
    case yyaccept:							     \
      goto yyacceptlab;							     \
    case yyerr:								     \
      goto yyuser_error;						     \
    default:								     \
      goto yybuglab;							     \
    }									     \
  } while (0)


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
  int yyresult;
  yySymbol yytoken;
  yyGLRStack yystack;
  size_t yyposn;


  YYSTYPE* const yylvalp = &yylval;
  YYLTYPE* const yyllocp = &yylloc;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yytoken = YYEMPTY;
  yylval = yyval_default;

#if YYLTYPE_IS_TRIVIAL
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 0;
#endif


  if (! yyinitGLRStack (&yystack, YYINITDEPTH))
    goto yyexhaustedlab;
  switch (YYSETJMP (yystack.yyexception_buffer))
    {
    case 0: break;
    case 1: goto yyabortlab;
    case 2: goto yyexhaustedlab;
    default: goto yybuglab;
    }
  yystack.yytokenp = &yytoken;
  yyglrShift (&yystack, 0, 0, 0, yylval, &yylloc);
  yyposn = 0;

  while (yytrue)
    {
      /* For efficiency, we have two loops, the first of which is
	 specialized to deterministic operation (single stack, no
	 potential ambiguity).  */
      /* Standard mode */
      while (yytrue)
	{
	  yyRuleNum yyrule;
	  int yyaction;
	  const short int* yyconflicts;

	  yyStateNum yystate = yystack.yytops.yystates[0]->yylrState;
          YYDPRINTF ((stderr, "Entering state %d\n", yystate));
	  if (yystate == YYFINAL)
	    goto yyacceptlab;
	  if (yyisDefaultedState (yystate))
	    {
	      yyrule = yydefaultAction (yystate);
	      if (yyrule == 0)
		{
		  yystack.yyerror_range[1].yystate.yyloc = *yyllocp;
		  yyreportSyntaxError (&yystack, yylvalp, yyllocp);
		  goto yyuser_error;
		}
	      YYCHK1 (yyglrReduce (&yystack, 0, yyrule, yytrue));
	    }
	  else
	    {
	      if (yytoken == YYEMPTY)
		{
		  YYDPRINTF ((stderr, "Reading a token: "));
		  yychar = YYLEX;
		  yytoken = YYTRANSLATE (yychar);
                  YY_SYMBOL_PRINT ("Next token is", yytoken, yylvalp, yyllocp);
		}
	      yygetLRActions (yystate, yytoken, &yyaction, &yyconflicts);
	      if (*yyconflicts != 0)
		break;
	      if (yyisShiftAction (yyaction))
		{
		  YY_SYMBOL_PRINT ("Shifting", yytoken, yylvalp, yyllocp);
		  if (yytoken != YYEOF)
		    yytoken = YYEMPTY;
		  yyposn += 1;
		  yyglrShift (&yystack, 0, yyaction, yyposn, yylval, yyllocp);
		  if (0 < yystack.yyerrState)
		    yystack.yyerrState -= 1;
		}
	      else if (yyisErrorAction (yyaction))
		{
		  yystack.yyerror_range[1].yystate.yyloc = *yyllocp;
		  yyreportSyntaxError (&yystack, yylvalp, yyllocp);
		  goto yyuser_error;
		}
	      else
		YYCHK1 (yyglrReduce (&yystack, 0, -yyaction, yytrue));
	    }
	}

      while (yytrue)
	{
	  size_t yys;
	  size_t yyn = yystack.yytops.yysize;
	  for (yys = 0; yys < yyn; yys += 1)
	    YYCHK1 (yyprocessOneStack (&yystack, yys, yyposn,
				       yylvalp, yyllocp));
	  yytoken = YYEMPTY;
	  yyposn += 1;
	  yyremoveDeletes (&yystack);
	  if (yystack.yytops.yysize == 0)
	    {
	      yyundeleteLastStack (&yystack);
	      if (yystack.yytops.yysize == 0)
		yyFail (&yystack, YY_("syntax error"));
	      YYCHK1 (yyresolveStack (&yystack));
	      YYDPRINTF ((stderr, "Returning to deterministic operation.\n"));
	      yystack.yyerror_range[1].yystate.yyloc = *yyllocp;
	      yyreportSyntaxError (&yystack, yylvalp, yyllocp);
	      goto yyuser_error;
	    }
	  else if (yystack.yytops.yysize == 1)
	    {
	      YYCHK1 (yyresolveStack (&yystack));
	      YYDPRINTF ((stderr, "Returning to deterministic operation.\n"));
	      yycompressStack (&yystack);
	      break;
	    }
	}
      continue;
    yyuser_error:
      yyrecoverSyntaxError (&yystack, yylvalp, yyllocp);
      yyposn = yystack.yytops.yystates[0]->yyposn;
    }

 yyacceptlab:
  yyresult = 0;
  goto yyreturn;

 yybuglab:
  YYASSERT (yyfalse);
  /* Fall through.  */

 yyabortlab:
  yyresult = 1;
  goto yyreturn;

 yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */

 yyreturn:
  if (yytoken != YYEOF && yytoken != YYEMPTY)
    yydestruct ("Cleanup: discarding lookahead",
                yytoken, yylvalp, yyllocp);

  /* If the stack is well-formed, pop the stack until it is empty,
     destroying its entries as we go.  But free the stack regardless
     of whether it is well-formed.  */
  if (yystack.yyitems)
    {
      yyGLRState** yystates = yystack.yytops.yystates;
      if (yystates)
	while (yystates[0])
	  {
	    yyGLRState *yys = yystates[0];
	  yystack.yyerror_range[1].yystate.yyloc = yys->yyloc;
	    yydestroyGLRState ("Cleanup: popping", yys);
	    yystates[0] = yys->yypred;
	    yystack.yynextFree -= 1;
	    yystack.yyspaceLeft += 1;
	  }
      yyfreeGLRStack (&yystack);
    }

  return yyresult;
}

/* DEBUGGING ONLY */
#ifdef YYDEBUG
static void yypstack (yyGLRStack* yystack, size_t yyk)
  __attribute__ ((__unused__));
static void yypdumpstack (yyGLRStack* yystack) __attribute__ ((__unused__));

static void
yy_yypstack (yyGLRState* yys)
{
  if (yys->yypred)
    {
      yy_yypstack (yys->yypred);
      fprintf (stderr, " -> ");
    }
  fprintf (stderr, "%d@%lu", yys->yylrState, (unsigned long int) yys->yyposn);
}

static void
yypstates (yyGLRState* yyst)
{
  if (yyst == NULL)
    fprintf (stderr, "<null>");
  else
    yy_yypstack (yyst);
  fprintf (stderr, "\n");
}

static void
yypstack (yyGLRStack* yystack, size_t yyk)
{
  yypstates (yystack->yytops.yystates[yyk]);
}

#define YYINDEX(YYX)							     \
    ((YYX) == NULL ? -1 : (yyGLRStackItem*) (YYX) - yystack->yyitems)


static void
yypdumpstack (yyGLRStack* yystack)
{
  yyGLRStackItem* yyp;
  size_t yyi;
  for (yyp = yystack->yyitems; yyp < yystack->yynextFree; yyp += 1)
    {
      fprintf (stderr, "%3lu. ", (unsigned long int) (yyp - yystack->yyitems));
      if (*(yybool *) yyp)
	{
	  fprintf (stderr, "Res: %d, LR State: %d, posn: %lu, pred: %ld",
		   yyp->yystate.yyresolved, yyp->yystate.yylrState,
		   (unsigned long int) yyp->yystate.yyposn,
		   (long int) YYINDEX (yyp->yystate.yypred));
	  if (! yyp->yystate.yyresolved)
	    fprintf (stderr, ", firstVal: %ld",
		     (long int) YYINDEX (yyp->yystate.yysemantics.yyfirstVal));
	}
      else
	{
	  fprintf (stderr, "Option. rule: %d, state: %ld, next: %ld",
		   yyp->yyoption.yyrule,
		   (long int) YYINDEX (yyp->yyoption.yystate),
		   (long int) YYINDEX (yyp->yyoption.yynext));
	}
      fprintf (stderr, "\n");
    }
  fprintf (stderr, "Tops:");
  for (yyi = 0; yyi < yystack->yytops.yysize; yyi += 1)
    fprintf (stderr, "%lu: %ld; ", (unsigned long int) yyi,
	     (long int) YYINDEX (yystack->yytops.yystates[yyi]));
  fprintf (stderr, "\n");
}
#endif


#line 1891 "c:\\laufwerkD\\doxygen59\\src\\\\..\\src\\verilogparser.y"

//------ ------------------------------------------------------------------------------------------------

 Entry* getCurrVerilogEntry(){return current;}
 Entry* getCurrVerilog(){return currentVerilog; }
 QCString getCurrVerilogParsingClass(){return currVerilogClass; }

 void initVerilogParser(Entry* ee,bool pc){
  currVerilogInst.resize(0);
  currVerilogClass.resize(0);
  prevDocEntryVerilog.reset();
  currentVerilog=0;
  currentFunctionVerilog=0;
  parseCode=pc;
if(pc) return;
  current_rootVerilog=ee;
  lastModule=0;
  current=new Entry;
  VerilogDocGen::initEntry(current);
  current_rootVerilog->name=QCString("XXX"); // dummy name for root
}

 Entry* VerilogDocGen::makeNewEntry(char* name,int sec,int spec,int line,bool add){
 
  bool bb=false; 
  Entry *e=current;
 
 //QCString kkk(name);
 //if(!kkk.isEmpty())fprintf(stderr,"\n name: %s 0x%p",kkk.data(),current);

if(parseCode) // should not happen!
 assert(0);

if(add){ // features like 'include xxx or 'define xxx must not be inserted here
 if(lastModule)
    addSubEntry(lastModule,e); 
  else
    addSubEntry(current_rootVerilog,e); 
}
   if(line){
  	  e->bodyLine=line;
      e->startLine=line;
  }else
   {
     e->bodyLine=getVerilogPrevLine();
     e->startLine=getVerilogPrevLine();
   }
   
  e->section=sec;
  e->spec=spec;
  e->name=name;

  current=new Entry;
  VerilogDocGen::initEntry(current);
  
  return e;
 }

void addSubEntry(Entry* root, Entry* e) {
 if(e==NULL || root==NULL) return;
  root->addSubEntry(e);
 } 




//-------------------------------------------------------------------------

// extracts module/primitive name

void parseModule(){
 
 QCString mod(getVerilogString());
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,' ');
 VhdlDocGen::deleteAllChars(mod,';');
 VhdlDocGen::deleteAllChars(mod,'(');
 
 QRegExp reg("[^_a-zA-Z0-9$]");

 int ll=mod.find(reg);

 if(ll>-1){
  char c=mod.at(ll);
  QCString val=mod.remove(ll,1);

 }

//if(mod.len>80)

 if(parseCode) {
 //generateVerilogClassOrGlobalLink(mod.data());
 currVerilogClass=mod;
 return;
 }
  currentVerilog->name=mod;
 }//parseModuleName


// extracts module instances [ module_name name,module_name #(...) name]

void parseModuleInst(QCString& first, QCString& sec) {
 
if(currVerilogType==VerilogDocGen::DEFPARAM) return;

 VhdlDocGen::deleteAllChars(sec,'(');
 VhdlDocGen::deleteAllChars(sec,'\n');
 VhdlDocGen::deleteAllChars(sec,')');
 VhdlDocGen::deleteAllChars(sec,' ');
 VhdlDocGen::deleteAllChars(sec,',');
 VhdlDocGen::deleteAllChars(sec,';');
 QCString temp=sec;
//while(sec.stripPrefix(" "));

if(sec!=first && (sec.contains("#")==0))
{ 
 //QStringList ql=QStringList::split(first.data(),sec,false);
int oo=sec.findRev(first.data());
if(oo>0) 
 sec=sec.left(oo);
}
else
 sec=getLastLetter();

if(temp.contains("#"))
{ 
 int ii=temp.find("#");
 sec=temp.left(ii);
while(sec.stripPrefix(" "));
}

 if(parseCode){
     VhdlDocGen::deleteAllChars(sec,'\t');
   currVerilogInst=sec;
   return;
  }
 else {
  Entry* pTemp=VerilogDocGen::makeNewEntry(first.data(),Entry::VARIABLE_SEC,VerilogDocGen::COMPONENT,c_lloc.first_line);
  pTemp->type=sec;
 
 if(sec==first)return;
if(currentVerilog)
 if(!findExtendsComponent(currentVerilog->extends,sec)){	
  	BaseInfo *bb=new BaseInfo(sec,Private,Normal);
    currentVerilog->extends->append(bb);						
   }
  }
}


void parseListOfPorts() {
 
  QCString type;

 QCString mod(getVerilogString());
 
 VhdlDocGen::deleteAllChars(mod,' ');
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,';');
 VhdlDocGen::deleteAllChars(mod,')');
 VhdlDocGen::deleteAllChars(mod,'(');
  QStringList ql=QStringList::split(",",mod,false);
  QCString name=(QCString)ql[0];
if(!parseCode) {
  for(uint j=0;j<ql.count();j++) {
  QCString name=(QCString)ql[j];
   int i=name.find('[');
  if(i > 0){
    type=mod.right(mod.length()-i);
    name=mod.left(i);
  }
  
 name.prepend(VhdlDocGen::getRecordNumber().data());
 Entry* pTemp=VerilogDocGen::makeNewEntry(name.data(),Entry::VARIABLE_SEC,VerilogDocGen::PORT,c_lloc.first_line);
  pTemp->type=type; 
   }
  return;
 }	

 }//parseListOfPorts



void parseReg(Entry* e){

// "reg"|"integer\real\event"|wire"|"tri"|"tri1"|"supply0"|"wand"|"triand"|"tri0"|"supply1"|"wor"|"trior"|"trireg"

static QCString prevType;
static QCString sigType;
static QRegExp qregg("[ \\[]");
QCString regType;
QCString qcs;

int p,l;
     

 if((CurrState==VerilogDocGen::STATE_FUNCTION || CurrState==VerilogDocGen::STATE_TASK )) return;

QCString mod(getVerilogString());

int port_type=0;

VhdlDocGen::deleteAllChars(mod,'(');
VhdlDocGen::deleteAllChars(mod,')');
VhdlDocGen::deleteAllChars(mod,';');
VhdlDocGen::deleteAllChars(mod,'\n');
VhdlDocGen::deleteAllChars(mod,',');

if(mod.contains("="))
{
 int i=mod.find("=");
 //qcs=mod.right(mod.length()-i-1);
 VhdlDocGen::deleteAllChars(qcs,' ');
 mod=mod.left(i);
}
  
 mod=mod.simplifyWhiteSpace(); 
  
//while(mod.stripPrefix(" "));
  p=qregg.match(mod,0,&l);

 if(p>0){
  sigType=mod.left(p);
  prevType.resize(0);
  mod.stripPrefix(sigType.data());
  while(mod.stripPrefix(" "));
  if(!mod.stripPrefix("signed ")){
  if(mod.stripPrefix("signed["))
    {mod.prepend("[");sigType.append(" signed ");}
  if(mod.stripPrefix("scalared "))
   sigType.append(" scalared ");
  if(mod.stripPrefix("vectored "))
    sigType.append(" vectored ");
 }
// else
  
}

 
 while(mod.stripPrefix(" "));
 

VhdlDocGen::deleteAllChars(mod,' ');

  int i=mod.find(']');
  int h=mod.find('[');

  if(h==0){
  	prevType+=mod.left(i+1);
  	mod=mod.right(mod.length()-i-1);
  h=mod.find('[');
  }

  if(h > 0){
   if(port_type!=2){ 
	regType=mod.right(mod.length()-h);
    mod=mod.left(h);
   }
   else {
    int ii=mod.find('[');
	if(ii>0){
  	prevType=mod.mid(ii,mod.length());
   	mod=mod.left(ii);
   }
  }
 }

  QStringList ql=QStringList::split(",",mod,false);
 uint len=ql.count() ;
 for(uint j=0;j<len;j++) {
  QCString name=(QCString)ql[j];
  name.prepend(VhdlDocGen::getRecordNumber().data());
 
  Entry* pTemp=VerilogDocGen::makeNewEntry(name.data(),Entry::VARIABLE_SEC,getVerilogPrevLine());
 // pTemp->type=prevType;
 
  if((prevType.isEmpty() && len==1) || (!regType.isEmpty() && len==1))
     pTemp->type=regType;
 else
  pTemp->args=regType;
    
  pTemp->args+=sigType+prevType; 
 // if(!prevType.isEmpty() && !regType.isEmpty())
 // pTemp->args+=prevType; 

 pTemp->args+=qcs;
  pTemp->spec=VerilogDocGen::SIGNAL;//currVerilogType;
  
  regType=prevType;
  if(getVerilogToken()==SEM_TOK)
   { prevType="";sigType="";}
  
  }
} // parsReg


// extracts function/task prototype 

void parseFunction(Entry* curF)
{
  QCString mod(getVerilogString());
  QCString type; 
 
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,';');
  while(mod.stripPrefix(" "));
 
  int i=mod.findRev(']');
  if(i > 0){
    type=mod.left(i+1);
   	mod=mod.right(mod.length()-i-1);
  }
  else {
  QStringList ql=QStringList::split(" ",mod,false);
  if(ql.count()>1) {
    type=(QCString)ql[0];
	mod=(QCString)ql[1];
  }
  }
 
 VhdlDocGen::deleteAllChars(mod,' ');
 VhdlDocGen::deleteAllChars(type,' ');

  curF->name+=mod;
  if(type.stripPrefix("automatic"))
   curF->type+="automatic "+type; 
   else
  curF->type+=type;
}
							   

// extract (local)parameter declaration 

void parseParam(Entry* e)
{
   QCString prevType,qcs;
  QRegExp regg("[ \t]");

  if((CurrState==VerilogDocGen::STATE_FUNCTION || CurrState==VerilogDocGen::STATE_TASK )) return;
  
  QCString mod(getVerilogString());
  VhdlDocGen::deleteAllChars(mod,';');
  VhdlDocGen::deleteAllChars(mod,'\n');
  VhdlDocGen::deleteAllChars(mod,',');

if(mod.contains("="))
{
 int i=mod.find("=");
 qcs=mod.right(mod.length()-i-1);
 while(qcs.stripPrefix(" "));
 mod=mod.left(i);
}

 while(mod.stripPrefix(" "));

 int j=mod.find(regg,0);
			 if(j>0){
			 bool bb=false;
			 QCString sem=mod.mid(0,j);
			 if(sem=="integer"){ prevType=sem;bb=true;}
			 else if(sem=="real"){prevType=sem;bb=true;}
			 else if(sem=="realtime"){prevType=sem;bb=true;}
			 else if(sem=="time"){prevType=sem;bb=true;}
			 else if(sem=="signed"){prevType=sem;bb=true;}
			 else if(sem=="wire"){prevType=sem;bb=true;}
			 if(bb)
			 mod.stripPrefix(sem.data());
			 }

 
 while(mod.stripPrefix(" "));
  
  int i=mod.find(']');
  if(i > 0){
    prevType+=" ";
	prevType+=mod.left(i+1);
   	mod=mod.right(mod.length()-i-1);
  }
 

  VhdlDocGen::deleteAllChars(mod,' ');


// each local member must get its unique number, because in Verilog
// two local variables can have the same identifier.
// ( input Q, reg Q)
  mod.prepend(VhdlDocGen::getRecordNumber().data());
 
  Entry* pTemp=VerilogDocGen::makeNewEntry(mod.data(),Entry::VARIABLE_SEC,VerilogDocGen::PARAMETER,getVerilogPrevLine());
  //pTemp->fileName+=getVerilogParsingFile();
  pTemp->type=prevType;
  pTemp->args=qcs;
  
  
}

// extract  input/output ports

void parsePortDir(Entry* e,int port)
{

static QCString prevType;
static QCString type; 

QCString mod(getVerilogString());
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,')');
 VhdlDocGen::deleteAllChars(mod,'(');
 VhdlDocGen::deleteAllChars(mod,';');
 VhdlDocGen::deleteAllChars(mod,',');

 while(mod.stripPrefix(" "));


if(mod.stripPrefix("input"))
 prevType="";
else if(mod.stripPrefix("output"))
  prevType=""; 
else if(mod.stripPrefix("inout"))
  prevType="";
else {
             QRegExp regg("[ \\[]");
  			 int j=mod.find(regg,0);
			 if(j>0){
			 type=mod.mid(0,j);
			 mod.stripPrefix(type.data());
			 }
	 } 


while(mod.stripPrefix(" "));
 
QRegExp regg("[ \t]");
 int j=mod.find(regg,0);
			 if(j>0){
			 bool bb=false;
			 QCString sem=mod.mid(0,j);
			 if(sem=="integer"){ prevType=sem;bb=true;}
			 else if(sem=="real"){prevType=sem;bb=true;}
			 else if(sem=="realtime"){prevType=sem;bb=true;}
			 else if(sem=="time"){prevType=sem;bb=true;}
			 else if(sem=="signed"){prevType=sem;bb=true;}
			 else if(sem=="wire"){prevType=sem;bb=true;}
			 if(bb)
			 mod.stripPrefix(sem.data());
			 }

while(mod.stripPrefix(" "));
  
  int i=mod.findRev(']');
  if(i > 0){
    prevType+=" ";
	prevType+=mod.left(i+1);
   	mod=mod.right(mod.length()-i-1);
  }
  else{ 
  int j=mod.find(regg,0);
   if(j>0){
    QCString sem=mod.mid(0,j);
	if(sem=="reg"){		
     mod=mod.right(mod.length()-j-1);
     prevType+=" reg";
     }
    }
   }
  
  VhdlDocGen::deleteAllChars(mod,' ');
  mod.prepend(VhdlDocGen::getRecordNumber().data());
  if(CurrState==VerilogDocGen::STATE_MODULE){  
  Entry* pTemp=VerilogDocGen::makeNewEntry(mod.data(),Entry::VARIABLE_SEC,0,c_lloc.first_line);
  pTemp->type=prevType;
  pTemp->args=type;
   assert(currVerilogType!=0);
  pTemp->spec=currVerilogType;
//   VerilogDocGen::addSubEntry(currentVerilog,pTemp);
  }
  else
  { 
   if(CurrState==VerilogDocGen::STATE_FUNCTION){
      Argument *arg=new Argument;
      
      switch(currVerilogType) {
      
      case VerilogDocGen::INPUT: arg->type="Input";break;
      case VerilogDocGen::INOUT:arg->type="Inout";break;         
      case VerilogDocGen::OUTPUT:arg->type="Output";break;         
      default:break;
      }                           
        arg->defval=prevType;                         
        arg->name=mod;//(QCString)ql[j];	
	  currentFunctionVerilog->argList->append(arg);
	  VerilogDocGen::adjustMemberName(mod); 
	  currentFunctionVerilog->args+=mod;//(QCString)ql[j]+",";
  } 
 }
 

  if(getVerilogToken()==SEM_TOK)//end of line
  {prevType="";type="";}
}

void parseAlways(bool bBody)
{

if(currVerilogType!=VerilogDocGen::ALWAYS) return ;

QRegExp regg1("[ \t]or[ \t]");

QCString mod(getVerilogString());
QCString type; 
QStringList ql;
bool sem=false;

 VhdlDocGen::deleteAllChars(mod,'@');
 VhdlDocGen::deleteAllChars(mod,'\n');
 VhdlDocGen::deleteAllChars(mod,'(');
 VhdlDocGen::deleteAllChars(mod,')');
 VhdlDocGen::deleteAllChars(mod,';'); 

if(mod.contains(","))
  ql=QStringList::split(",",mod,false);
 else
  ql=QStringList::split(regg1,mod,false);
 

 if(!parseCode) {
 currentFunctionVerilog=VerilogDocGen::makeNewEntry(VhdlDocGen::getProcessNumber().data(),Entry::FUNCTION_SEC,VerilogDocGen::ALWAYS);
  currentFunctionVerilog->stat=TRUE;
  currentFunctionVerilog->fileName=getVerilogParsingFile();
  if(!bBody)
  for(uint j=0;j<ql.count();j++) {
  QCString ll=(QCString)ql[j];
  if(ll=="or" || ll=="and") continue; 
  if(sem)
	  currentFunctionVerilog->args+=',';
	  Argument *arg=new Argument;
      arg->name=ll;	
	  currentFunctionVerilog->argList->append(arg);
      currentFunctionVerilog->args+=ll; 
      sem = true;
 }
 return;
}


}//parseAlways



 // sets the current parsing module (only for parsing inline_sources)             
 void VerilogDocGen::setCurrVerilogClass(QCString& cl){ currVerilogClass = cl;}
   
 //-------------------------------------------------------------------------------------------  
           
 int MyParserConv::parse(MyParserConv* conv){
  myconv=conv;
  assert(myconv);
  return c_parse();
 } 
        
int c_lex(void){
 return myconv->doLex(); 
}


void c_error(const char * err){
   if(err && !parseCode){
   fprintf(stderr,"\n\nerror occurred at line [%d]... : in file [%s]\n\n",c_lloc.first_line,getVerilogParsingFile());
  vbufreset();
  exit(0);
  }
   } 
    
int getVerilogToken(){return c_char;}
 //------------------------------------------------------------------------------------------------  

// writes a digit to the source

void writeDigit()
 {
   if(parseCode) {
     writePrevVerilogWords(identVerilog);
	 writeVerilogFont("vhdllogic",identVerilog.data());
	 identVerilog.resize(0);
	 printVerilogBuffer(true);
	 }
 }// writeDigit

// prints and links the parsed identifiers  

void parseString(){				
					if(parseCode ) { 
					 //   printVerilogStringList();
						 identVerilog=identVerilog.stripWhiteSpace();
				   	  writePrevVerilogWords(identVerilog);
						 bool b=false;
					 
					 if(currVerilogType==VerilogDocGen::DEFPARAM){
				       QCString s(getVerilogString());
                       if(s.contains(".")==0)
                           b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::COMPONENT);
				       else if(s.contains("="))
                           b=generateVerilogMemLink(currVerilogClass,identVerilog,-1);
                       else
				         b=generateVerilogMemLink(currVerilogInst,identVerilog,-1);	       
				     }
					 else if(currVerilogType==VerilogDocGen::COMPONENT){
					    QCString tt(getVerilogString());
					    if(tt.contains('('))
					     b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::PORT);
				        else if(!b)   
				         b=generateVerilogMemLink(currVerilogInst,identVerilog,VerilogDocGen::PORT);
				        if(!b)   
				         b=generateVerilogMemLink(currVerilogClass,identVerilog,-1);    
					   }
				    /*
				      else if(currVerilogType==VerilogDocGen::NETTYPE){
                       QCString tt(getVerilogString());
                      if(tt.contains("["))
                         b=generateVerilogMemLink(currVerilogClass,identVerilog,-1);
                       else{
                      	 codifyVerilogString(identVerilog.data(),"vhdlcharacter");
				         b=true;
				          }
                      	 }
				      */
				      else if(currVerilogType==VerilogDocGen::PORT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::PORT);
				     else if(currVerilogType==VerilogDocGen::PARAMETER)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::PARAMETER);
				     else if(currVerilogType==VerilogDocGen::SIGNAL)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::SIGNAL);
				     else if(currVerilogType==VerilogDocGen::INPUT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::INPUT);				       
         		     else if(currVerilogType==VerilogDocGen::OUTPUT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::OUTPUT);
				     else if(currVerilogType==VerilogDocGen::INOUT)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::INOUT);
				   
				     else if(currVerilogType==VerilogDocGen::ALWAYS)
                        b=generateVerilogMemLink(currVerilogClass,identVerilog,VerilogDocGen::ALWAYS);
						
				     if(!b){
					   b =  generateVerilogMemLink(currVerilogClass,identVerilog,-1); 
					   if(!b && getClass(identVerilog.data()))
                       b=generateVerilogClassOrGlobalLink(identVerilog.data());
					  if(!b){
					   int  col=VerilogDocGen::findKeyWord(identVerilog.data());
					   if(col==1)
					    codifyVerilogString(identVerilog.data(),"vhdldigit");
					   else if(col==2)
					     codifyVerilogString(identVerilog.data(),"comment"); 
					    else
					   codifyVerilogString(identVerilog.data(),"vhdlchar");
					   }   
					 }
					   printVerilogBuffer(true);
					  }
				   identVerilog.resize(0);
				 
}// parseString

// inits the parser

 //---------------------------------------------------------------------------------------------------  



// do not include the same class twice 

bool findExtendsComponent(QList<BaseInfo> *extend,QCString& compName)
{
 for(uint j=0;j<extend->count();j++){
  BaseInfo *bb=extend->at(j);
  if(bb->name==compName)
   return true;
 }
 return false;
}// findExtendsComponent


/*
attribute_instance11 : LBRACE_TOK MULT_TOK attr_spec_list  MULT_TOK  RBRACE_TOK
                   |  LBRACE_TOK MULT_TOK error MULT_TOK  RBRACE_TOK
                   ;

attribute_instance :  
                   |  LBRACE_TOK MULT_TOK attr_spec_list MULT_TOK  RBRACE_TOK
                   |  LBRACE_TOK MULT_TOK error MULT_TOK  RBRACE_TOK
                   ;
*/
